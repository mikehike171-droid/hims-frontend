import React from "react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { useLanguage } from "@/i18n/LanguageContext";
import TreatmentExplorer from "./TreatmentExplorer";

const TreatmentsSection = () => {
  const { t } = useLanguage();
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section className="py-8 relative overflow-hidden bg-slate-50/50" id="treatments" ref={ref}>
      {/* Background Decorations */}
      <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-blue-50/50 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 -z-10" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-emerald-50/50 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 -z-10" />

      <div className="container mx-auto px-4">
        <div className={`text-center max-w-3xl mx-auto mb-6 transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>
          <span className="inline-block px-4 py-1 rounded-full bg-blue-50 text-blue-600 text-sm font-bold tracking-wider mb-4">
            {t('Treatments - 110+ Diseases Treated')}
          </span>
          <h2 className="text-3xl md:text-5xl font-extrabold text-[#1a2e5a] font-heading mb-6 leading-tight">
            {t('Our Treatments')}
          </h2>
          <p className="text-gray-500 text-lg md:text-xl leading-relaxed">
            {t('Access our successful treatments that have put over 44 lakh happy patients on the road to recovery.')}
          </p>
        </div>

        <TreatmentExplorer />

        <div className={`text-center mt-8 transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`} style={{ transitionDelay: "400ms" }}>
          <a
            href="#appointment"
            className="inline-flex items-center gap-2 bg-[#22c55e] text-white px-10 py-4 rounded-2xl font-bold text-lg shadow-lg hover:shadow-emerald-200 hover:scale-105 transition-all duration-300"
          >
            {t('View All Treatments')}
          </a>
        </div>
      </div>
    </section>
  );
};

export default TreatmentsSection;

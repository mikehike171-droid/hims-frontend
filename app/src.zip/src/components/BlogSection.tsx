import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { useLanguage } from "@/i18n/LanguageContext";

const BlogSection = () => {
  const { t } = useLanguage();
  const { ref, isVisible } = useScrollAnimation();

  const blogs = [
    {
      title: "Homeopathy Treatment for Tuberculosis: A Comprehensive Supportive Approach",
      excerpt: "Tuberculosis (TB) is a serious but treatable infectious disease that continues to affect millions worldwide...",
      img: "https://drcarehomeopathy.com/wp-content/uploads/2026/03/Homeopathy-Treatment-for-Tuberculosis-A-Comprehensive-Supportive-Approach.webp",
    },
    {
      title: "Homeopathy for Kidney Stones: A Natural Path to Relief and Prevention",
      excerpt: "Dealing with the sharp, stabbing pain of a kidney stone can be an overwhelming experience...",
      img: "https://drcarehomeopathy.com/wp-content/uploads/2026/01/Kindey-Stones.jpeg",
    },
    {
      title: "Brain Tumors: Causes, Symptoms and Homeopathy Treatment",
      excerpt: "Understanding brain tumors and how holistic homeopathy treatment can support recovery and well-being...",
      img: "https://drcarehomeopathy.com/wp-content/uploads/2026/03/Artboard-18-3.png",
    },
  ];

  return (
    <section className="py-6" id="blogs" ref={ref}>
      <div className="container mx-auto px-4">
        <div className={`transition-all duration-700 ${isVisible ? "animate-fade-in-up opacity-100" : "opacity-0"}`}>
          <h2 className="section-heading">{t('Our Blogs')}</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-10">
          {blogs.map((b, i) => (
            <div
              key={b.title}
              className={`treatment-card group hover:-translate-y-2 transition-all duration-500 ${isVisible ? "animate-fade-in-up opacity-100" : "opacity-0"}`}
              style={{ animationDelay: `${i * 150}ms` }}
            >
              <div className="overflow-hidden">
                <img
                  src={b.img}
                  alt={b.title}
                  loading="lazy"
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <h3 className="text-base font-bold text-foreground font-heading line-clamp-2 group-hover:text-primary transition-colors duration-300">{b.title}</h3>
                <p className="text-muted-foreground text-sm mt-2 line-clamp-2">{b.excerpt}</p>
                <a href="#" className="text-primary font-semibold text-sm mt-4 inline-block hover:underline group-hover:translate-x-1 transition-transform duration-300">
                  {t('Read More')} →
                </a>
              </div>
            </div>
          ))}
        </div>
        <div className={`text-center mt-10 ${isVisible ? "animate-fade-in-up opacity-100" : "opacity-0"}`} style={{ animationDelay: "450ms" }}>
          <a href="#" className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:scale-105 hover:shadow-lg transition-all duration-300 inline-block">
            {t('View All Blogs')}
          </a>
        </div>
      </div>
    </section>
  );
};

export default BlogSection;

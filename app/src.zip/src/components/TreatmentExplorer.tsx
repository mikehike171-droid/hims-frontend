import React, { useState, useEffect, useRef } from "react";
import { treatmentsData } from "@/data/treatmentsData";
import { useLanguage } from "@/i18n/LanguageContext";
import { ChevronRight, ArrowRight, Activity, Droplets, Wind, Zap, Heart } from "lucide-react";
import { Link } from "react-router-dom";

const AUTO_PLAY_INTERVAL = 6000;

const TreatmentExplorer = () => {
  const { t } = useLanguage();
  const [activeId, setActiveId] = useState("low-back-pain");
  const [isPaused, setIsPaused] = useState(false);
  const activeTreatment = treatmentsData[activeId];
  const treatmentIds = Object.keys(treatmentsData);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const icons: Record<string, React.ReactNode> = {
    "low-back-pain": <Activity className="w-6 h-6" />,
    "kidney-stones": <Droplets className="w-6 h-6" />,
    "spondylitis": <Activity className="w-6 h-6" />,
    "sinusitis": <Wind className="w-6 h-6" />,
    "thyroid": <Zap className="w-6 h-6" />,
    "pcos": <Heart className="w-6 h-6" />,
  };

  useEffect(() => {
    if (!isPaused) {
      timerRef.current = setInterval(() => {
        setActiveId((prevId) => {
          const currentIndex = treatmentIds.indexOf(prevId);
          const nextIndex = (currentIndex + 1) % treatmentIds.length;
          return treatmentIds[nextIndex];
        });
      }, AUTO_PLAY_INTERVAL);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPaused, treatmentIds]);

  const handleManualSelection = (id: string) => {
    setActiveId(id);
    setIsPaused(true);
    setTimeout(() => setIsPaused(false), 12000); 
  };

  return (
    <div 
      className="bg-white rounded-[3.5rem] shadow-2xl overflow-hidden border border-slate-100 mb-20 animate-fade-in group/explorer"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="flex flex-col lg:flex-row min-h-[500px]">
        {/* Column 1: Selection Sidebar (LEFT - 20%) */}
        <div className="lg:w-[20%] bg-slate-50/80 p-8 border-r border-slate-100 flex flex-col backdrop-blur-sm">
          <div className="mb-6">
            <h3 className="text-lg font-black text-[#1a2e5a] flex items-center gap-2 uppercase tracking-tight">
              <span className="w-1 h-6 bg-emerald-500 rounded-full" />
              {t('Explore')}
            </h3>
            <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest font-bold">
              {t('Select Treatment')}
            </p>
          </div>

          <div className="flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-4 lg:pb-0 no-scrollbar">
            {Object.values(treatmentsData).map((treatment) => (
              <button
                key={treatment.id}
                onClick={() => handleManualSelection(treatment.id)}
                className={`flex items-center gap-4 p-4 rounded-2xl transition-all duration-500 min-w-[190px] lg:min-w-0 text-left relative overflow-hidden ${
                  activeId === treatment.id
                    ? "bg-white shadow-lg text-emerald-600 scale-105"
                    : "text-slate-500 hover:bg-white/50 hover:text-[#1a2e5a]"
                }`}
              >
                {activeId === treatment.id && (
                  <div className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-emerald-500 rounded-r-full" />
                )}
                
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-500 flex-shrink-0 ${
                  activeId === treatment.id ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-400"
                }`}>
                  {icons[treatment.id] || <Activity size={18} />}
                </div>
                
                <div className="flex-grow">
                  <p className="font-bold text-[10px] lg:text-[12px] leading-tight uppercase tracking-tight">{t(treatment.title)}</p>
                  <div className={`h-1 bg-emerald-100 rounded-full mt-1.5 overflow-hidden transition-all duration-300 ${activeId === treatment.id ? "w-full" : "w-0"}`}>
                    {activeId === treatment.id && !isPaused && (
                      <div 
                        className="h-full bg-emerald-500" 
                        style={{ 
                          animation: `progress ${AUTO_PLAY_INTERVAL}ms linear infinite` 
                        }} 
                      />
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>

          <div className="mt-auto pt-4 hidden lg:block opacity-20 text-center">
             <p className="text-[8px] text-slate-400 uppercase tracking-[0.4em] font-black">
              {t('Expert Care')}
            </p>
          </div>
        </div>

        {/* Column 2: Aligned Image Center (MIDDLE - 38%) */}
        <div className="lg:w-[38%] h-[350px] lg:h-auto overflow-hidden relative flex items-start justify-end pt-10 lg:pt-14 pr-4 lg:pr-8 bg-slate-50/5">
          <div 
            key={`${activeId}-img`} 
            className="w-full flex justify-end animate-in fade-in zoom-in-95 duration-1000 pl-4"
          >
            <div className="w-full max-w-[380px] h-[260px] lg:h-[300px] rounded-[3rem] overflow-hidden shadow-2xl relative group border-4 border-white">
              <img 
                src={activeTreatment.featuredImage} 
                alt={t(activeTreatment.title)}
                className="w-full h-full object-cover transition-transform duration-[6000ms] group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-30" />
              <div className="absolute bottom-4 left-4 flex items-center">
                 <span className="px-4 py-1.5 bg-emerald-500/90 backdrop-blur-md rounded-full text-white text-[9px] font-black uppercase tracking-widest shadow-lg">
                    {t('Verified Approach')}
                 </span>
              </div>
            </div>
          </div>
        </div>

        {/* Column 3: Balanced Data Side (RIGHT - 42%) */}
        <div className="lg:w-[42%] p-8 lg:p-12 flex flex-col justify-start pt-10 lg:pt-14 bg-white relative pl-4 lg:pl-10">
          <div 
            key={`${activeId}-text`} 
            className="animate-in fade-in slide-in-from-right-10 duration-700 space-y-5"
          >
            <div>
               <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.2em]">{t('Treatment Focus')}</span>
                  <div className="h-[1px] w-8 bg-emerald-100" />
               </div>
              <h4 className="text-xl md:text-2xl font-black text-[#1a2e5a] leading-tight font-heading uppercase group-hover/explorer:text-emerald-600 transition-colors">
                {t(activeTreatment.title)}
              </h4>
              <div className="mt-4">
                 <p className="text-slate-500 text-[13px] md:text-[14px] leading-relaxed italic border-l-2 border-emerald-50 pl-4 py-1">
                   {t(activeTreatment.longDesc)}
                 </p>
                 <div className="mt-5 flex items-center gap-2 text-[9px] font-black text-slate-300 uppercase tracking-widest">
                    <span>44 Lakh+ {t('Success Stories')}</span>
                 </div>
              </div>
            </div>
            
            <div className="flex flex-col gap-2.5 pt-2">
              <Link
                to={`/treatment/${activeTreatment.id}`}
                className="bg-[#1a2e5a] text-white px-8 py-3.5 rounded-full font-black text-[10px] text-center flex items-center justify-center gap-2.5 hover:bg-emerald-600 hover:-translate-y-0.5 transition-all shadow-lg active:scale-95 group"
              >
                {t('EXPLORE DETAILS')}
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <a
                href="#appointment"
                className="bg-slate-50 text-slate-500 px-8 py-3.5 rounded-full font-black text-[10px] text-center border border-slate-100 hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-100 transition-all active:scale-95 flex items-center justify-center gap-2.5"
              >
                <Activity size={14} />
                {t('BOOK VISIT')}
              </a>
            </div>
          </div>

          <div className="absolute top-8 right-12 text-slate-100/30 text-5xl font-black select-none pointer-events-none -z-10">
            0{treatmentIds.indexOf(activeId) + 1}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes progress {
          from { width: 0%; }
          to { width: 100%; }
        }
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
};

export default TreatmentExplorer;

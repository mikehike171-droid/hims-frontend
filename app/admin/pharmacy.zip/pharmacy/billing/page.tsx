"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Search,
  CreditCard,
  Receipt,
  Percent,
  DollarSign,
  Filter,
  Download,
  RefreshCw,
  CheckCircle,
  Clock,
  XCircle,
} from "lucide-react"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface BillingRecord {
  id: string
  receiptNumber: string
  patientName: string
  patientPhone: string
  type: "prescription" | "direct_sale"
  prescriptionId?: string
  items: BillingItem[]
  subtotal: number
  discountAmount: number
  discountReason: string
  taxAmount: number
  totalAmount: number
  paymentMethod: string
  paymentStatus: "completed" | "pending" | "failed"
  createdAt: string
  pharmacistName: string
}

interface BillingItem {
  medicineName: string
  quantity: number
  unitPrice: number
  totalPrice: number
}

interface DiscountRule {
  id: string
  name: string
  type: "percentage" | "fixed"
  value: number
  applicableTo: string
  conditions: any
  isActive: boolean
}

export default function PharmacyBilling() {
  const [billingRecords, setBillingRecords] = useState<BillingRecord[]>([])
  const [filteredRecords, setFilteredRecords] = useState<BillingRecord[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedDateRange, setSelectedDateRange] = useState("today")
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [loading, setLoading] = useState(true)
  const [showDiscountRulesDialog, setShowDiscountRulesDialog] = useState(false)

  const [discountRules] = useState<DiscountRule[]>([
    {
      id: "1",
      name: "Senior Citizen (60+)",
      type: "percentage",
      value: 10,
      applicableTo: "all",
      conditions: { ageAbove: 60 },
      isActive: true,
    },
    {
      id: "2",
      name: "Staff Discount",
      type: "percentage",
      value: 20,
      applicableTo: "all",
      conditions: { employee: true },
      isActive: true,
    },
    {
      id: "3",
      name: "TCS Employee",
      type: "percentage",
      value: 15,
      applicableTo: "consultation",
      conditions: { company: "TCS" },
      isActive: true,
    },
    {
      id: "4",
      name: "Emergency Discount",
      type: "fixed",
      value: 500,
      applicableTo: "consultation",
      conditions: { emergency: true },
      isActive: true,
    },
    {
      id: "5",
      name: "Insurance Co-pay",
      type: "percentage",
      value: 80,
      applicableTo: "all",
      conditions: { insurance: true },
      isActive: true,
    },
  ])

  // Mock billing data
  const mockBillingRecords: BillingRecord[] = [
    {
      id: "1",
      receiptNumber: "RCP1705847234567",
      patientName: "Rajesh Kumar",
      patientPhone: "+91 9876543210",
      type: "prescription",
      prescriptionId: "RX001234",
      items: [
        { medicineName: "Paracetamol 500mg", quantity: 10, unitPrice: 22.0, totalPrice: 220.0 },
        { medicineName: "Amoxicillin 250mg", quantity: 21, unitPrice: 75.0, totalPrice: 1575.0 },
      ],
      subtotal: 1795.0,
      discountAmount: 179.5,
      discountReason: "Senior Citizen (10%)",
      taxAmount: 193.86,
      totalAmount: 1809.36,
      paymentMethod: "cash",
      paymentStatus: "completed",
      createdAt: "2024-01-20T11:30:00Z",
      pharmacistName: "Dr. Pharmacist",
    },
    {
      id: "2",
      receiptNumber: "RCP1705847234568",
      patientName: "Priya Singh",
      patientPhone: "+91 9876543211",
      type: "direct_sale",
      items: [
        { medicineName: "Cetirizine 10mg", quantity: 10, unitPrice: 24.0, totalPrice: 240.0 },
        { medicineName: "Vitamin D3 60K", quantity: 4, unitPrice: 45.0, totalPrice: 180.0 },
      ],
      subtotal: 420.0,
      discountAmount: 0,
      discountReason: "",
      taxAmount: 50.4,
      totalAmount: 470.4,
      paymentMethod: "upi",
      paymentStatus: "completed",
      createdAt: "2024-01-20T10:15:00Z",
      pharmacistName: "Dr. Pharmacist",
    },
    {
      id: "3",
      receiptNumber: "RCP1705847234569",
      patientName: "Amit Verma",
      patientPhone: "+91 9876543212",
      type: "prescription",
      prescriptionId: "RX001235",
      items: [{ medicineName: "Omeprazole 20mg", quantity: 14, unitPrice: 38.0, totalPrice: 532.0 }],
      subtotal: 532.0,
      discountAmount: 106.4,
      discountReason: "Staff Discount (20%)",
      taxAmount: 51.07,
      totalAmount: 476.67,
      paymentMethod: "card",
      paymentStatus: "completed",
      createdAt: "2024-01-20T09:45:00Z",
      pharmacistName: "Dr. Pharmacist",
    },
    {
      id: "4",
      receiptNumber: "RCP1705847234570",
      patientName: "Sunita Sharma",
      patientPhone: "+91 9876543213",
      type: "direct_sale",
      items: [{ medicineName: "Cough Syrup", quantity: 2, unitPrice: 85.0, totalPrice: 170.0 }],
      subtotal: 170.0,
      discountAmount: 0,
      discountReason: "",
      taxAmount: 20.4,
      totalAmount: 190.4,
      paymentMethod: "cash",
      paymentStatus: "pending",
      createdAt: "2024-01-20T08:30:00Z",
      pharmacistName: "Dr. Pharmacist",
    },
  ]

  useEffect(() => {
    fetchBillingRecords()
  }, [])

  useEffect(() => {
    filterRecords()
  }, [billingRecords, searchTerm, selectedDateRange, selectedPaymentMethod, selectedStatus])

  const fetchBillingRecords = async () => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setBillingRecords(mockBillingRecords)
      setLoading(false)
    }, 1000)
  }

  const filterRecords = () => {
    let filtered = [...billingRecords]

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (record) =>
          record.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          record.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          record.patientPhone.includes(searchTerm) ||
          (record.prescriptionId && record.prescriptionId.toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    // Date range filter
    if (selectedDateRange !== "all") {
      const today = new Date()
      const filterDate = new Date()

      switch (selectedDateRange) {
        case "today":
          filterDate.setHours(0, 0, 0, 0)
          break
        case "yesterday":
          filterDate.setDate(today.getDate() - 1)
          filterDate.setHours(0, 0, 0, 0)
          break
        case "week":
          filterDate.setDate(today.getDate() - 7)
          break
        case "month":
          filterDate.setMonth(today.getMonth() - 1)
          break
      }

      filtered = filtered.filter((record) => new Date(record.createdAt) >= filterDate)
    }

    // Payment method filter
    if (selectedPaymentMethod !== "all") {
      filtered = filtered.filter((record) => record.paymentMethod === selectedPaymentMethod)
    }

    // Status filter
    if (selectedStatus !== "all") {
      filtered = filtered.filter((record) => record.paymentStatus === selectedStatus)
    }

    setFilteredRecords(filtered)
  }

  const getTotalStats = () => {
    const totalAmount = filteredRecords.reduce((sum, record) => sum + record.totalAmount, 0)
    const totalDiscount = filteredRecords.reduce((sum, record) => sum + record.discountAmount, 0)
    const completedCount = filteredRecords.filter((record) => record.paymentStatus === "completed").length
    const pendingCount = filteredRecords.filter((record) => record.paymentStatus === "pending").length

    return { totalAmount, totalDiscount, completedCount, pendingCount }
  }

  const exportRecords = () => {
    // Simulate export functionality
    alert("Billing records exported successfully!")
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "failed":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const stats = getTotalStats()

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-red-600"></div>
      </div>
    )
  }

  return (
    <PrivateRoute modulePath="admin/pharmacy/billing" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Pharmacy Billing & Payments</h1>
          <p className="text-gray-600">Manage billing records, payments, and discount rules</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => setShowDiscountRulesDialog(true)}>
            <Percent className="h-4 w-4 mr-2" />
            Discount Rules
          </Button>
          <Button variant="outline" onClick={exportRecords}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button onClick={fetchBillingRecords}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-green-600">₹{stats.totalAmount.toFixed(2)}</p>
                <p className="text-xs text-green-600">From {filteredRecords.length} transactions</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Discounts</p>
                <p className="text-2xl font-bold text-blue-600">₹{stats.totalDiscount.toFixed(2)}</p>
                <p className="text-xs text-blue-600">
                  {((stats.totalDiscount / (stats.totalAmount + stats.totalDiscount)) * 100).toFixed(1)}% of gross
                </p>
              </div>
              <Percent className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-purple-600">{stats.completedCount}</p>
                <p className="text-xs text-purple-600">Successful payments</p>
              </div>
              <CheckCircle className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-orange-600">{stats.pendingCount}</p>
                <p className="text-xs text-orange-600">Awaiting payment</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-end">
            <div className="flex-1 min-w-64">
              <Label>Search</Label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Receipt number, patient name, phone, or prescription ID"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Label>Date Range</Label>
              <Select value={selectedDateRange} onValueChange={setSelectedDateRange}>
                <SelectTrigger className="w-40 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="week">Last 7 Days</SelectItem>
                  <SelectItem value="month">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Payment Method</Label>
              <Select value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
                <SelectTrigger className="w-40 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Methods</SelectItem>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="insurance">Insurance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Status</Label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-40 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Apply Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Billing Records */}
      <Card>
        <CardHeader>
          <CardTitle>Billing Records ({filteredRecords.length})</CardTitle>
          <CardDescription>Complete billing history with payment details</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredRecords.map((record) => (
              <div key={record.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-4">
                    <div>
                      <h3 className="font-semibold text-lg">{record.receiptNumber}</h3>
                      <p className="text-sm text-gray-600">
                        {record.patientName} • {record.patientPhone}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(record.createdAt).toLocaleString()} • {record.pharmacistName}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="capitalize">
                        {record.type.replace("_", " ")}
                      </Badge>
                      {record.prescriptionId && (
                        <Badge variant="outline" className="text-blue-600">
                          {record.prescriptionId}
                        </Badge>
                      )}
                      <Badge className={getStatusColor(record.paymentStatus)}>
                        {getStatusIcon(record.paymentStatus)}
                        <span className="ml-1 capitalize">{record.paymentStatus}</span>
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-green-600">₹{record.totalAmount.toFixed(2)}</p>
                    <p className="text-sm text-gray-600 capitalize">{record.paymentMethod}</p>
                  </div>
                </div>

                {/* Items */}
                <div className="bg-gray-50 p-3 rounded-lg mb-3">
                  <h4 className="font-medium mb-2">Items ({record.items.length})</h4>
                  <div className="space-y-1">
                    {record.items.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span>
                          {item.medicineName} × {item.quantity}
                        </span>
                        <span>₹{item.totalPrice.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Billing Breakdown */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>₹{record.subtotal.toFixed(2)}</span>
                    </div>
                    {record.discountAmount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Discount ({record.discountReason}):</span>
                        <span>-₹{record.discountAmount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Tax (12% GST):</span>
                      <span>₹{record.taxAmount.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-semibold">
                      <span>Total:</span>
                      <span>₹{record.totalAmount.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button size="sm" variant="outline">
                      <Receipt className="h-4 w-4 mr-1" />
                      View Receipt
                    </Button>
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                    {record.paymentStatus === "pending" && (
                      <Button size="sm">
                        <CreditCard className="h-4 w-4 mr-1" />
                        Process Payment
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {filteredRecords.length === 0 && (
              <div className="text-center py-8">
                <Receipt className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">No billing records found matching your criteria</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Discount Rules Dialog */}
      <Dialog open={showDiscountRulesDialog} onOpenChange={setShowDiscountRulesDialog}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Discount Rules Management</DialogTitle>
            <DialogDescription>Configure automatic discount rules for pharmacy billing</DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="active" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="active">Active Rules</TabsTrigger>
              <TabsTrigger value="create">Create New Rule</TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="space-y-4">
              <div className="space-y-3">
                {discountRules
                  .filter((rule) => rule.isActive)
                  .map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div
                          className={`p-2 rounded-full ${rule.type === "percentage" ? "bg-blue-100" : "bg-green-100"}`}
                        >
                          {rule.type === "percentage" ? (
                            <Percent className="h-4 w-4 text-blue-600" />
                          ) : (
                            <DollarSign className="h-4 w-4 text-green-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{rule.name}</p>
                          <p className="text-sm text-gray-600">
                            {rule.type === "percentage" ? `${rule.value}%` : `₹${rule.value}`} off
                            {rule.applicableTo !== "all" && ` on ${rule.applicableTo}`}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className="bg-green-100 text-green-800">Active</Badge>
                        <Button size="sm" variant="outline">
                          Edit
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="create" className="space-y-4">
              <div className="space-y-4">
                <div>
                  <Label>Rule Name</Label>
                  <Input placeholder="Enter discount rule name" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Discount Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="percentage">Percentage (%)</SelectItem>
                        <SelectItem value="fixed">Fixed Amount (₹)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Discount Value</Label>
                    <Input type="number" placeholder="Enter value" />
                  </div>
                </div>
                <div>
                  <Label>Applicable To</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select applicability" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Items</SelectItem>
                      <SelectItem value="prescription">Prescription Only</SelectItem>
                      <SelectItem value="direct_sale">Direct Sale Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Conditions</Label>
                  <Input placeholder="e.g., Age > 60, Employee ID required" />
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDiscountRulesDialog(false)}>
              Close
            </Button>
            <Button>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      </div>
    </PrivateRoute>
  )
}

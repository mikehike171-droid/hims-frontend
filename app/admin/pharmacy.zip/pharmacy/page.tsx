"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert } from "@/components/ui/alert"
import { useBranch } from "@/contexts/branch-context"
import {
  AlertTriangle,
  TrendingUp,
  Clock,
  DollarSign,
  Bell,
  Calendar,
  Pill,
  ShoppingCart,
  Package,
  Activity,
  Zap,
  MessageSquare,
  Phone,
  CheckCircle,
  XCircle,
  RefreshCw,
  Users,
  Receipt,
} from "lucide-react"
import Link from "next/link"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface DashboardMetrics {
  totalSales: number
  todayRevenue: number
  pendingPrescriptions: number
  lowStockAlerts: number
  expiryAlerts: number
  completionReminders: number
  followUpRequired: number
  bounceRate: number
  completionRate: number
  averageOrderValue: number
  directSales: number
  prescriptionSales: number
}

interface QuickAlert {
  id: string
  type: "stock" | "expiry" | "reminder" | "follow_up" | "bounce"
  title: string
  message: string
  severity: "low" | "medium" | "high" | "critical"
  actionRequired: boolean
  createdAt: string
}

interface RecentActivity {
  id: string
  type: "sale" | "prescription" | "alert" | "reminder" | "bounce"
  description: string
  amount?: number
  timestamp: string
  status: "success" | "pending" | "failed"
}

export default function PharmacyDashboard() {
  const { currentBranch } = useBranch()
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalSales: 0,
    todayRevenue: 0,
    pendingPrescriptions: 0,
    lowStockAlerts: 0,
    expiryAlerts: 0,
    completionReminders: 0,
    followUpRequired: 0,
    bounceRate: 0,
    completionRate: 0,
    averageOrderValue: 0,
    directSales: 0,
    prescriptionSales: 0,
  })

  const [quickAlerts, setQuickAlerts] = useState<QuickAlert[]>([])
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    fetchDashboardData()

    // Listen for branch changes
    const handleBranchChange = () => {
      fetchDashboardData()
    }

    window.addEventListener("branchChanged", handleBranchChange)
    return () => window.removeEventListener("branchChanged", handleBranchChange)
  }, [currentBranch])

  const fetchDashboardData = async () => {
    setLoading(true)

    try {
      // Branch-specific pharmacy data
      const branchPharmacyData = {
        "1": {
          // Main Branch
          totalSales: 247,
          todayRevenue: 67890,
          pendingPrescriptions: 18,
          lowStockAlerts: 12,
          expiryAlerts: 8,
          completionReminders: 23,
          followUpRequired: 15,
          bounceRate: 8.5,
          completionRate: 91.5,
          averageOrderValue: 275,
          directSales: 89,
          prescriptionSales: 158,
        },
        "2": {
          // Whitefield
          totalSales: 189,
          todayRevenue: 52340,
          pendingPrescriptions: 14,
          lowStockAlerts: 8,
          expiryAlerts: 5,
          completionReminders: 18,
          followUpRequired: 11,
          bounceRate: 7.2,
          completionRate: 92.8,
          averageOrderValue: 285,
          directSales: 67,
          prescriptionSales: 122,
        },
        // Add data for other branches...
      }

      setTimeout(() => {
        const data = branchPharmacyData[currentBranch?.id || "1"] || branchPharmacyData["1"]
        setMetrics(data)
        setLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Error fetching dashboard data:", error)
      setLoading(false)
    }
  }

  const handleRefresh = () => {
    setRefreshing(true)
    fetchDashboardData()
    setTimeout(() => setRefreshing(false), 1000)
  }

  const getAlertColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "border-red-500 bg-red-50"
      case "high":
        return "border-orange-500 bg-orange-50"
      case "medium":
        return "border-yellow-500 bg-yellow-50"
      default:
        return "border-blue-500 bg-blue-50"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "stock":
        return <Package className="h-4 w-4" />
      case "expiry":
        return <Calendar className="h-4 w-4" />
      case "reminder":
        return <Bell className="h-4 w-4" />
      case "follow_up":
        return <Phone className="h-4 w-4" />
      case "bounce":
        return <XCircle className="h-4 w-4" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "sale":
        return <ShoppingCart className="h-4 w-4 text-green-600" />
      case "prescription":
        return <Pill className="h-4 w-4 text-blue-600" />
      case "alert":
        return <AlertTriangle className="h-4 w-4 text-orange-600" />
      case "reminder":
        return <MessageSquare className="h-4 w-4 text-purple-600" />
      case "bounce":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Activity className="h-4 w-4 text-gray-600" />
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Activity className="h-4 w-4 text-gray-600" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-red-600"></div>
      </div>
    )
  }

  return (
    <PrivateRoute modulePath="admin/pharmacy" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Pharmacy Dashboard</h1>
          {currentBranch && (
            <p className="text-gray-600">{currentBranch.name} • Complete pharmacy management and analytics</p>
          )}
        </div>
        <div className="flex space-x-3">
          <Button onClick={handleRefresh} variant="outline" size="sm" disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Link href="/pharmacy/dispensing">
            <Button size="sm">
              <Pill className="h-4 w-4 mr-2" />
              New Dispensing
            </Button>
          </Link>
          <Link href="/pharmacy/sales">
            <Button variant="outline" size="sm">
              <ShoppingCart className="h-4 w-4 mr-2" />
              Direct Sales
            </Button>
          </Link>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 text-sm font-medium">Total Sales</p>
                <p className="text-2xl font-bold text-blue-800">{metrics.totalSales}</p>
                <p className="text-blue-600 text-xs">+12% from yesterday</p>
              </div>
              <Receipt className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 text-sm font-medium">Revenue</p>
                <p className="text-2xl font-bold text-green-800">₹{metrics.todayRevenue.toLocaleString()}</p>
                <p className="text-green-600 text-xs">₹{metrics.averageOrderValue} avg order</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 text-sm font-medium">Prescription Sales</p>
                <p className="text-2xl font-bold text-purple-800">{metrics.prescriptionSales}</p>
                <p className="text-purple-600 text-xs">{metrics.completionRate}% completion</p>
              </div>
              <Pill className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-indigo-200 bg-gradient-to-br from-indigo-50 to-indigo-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-indigo-600 text-sm font-medium">Direct Sales</p>
                <p className="text-2xl font-bold text-indigo-800">{metrics.directSales}</p>
                <p className="text-indigo-600 text-xs">Non-prescription</p>
              </div>
              <ShoppingCart className="h-8 w-8 text-indigo-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-600 text-sm font-medium">Pending</p>
                <p className="text-2xl font-bold text-orange-800">{metrics.pendingPrescriptions}</p>
                <p className="text-orange-600 text-xs">Prescriptions</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-200 bg-gradient-to-br from-red-50 to-red-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-600 text-sm font-medium">Bounce Rate</p>
                <p className="text-2xl font-bold text-red-800">{metrics.bounceRate}%</p>
                <p className="text-red-600 text-xs">Need attention</p>
              </div>
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Link href="/pharmacy/dispensing">
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-green-200">
            <CardContent className="p-4 text-center">
              <Pill className="h-8 w-8 mx-auto mb-2 text-green-600" />
              <p className="font-medium text-green-800">Prescription Dispensing</p>
              <p className="text-sm text-green-600">Process prescriptions</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/pharmacy/sales">
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-blue-200">
            <CardContent className="p-4 text-center">
              <ShoppingCart className="h-8 w-8 mx-auto mb-2 text-blue-600" />
              <p className="font-medium text-blue-800">Direct Sales</p>
              <p className="text-sm text-blue-600">Sell to customers</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/pharmacy/billing">
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-purple-200">
            <CardContent className="p-4 text-center">
              <DollarSign className="h-8 w-8 mx-auto mb-2 text-purple-600" />
              <p className="font-medium text-purple-800">Billing & Payments</p>
              <p className="text-sm text-purple-600">Process payments</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/pharmacy/reports">
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-orange-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 mx-auto mb-2 text-orange-600" />
              <p className="font-medium text-orange-800">Reports & Analytics</p>
              <p className="text-sm text-orange-600">Business insights</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="alerts" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="alerts">Quick Alerts ({quickAlerts.length})</TabsTrigger>
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          <TabsTrigger value="reminders">Patient Reminders ({metrics.completionReminders})</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="followup">Follow-up Tasks ({metrics.followUpRequired})</TabsTrigger>
        </TabsList>

        {/* Quick Alerts Tab */}
        <TabsContent value="alerts" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {quickAlerts.map((alert) => (
              <Alert key={alert.id} className={getAlertColor(alert.severity)}>
                <div className="flex items-start space-x-3">
                  {getAlertIcon(alert.type)}
                  <div className="flex-1">
                    <h4 className="font-semibold">{alert.title}</h4>
                    <p className="text-sm mt-1">{alert.message}</p>
                    <div className="flex items-center justify-between mt-3">
                      <Badge variant="outline" className="text-xs">
                        {alert.severity.toUpperCase()}
                      </Badge>
                      {alert.actionRequired && (
                        <Button size="sm" variant="outline">
                          Take Action
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </Alert>
            ))}
          </div>
        </TabsContent>

        {/* Recent Activity Tab */}
        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest transactions and system events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      {getActivityIcon(activity.type)}
                      <div>
                        <p className="font-medium">{activity.description}</p>
                        <p className="text-sm text-gray-500">{new Date(activity.timestamp).toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {activity.amount && <span className="font-medium text-green-600">₹{activity.amount}</span>}
                      {getStatusIcon(activity.status)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Patient Reminders Tab */}
        <TabsContent value="reminders" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bell className="h-5 w-5 mr-2 text-blue-600" />
                  Medication Completion Reminders
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium">Due Today</p>
                      <p className="text-sm text-gray-600">Patients completing medication</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-blue-600">{metrics.completionReminders}</p>
                      <Button size="sm" className="mt-1">
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Send WhatsApp
                      </Button>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium">Stock Available Alerts</p>
                      <p className="text-sm text-gray-600">Previously unavailable medicines</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-600">7</p>
                      <Button size="sm" className="mt-1 bg-transparent" variant="outline">
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Notify Patients
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Phone className="h-5 w-5 mr-2 text-orange-600" />
                  Follow-up Required
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                    <div>
                      <p className="font-medium">Partial Dispensing</p>
                      <p className="text-sm text-gray-600">Patients with remaining medicines</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-orange-600">{metrics.followUpRequired}</p>
                      <Button size="sm" className="mt-1 bg-transparent" variant="outline">
                        <Phone className="h-4 w-4 mr-1" />
                        Call Patients
                      </Button>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                    <div>
                      <p className="font-medium">Promotional Opportunities</p>
                      <p className="text-sm text-gray-600">Additional medicine recommendations</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-purple-600">12</p>
                      <Button size="sm" className="mt-1 bg-transparent" variant="outline">
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Send Offers
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* AI Insights Tab */}
        <TabsContent value="insights" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="h-5 w-5 mr-2 text-purple-600" />
                  AI Demand Forecasting
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-red-800">High Risk Items</span>
                      <Badge className="bg-red-600">3 items</Badge>
                    </div>
                    <p className="text-sm text-red-600">
                      Paracetamol, Amoxicillin, Omeprazole likely to stock out in 7 days
                    </p>
                    <Button size="sm" className="mt-2 bg-red-600 hover:bg-red-700">
                      Create Purchase Orders
                    </Button>
                  </div>

                  <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-yellow-800">Medium Risk Items</span>
                      <Badge className="bg-yellow-600">5 items</Badge>
                    </div>
                    <p className="text-sm text-yellow-600">Monitor closely - may need reordering in 2 weeks</p>
                    <Button size="sm" className="mt-2 bg-transparent" variant="outline">
                      View Details
                    </Button>
                  </div>

                  <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-green-800">Optimal Stock Items</span>
                      <Badge className="bg-green-600">42 items</Badge>
                    </div>
                    <p className="text-sm text-green-600">Stock levels are optimal for forecasted demand</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
                  Performance Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Revenue Growth (vs last month)</span>
                    <span className="font-bold text-green-600">+18.5%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Prescription Completion Rate</span>
                    <span className="font-bold text-blue-600">{metrics.completionRate}%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Processing Time</span>
                    <span className="font-bold text-purple-600">4.2 min</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Customer Satisfaction</span>
                    <span className="font-bold text-green-600">4.7/5</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">WhatsApp Delivery Rate</span>
                    <span className="font-bold text-blue-600">96.8%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Bounce Rate Trend</span>
                    <span className="font-bold text-orange-600">-2.1%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Follow-up Tasks Tab */}
        <TabsContent value="followup" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Telecaller Tasks</CardTitle>
                <CardDescription>Patient follow-up and promotional calls</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Partial Dispensing Follow-up</h4>
                      <Badge variant="outline">15 patients</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      Patients who received partial medicines need follow-up for remaining items
                    </p>
                    <Button size="sm">
                      <Phone className="h-4 w-4 mr-1" />
                      Start Calling
                    </Button>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Medicine Promotion</h4>
                      <Badge variant="outline">8 opportunities</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      Patients who might need additional medicines or supplements
                    </p>
                    <Button size="sm" variant="outline">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Send Offers
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pharmacist Tasks</CardTitle>
                <CardDescription>Clinical and operational tasks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Alternative Medicine Review</h4>
                      <Badge variant="outline">6 cases</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      Review and approve alternative medicine suggestions for out-of-stock items
                    </p>
                    <Button size="sm">
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Review Cases
                    </Button>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Prescription Consultation</h4>
                      <Badge variant="outline">3 pending</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      Complex prescriptions requiring pharmacist consultation
                    </p>
                    <Button size="sm" variant="outline">
                      <Users className="h-4 w-4 mr-1" />
                      Consult Patients
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PrivateRoute>
  )
}

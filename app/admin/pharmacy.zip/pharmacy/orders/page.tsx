"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Search,
  Filter,
  Package,
  Clock,
  CheckCircle,
  Truck,
  AlertTriangle,
  Phone,
  MessageSquare,
  Eye,
  RefreshCw,
  Calendar,
  User,
  MapPin,
  Pill,
  ShoppingCart,
  FileText,
  Download,
  XCircle,
} from "lucide-react"
import Link from "next/link"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface PatientOrder {
  id: string
  orderNumber: string
  patientId: string
  patientName: string
  patientPhone: string
  patientEmail: string
  orderDate: string
  orderType: "refill" | "prescription" | "direct"
  status: "pending" | "processing" | "ready" | "dispatched" | "delivered" | "cancelled" | "partial"
  priority: "normal" | "urgent" | "emergency"
  deliveryMethod: "delivery" | "pickup"
  deliveryAddress?: {
    street: string
    city: string
    pincode: string
    landmark?: string
  }
  items: {
    id: string
    medicineId: string
    medicineName: string
    genericName: string
    strength: string
    form: string
    quantityOrdered: number
    quantityAvailable: number
    quantityDispensed: number
    unitPrice: number
    totalPrice: number
    prescriptionRequired: boolean
    inStock: boolean
    batchNumber?: string
    expiryDate?: string
    substituted: boolean
    substituteReason?: string
  }[]
  subtotal: number
  discount: number
  tax: number
  deliveryFee: number
  totalAmount: number
  paymentMethod: "online" | "cod" | "insurance"
  paymentStatus: "pending" | "paid" | "failed"
  prescriptionUploaded: boolean
  prescriptionVerified: boolean
  pharmacistNotes?: string
  estimatedReadyTime?: string
  dispatchTime?: string
  deliveryTime?: string
  trackingNumber?: string
  lastUpdated: string
}

export default function PharmacyOrders() {
  const [orders, setOrders] = useState<PatientOrder[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [selectedTab, setSelectedTab] = useState("all")

  // Mock data - replace with actual API calls
  useEffect(() => {
    const mockOrders: PatientOrder[] = [
      {
        id: "ord_001",
        orderNumber: "ORD2024001234",
        patientId: "pat_001",
        patientName: "Rajesh Kumar",
        patientPhone: "+91 98765 43210",
        patientEmail: "rajesh.kumar@email.com",
        orderDate: "2024-01-20T10:30:00Z",
        orderType: "refill",
        status: "pending",
        priority: "normal",
        deliveryMethod: "delivery",
        deliveryAddress: {
          street: "123 MG Road, Apartment 4B",
          city: "Mumbai",
          pincode: "400001",
          landmark: "Near ABC Mall",
        },
        items: [
          {
            id: "item_001",
            medicineId: "med_001",
            medicineName: "Metformin 500mg",
            genericName: "Metformin Hydrochloride",
            strength: "500mg",
            form: "Tablet",
            quantityOrdered: 60,
            quantityAvailable: 60,
            quantityDispensed: 0,
            unitPrice: 12.5,
            totalPrice: 750,
            prescriptionRequired: true,
            inStock: true,
            batchNumber: "BATCH001",
            expiryDate: "2025-12-31",
            substituted: false,
          },
          {
            id: "item_002",
            medicineId: "med_002",
            medicineName: "Lisinopril 10mg",
            genericName: "Lisinopril",
            strength: "10mg",
            form: "Tablet",
            quantityOrdered: 30,
            quantityAvailable: 25,
            quantityDispensed: 0,
            unitPrice: 8.75,
            totalPrice: 262.5,
            prescriptionRequired: true,
            inStock: true,
            batchNumber: "BATCH002",
            expiryDate: "2025-10-31",
            substituted: false,
          },
        ],
        subtotal: 1012.5,
        discount: 50,
        tax: 115.5,
        deliveryFee: 0,
        totalAmount: 1078,
        paymentMethod: "online",
        paymentStatus: "paid",
        prescriptionUploaded: true,
        prescriptionVerified: false,
        estimatedReadyTime: "2024-01-20T14:00:00Z",
        lastUpdated: "2024-01-20T10:30:00Z",
      },
      {
        id: "ord_002",
        orderNumber: "ORD2024001235",
        patientId: "pat_002",
        patientName: "Priya Singh",
        patientPhone: "+91 87654 32109",
        patientEmail: "priya.singh@email.com",
        orderDate: "2024-01-20T09:15:00Z",
        orderType: "prescription",
        status: "processing",
        priority: "urgent",
        deliveryMethod: "pickup",
        items: [
          {
            id: "item_003",
            medicineId: "med_003",
            medicineName: "Amoxicillin 500mg",
            genericName: "Amoxicillin",
            strength: "500mg",
            form: "Capsule",
            quantityOrdered: 21,
            quantityAvailable: 21,
            quantityDispensed: 21,
            unitPrice: 15.5,
            totalPrice: 325.5,
            prescriptionRequired: true,
            inStock: true,
            batchNumber: "BATCH003",
            expiryDate: "2025-08-31",
            substituted: false,
          },
        ],
        subtotal: 325.5,
        discount: 0,
        tax: 39.06,
        deliveryFee: 0,
        totalAmount: 364.56,
        paymentMethod: "cod",
        paymentStatus: "pending",
        prescriptionUploaded: true,
        prescriptionVerified: true,
        pharmacistNotes: "Urgent antibiotic course - patient has infection",
        estimatedReadyTime: "2024-01-20T11:00:00Z",
        lastUpdated: "2024-01-20T10:45:00Z",
      },
      {
        id: "ord_003",
        orderNumber: "ORD2024001236",
        patientId: "pat_003",
        patientName: "Amit Patel",
        patientPhone: "+91 76543 21098",
        patientEmail: "amit.patel@email.com",
        orderDate: "2024-01-20T08:00:00Z",
        orderType: "direct",
        status: "ready",
        priority: "normal",
        deliveryMethod: "delivery",
        deliveryAddress: {
          street: "456 Park Street, Block C",
          city: "Mumbai",
          pincode: "400002",
          landmark: "Opposite City Hospital",
        },
        items: [
          {
            id: "item_004",
            medicineId: "med_004",
            medicineName: "Paracetamol 500mg",
            genericName: "Acetaminophen",
            strength: "500mg",
            form: "Tablet",
            quantityOrdered: 20,
            quantityAvailable: 20,
            quantityDispensed: 20,
            unitPrice: 3.25,
            totalPrice: 65,
            prescriptionRequired: false,
            inStock: true,
            batchNumber: "BATCH004",
            expiryDate: "2025-06-30",
            substituted: false,
          },
          {
            id: "item_005",
            medicineId: "med_005",
            medicineName: "Vitamin D3 60000 IU",
            genericName: "Cholecalciferol",
            strength: "60000 IU",
            form: "Capsule",
            quantityOrdered: 8,
            quantityAvailable: 0,
            quantityDispensed: 0,
            unitPrice: 30,
            totalPrice: 240,
            prescriptionRequired: false,
            inStock: false,
            substituted: true,
            substituteReason: "Out of stock - substituted with 1000 IU daily dose",
          },
        ],
        subtotal: 305,
        discount: 15,
        tax: 34.8,
        deliveryFee: 50,
        totalAmount: 374.8,
        paymentMethod: "online",
        paymentStatus: "paid",
        prescriptionUploaded: false,
        prescriptionVerified: true,
        pharmacistNotes: "Vitamin D3 substituted - patient informed",
        estimatedReadyTime: "2024-01-20T10:00:00Z",
        lastUpdated: "2024-01-20T09:30:00Z",
      },
    ]

    setTimeout(() => {
      setOrders(mockOrders)
      setLoading(false)
    }, 1000)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "processing":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "ready":
        return "bg-green-100 text-green-800 border-green-200"
      case "dispatched":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "delivered":
        return "bg-emerald-100 text-emerald-800 border-emerald-200"
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-200"
      case "partial":
        return "bg-orange-100 text-orange-800 border-orange-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "emergency":
        return "bg-red-500 text-white"
      case "urgent":
        return "bg-orange-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "processing":
        return <Package className="h-4 w-4" />
      case "ready":
        return <CheckCircle className="h-4 w-4" />
      case "dispatched":
        return <Truck className="h-4 w-4" />
      case "delivered":
        return <CheckCircle className="h-4 w-4" />
      case "cancelled":
        return <XCircle className="h-4 w-4" />
      case "partial":
        return <AlertTriangle className="h-4 w-4" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.patientPhone.includes(searchTerm) ||
      order.items.some((item) => item.medicineName.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesStatus = statusFilter === "all" || order.status === statusFilter
    const matchesPriority = priorityFilter === "all" || order.priority === priorityFilter
    const matchesTab =
      selectedTab === "all" ||
      (selectedTab === "pending" && ["pending", "processing"].includes(order.status)) ||
      (selectedTab === "ready" && order.status === "ready") ||
      (selectedTab === "dispatched" && ["dispatched", "delivered"].includes(order.status))

    return matchesSearch && matchesStatus && matchesPriority && matchesTab
  })

  const getOrderCounts = () => {
    return {
      all: orders.length,
      pending: orders.filter((o) => ["pending", "processing"].includes(o.status)).length,
      ready: orders.filter((o) => o.status === "ready").length,
      dispatched: orders.filter((o) => ["dispatched", "delivered"].includes(o.status)).length,
    }
  }

  const orderCounts = getOrderCounts()

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <PrivateRoute modulePath="admin/pharmacy/orders" action="view">
      <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Patient Orders</h1>
            <p className="text-sm sm:text-base text-gray-600">Manage and dispatch patient medicine orders</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            <Button variant="outline" size="sm" className="w-full sm:w-auto bg-transparent">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm" className="w-full sm:w-auto bg-transparent">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6 space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-600 text-xs sm:text-sm font-medium">Total Orders</p>
                  <p className="text-lg sm:text-2xl font-bold text-blue-800">{orderCounts.all}</p>
                </div>
                <ShoppingCart className="h-6 w-6 sm:h-8 sm:w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-yellow-200 bg-gradient-to-br from-yellow-50 to-yellow-100">
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-600 text-xs sm:text-sm font-medium">Pending</p>
                  <p className="text-lg sm:text-2xl font-bold text-yellow-800">{orderCounts.pending}</p>
                </div>
                <Clock className="h-6 w-6 sm:h-8 sm:w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-600 text-xs sm:text-sm font-medium">Ready</p>
                  <p className="text-lg sm:text-2xl font-bold text-green-800">{orderCounts.ready}</p>
                </div>
                <CheckCircle className="h-6 w-6 sm:h-8 sm:w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-600 text-xs sm:text-sm font-medium">Dispatched</p>
                  <p className="text-lg sm:text-2xl font-bold text-purple-800">{orderCounts.dispatched}</p>
                </div>
                <Truck className="h-6 w-6 sm:h-8 sm:w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col gap-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search by order number, patient name, phone, or medicine..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="ready">Ready</SelectItem>
                      <SelectItem value="dispatched">Dispatched</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="Priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priority</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                      <SelectItem value="emergency">Emergency</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Orders Tabs */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all" className="text-xs sm:text-sm">
              All ({orderCounts.all})
            </TabsTrigger>
            <TabsTrigger value="pending" className="text-xs sm:text-sm">
              Pending ({orderCounts.pending})
            </TabsTrigger>
            <TabsTrigger value="ready" className="text-xs sm:text-sm">
              Ready ({orderCounts.ready})
            </TabsTrigger>
            <TabsTrigger value="dispatched" className="text-xs sm:text-sm">
              Dispatched ({orderCounts.dispatched})
            </TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab} className="space-y-4">
            {filteredOrders.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Package className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
                  <p className="text-gray-600">No orders match your current filters.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {filteredOrders.map((order) => (
                  <Card key={order.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4 sm:p-6">
                      {/* Order Header */}
                      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                        <div className="flex-1">
                          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2">
                            <div className="flex items-center gap-2">
                              <FileText className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600" />
                              <span className="font-semibold text-sm sm:text-base">{order.orderNumber}</span>
                            </div>
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge className={getStatusColor(order.status)}>
                                {getStatusIcon(order.status)}
                                <span className="ml-1 capitalize text-xs">{order.status.replace("_", " ")}</span>
                              </Badge>
                              {order.priority !== "normal" && (
                                <Badge className={getPriorityColor(order.priority)}>
                                  <span className="text-xs capitalize">{order.priority}</span>
                                </Badge>
                              )}
                              <Badge variant="outline" className="text-xs">
                                {order.orderType.toUpperCase()}
                              </Badge>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs sm:text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <User className="h-3 w-3 sm:h-4 sm:w-4" />
                              <span className="truncate">{order.patientName}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Phone className="h-3 w-3 sm:h-4 sm:w-4" />
                              <span>{order.patientPhone}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3 sm:h-4 sm:w-4" />
                              <span>{new Date(order.orderDate).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Package className="h-3 w-3 sm:h-4 sm:w-4" />
                              <span>{order.items.length} items</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-2">
                          <Link href={`/pharmacy/orders/${order.id}`}>
                            <Button size="sm" variant="outline" className="w-full sm:w-auto bg-transparent">
                              <Eye className="h-4 w-4 mr-1" />
                              View Details
                            </Button>
                          </Link>
                          {order.status === "pending" && (
                            <Button size="sm" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700">
                              <Package className="h-4 w-4 mr-1" />
                              Process
                            </Button>
                          )}
                          {order.status === "ready" && (
                            <Button size="sm" className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
                              <Truck className="h-4 w-4 mr-1" />
                              Dispatch
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* Order Items Preview */}
                      <div className="space-y-2 mb-4">
                        <h4 className="font-medium text-gray-900 text-sm">Items:</h4>
                        <div className="space-y-1">
                          {order.items.slice(0, 2).map((item) => (
                            <div
                              key={item.id}
                              className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-2 px-3 bg-gray-50 rounded-lg gap-2"
                            >
                              <div className="flex items-center gap-2">
                                <Pill className="h-4 w-4 text-blue-600" />
                                <div>
                                  <span className="font-medium text-sm">{item.medicineName}</span>
                                  <div className="flex flex-wrap items-center gap-2 text-xs text-gray-600">
                                    <span>Qty: {item.quantityOrdered}</span>
                                    {!item.inStock && (
                                      <Badge className="bg-red-100 text-red-800 text-xs">Out of Stock</Badge>
                                    )}
                                    {item.substituted && (
                                      <Badge className="bg-orange-100 text-orange-800 text-xs">Substituted</Badge>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <span className="font-semibold text-sm">₹{item.totalPrice.toFixed(2)}</span>
                            </div>
                          ))}
                          {order.items.length > 2 && (
                            <div className="text-center py-2 text-sm text-gray-600">
                              +{order.items.length - 2} more items
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Delivery Information */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 p-3 sm:p-4 bg-blue-50 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900 mb-2 text-sm">Delivery Information</h4>
                          <div className="space-y-1 text-xs sm:text-sm">
                            <div className="flex items-center gap-2">
                              {order.deliveryMethod === "delivery" ? (
                                <Truck className="h-4 w-4 text-green-600" />
                              ) : (
                                <Package className="h-4 w-4 text-blue-600" />
                              )}
                              <span className="capitalize">{order.deliveryMethod}</span>
                            </div>
                            {order.deliveryAddress && (
                              <div className="flex items-start gap-2">
                                <MapPin className="h-4 w-4 text-gray-500 mt-0.5" />
                                <div className="text-gray-600">
                                  <p>{order.deliveryAddress.street}</p>
                                  <p>
                                    {order.deliveryAddress.city} - {order.deliveryAddress.pincode}
                                  </p>
                                  {order.deliveryAddress.landmark && (
                                    <p className="text-xs">Landmark: {order.deliveryAddress.landmark}</p>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-900 mb-2 text-sm">Order Summary</h4>
                          <div className="space-y-1 text-xs sm:text-sm">
                            <div className="flex justify-between">
                              <span>Total Amount:</span>
                              <span className="font-semibold">₹{order.totalAmount.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Payment:</span>
                              <Badge
                                className={
                                  order.paymentStatus === "paid"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-yellow-100 text-yellow-800"
                                }
                              >
                                {order.paymentStatus}
                              </Badge>
                            </div>
                            {order.prescriptionRequired && (
                              <div className="flex justify-between">
                                <span>Prescription:</span>
                                <Badge
                                  className={
                                    order.prescriptionVerified
                                      ? "bg-green-100 text-green-800"
                                      : "bg-yellow-100 text-yellow-800"
                                  }
                                >
                                  {order.prescriptionVerified ? "Verified" : "Pending"}
                                </Badge>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-4 pt-4 border-t">
                        <div className="flex flex-wrap gap-2">
                          <Button size="sm" variant="outline" className="text-xs bg-transparent">
                            <Phone className="h-3 w-3 mr-1" />
                            Call Patient
                          </Button>
                          <Button size="sm" variant="outline" className="text-xs bg-transparent">
                            <MessageSquare className="h-3 w-3 mr-1" />
                            WhatsApp
                          </Button>
                          {order.trackingNumber && (
                            <Button size="sm" variant="outline" className="text-xs bg-transparent">
                              <Truck className="h-3 w-3 mr-1" />
                              Track: {order.trackingNumber}
                            </Button>
                          )}
                        </div>

                        <div className="text-xs text-gray-500">
                          Last updated: {new Date(order.lastUpdated).toLocaleString()}
                        </div>
                      </div>

                      {/* Pharmacist Notes */}
                      {order.pharmacistNotes && (
                        <Alert className="mt-4">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription className="text-sm">
                            <strong>Pharmacist Notes:</strong> {order.pharmacistNotes}
                          </AlertDescription>
                        </Alert>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      </div>
    </PrivateRoute>
  )
}

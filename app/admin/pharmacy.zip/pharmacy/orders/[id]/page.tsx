"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  ArrowLeft,
  Package,
  Clock,
  CheckCircle,
  Truck,
  AlertTriangle,
  Phone,
  MessageSquare,
  User,
  MapPin,
  Pill,
  FileText,
  Download,
  Send,
  XCircle,
  Edit,
  Save,
  Printer,
  Eye,
  RefreshCw,
  Plus,
  Minus,
} from "lucide-react"
import { useParams, useRouter } from "next/navigation"

interface OrderItem {
  id: string
  medicineId: string
  medicineName: string
  genericName: string
  strength: string
  form: string
  quantityOrdered: number
  quantityAvailable: number
  quantityDispensed: number
  unitPrice: number
  totalPrice: number
  prescriptionRequired: boolean
  inStock: boolean
  batchNumber?: string
  expiryDate?: string
  substituted: boolean
  substituteReason?: string
  substituteMedicine?: {
    id: string
    name: string
    strength: string
    form: string
    unitPrice: number
  }
}

interface PatientOrder {
  id: string
  orderNumber: string
  patientId: string
  patientName: string
  patientPhone: string
  patientEmail: string
  patientAge: number
  patientGender: string
  orderDate: string
  orderType: "refill" | "prescription" | "direct"
  status: "pending" | "processing" | "ready" | "dispatched" | "delivered" | "cancelled" | "partial"
  priority: "normal" | "urgent" | "emergency"
  deliveryMethod: "delivery" | "pickup"
  deliveryAddress?: {
    street: string
    city: string
    pincode: string
    landmark?: string
  }
  items: OrderItem[]
  subtotal: number
  discount: number
  tax: number
  deliveryFee: number
  totalAmount: number
  paymentMethod: "online" | "cod" | "insurance"
  paymentStatus: "pending" | "paid" | "failed"
  prescriptionUploaded: boolean
  prescriptionVerified: boolean
  prescriptionImages?: string[]
  pharmacistNotes?: string
  estimatedReadyTime?: string
  dispatchTime?: string
  deliveryTime?: string
  trackingNumber?: string
  assignedPharmacist?: string
  lastUpdated: string
  timeline: {
    timestamp: string
    status: string
    description: string
    user: string
  }[]
}

export default function OrderDetails() {
  const params = useParams()
  const router = useRouter()
  const orderId = params.id as string

  const [order, setOrder] = useState<PatientOrder | null>(null)
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)
  const [pharmacistNotes, setPharmacistNotes] = useState("")
  const [trackingNumber, setTrackingNumber] = useState("")
  const [showDispatchDialog, setShowDispatchDialog] = useState(false)
  const [showSubstituteDialog, setShowSubstituteDialog] = useState(false)
  const [selectedItem, setSelectedItem] = useState<OrderItem | null>(null)

  useEffect(() => {
    // Mock data - replace with actual API call
    const mockOrder: PatientOrder = {
      id: orderId,
      orderNumber: "ORD2024001234",
      patientId: "pat_001",
      patientName: "Rajesh Kumar",
      patientPhone: "+91 98765 43210",
      patientEmail: "rajesh.kumar@email.com",
      patientAge: 45,
      patientGender: "Male",
      orderDate: "2024-01-20T10:30:00Z",
      orderType: "refill",
      status: "pending",
      priority: "normal",
      deliveryMethod: "delivery",
      deliveryAddress: {
        street: "123 MG Road, Apartment 4B",
        city: "Mumbai",
        pincode: "400001",
        landmark: "Near ABC Mall",
      },
      items: [
        {
          id: "item_001",
          medicineId: "med_001",
          medicineName: "Metformin 500mg",
          genericName: "Metformin Hydrochloride",
          strength: "500mg",
          form: "Tablet",
          quantityOrdered: 60,
          quantityAvailable: 60,
          quantityDispensed: 0,
          unitPrice: 12.5,
          totalPrice: 750,
          prescriptionRequired: true,
          inStock: true,
          batchNumber: "BATCH001",
          expiryDate: "2025-12-31",
          substituted: false,
        },
        {
          id: "item_002",
          medicineId: "med_002",
          medicineName: "Lisinopril 10mg",
          genericName: "Lisinopril",
          strength: "10mg",
          form: "Tablet",
          quantityOrdered: 30,
          quantityAvailable: 25,
          quantityDispensed: 0,
          unitPrice: 8.75,
          totalPrice: 262.5,
          prescriptionRequired: true,
          inStock: true,
          batchNumber: "BATCH002",
          expiryDate: "2025-10-31",
          substituted: false,
        },
      ],
      subtotal: 1012.5,
      discount: 50,
      tax: 115.5,
      deliveryFee: 0,
      totalAmount: 1078,
      paymentMethod: "online",
      paymentStatus: "paid",
      prescriptionUploaded: true,
      prescriptionVerified: false,
      prescriptionImages: ["/placeholder.svg?height=400&width=300&text=Prescription"],
      pharmacistNotes: "",
      estimatedReadyTime: "2024-01-20T14:00:00Z",
      assignedPharmacist: "Dr. Priya Sharma",
      lastUpdated: "2024-01-20T10:30:00Z",
      timeline: [
        {
          timestamp: "2024-01-20T10:30:00Z",
          status: "pending",
          description: "Order received from patient portal",
          user: "System",
        },
        {
          timestamp: "2024-01-20T10:35:00Z",
          status: "pending",
          description: "Prescription uploaded by patient",
          user: "Rajesh Kumar",
        },
      ],
    }

    setTimeout(() => {
      setOrder(mockOrder)
      setPharmacistNotes(mockOrder.pharmacistNotes || "")
      setTrackingNumber(mockOrder.trackingNumber || "")
      setLoading(false)
    }, 1000)
  }, [orderId])

  const updateOrderStatus = async (newStatus: string) => {
    if (!order) return

    setUpdating(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const updatedOrder = {
        ...order,
        status: newStatus as any,
        lastUpdated: new Date().toISOString(),
        timeline: [
          ...order.timeline,
          {
            timestamp: new Date().toISOString(),
            status: newStatus,
            description: `Order status updated to ${newStatus}`,
            user: "Pharmacist",
          },
        ],
      }

      if (newStatus === "dispatched" && trackingNumber) {
        updatedOrder.trackingNumber = trackingNumber
        updatedOrder.dispatchTime = new Date().toISOString()
      }

      setOrder(updatedOrder)
      alert(`Order status updated to ${newStatus}`)
    } catch (error) {
      alert("Failed to update order status")
    } finally {
      setUpdating(false)
      setShowDispatchDialog(false)
    }
  }

  const updatePharmacistNotes = async () => {
    if (!order) return

    setUpdating(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500))

      const updatedOrder = {
        ...order,
        pharmacistNotes,
        lastUpdated: new Date().toISOString(),
      }

      setOrder(updatedOrder)
      alert("Notes updated successfully")
    } catch (error) {
      alert("Failed to update notes")
    } finally {
      setUpdating(false)
    }
  }

  const handleSubstitute = async (itemId: string, substituteData: any) => {
    if (!order) return

    setUpdating(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const updatedItems = order.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              substituted: true,
              substituteReason: substituteData.reason,
              substituteMedicine: substituteData.medicine,
            }
          : item,
      )

      const updatedOrder = {
        ...order,
        items: updatedItems,
        lastUpdated: new Date().toISOString(),
      }

      setOrder(updatedOrder)
      alert("Medicine substituted successfully")
    } catch (error) {
      alert("Failed to substitute medicine")
    } finally {
      setUpdating(false)
      setShowSubstituteDialog(false)
      setSelectedItem(null)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "processing":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "ready":
        return "bg-green-100 text-green-800 border-green-200"
      case "dispatched":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "delivered":
        return "bg-emerald-100 text-emerald-800 border-emerald-200"
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-200"
      case "partial":
        return "bg-orange-100 text-orange-800 border-orange-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "processing":
        return <Package className="h-4 w-4" />
      case "ready":
        return <CheckCircle className="h-4 w-4" />
      case "dispatched":
        return <Truck className="h-4 w-4" />
      case "delivered":
        return <CheckCircle className="h-4 w-4" />
      case "cancelled":
        return <XCircle className="h-4 w-4" />
      case "partial":
        return <AlertTriangle className="h-4 w-4" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Order not found</h3>
            <p className="text-gray-600 mb-4">The order you're looking for doesn't exist.</p>
            <Button onClick={() => router.back()}>Go Back</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => router.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Order Details</h1>
              <p className="text-sm sm:text-base text-gray-600">{order.orderNumber}</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            <Button variant="outline" size="sm" className="w-full sm:w-auto bg-transparent">
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button variant="outline" size="sm" className="w-full sm:w-auto bg-transparent">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" size="sm" className="w-full sm:w-auto bg-transparent">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6 space-y-6">
        {/* Order Status & Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-5 w-5 text-blue-600" />
                      {order.orderNumber}
                    </CardTitle>
                    <CardDescription>
                      Ordered on {new Date(order.orderDate).toLocaleDateString()} at{" "}
                      {new Date(order.orderDate).toLocaleTimeString()}
                    </CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge className={getStatusColor(order.status)}>
                      {getStatusIcon(order.status)}
                      <span className="ml-1 capitalize">{order.status.replace("_", " ")}</span>
                    </Badge>
                    {order.priority !== "normal" && (
                      <Badge
                        className={
                          order.priority === "emergency" ? "bg-red-500 text-white" : "bg-orange-500 text-white"
                        }
                      >
                        {order.priority.toUpperCase()}
                      </Badge>
                    )}
                    <Badge variant="outline">{order.orderType.toUpperCase()}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="font-medium">{order.patientName}</p>
                      <p className="text-gray-600">
                        {order.patientAge}Y, {order.patientGender}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="font-medium">{order.patientPhone}</p>
                      <p className="text-gray-600">{order.patientEmail}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Package className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="font-medium">{order.items.length} items</p>
                      <p className="text-gray-600">₹{order.totalAmount.toFixed(2)} total</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {order.status === "pending" && (
                  <Button
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    onClick={() => updateOrderStatus("processing")}
                    disabled={updating}
                  >
                    <Package className="h-4 w-4 mr-2" />
                    Start Processing
                  </Button>
                )}

                {order.status === "processing" && (
                  <Button
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={() => updateOrderStatus("ready")}
                    disabled={updating}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Mark Ready
                  </Button>
                )}

                {order.status === "ready" && (
                  <Button
                    className="w-full bg-purple-600 hover:bg-purple-700"
                    onClick={() => setShowDispatchDialog(true)}
                    disabled={updating}
                  >
                    <Truck className="h-4 w-4 mr-2" />
                    Dispatch Order
                  </Button>
                )}

                <div className="flex flex-col sm:flex-row gap-2">
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    WhatsApp
                  </Button>
                </div>

                {order.trackingNumber && (
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <p className="text-sm font-medium text-purple-800">Tracking Number</p>
                    <p className="text-sm text-purple-600">{order.trackingNumber}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="items" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-5">
            <TabsTrigger value="items" className="text-xs sm:text-sm">
              Items
            </TabsTrigger>
            <TabsTrigger value="delivery" className="text-xs sm:text-sm">
              Delivery
            </TabsTrigger>
            <TabsTrigger value="prescription" className="text-xs sm:text-sm">
              Prescription
            </TabsTrigger>
            <TabsTrigger value="timeline" className="text-xs sm:text-sm">
              Timeline
            </TabsTrigger>
            <TabsTrigger value="notes" className="text-xs sm:text-sm">
              Notes
            </TabsTrigger>
          </TabsList>

          {/* Items Tab */}
          <TabsContent value="items" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Order Items</CardTitle>
                <CardDescription>Manage medicines in this order</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {order.items.map((item) => (
                    <div key={item.id} className="border rounded-lg p-4">
                      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Pill className="h-6 w-6 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                              <div>
                                <h4 className="font-semibold text-gray-900">{item.medicineName}</h4>
                                <p className="text-sm text-gray-600">{item.genericName}</p>
                                <div className="flex flex-wrap items-center gap-2 mt-1">
                                  <Badge variant="outline" className="text-xs">
                                    {item.strength}
                                  </Badge>
                                  <Badge variant="outline" className="text-xs">
                                    {item.form}
                                  </Badge>
                                  {item.prescriptionRequired && (
                                    <Badge className="bg-orange-100 text-orange-800 text-xs">Rx Required</Badge>
                                  )}
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-semibold">₹{item.totalPrice.toFixed(2)}</p>
                                <p className="text-sm text-gray-600">₹{item.unitPrice} each</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-3 text-sm">
                              <div>
                                <p className="text-gray-600">
                                  Ordered: <span className="font-medium">{item.quantityOrdered}</span>
                                </p>
                                <p className="text-gray-600">
                                  Available: <span className="font-medium">{item.quantityAvailable}</span>
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-600">
                                  Dispensed: <span className="font-medium">{item.quantityDispensed}</span>
                                </p>
                                {item.batchNumber && (
                                  <p className="text-gray-600">
                                    Batch: <span className="font-medium">{item.batchNumber}</span>
                                  </p>
                                )}
                              </div>
                              <div>
                                {item.expiryDate && (
                                  <p className="text-gray-600">
                                    Expiry:{" "}
                                    <span className="font-medium">
                                      {new Date(item.expiryDate).toLocaleDateString()}
                                    </span>
                                  </p>
                                )}
                                <div className="flex items-center gap-1 mt-1">
                                  {item.inStock ? (
                                    <Badge className="bg-green-100 text-green-800 text-xs">In Stock</Badge>
                                  ) : (
                                    <Badge className="bg-red-100 text-red-800 text-xs">Out of Stock</Badge>
                                  )}
                                  {item.substituted && (
                                    <Badge className="bg-orange-100 text-orange-800 text-xs">Substituted</Badge>
                                  )}
                                </div>
                              </div>
                            </div>

                            {item.substituted && item.substituteReason && (
                              <Alert className="mt-3">
                                <AlertTriangle className="h-4 w-4" />
                                <AlertDescription className="text-sm">
                                  <strong>Substitution:</strong> {item.substituteReason}
                                </AlertDescription>
                              </Alert>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-2">
                          {!item.inStock && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedItem(item)
                                setShowSubstituteDialog(true)
                              }}
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Substitute
                            </Button>
                          )}
                          <div className="flex items-center gap-1">
                            <Button size="sm" variant="outline" className="px-2 bg-transparent">
                              <Minus className="h-3 w-3" />
                            </Button>
                            <Input
                              type="number"
                              value={item.quantityDispensed}
                              className="w-16 h-8 text-center text-sm"
                              min="0"
                              max={item.quantityAvailable}
                            />
                            <Button size="sm" variant="outline" className="px-2 bg-transparent">
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Order Summary */}
                  <div className="border-t pt-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-semibold mb-3">Order Summary</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Subtotal:</span>
                          <span>₹{order.subtotal.toFixed(2)}</span>
                        </div>
                        {order.discount > 0 && (
                          <div className="flex justify-between text-green-600">
                            <span>Discount:</span>
                            <span>-₹{order.discount.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span>Tax (GST):</span>
                          <span>₹{order.tax.toFixed(2)}</span>
                        </div>
                        {order.deliveryFee > 0 && (
                          <div className="flex justify-between">
                            <span>Delivery Fee:</span>
                            <span>₹{order.deliveryFee.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="flex justify-between font-semibold text-base border-t pt-2">
                          <span>Total Amount:</span>
                          <span>₹{order.totalAmount.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Delivery Tab */}
          <TabsContent value="delivery" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {order.deliveryMethod === "delivery" ? (
                      <Truck className="h-5 w-5 text-green-600" />
                    ) : (
                      <Package className="h-5 w-5 text-blue-600" />
                    )}
                    {order.deliveryMethod === "delivery" ? "Home Delivery" : "Store Pickup"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {order.deliveryAddress ? (
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <MapPin className="h-4 w-4 text-gray-500 mt-1" />
                        <div>
                          <p className="font-medium">{order.patientName}</p>
                          <p className="text-sm text-gray-600">{order.deliveryAddress.street}</p>
                          <p className="text-sm text-gray-600">
                            {order.deliveryAddress.city} - {order.deliveryAddress.pincode}
                          </p>
                          {order.deliveryAddress.landmark && (
                            <p className="text-sm text-gray-500">Landmark: {order.deliveryAddress.landmark}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="h-4 w-4 text-gray-500" />
                        <span>{order.patientPhone}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <Package className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p className="text-gray-600">Store pickup - No delivery address required</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Delivery Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {order.estimatedReadyTime && (
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                        <div>
                          <p className="font-medium text-sm">Estimated Ready Time</p>
                          <p className="text-sm text-gray-600">{new Date(order.estimatedReadyTime).toLocaleString()}</p>
                        </div>
                      </div>
                    )}

                    {order.dispatchTime && (
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <div>
                          <p className="font-medium text-sm">Dispatched</p>
                          <p className="text-sm text-gray-600">{new Date(order.dispatchTime).toLocaleString()}</p>
                        </div>
                      </div>
                    )}

                    {order.deliveryTime && (
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div>
                          <p className="font-medium text-sm">Delivered</p>
                          <p className="text-sm text-gray-600">{new Date(order.deliveryTime).toLocaleString()}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Prescription Tab */}
          <TabsContent value="prescription" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Prescription Details</CardTitle>
                <CardDescription>
                  {order.prescriptionUploaded ? "Prescription uploaded by patient" : "No prescription required"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {order.prescriptionUploaded ? (
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div className="flex items-center gap-2">
                        <Badge
                          className={
                            order.prescriptionVerified ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                          }
                        >
                          {order.prescriptionVerified ? "Verified" : "Pending Verification"}
                        </Badge>
                        {order.assignedPharmacist && (
                          <span className="text-sm text-gray-600">by {order.assignedPharmacist}</span>
                        )}
                      </div>
                      {!order.prescriptionVerified && (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Verify Prescription
                        </Button>
                      )}
                    </div>

                    {order.prescriptionImages && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {order.prescriptionImages.map((image, index) => (
                          <div key={index} className="border rounded-lg p-2">
                            <img
                              src={image || "/placeholder.svg"}
                              alt={`Prescription ${index + 1}`}
                              className="w-full h-48 object-cover rounded"
                            />
                            <div className="flex justify-between items-center mt-2">
                              <span className="text-sm text-gray-600">Page {index + 1}</span>
                              <Button size="sm" variant="outline">
                                <Eye className="h-4 w-4 mr-1" />
                                View
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileText className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p className="text-gray-600">No prescription required for this order</p>
                    <p className="text-sm text-gray-500">All items are over-the-counter medicines</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Timeline Tab */}
          <TabsContent value="timeline" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Order Timeline</CardTitle>
                <CardDescription>Track all activities for this order</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {order.timeline.map((event, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <div>
                            <p className="font-medium text-sm">{event.description}</p>
                            <p className="text-xs text-gray-600">by {event.user}</p>
                          </div>
                          <div className="text-xs text-gray-500">{new Date(event.timestamp).toLocaleString()}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notes Tab */}
          <TabsContent value="notes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pharmacist Notes</CardTitle>
                <CardDescription>Add notes and instructions for this order</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Textarea
                    placeholder="Add notes about this order, substitutions, special instructions, etc."
                    value={pharmacistNotes}
                    onChange={(e) => setPharmacistNotes(e.target.value)}
                    rows={6}
                  />
                  <Button onClick={updatePharmacistNotes} disabled={updating} className="bg-blue-600 hover:bg-blue-700">
                    <Save className="h-4 w-4 mr-2" />
                    Save Notes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dispatch Dialog */}
      <Dialog open={showDispatchDialog} onOpenChange={setShowDispatchDialog}>
        <DialogContent className="w-[95vw] max-w-md">
          <DialogHeader>
            <DialogTitle>Dispatch Order</DialogTitle>
            <DialogDescription>Enter tracking details to dispatch this order</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="tracking">Tracking Number</Label>
              <Input
                id="tracking"
                placeholder="Enter tracking number"
                value={trackingNumber}
                onChange={(e) => setTrackingNumber(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="courier">Courier Service</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select courier" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bluedart">Blue Dart</SelectItem>
                  <SelectItem value="dtdc">DTDC</SelectItem>
                  <SelectItem value="fedex">FedEx</SelectItem>
                  <SelectItem value="delhivery">Delhivery</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDispatchDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => updateOrderStatus("dispatched")}
              disabled={!trackingNumber || updating}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Send className="h-4 w-4 mr-2" />
              Dispatch Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Substitute Dialog */}
      <Dialog open={showSubstituteDialog} onOpenChange={setShowSubstituteDialog}>
        <DialogContent className="w-[95vw] max-w-lg">
          <DialogHeader>
            <DialogTitle>Substitute Medicine</DialogTitle>
            <DialogDescription>{selectedItem && `Find substitute for ${selectedItem.medicineName}`}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="substitute">Substitute Medicine</Label>
              <Input id="substitute" placeholder="Search for substitute medicine" />
            </div>
            <div>
              <Label htmlFor="reason">Reason for Substitution</Label>
              <Textarea id="reason" placeholder="Explain why this substitution is being made" rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSubstituteDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => handleSubstitute(selectedItem?.id || "", { reason: "Out of stock", medicine: null })}
              disabled={updating}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Edit className="h-4 w-4 mr-2" />
              Substitute
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

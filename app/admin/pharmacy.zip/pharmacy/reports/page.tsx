"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Download,
  Calendar,
  DollarSign,
  Package,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Pill,
  RefreshCw,
  Zap,
} from "lucide-react"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface PrescriptionReport {
  totalPrescriptions: number
  completedPrescriptions: number
  partialPrescriptions: number
  bouncedPrescriptions: number
  completionRate: number
  bounceRate: number
  averageItemsPerPrescription: number
  totalRevenue: number
  averageOrderValue: number
}

interface BounceAnalysis {
  medicineId: string
  medicineName: string
  totalPrescriptions: number
  bouncedPrescriptions: number
  bounceRate: number
  reason: string
  estimatedLoss: number
}

interface TopSellingMedicine {
  medicineId: string
  medicineName: string
  quantitySold: number
  revenue: number
  profit: number
}

interface AIForecast {
  medicineId: string
  medicineName: string
  currentStock: number
  predictedDemand: number
  recommendedOrder: number
  riskLevel: "low" | "medium" | "high" | "critical"
  confidence: number
}

export default function PharmacyReports() {
  const [activeTab, setActiveTab] = useState("prescriptions")
  const [selectedPeriod, setSelectedPeriod] = useState("30days")
  const [loading, setLoading] = useState(true)

  const [prescriptionReport, setPrescriptionReport] = useState<PrescriptionReport>({
    totalPrescriptions: 0,
    completedPrescriptions: 0,
    partialPrescriptions: 0,
    bouncedPrescriptions: 0,
    completionRate: 0,
    bounceRate: 0,
    averageItemsPerPrescription: 0,
    totalRevenue: 0,
    averageOrderValue: 0,
  })

  const [bounceAnalysis, setBounceAnalysis] = useState<BounceAnalysis[]>([])
  const [topSellingMedicines, setTopSellingMedicines] = useState<TopSellingMedicine[]>([])
  const [aiForecasts, setAiForecasts] = useState<AIForecast[]>([])

  useEffect(() => {
    fetchReportsData()
  }, [selectedPeriod])

  const fetchReportsData = async () => {
    setLoading(true)

    // Simulate API calls
    setTimeout(() => {
      // Mock prescription report data
      setPrescriptionReport({
        totalPrescriptions: 1247,
        completedPrescriptions: 1089,
        partialPrescriptions: 92,
        bouncedPrescriptions: 66,
        completionRate: 87.3,
        bounceRate: 5.3,
        averageItemsPerPrescription: 3.2,
        totalRevenue: 2847650,
        averageOrderValue: 2284,
      })

      // Mock bounce analysis data
      setBounceAnalysis([
        {
          medicineId: "1",
          medicineName: "Insulin Injection 100IU",
          totalPrescriptions: 45,
          bouncedPrescriptions: 23,
          bounceRate: 51.1,
          reason: "Out of stock",
          estimatedLoss: 34500,
        },
        {
          medicineId: "2",
          medicineName: "Thyroid Medication",
          totalPrescriptions: 32,
          bouncedPrescriptions: 15,
          bounceRate: 46.9,
          reason: "Out of stock",
          estimatedLoss: 22500,
        },
        {
          medicineId: "3",
          medicineName: "Blood Pressure Medicine",
          totalPrescriptions: 28,
          bouncedPrescriptions: 12,
          bounceRate: 42.9,
          reason: "Expired stock",
          estimatedLoss: 18000,
        },
        {
          medicineId: "4",
          medicineName: "Antibiotic Syrup",
          totalPrescriptions: 25,
          bouncedPrescriptions: 9,
          bounceRate: 36.0,
          reason: "Out of stock",
          estimatedLoss: 13500,
        },
        {
          medicineId: "5",
          medicineName: "Pain Relief Gel",
          totalPrescriptions: 22,
          bouncedPrescriptions: 7,
          bounceRate: 31.8,
          reason: "Expired stock",
          estimatedLoss: 10500,
        },
      ])

      // Mock top selling medicines
      setTopSellingMedicines([
        {
          medicineId: "1",
          medicineName: "Paracetamol 500mg",
          quantitySold: 2450,
          revenue: 53900,
          profit: 9800,
        },
        {
          medicineId: "2",
          medicineName: "Amoxicillin 250mg",
          quantitySold: 1890,
          revenue: 141750,
          profit: 18900,
        },
        {
          medicineId: "3",
          medicineName: "Omeprazole 20mg",
          quantitySold: 1567,
          revenue: 59546,
          profit: 9402,
        },
        {
          medicineId: "4",
          medicineName: "Cetirizine 10mg",
          quantitySold: 1234,
          revenue: 29616,
          profit: 4936,
        },
        {
          medicineId: "5",
          medicineName: "Metformin 500mg",
          quantitySold: 1098,
          revenue: 43920,
          profit: 6588,
        },
      ])

      // Mock AI forecasts
      setAiForecasts([
        {
          medicineId: "1",
          medicineName: "Paracetamol 500mg",
          currentStock: 45,
          predictedDemand: 180,
          recommendedOrder: 200,
          riskLevel: "critical",
          confidence: 92,
        },
        {
          medicineId: "2",
          medicineName: "Amoxicillin 250mg",
          currentStock: 120,
          predictedDemand: 150,
          recommendedOrder: 100,
          riskLevel: "high",
          confidence: 87,
        },
        {
          medicineId: "3",
          medicineName: "Vitamin D3 60K",
          currentStock: 200,
          predictedDemand: 80,
          recommendedOrder: 0,
          riskLevel: "low",
          confidence: 78,
        },
        {
          medicineId: "4",
          medicineName: "Cough Syrup",
          currentStock: 85,
          predictedDemand: 120,
          recommendedOrder: 60,
          riskLevel: "medium",
          confidence: 84,
        },
      ])

      setLoading(false)
    }, 1000)
  }

  const exportReport = (reportType: string) => {
    alert(`Exporting ${reportType} report...`)
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-200"
      case "high":
        return "bg-orange-100 text-orange-800 border-orange-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-red-600"></div>
      </div>
    )
  }

  return (
    <PrivateRoute modulePath="admin/pharmacy/reports" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Pharmacy Reports & Analytics</h1>
          <p className="text-gray-600">Comprehensive business insights and performance metrics</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => fetchReportsData()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" onClick={() => exportReport("all")}>
            <Download className="h-4 w-4 mr-2" />
            Export All
          </Button>
        </div>
      </div>

      {/* Period Selection */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <Label>Report Period:</Label>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="90days">Last 90 Days</SelectItem>
                <SelectItem value="1year">Last 1 Year</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={fetchReportsData}>
              <Calendar className="h-4 w-4 mr-2" />
              Apply Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="prescriptions">Prescription Analysis</TabsTrigger>
          <TabsTrigger value="bounce">Bounce Analysis</TabsTrigger>
          <TabsTrigger value="sales">Sales Performance</TabsTrigger>
          <TabsTrigger value="forecast">AI Forecasting</TabsTrigger>
        </TabsList>

        {/* Prescription Analysis Tab */}
        <TabsContent value="prescriptions" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Prescriptions</p>
                    <p className="text-2xl font-bold text-blue-600">{prescriptionReport.totalPrescriptions}</p>
                    <p className="text-xs text-blue-600">+12% from last period</p>
                  </div>
                  <Pill className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-green-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Completion Rate</p>
                    <p className="text-2xl font-bold text-green-600">{prescriptionReport.completionRate}%</p>
                    <p className="text-xs text-green-600">+2.3% improvement</p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-red-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Bounce Rate</p>
                    <p className="text-2xl font-bold text-red-600">{prescriptionReport.bounceRate}%</p>
                    <p className="text-xs text-red-600">-0.8% improvement</p>
                  </div>
                  <XCircle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-purple-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Avg Order Value</p>
                    <p className="text-2xl font-bold text-purple-600">₹{prescriptionReport.averageOrderValue}</p>
                    <p className="text-xs text-purple-600">+5.2% increase</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Prescription Status Breakdown</CardTitle>
                <CardDescription>Distribution of prescription fulfillment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span className="font-medium">Completed</span>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-bold text-green-600">
                        {prescriptionReport.completedPrescriptions}
                      </span>
                      <p className="text-sm text-green-600">{prescriptionReport.completionRate}%</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <AlertTriangle className="h-5 w-5 text-yellow-600" />
                      <span className="font-medium">Partial</span>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-bold text-yellow-600">
                        {prescriptionReport.partialPrescriptions}
                      </span>
                      <p className="text-sm text-yellow-600">
                        {(
                          (prescriptionReport.partialPrescriptions / prescriptionReport.totalPrescriptions) *
                          100
                        ).toFixed(1)}
                        %
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <XCircle className="h-5 w-5 text-red-600" />
                      <span className="font-medium">Bounced</span>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-bold text-red-600">{prescriptionReport.bouncedPrescriptions}</span>
                      <p className="text-sm text-red-600">{prescriptionReport.bounceRate}%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue Analysis</CardTitle>
                <CardDescription>Prescription-based revenue metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Total Revenue</span>
                    <span className="text-lg font-bold text-green-600">
                      ₹{prescriptionReport.totalRevenue.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Average Order Value</span>
                    <span className="text-lg font-bold text-blue-600">₹{prescriptionReport.averageOrderValue}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Average Items per Prescription</span>
                    <span className="text-lg font-bold text-purple-600">
                      {prescriptionReport.averageItemsPerPrescription}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Revenue per Prescription</span>
                    <span className="text-lg font-bold text-orange-600">
                      ₹{Math.round(prescriptionReport.totalRevenue / prescriptionReport.totalPrescriptions)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => exportReport("prescriptions")}>
              <Download className="h-4 w-4 mr-2" />
              Export Prescription Report
            </Button>
          </div>
        </TabsContent>

        {/* Bounce Analysis Tab */}
        <TabsContent value="bounce" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Prescription Bounce Analysis</CardTitle>
              <CardDescription>Medicines with highest bounce rates and estimated revenue loss</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {bounceAnalysis.map((item, index) => (
                  <div key={item.medicineId} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <Badge variant="outline" className="w-8 h-8 rounded-full flex items-center justify-center">
                          {index + 1}
                        </Badge>
                        <div>
                          <h4 className="font-semibold text-lg">{item.medicineName}</h4>
                          <p className="text-sm text-gray-600">Primary reason: {item.reason}</p>
                        </div>
                      </div>
                      <Badge
                        className={
                          item.bounceRate > 40
                            ? "bg-red-100 text-red-800"
                            : item.bounceRate > 25
                              ? "bg-orange-100 text-orange-800"
                              : "bg-yellow-100 text-yellow-800"
                        }
                      >
                        {item.bounceRate.toFixed(1)}% Bounce Rate
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm font-medium">Total Prescriptions</p>
                        <p className="text-xl font-bold text-blue-600">{item.totalPrescriptions}</p>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded-lg">
                        <p className="text-sm font-medium">Bounced</p>
                        <p className="text-xl font-bold text-red-600">{item.bouncedPrescriptions}</p>
                      </div>
                      <div className="text-center p-3 bg-orange-50 rounded-lg">
                        <p className="text-sm font-medium">Bounce Rate</p>
                        <p className="text-xl font-bold text-orange-600">{item.bounceRate.toFixed(1)}%</p>
                      </div>
                      <div className="text-center p-3 bg-purple-50 rounded-lg">
                        <p className="text-sm font-medium">Estimated Loss</p>
                        <p className="text-xl font-bold text-purple-600">₹{item.estimatedLoss.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="mt-3 flex justify-end space-x-2">
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                      <Button size="sm">Create Action Plan</Button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold mb-2">Bounce Analysis Summary</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Total Bounced Prescriptions</p>
                    <p className="text-2xl font-bold text-red-600">
                      {bounceAnalysis.reduce((sum, item) => sum + item.bouncedPrescriptions, 0)}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Average Bounce Rate</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {(bounceAnalysis.reduce((sum, item) => sum + item.bounceRate, 0) / bounceAnalysis.length).toFixed(
                        1,
                      )}
                      %
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Total Estimated Loss</p>
                    <p className="text-2xl font-bold text-purple-600">
                      ₹{bounceAnalysis.reduce((sum, item) => sum + item.estimatedLoss, 0).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={() => exportReport("bounce")}>
              <Download className="h-4 w-4 mr-2" />
              Export Bounce Analysis
            </Button>
          </div>
        </TabsContent>

        {/* Sales Performance Tab */}
        <TabsContent value="sales" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Top Selling Medicines</CardTitle>
              <CardDescription>Best performing medicines by quantity and revenue</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {topSellingMedicines.map((medicine, index) => (
                  <div key={medicine.medicineId} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Badge variant="outline" className="w-8 h-8 rounded-full flex items-center justify-center">
                        {index + 1}
                      </Badge>
                      <div>
                        <h4 className="font-medium">{medicine.medicineName}</h4>
                        <p className="text-sm text-gray-600">Quantity Sold: {medicine.quantitySold}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">₹{medicine.revenue.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">Profit: ₹{medicine.profit.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={() => exportReport("sales")}>
              <Download className="h-4 w-4 mr-2" />
              Export Sales Report
            </Button>
          </div>
        </TabsContent>

        {/* AI Forecasting Tab */}
        <TabsContent value="forecast" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 mr-2 text-purple-600" />
                AI-Driven Stock Demand Forecasting
              </CardTitle>
              <CardDescription>Intelligent predictions for optimal inventory management</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiForecasts.map((forecast) => (
                  <div key={forecast.medicineId} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-lg">{forecast.medicineName}</h4>
                        <p className="text-sm text-gray-600">Confidence: {forecast.confidence}%</p>
                      </div>
                      <Badge className={getRiskColor(forecast.riskLevel)}>
                        {forecast.riskLevel.toUpperCase()} RISK
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm font-medium">Current Stock</p>
                        <p className="text-xl font-bold text-blue-600">{forecast.currentStock}</p>
                      </div>
                      <div className="text-center p-3 bg-orange-50 rounded-lg">
                        <p className="text-sm font-medium">Predicted Demand</p>
                        <p className="text-xl font-bold text-orange-600">{forecast.predictedDemand}</p>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <p className="text-sm font-medium">Recommended Order</p>
                        <p className="text-xl font-bold text-green-600">{forecast.recommendedOrder}</p>
                      </div>
                      <div className="text-center p-3 bg-purple-50 rounded-lg">
                        <p className="text-sm font-medium">Days Until Stockout</p>
                        <p className="text-xl font-bold text-purple-600">
                          {Math.ceil(forecast.currentStock / (forecast.predictedDemand / 30))}
                        </p>
                      </div>
                    </div>

                    <div className="mt-3 flex justify-end space-x-2">
                      <Button size="sm" variant="outline">
                        View Trends
                      </Button>
                      {forecast.recommendedOrder > 0 && (
                        <Button size="sm">
                          <Package className="h-4 w-4 mr-1" />
                          Create Purchase Order
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* AI Insights Summary */}
              <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                <h4 className="font-semibold mb-2 flex items-center">
                  <Zap className="h-4 w-4 mr-2 text-purple-600" />
                  AI Insights Summary
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Critical Risk Items</p>
                    <p className="text-2xl font-bold text-red-600">
                      {aiForecasts.filter((f) => f.riskLevel === "critical").length}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">High Risk Items</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {aiForecasts.filter((f) => f.riskLevel === "high").length}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Total Recommended Orders</p>
                    <p className="text-2xl font-bold text-green-600">
                      {aiForecasts.reduce((sum, f) => sum + f.recommendedOrder, 0)}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Average Confidence</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {Math.round(aiForecasts.reduce((sum, f) => sum + f.confidence, 0) / aiForecasts.length)}%
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={() => exportReport("forecast")}>
              <Download className="h-4 w-4 mr-2" />
              Export Forecast Report
            </Button>
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PrivateRoute>
  )
}

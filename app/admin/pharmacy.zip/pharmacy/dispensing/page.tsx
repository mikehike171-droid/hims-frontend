"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Search,
  User,
  Pill,
  CreditCard,
  Printer,
  MessageSquare,
  AlertTriangle,
  CheckCircle,
  Calculator,
  Phone,
  Plus,
  Minus,
  Receipt,
  XCircle,
  Save,
  Percent,
  Calendar,
  Bell,
  Zap,
} from "lucide-react"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface Medicine {
  id: string
  name: string
  genericName: string
  strength: string
  dosageForm: string
  manufacturer: string
  batchNumber: string
  expiryDate: string
  availableStock: number
  unitPrice: number
  mrp: number
  isPrescriptionRequired: boolean
  category: string
  alternatives?: Medicine[]
}

interface PrescriptionItem {
  id: string
  medicineId: string
  medicine: Medicine
  quantityPrescribed: number
  quantityDispensed: number
  dosageInstructions: string
  frequency: string
  duration: string
  isPartialDispensing: boolean
  partialReason: string
  isSubstitute: boolean
  substituteMedicine?: Medicine
  substituteReason: string
  additionalQuantity?: number
  additionalReason?: string
}

interface Patient {
  id: string
  name: string
  phone: string
  age: number
  gender: string
  address: string
  emergencyContact?: string
  createdAt?: string
  registrationNumber?: string
}

interface Prescription {
  id: string
  patient: Patient
  doctorName: string
  department: string
  prescriptionDate: string
  diagnosis: string
  items: PrescriptionItem[]
}

interface PaymentDetails {
  subtotal: number
  discountAmount: number
  discountPercentage: number
  discountReason: string
  taxAmount: number
  totalAmount: number
  paymentMethod: string
  paidAmount: number
  changeAmount: number
}

export default function PharmacyDispensing() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null)
  const [prescriptionItems, setPrescriptionItems] = useState<PrescriptionItem[]>([])
  const [selectedCustomer, setSelectedCustomer] = useState<Patient | null>(null)
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails>({
    subtotal: 0,
    discountAmount: 0,
    discountPercentage: 0,
    discountReason: "",
    taxAmount: 0,
    totalAmount: 0,
    paymentMethod: "",
    paidAmount: 0,
    changeAmount: 0,
  })
  const [showPaymentDialog, setShowPaymentDialog] = useState(false)
  const [showDiscountDialog, setShowDiscountDialog] = useState(false)
  const [showCreatePatientDialog, setShowCreatePatientDialog] = useState(false)
  const [loading, setLoading] = useState(false)
  const [creatingPatient, setCreatingPatient] = useState(false)
  const [newPatient, setNewPatient] = useState({
    name: "",
    phone: "",
    age: 0,
    gender: "",
    address: "",
    emergencyContact: "",
  })

  // Mock data with alternatives
  const mockMedicines: Medicine[] = [
    {
      id: "1",
      name: "Paracetamol 500mg",
      genericName: "Paracetamol",
      strength: "500mg",
      dosageForm: "Tablet",
      manufacturer: "GSK",
      batchNumber: "BATCH001",
      expiryDate: "2025-12-31",
      availableStock: 150,
      unitPrice: 22.0,
      mrp: 25.0,
      isPrescriptionRequired: false,
      category: "Analgesic",
    },
    {
      id: "2",
      name: "Amoxicillin 250mg",
      genericName: "Amoxicillin",
      strength: "250mg",
      dosageForm: "Capsule",
      manufacturer: "GSK",
      batchNumber: "BATCH002",
      expiryDate: "2025-06-30",
      availableStock: 75,
      unitPrice: 75.0,
      mrp: 85.0,
      isPrescriptionRequired: true,
      category: "Antibiotic",
    },
    {
      id: "3",
      name: "Omeprazole 20mg",
      genericName: "Omeprazole",
      strength: "20mg",
      dosageForm: "Capsule",
      manufacturer: "Dr Reddy",
      batchNumber: "BATCH003",
      expiryDate: "2025-09-15",
      availableStock: 0,
      unitPrice: 38.0,
      mrp: 45.0,
      isPrescriptionRequired: true,
      category: "PPI",
    },
    {
      id: "4",
      name: "Pantoprazole 40mg",
      genericName: "Pantoprazole",
      strength: "40mg",
      dosageForm: "Tablet",
      manufacturer: "Sun Pharma",
      batchNumber: "BATCH004",
      expiryDate: "2025-11-20",
      availableStock: 120,
      unitPrice: 42.0,
      mrp: 48.0,
      isPrescriptionRequired: true,
      category: "PPI",
    },
    {
      id: "5",
      name: "Cetirizine 10mg",
      genericName: "Cetirizine",
      strength: "10mg",
      dosageForm: "Tablet",
      manufacturer: "UCB",
      batchNumber: "BATCH005",
      expiryDate: "2025-11-20",
      availableStock: 200,
      unitPrice: 24.0,
      mrp: 28.0,
      isPrescriptionRequired: false,
      category: "Antihistamine",
    },
  ]

  const mockPrescription: Prescription = {
    id: "RX001234",
    patient: {
      id: "P001",
      name: "Rajesh Kumar",
      phone: "+91 9876543210",
      age: 45,
      gender: "Male",
      address: "123 Main Street, Delhi",
    },
    doctorName: "Dr. Sharma",
    department: "General Medicine",
    prescriptionDate: "2024-01-20",
    diagnosis: "Fever and headache with gastric issues",
    items: [
      {
        id: "1",
        medicineId: "1",
        medicine: mockMedicines[0],
        quantityPrescribed: 10,
        quantityDispensed: 10,
        dosageInstructions: "Take 1 tablet twice daily after meals",
        frequency: "1-0-1",
        duration: "5 days",
        isPartialDispensing: false,
        partialReason: "",
        isSubstitute: false,
        substituteReason: "",
      },
      {
        id: "2",
        medicineId: "2",
        medicine: mockMedicines[1],
        quantityPrescribed: 21,
        quantityDispensed: 21,
        dosageInstructions: "Take 1 capsule three times daily before meals",
        frequency: "1-1-1",
        duration: "7 days",
        isPartialDispensing: false,
        partialReason: "",
        isSubstitute: false,
        substituteReason: "",
      },
      {
        id: "3",
        medicineId: "3",
        medicine: mockMedicines[2],
        quantityPrescribed: 14,
        quantityDispensed: 0,
        dosageInstructions: "Take 1 capsule once daily before breakfast",
        frequency: "1-0-0",
        duration: "14 days",
        isPartialDispensing: false,
        partialReason: "Out of stock - expected delivery tomorrow",
        isSubstitute: false,
        substituteReason: "",
      },
    ],
  }

  useEffect(() => {
    calculateTotals()
  }, [prescriptionItems, paymentDetails.discountAmount])

  const handleSearchPrescription = () => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      if (searchTerm === "RX001234" || searchTerm === "P001" || searchTerm === "+91 9876543210") {
        setSelectedPrescription(mockPrescription)
        setPrescriptionItems([...mockPrescription.items])
        setSelectedCustomer(mockPrescription.patient)
      } else {
        alert("Prescription not found")
      }
      setLoading(false)
    }, 1000)
  }

  const updatePrescriptionItemQuantity = (itemId: string, quantity: number) => {
    setPrescriptionItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const maxQuantity = Math.min(item.quantityPrescribed, item.medicine.availableStock)
          const newQuantity = Math.max(0, Math.min(quantity, maxQuantity))
          return {
            ...item,
            quantityDispensed: newQuantity,
            isPartialDispensing: newQuantity < item.quantityPrescribed && newQuantity > 0,
          }
        }
        return item
      }),
    )
  }

  const addAdditionalQuantity = (itemId: string, additionalQty: number, reason: string) => {
    setPrescriptionItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const maxAdditional = item.medicine.availableStock - item.quantityDispensed
          const safeAdditional = Math.min(additionalQty, maxAdditional)
          return {
            ...item,
            additionalQuantity: safeAdditional,
            additionalReason: reason,
            quantityDispensed: item.quantityDispensed + safeAdditional,
          }
        }
        return item
      }),
    )
  }

  const getAlternativeMedicines = (medicine: Medicine): Medicine[] => {
    return mockMedicines
      .filter(
        (med) =>
          med.id !== medicine.id &&
          (med.genericName === medicine.genericName || med.category === medicine.category) &&
          med.availableStock > 0,
      )
      .slice(0, 3)
  }

  const substituteWithAlternative = (itemId: string, alternativeMedicine: Medicine, reason: string) => {
    setPrescriptionItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          return {
            ...item,
            isSubstitute: true,
            substituteMedicine: alternativeMedicine,
            substituteReason: reason,
            quantityDispensed: Math.min(item.quantityPrescribed, alternativeMedicine.availableStock),
            medicine: alternativeMedicine, // Update the medicine for pricing
          }
        }
        return item
      }),
    )

    alert(`Medicine substituted with ${alternativeMedicine.name}`)
  }

  const calculateTotals = () => {
    const subtotal = prescriptionItems.reduce((sum, item) => sum + item.quantityDispensed * item.medicine.unitPrice, 0)
    const taxAmount = (subtotal - paymentDetails.discountAmount) * 0.12 // 12% GST
    const totalAmount = subtotal - paymentDetails.discountAmount + taxAmount

    setPaymentDetails((prev) => ({
      ...prev,
      subtotal,
      taxAmount,
      totalAmount,
    }))
  }

  const applyDiscount = (amount: number, reason: string) => {
    const percentage = (amount / paymentDetails.subtotal) * 100
    setPaymentDetails((prev) => ({
      ...prev,
      discountAmount: amount,
      discountPercentage: percentage,
      discountReason: reason,
    }))
    setShowDiscountDialog(false)
  }

  const processPayment = async () => {
    setLoading(true)

    setTimeout(async () => {
      try {
        const receiptNumber = `RCP${Date.now()}`

        // Send WhatsApp receipt
        await sendWhatsAppReceipt(receiptNumber)

        // Update medication tracking for reminders
        if (selectedCustomer) {
          await updateMedicationTracking()
        }

        // Create follow-up tasks for partial dispensing
        await createFollowUpTasks()

        alert(`Payment successful! Receipt ${receiptNumber} sent to WhatsApp.`)

        // Reset form
        resetForm()
        setShowPaymentDialog(false)
      } catch (error) {
        alert("Payment failed. Please try again.")
      }
      setLoading(false)
    }, 2000)
  }

  const sendWhatsAppReceipt = async (receiptNumber: string) => {
    const customer = selectedCustomer
    if (!customer) return

    const dispensedItems = prescriptionItems.filter((item) => item.quantityDispensed > 0)

    const message = `
🏥 PRANAM HOSPITAL - PHARMACY RECEIPT

Receipt No: ${receiptNumber}
Date: ${new Date().toLocaleDateString()}
Time: ${new Date().toLocaleTimeString()}

Patient: ${customer.name}
Phone: ${customer.phone}
Prescription: ${selectedPrescription?.id}
Doctor: ${selectedPrescription?.doctorName}

DISPENSED MEDICINES:
${dispensedItems
  .map(
    (item, index) =>
      `${index + 1}. ${item.medicine.name}${item.isSubstitute ? ` (Substitute for ${item.medicine.name})` : ""}
   Qty: ${item.quantityDispensed}${item.additionalQuantity ? ` (${item.quantityPrescribed} prescribed + ${item.additionalQuantity} additional)` : ""} 
   Price: ₹${(item.quantityDispensed * item.medicine.unitPrice).toFixed(2)}
   Instructions: ${item.dosageInstructions}${item.isSubstitute ? `\n   Substitute Reason: ${item.substituteReason}` : ""}${item.additionalQuantity ? `\n   Additional Reason: ${item.additionalReason}` : ""}`,
  )
  .join("\n\n")}

${
  prescriptionItems.some((item) => item.isPartialDispensing)
    ? `\n⚠️ PARTIAL DISPENSING NOTICE:
Some medicines were partially dispensed. We will contact you when remaining medicines are available.`
    : ""
}

BILLING SUMMARY:
Subtotal: ₹${paymentDetails.subtotal.toFixed(2)}
${paymentDetails.discountAmount > 0 ? `Discount (${paymentDetails.discountReason}): -₹${paymentDetails.discountAmount.toFixed(2)}` : ""}
Tax (12% GST): ₹${paymentDetails.taxAmount.toFixed(2)}
TOTAL PAID: ₹${paymentDetails.totalAmount.toFixed(2)}
Payment Method: ${paymentDetails.paymentMethod}

Thank you for choosing Pranam Hospital!
For queries: +91-XXXXXXXXXX

📱 You will receive medication reminders via WhatsApp when it's time to complete your course.
    `.trim()

    console.log("Sending WhatsApp receipt:", message)
    // In real implementation, call WhatsApp API
  }

  const updateMedicationTracking = async () => {
    const dispensedItems = prescriptionItems.filter((item) => item.quantityDispensed > 0)

    for (const item of dispensedItems) {
      const dailyDosage = item.frequency.split("-").reduce((sum, dose) => sum + Number.parseInt(dose), 0)
      const durationDays = Math.ceil(item.quantityDispensed / dailyDosage)

      const trackingData = {
        patientId: selectedCustomer!.id,
        patientName: selectedCustomer!.name,
        patientPhone: selectedCustomer!.phone,
        medicineId: item.medicine.id,
        medicineName: item.medicine.name,
        startDate: new Date().toISOString().split("T")[0],
        endDate: new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        durationDays,
        dailyDosage,
        totalQuantity: item.quantityDispensed,
        reminderScheduled: true,
      }

      console.log("Creating medication tracking:", trackingData)
      // In real implementation, save to database and schedule WhatsApp reminders
    }
  }

  const createFollowUpTasks = async () => {
    const partialItems = prescriptionItems.filter((item) => item.isPartialDispensing)

    if (partialItems.length > 0) {
      const followUpTask = {
        patientId: selectedCustomer!.id,
        patientName: selectedCustomer!.name,
        patientPhone: selectedCustomer!.phone,
        prescriptionId: selectedPrescription!.id,
        taskType: "partial_dispensing_followup",
        pendingMedicines: partialItems.map((item) => ({
          medicineName: item.medicine.name,
          pendingQuantity: item.quantityPrescribed - item.quantityDispensed,
          reason: item.partialReason,
        })),
        assignedTo: "telecaller",
        priority: "medium",
        dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow
      }

      console.log("Creating follow-up task:", followUpTask)
      // In real implementation, save to database and notify telecaller
    }
  }

  const resetForm = () => {
    setSelectedPrescription(null)
    setPrescriptionItems([])
    setSelectedCustomer(null)
    setSearchTerm("")
    setPaymentDetails({
      subtotal: 0,
      discountAmount: 0,
      discountPercentage: 0,
      discountReason: "",
      taxAmount: 0,
      totalAmount: 0,
      paymentMethod: "",
      paidAmount: 0,
      changeAmount: 0,
    })
  }

  const handleCreatePatient = async () => {
    if (!newPatient.name || !newPatient.phone || !newPatient.age || !newPatient.gender || !newPatient.address) {
      alert("Please fill all required fields")
      return
    }

    setCreatingPatient(true)

    setTimeout(() => {
      const patientId = `P${Date.now()}`
      const createdPatient = {
        id: patientId,
        name: newPatient.name,
        phone: newPatient.phone,
        age: newPatient.age,
        gender: newPatient.gender,
        address: newPatient.address,
        emergencyContact: newPatient.emergencyContact,
        createdAt: new Date().toISOString(),
        registrationNumber: `REG${Date.now()}`,
      }

      setSelectedCustomer(createdPatient)
      setNewPatient({ name: "", phone: "", age: 0, gender: "", address: "", emergencyContact: "" })
      setShowCreatePatientDialog(false)
      setCreatingPatient(false)

      alert(`Patient created successfully! Patient ID: ${patientId}`)
    }, 1500)
  }

  return (
    <PrivateRoute modulePath="admin/pharmacy/dispensing" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Prescription Dispensing</h1>
          <p className="text-gray-600">Process prescriptions with partial dispensing and alternatives</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={resetForm}>
            <XCircle className="h-4 w-4 mr-2" />
            Clear All
          </Button>
          <Button>
            <Save className="h-4 w-4 mr-2" />
            Save Draft
          </Button>
        </div>
      </div>

      {/* Search Prescription */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="h-5 w-5 mr-2 text-blue-600" />
            Search Prescription
          </CardTitle>
          <CardDescription>Enter prescription ID, patient ID, or phone number</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="RX001234, P001, or +91 9876543210"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button onClick={handleSearchPrescription} disabled={loading}>
              {loading ? "Searching..." : "Search"}
            </Button>
            <Button variant="outline" onClick={() => setShowCreatePatientDialog(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Patient
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Prescription Details */}
      {selectedPrescription && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Patient Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2 text-blue-600" />
                Patient Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-sm font-medium">Name</Label>
                <p className="text-lg font-semibold">{selectedPrescription.patient.name}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Patient ID</Label>
                  <p>{selectedPrescription.patient.id}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Age/Gender</Label>
                  <p>
                    {selectedPrescription.patient.age}Y, {selectedPrescription.patient.gender}
                  </p>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">Phone</Label>
                <p className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  {selectedPrescription.patient.phone}
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Address</Label>
                <p className="text-sm">{selectedPrescription.patient.address}</p>
              </div>
              <Separator />
              <div>
                <Label className="text-sm font-medium">Doctor</Label>
                <p>{selectedPrescription.doctorName}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Department</Label>
                <p>{selectedPrescription.department}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Date</Label>
                <p className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  {selectedPrescription.prescriptionDate}
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Diagnosis</Label>
                <p className="text-sm">{selectedPrescription.diagnosis}</p>
              </div>
            </CardContent>
          </Card>

          {/* Medicine List */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center">
                  <Pill className="h-5 w-5 mr-2 text-green-600" />
                  Prescribed Medicines ({prescriptionItems.length})
                </span>
                <Badge variant="outline">
                  {prescriptionItems.filter((item) => item.quantityDispensed > 0).length} dispensing
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {prescriptionItems.map((item) => (
                  <div key={item.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">
                          {item.isSubstitute && item.substituteMedicine
                            ? `${item.substituteMedicine.name} (Substitute)`
                            : item.medicine.name}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {item.medicine.genericName} • {item.medicine.manufacturer}
                        </p>
                        <p className="text-sm text-gray-500">
                          Batch: {item.medicine.batchNumber} • Exp: {item.medicine.expiryDate}
                        </p>
                        {item.isSubstitute && (
                          <p className="text-sm text-orange-600 mt-1">
                            <Zap className="h-3 w-3 inline mr-1" />
                            Substituted: {item.substituteReason}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        {item.medicine.availableStock > 0 ? (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Available ({item.medicine.availableStock})
                          </Badge>
                        ) : (
                          <Badge className="bg-red-100 text-red-800">
                            <XCircle className="h-3 w-3 mr-1" />
                            Out of Stock
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Dosage Instructions */}
                    <div className="bg-blue-50 p-3 rounded-lg mb-3">
                      <p className="text-sm font-medium text-blue-800">Dosage Instructions:</p>
                      <p className="text-sm text-blue-700">{item.dosageInstructions}</p>
                      <p className="text-xs text-blue-600">
                        Frequency: {item.frequency} • Duration: {item.duration}
                      </p>
                    </div>

                    {/* Quantity Controls */}
                    <div className="grid grid-cols-4 gap-4 items-center mb-3">
                      <div className="text-center">
                        <Label className="text-sm">Prescribed</Label>
                        <p className="text-lg font-bold text-blue-600">{item.quantityPrescribed}</p>
                      </div>
                      <div className="text-center">
                        <Label className="text-sm">Available</Label>
                        <p className="text-lg font-bold text-green-600">{item.medicine.availableStock}</p>
                      </div>
                      <div className="text-center">
                        <Label className="text-sm">Dispensing</Label>
                        <div className="flex items-center justify-center space-x-2 mt-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updatePrescriptionItemQuantity(item.id, item.quantityDispensed - 1)}
                            disabled={item.quantityDispensed === 0}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <Input
                            type="number"
                            value={item.quantityDispensed}
                            onChange={(e) =>
                              updatePrescriptionItemQuantity(item.id, Number.parseInt(e.target.value) || 0)
                            }
                            className="w-16 text-center h-8"
                            min="0"
                            max={Math.min(item.quantityPrescribed, item.medicine.availableStock)}
                          />
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updatePrescriptionItemQuantity(item.id, item.quantityDispensed + 1)}
                            disabled={
                              item.quantityDispensed >= Math.min(item.quantityPrescribed, item.medicine.availableStock)
                            }
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="text-center">
                        <Label className="text-sm">Total Price</Label>
                        <p className="text-lg font-bold text-orange-600">
                          ₹{(item.quantityDispensed * item.medicine.unitPrice).toFixed(2)}
                        </p>
                        <p className="text-xs text-gray-500">₹{item.medicine.unitPrice}/unit</p>
                      </div>
                    </div>

                    {/* Partial Dispensing Alert */}
                    {item.isPartialDispensing && (
                      <Alert className="border-yellow-300 bg-yellow-50 mb-3">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <AlertDescription className="text-yellow-800">
                          <strong>Partial Dispensing:</strong> Only {item.quantityDispensed} of{" "}
                          {item.quantityPrescribed} units dispensed.
                          {item.partialReason && <span> Reason: {item.partialReason}</span>}
                        </AlertDescription>
                      </Alert>
                    )}

                    {/* Out of Stock Alert with Alternatives */}
                    {item.medicine.availableStock === 0 && (
                      <div className="space-y-3">
                        <Alert className="border-red-300 bg-red-50">
                          <XCircle className="h-4 w-4 text-red-600" />
                          <AlertDescription className="text-red-800">
                            <strong>Out of Stock:</strong> This medicine is currently unavailable.
                            {item.partialReason && <span> {item.partialReason}</span>}
                          </AlertDescription>
                        </Alert>

                        {/* Alternative Medicine Suggestions */}
                        <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                          <h4 className="font-medium text-green-800 mb-2 flex items-center">
                            <Zap className="h-4 w-4 mr-2" />
                            AI-Suggested Alternative Medicines
                          </h4>
                          <div className="space-y-2">
                            {getAlternativeMedicines(item.medicine).map((altMed) => (
                              <div
                                key={altMed.id}
                                className="flex items-center justify-between p-2 bg-white rounded border"
                              >
                                <div className="flex-1">
                                  <p className="font-medium text-sm">{altMed.name}</p>
                                  <p className="text-xs text-gray-600">
                                    {altMed.genericName} • {altMed.manufacturer}
                                  </p>
                                  <p className="text-xs text-green-600">
                                    Stock: {altMed.availableStock} • ₹{altMed.unitPrice}/unit
                                  </p>
                                </div>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() =>
                                    substituteWithAlternative(
                                      item.id,
                                      altMed,
                                      `Original medicine unavailable. Substituted with therapeutic equivalent.`,
                                    )
                                  }
                                  className="text-green-700 border-green-300 hover:bg-green-100"
                                >
                                  Use Alternative
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Additional Quantity Option */}
                    {item.quantityDispensed > 0 && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <p className="text-sm font-medium">Patient wants additional quantity?</p>
                            <p className="text-xs text-gray-600">Sell more than prescribed amount</p>
                          </div>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline">
                                <Plus className="h-4 w-4 mr-1" />
                                Add Extra
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Add Additional Quantity</DialogTitle>
                                <DialogDescription>
                                  Add extra quantity beyond prescribed amount for {item.medicine.name}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Additional Quantity</Label>
                                  <Input
                                    type="number"
                                    placeholder="Enter additional quantity"
                                    max={item.medicine.availableStock - item.quantityDispensed}
                                  />
                                </div>
                                <div>
                                  <Label>Reason</Label>
                                  <Select>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select reason" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="patient_request">Patient Request</SelectItem>
                                      <SelectItem value="doctor_verbal">Doctor Verbal Instruction</SelectItem>
                                      <SelectItem value="emergency_stock">Emergency Stock</SelectItem>
                                      <SelectItem value="travel">Travel Purpose</SelectItem>
                                      <SelectItem value="other">Other</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                              <DialogFooter>
                                <Button
                                  onClick={() => {
                                    const qty = 5 // This would come from the input
                                    const reason = "Patient Request" // This would come from the select
                                    addAdditionalQuantity(item.id, qty, reason)
                                  }}
                                >
                                  Add Quantity
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                        {item.additionalQuantity && (
                          <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                            <strong>Additional:</strong> {item.additionalQuantity} units added - {item.additionalReason}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Billing Section */}
      {prescriptionItems.some((item) => item.quantityDispensed > 0) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center">
                <Calculator className="h-5 w-5 mr-2 text-purple-600" />
                Billing Summary
              </span>
              <div className="flex space-x-2">
                <Dialog open={showDiscountDialog} onOpenChange={setShowDiscountDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Percent className="h-4 w-4 mr-2" />
                      Apply Discount
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Apply Discount</DialogTitle>
                      <DialogDescription>Apply discount to the current prescription</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label>Discount Amount</Label>
                        <Input
                          type="number"
                          placeholder="0.00"
                          onChange={(e) => {
                            const amount = Number.parseFloat(e.target.value) || 0
                            applyDiscount(amount, paymentDetails.discountReason || "Manual discount")
                          }}
                        />
                      </div>
                      <div>
                        <Label>Discount Reason</Label>
                        <Select
                          onValueChange={(value) => setPaymentDetails((prev) => ({ ...prev, discountReason: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select reason" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="senior_citizen">Senior Citizen (10%)</SelectItem>
                            <SelectItem value="employee">Employee Discount (20%)</SelectItem>
                            <SelectItem value="insurance">Insurance Coverage</SelectItem>
                            <SelectItem value="promotional">Promotional Offer</SelectItem>
                            <SelectItem value="loyalty">Loyalty Discount</SelectItem>
                            <SelectItem value="bulk">Bulk Purchase</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button onClick={() => setShowDiscountDialog(false)}>Apply</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                <Button onClick={() => setShowPaymentDialog(true)}>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Process Payment
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Bill Breakdown */}
              <div className="space-y-3">
                <div className="flex justify-between text-lg">
                  <span>Subtotal:</span>
                  <span>₹{paymentDetails.subtotal.toFixed(2)}</span>
                </div>
                {paymentDetails.discountAmount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount ({paymentDetails.discountPercentage.toFixed(1)}%):</span>
                    <span>-₹{paymentDetails.discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Tax (12% GST):</span>
                  <span>₹{paymentDetails.taxAmount.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-xl font-bold">
                  <span>Total Amount:</span>
                  <span className="text-green-600">₹{paymentDetails.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              {/* Summary Info */}
              <div className="space-y-3 text-sm">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="font-medium text-blue-800">Prescription Summary</p>
                  <p className="text-blue-700">
                    {prescriptionItems.filter((item) => item.quantityDispensed > 0).length} medicines dispensed
                  </p>
                  {prescriptionItems.some((item) => item.isPartialDispensing) && (
                    <p className="text-orange-600 mt-1">⚠️ Partial dispensing - follow-up scheduled</p>
                  )}
                  {prescriptionItems.some((item) => item.isSubstitute) && (
                    <p className="text-purple-600 mt-1">🔄 Alternative medicines used</p>
                  )}
                  {prescriptionItems.some((item) => item.additionalQuantity) && (
                    <p className="text-green-600 mt-1">➕ Additional quantities added</p>
                  )}
                </div>

                {paymentDetails.discountAmount > 0 && (
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="font-medium text-green-800">Discount Applied</p>
                    <p className="text-green-700">{paymentDetails.discountReason}</p>
                    <p className="text-green-600">Savings: ₹{paymentDetails.discountAmount.toFixed(2)}</p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2" />
              Process Payment
            </DialogTitle>
            <DialogDescription>Total Amount: ₹{paymentDetails.totalAmount.toFixed(2)}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Payment Method *</Label>
              <Select
                value={paymentDetails.paymentMethod}
                onValueChange={(value) => setPaymentDetails((prev) => ({ ...prev, paymentMethod: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="card">Credit/Debit Card</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="insurance">Insurance</SelectItem>
                  <SelectItem value="credit">Credit Account</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {paymentDetails.paymentMethod === "cash" && (
              <div>
                <Label>Amount Received</Label>
                <Input
                  type="number"
                  value={paymentDetails.paidAmount}
                  onChange={(e) => {
                    const paidAmount = Number.parseFloat(e.target.value) || 0
                    const changeAmount = Math.max(0, paidAmount - paymentDetails.totalAmount)
                    setPaymentDetails((prev) => ({ ...prev, paidAmount, changeAmount }))
                  }}
                  placeholder={paymentDetails.totalAmount.toFixed(2)}
                />
                {paymentDetails.changeAmount > 0 && (
                  <p className="text-sm text-green-600 mt-1">
                    Change to return: ₹{paymentDetails.changeAmount.toFixed(2)}
                  </p>
                )}
              </div>
            )}

            <Separator />

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox id="whatsapp" defaultChecked />
                <Label htmlFor="whatsapp" className="flex items-center text-sm">
                  <MessageSquare className="h-4 w-4 mr-2 text-green-600" />
                  Send receipt via WhatsApp
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="print" />
                <Label htmlFor="print" className="flex items-center text-sm">
                  <Printer className="h-4 w-4 mr-2 text-gray-600" />
                  Print receipt
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="reminders" defaultChecked />
                <Label htmlFor="reminders" className="flex items-center text-sm">
                  <Bell className="h-4 w-4 mr-2 text-blue-600" />
                  Enable medication reminders
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="followup" defaultChecked />
                <Label htmlFor="followup" className="flex items-center text-sm">
                  <Phone className="h-4 w-4 mr-2 text-orange-600" />
                  Schedule follow-up for partial dispensing
                </Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPaymentDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={processPayment}
              disabled={
                loading ||
                !paymentDetails.paymentMethod ||
                (paymentDetails.paymentMethod === "cash" && paymentDetails.paidAmount < paymentDetails.totalAmount)
              }
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Processing...
                </>
              ) : (
                <>
                  <Receipt className="h-4 w-4 mr-2" />
                  Complete Payment
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create New Patient Dialog */}
      <Dialog open={showCreatePatientDialog} onOpenChange={setShowCreatePatientDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Patient</DialogTitle>
            <DialogDescription>Add a new patient to the system</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Patient Name *</Label>
              <Input
                placeholder="Enter patient name"
                value={newPatient.name}
                onChange={(e) => setNewPatient((prev) => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label>Phone Number *</Label>
              <Input
                placeholder="+91 XXXXXXXXXX"
                value={newPatient.phone}
                onChange={(e) => setNewPatient((prev) => ({ ...prev, phone: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Age *</Label>
                <Input
                  type="number"
                  placeholder="25"
                  value={newPatient.age}
                  onChange={(e) => setNewPatient((prev) => ({ ...prev, age: Number.parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div>
                <Label>Gender *</Label>
                <Select onValueChange={(value) => setNewPatient((prev) => ({ ...prev, gender: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Address *</Label>
              <Textarea
                placeholder="Enter complete address"
                value={newPatient.address}
                onChange={(e) => setNewPatient((prev) => ({ ...prev, address: e.target.value }))}
                rows={3}
              />
            </div>
            <div>
              <Label>Emergency Contact (Optional)</Label>
              <Input
                placeholder="+91 XXXXXXXXXX"
                value={newPatient.emergencyContact}
                onChange={(e) => setNewPatient((prev) => ({ ...prev, emergencyContact: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreatePatientDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreatePatient} disabled={creatingPatient}>
              {creatingPatient ? "Creating..." : "Create Patient"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      </div>
    </PrivateRoute>
  )
}

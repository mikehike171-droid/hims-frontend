"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Search,
  ShoppingCart,
  CreditCard,
  Printer,
  MessageSquare,
  AlertTriangle,
  Package,
  Calculator,
  Phone,
  Plus,
  Minus,
  Receipt,
  XCircle,
  Users,
  Percent,
  Zap,
} from "lucide-react"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface Medicine {
  id: string
  name: string
  genericName: string
  strength: string
  dosageForm: string
  manufacturer: string
  batchNumber: string
  expiryDate: string
  availableStock: number
  unitPrice: number
  mrp: number
  isPrescriptionRequired: boolean
  category: string
}

interface SaleItem {
  id: string
  medicine: Medicine
  quantity: number
  unitPrice: number
  totalPrice: number
}

interface Customer {
  id?: string
  name: string
  phone: string
  address: string
  age?: number
  gender?: string
}

interface PaymentDetails {
  subtotal: number
  discountAmount: number
  discountPercentage: number
  discountReason: string
  taxAmount: number
  totalAmount: number
  paymentMethod: string
  paidAmount: number
  changeAmount: number
}

export default function PharmacySales() {
  const [searchTerm, setSearchTerm] = useState("")
  const [medicineSearchTerm, setMedicineSearchTerm] = useState("")
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const [newCustomer, setNewCustomer] = useState<Customer>({
    name: "",
    phone: "",
    address: "",
  })
  const [saleItems, setSaleItems] = useState<SaleItem[]>([])
  const [availableMedicines, setAvailableMedicines] = useState<Medicine[]>([])
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails>({
    subtotal: 0,
    discountAmount: 0,
    discountPercentage: 0,
    discountReason: "",
    taxAmount: 0,
    totalAmount: 0,
    paymentMethod: "",
    paidAmount: 0,
    changeAmount: 0,
  })
  const [showPaymentDialog, setShowPaymentDialog] = useState(false)
  const [showDiscountDialog, setShowDiscountDialog] = useState(false)
  const [loading, setLoading] = useState(false)
  const [searchingCustomer, setSearchingCustomer] = useState(false)
  const [showCreatePatientDialog, setShowCreatePatientDialog] = useState(false)
  const [creatingPatient, setCreatingPatient] = useState(false)
  const [newPatientData, setNewPatientData] = useState({
    name: "",
    phone: "",
    age: 0,
    gender: "",
    address: "",
    emergencyContact: "",
  })

  // Mock data with alternatives
  const mockMedicines: Medicine[] = [
    {
      id: "1",
      name: "Paracetamol 500mg",
      genericName: "Paracetamol",
      strength: "500mg",
      dosageForm: "Tablet",
      manufacturer: "GSK",
      batchNumber: "BATCH001",
      expiryDate: "2025-12-31",
      availableStock: 150,
      unitPrice: 22.0,
      mrp: 25.0,
      isPrescriptionRequired: false,
      category: "Analgesic",
    },
    {
      id: "2",
      name: "Cetirizine 10mg",
      genericName: "Cetirizine",
      strength: "10mg",
      dosageForm: "Tablet",
      manufacturer: "UCB",
      batchNumber: "BATCH002",
      expiryDate: "2025-11-20",
      availableStock: 200,
      unitPrice: 24.0,
      mrp: 28.0,
      isPrescriptionRequired: false,
      category: "Antihistamine",
    },
    {
      id: "3",
      name: "Vitamin D3 60K",
      genericName: "Cholecalciferol",
      strength: "60000 IU",
      dosageForm: "Capsule",
      manufacturer: "Sun Pharma",
      batchNumber: "BATCH003",
      expiryDate: "2025-08-15",
      availableStock: 0,
      unitPrice: 45.0,
      mrp: 52.0,
      isPrescriptionRequired: false,
      category: "Vitamin",
    },
    {
      id: "4",
      name: "Vitamin D3 1000 IU",
      genericName: "Cholecalciferol",
      strength: "1000 IU",
      dosageForm: "Tablet",
      manufacturer: "Cipla",
      batchNumber: "BATCH004",
      expiryDate: "2025-10-30",
      availableStock: 85,
      unitPrice: 35.0,
      mrp: 40.0,
      isPrescriptionRequired: false,
      category: "Vitamin",
    },
    {
      id: "5",
      name: "Cough Syrup",
      genericName: "Dextromethorphan",
      strength: "100ml",
      dosageForm: "Syrup",
      manufacturer: "Cipla",
      batchNumber: "BATCH005",
      expiryDate: "2025-06-30",
      availableStock: 3,
      unitPrice: 85.0,
      mrp: 95.0,
      isPrescriptionRequired: false,
      category: "Cough & Cold",
    },
  ]

  const mockCustomer = {
    id: "C001",
    name: "Rajesh Kumar",
    phone: "+91 9876543210",
    address: "123 Main Street, Delhi",
    age: 45,
    gender: "Male",
  }

  useEffect(() => {
    setAvailableMedicines(mockMedicines)
  }, [])

  useEffect(() => {
    calculateTotals()
  }, [saleItems, paymentDetails.discountAmount])

  const handleSearchCustomer = () => {
    setSearchingCustomer(true)
    // Simulate API call
    setTimeout(() => {
      if (searchTerm === "C001" || searchTerm === "+91 9876543210" || searchTerm.toLowerCase().includes("rajesh")) {
        setSelectedCustomer(mockCustomer)
        setNewCustomer({ name: "", phone: "", address: "" })
      } else {
        alert("Customer not found")
      }
      setSearchingCustomer(false)
    }, 1000)
  }

  const addMedicineToCart = (medicine: Medicine) => {
    const existingItem = saleItems.find((item) => item.medicine.id === medicine.id)
    if (existingItem) {
      updateItemQuantity(existingItem.id, existingItem.quantity + 1)
    } else {
      const newItem: SaleItem = {
        id: Date.now().toString(),
        medicine,
        quantity: 1,
        unitPrice: medicine.unitPrice,
        totalPrice: medicine.unitPrice,
      }
      setSaleItems((prev) => [...prev, newItem])
    }
  }

  const updateItemQuantity = (itemId: string, quantity: number) => {
    setSaleItems((prev) =>
      prev
        .map((item) => {
          if (item.id === itemId) {
            const maxQuantity = item.medicine.availableStock
            const newQuantity = Math.max(0, Math.min(quantity, maxQuantity))
            return {
              ...item,
              quantity: newQuantity,
              totalPrice: newQuantity * item.unitPrice,
            }
          }
          return item
        })
        .filter((item) => item.quantity > 0),
    )
  }

  const removeItem = (itemId: string) => {
    setSaleItems((prev) => prev.filter((item) => item.id !== itemId))
  }

  const calculateTotals = () => {
    const subtotal = saleItems.reduce((sum, item) => sum + item.totalPrice, 0)
    const taxAmount = (subtotal - paymentDetails.discountAmount) * 0.12 // 12% GST
    const totalAmount = subtotal - paymentDetails.discountAmount + taxAmount

    setPaymentDetails((prev) => ({
      ...prev,
      subtotal,
      taxAmount,
      totalAmount,
    }))
  }

  const applyDiscount = (amount: number, reason: string) => {
    const percentage = (amount / paymentDetails.subtotal) * 100
    setPaymentDetails((prev) => ({
      ...prev,
      discountAmount: amount,
      discountPercentage: percentage,
      discountReason: reason,
    }))
    setShowDiscountDialog(false)
  }

  const processPayment = async () => {
    setLoading(true)

    // Validate customer information
    const customer = selectedCustomer || newCustomer
    if (!customer.name || !customer.phone) {
      alert("Please provide customer name and phone number")
      setLoading(false)
      return
    }

    // Simulate payment processing
    setTimeout(async () => {
      try {
        // Generate receipt
        const receiptNumber = `RCP${Date.now()}`

        // Send WhatsApp receipt
        await sendWhatsAppReceipt(receiptNumber, customer)

        // Update inventory
        await updateInventory()

        alert(`Payment successful! Receipt ${receiptNumber} sent to WhatsApp.`)

        // Reset form
        resetForm()
        setShowPaymentDialog(false)
      } catch (error) {
        alert("Payment failed. Please try again.")
      }
      setLoading(false)
    }, 2000)
  }

  const sendWhatsAppReceipt = async (receiptNumber: string, customer: Customer) => {
    const message = `
🏥 PRANAM HOSPITAL - PHARMACY RECEIPT

Receipt No: ${receiptNumber}
Date: ${new Date().toLocaleDateString()}
Time: ${new Date().toLocaleTimeString()}

Customer: ${customer.name}
Phone: ${customer.phone}
${customer.address ? `Address: ${customer.address}` : ""}

DIRECT SALE - MEDICINES:
${saleItems
  .map(
    (item, index) =>
      `${index + 1}. ${item.medicine.name}
   Qty: ${item.quantity} x ₹${item.unitPrice} = ₹${item.totalPrice.toFixed(2)}
   Batch: ${item.medicine.batchNumber} | Exp: ${item.medicine.expiryDate}`,
  )
  .join("\n\n")}

BILLING SUMMARY:
Subtotal: ₹${paymentDetails.subtotal.toFixed(2)}
${paymentDetails.discountAmount > 0 ? `Discount (${paymentDetails.discountReason}): -₹${paymentDetails.discountAmount.toFixed(2)}` : ""}
Tax (12% GST): ₹${paymentDetails.taxAmount.toFixed(2)}
TOTAL PAID: ₹${paymentDetails.totalAmount.toFixed(2)}
Payment Method: ${paymentDetails.paymentMethod}
${paymentDetails.changeAmount > 0 ? `Change Returned: ₹${paymentDetails.changeAmount.toFixed(2)}` : ""}

Thank you for choosing Pranam Hospital!
For queries: +91-XXXXXXXXXX
    `.trim()

    console.log("Sending WhatsApp message:", message)
    // In real implementation, call WhatsApp API
  }

  const updateInventory = async () => {
    for (const item of saleItems) {
      console.log(`Updating inventory: ${item.medicine.name} - ${item.quantity} units sold`)
      // In real implementation, update database
    }
  }

  const resetForm = () => {
    setSelectedCustomer(null)
    setNewCustomer({ name: "", phone: "", address: "" })
    setSaleItems([])
    setSearchTerm("")
    setMedicineSearchTerm("")
    setPaymentDetails({
      subtotal: 0,
      discountAmount: 0,
      discountPercentage: 0,
      discountReason: "",
      taxAmount: 0,
      totalAmount: 0,
      paymentMethod: "",
      paidAmount: 0,
      changeAmount: 0,
    })
  }

  const filteredMedicines = availableMedicines.filter(
    (medicine) =>
      medicine.name.toLowerCase().includes(medicineSearchTerm.toLowerCase()) ||
      medicine.genericName.toLowerCase().includes(medicineSearchTerm.toLowerCase()) ||
      medicine.category.toLowerCase().includes(medicineSearchTerm.toLowerCase()),
  )

  const getAlternativeMedicinesForSale = (medicine: Medicine): Medicine[] => {
    return availableMedicines
      .filter(
        (med) =>
          med.id !== medicine.id &&
          (med.genericName === medicine.genericName || med.category === medicine.category) &&
          med.availableStock > 0 &&
          !med.isPrescriptionRequired,
      )
      .slice(0, 3)
  }

  const handleCreateNewPatient = async () => {
    if (
      !newPatientData.name ||
      !newPatientData.phone ||
      !newPatientData.age ||
      !newPatientData.gender ||
      !newPatientData.address
    ) {
      alert("Please fill all required fields")
      return
    }

    setCreatingPatient(true)

    // Simulate API call to create patient
    setTimeout(() => {
      const patientId = `P${Date.now()}`
      const createdPatient = {
        id: patientId,
        name: newPatientData.name,
        phone: newPatientData.phone,
        age: newPatientData.age,
        gender: newPatientData.gender,
        address: newPatientData.address,
        emergencyContact: newPatientData.emergencyContact,
        createdAt: new Date().toISOString(),
        registrationNumber: `REG${Date.now()}`,
      }

      setSelectedCustomer(createdPatient)
      setNewPatientData({ name: "", phone: "", age: 0, gender: "", address: "", emergencyContact: "" })
      setShowCreatePatientDialog(false)
      setCreatingPatient(false)

      alert(`Patient created successfully! Patient ID: ${patientId}`)
    }, 1500)
  }

  return (
    <PrivateRoute modulePath="admin/pharmacy/sales" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Direct Medicine Sales</h1>
          <p className="text-gray-600">Sell medicines directly to customers without prescription</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={resetForm}>
            <XCircle className="h-4 w-4 mr-2" />
            Clear All
          </Button>
          <Button>
            <Receipt className="h-4 w-4 mr-2" />
            View Sales History
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Customer Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-blue-600" />
              Customer Information
            </CardTitle>
            <CardDescription>Search existing customer or add new customer details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Customer Search */}
            <div>
              <Label>Search Existing Customer</Label>
              <div className="flex space-x-2 mt-1">
                <Input
                  placeholder="Customer ID, phone, or name"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Button size="sm" onClick={handleSearchCustomer} disabled={searchingCustomer}>
                  {searchingCustomer ? "..." : <Search className="h-4 w-4" />}
                </Button>
                <Button size="sm" variant="outline" onClick={() => setShowCreatePatientDialog(true)}>
                  <Plus className="h-4 w-4 mr-1" />
                  Create New Patient
                </Button>
              </div>
            </div>

            <Separator />

            {selectedCustomer ? (
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-blue-800">{selectedCustomer.name}</h3>
                    <p className="text-sm text-blue-600">{selectedCustomer.phone}</p>
                    {selectedCustomer.address && <p className="text-sm text-blue-600">{selectedCustomer.address}</p>}
                    {"age" in selectedCustomer && selectedCustomer.age && (
                      <p className="text-xs text-blue-500">
                        {selectedCustomer.age}Y, {selectedCustomer.gender}
                      </p>
                    )}
                  </div>
                  <Button size="sm" variant="outline" onClick={() => setSelectedCustomer(null)}>
                    Change
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <Label>Customer Name *</Label>
                  <Input
                    placeholder="Enter customer name"
                    value={newCustomer.name}
                    onChange={(e) => setNewCustomer((prev) => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Phone Number *</Label>
                  <Input
                    placeholder="+91 XXXXXXXXXX"
                    value={newCustomer.phone}
                    onChange={(e) => setNewCustomer((prev) => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Address (Optional)</Label>
                  <Textarea
                    placeholder="Customer address"
                    rows={2}
                    value={newCustomer.address}
                    onChange={(e) => setNewCustomer((prev) => ({ ...prev, address: e.target.value }))}
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Medicine Selection */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Package className="h-5 w-5 mr-2 text-green-600" />
              Medicine Selection
            </CardTitle>
            <CardDescription>Search and add medicines to the cart</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search medicines by name, generic name, or category..."
                  value={medicineSearchTerm}
                  onChange={(e) => setMedicineSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="max-h-64 overflow-y-auto space-y-2">
                {filteredMedicines.map((medicine) => (
                  <div
                    key={medicine.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex-1">
                      <h4 className="font-medium">{medicine.name}</h4>
                      <p className="text-sm text-gray-600">
                        {medicine.genericName} • {medicine.manufacturer}
                      </p>
                      <div className="flex items-center space-x-4 mt-1">
                        <span
                          className={`text-sm ${
                            medicine.availableStock === 0
                              ? "text-red-600"
                              : medicine.availableStock < 10
                                ? "text-orange-600"
                                : "text-green-600"
                          }`}
                        >
                          Stock: {medicine.availableStock}
                        </span>
                        <span className="text-sm">₹{medicine.unitPrice}</span>
                        <Badge variant="outline" className="text-xs">
                          {medicine.category}
                        </Badge>
                        {medicine.isPrescriptionRequired && (
                          <Badge variant="destructive" className="text-xs">
                            Rx Required
                          </Badge>
                        )}
                      </div>

                      {/* Show alternatives when stock is low or zero */}
                      {(medicine.availableStock === 0 || medicine.availableStock < 5) && (
                        <div className="mt-2 p-2 bg-blue-50 rounded text-xs">
                          <p className="font-medium text-blue-800 flex items-center">
                            <Zap className="h-3 w-3 mr-1" />
                            Alternative Available:
                          </p>
                          {getAlternativeMedicinesForSale(medicine)
                            .slice(0, 1)
                            .map((alt) => (
                              <p key={alt.id} className="text-blue-700">
                                {alt.name} (Stock: {alt.availableStock}) - ₹{alt.unitPrice}
                              </p>
                            ))}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col space-y-2">
                      <Button
                        size="sm"
                        onClick={() => addMedicineToCart(medicine)}
                        disabled={medicine.availableStock === 0 || medicine.isPrescriptionRequired}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                      {(medicine.availableStock === 0 || medicine.availableStock < 5) &&
                        getAlternativeMedicinesForSale(medicine).length > 0 && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => addMedicineToCart(getAlternativeMedicinesForSale(medicine)[0])}
                            className="text-blue-600 border-blue-300"
                          >
                            Add Alternative
                          </Button>
                        )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Shopping Cart */}
      {saleItems.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center">
                <ShoppingCart className="h-5 w-5 mr-2 text-orange-600" />
                Shopping Cart ({saleItems.length} items)
              </span>
              <div className="flex space-x-2">
                <Dialog open={showDiscountDialog} onOpenChange={setShowDiscountDialog}>
                  <Button variant="outline" size="sm" onClick={() => setShowDiscountDialog(true)}>
                    <Percent className="h-4 w-4 mr-2" />
                    Apply Discount
                  </Button>
                </Dialog>
                <Button onClick={() => setShowPaymentDialog(true)} disabled={saleItems.length === 0}>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Proceed to Payment
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {saleItems.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium">{item.medicine.name}</h4>
                    <p className="text-sm text-gray-600">
                      {item.medicine.genericName} • ₹{item.unitPrice} per unit
                    </p>
                    <p className="text-xs text-gray-500">
                      Batch: {item.medicine.batchNumber} • Exp: {item.medicine.expiryDate}
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateItemQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateItemQuantity(item.id, Number.parseInt(e.target.value) || 0)}
                        className="w-16 text-center h-8"
                        min="1"
                        max={item.medicine.availableStock}
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateItemQuantity(item.id, item.quantity + 1)}
                        disabled={item.quantity >= item.medicine.availableStock}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <span className="font-medium w-20 text-right">₹{item.totalPrice.toFixed(2)}</span>
                    <Button size="sm" variant="outline" onClick={() => removeItem(item.id)}>
                      <XCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* Billing Summary */}
            <Separator className="my-4" />
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold text-lg mb-4 flex items-center">
                <Calculator className="h-5 w-5 mr-2 text-gray-600" />
                Billing Summary
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span className="font-medium">₹{paymentDetails.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax (12% GST):</span>
                    <span className="font-medium">₹{paymentDetails.taxAmount.toFixed(2)}</span>
                  </div>
                  {paymentDetails.discountAmount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Discount ({paymentDetails.discountReason}):</span>
                      <span className="font-medium">-₹{paymentDetails.discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total Amount:</span>
                    <span className="text-green-600">₹{paymentDetails.totalAmount.toFixed(2)}</span>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-medium text-blue-800">Transaction Summary</p>
                    <p className="text-blue-700">{saleItems.length} items • Direct Sale</p>
                    <p className="text-blue-600">
                      Customer: {selectedCustomer?.name || newCustomer.name || "Walk-in Customer"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Discount Dialog */}
      <Dialog open={showDiscountDialog} onOpenChange={setShowDiscountDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Apply Discount</DialogTitle>
            <DialogDescription>Apply discount to the current sale</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Discount Amount</Label>
              <Input
                type="number"
                placeholder="0.00"
                onChange={(e) => {
                  const amount = Number.parseFloat(e.target.value) || 0
                  applyDiscount(amount, paymentDetails.discountReason || "Manual discount")
                }}
              />
            </div>
            <div>
              <Label>Discount Reason</Label>
              <Select onValueChange={(value) => setPaymentDetails((prev) => ({ ...prev, discountReason: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select reason" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="senior_citizen">Senior Citizen (10%)</SelectItem>
                  <SelectItem value="employee">Employee Discount (20%)</SelectItem>
                  <SelectItem value="bulk_purchase">Bulk Purchase (5%)</SelectItem>
                  <SelectItem value="promotional">Promotional Offer</SelectItem>
                  <SelectItem value="loyalty">Loyalty Discount</SelectItem>
                  <SelectItem value="clearance">Clearance Sale</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowDiscountDialog(false)}>Apply</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2" />
              Process Payment
            </DialogTitle>
            <DialogDescription>Total Amount: ₹{paymentDetails.totalAmount.toFixed(2)}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Payment Method *</Label>
              <Select
                value={paymentDetails.paymentMethod}
                onValueChange={(value) => setPaymentDetails((prev) => ({ ...prev, paymentMethod: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="card">Credit/Debit Card</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="wallet">Digital Wallet</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {paymentDetails.paymentMethod === "cash" && (
              <div>
                <Label>Amount Received</Label>
                <Input
                  type="number"
                  value={paymentDetails.paidAmount}
                  onChange={(e) => {
                    const paidAmount = Number.parseFloat(e.target.value) || 0
                    const changeAmount = Math.max(0, paidAmount - paymentDetails.totalAmount)
                    setPaymentDetails((prev) => ({ ...prev, paidAmount, changeAmount }))
                  }}
                  placeholder={paymentDetails.totalAmount.toFixed(2)}
                />
                {paymentDetails.changeAmount > 0 && (
                  <p className="text-sm text-green-600 mt-1">
                    Change to return: ₹{paymentDetails.changeAmount.toFixed(2)}
                  </p>
                )}
              </div>
            )}

            <Separator />

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox id="whatsapp" defaultChecked />
                <Label htmlFor="whatsapp" className="flex items-center text-sm">
                  <MessageSquare className="h-4 w-4 mr-2 text-green-600" />
                  Send receipt via WhatsApp
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="print" />
                <Label htmlFor="print" className="flex items-center text-sm">
                  <Printer className="h-4 w-4 mr-2 text-gray-600" />
                  Print receipt
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="sms" />
                <Label htmlFor="sms" className="flex items-center text-sm">
                  <Phone className="h-4 w-4 mr-2 text-blue-600" />
                  Send SMS confirmation
                </Label>
              </div>
            </div>

            {/* Customer Validation Alert */}
            {!selectedCustomer && (!newCustomer.name || !newCustomer.phone) && (
              <Alert className="border-orange-300 bg-orange-50">
                <AlertTriangle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-orange-800">
                  Please provide customer name and phone number to proceed with payment.
                </AlertDescription>
              </Alert>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPaymentDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={processPayment}
              disabled={
                loading ||
                !paymentDetails.paymentMethod ||
                (paymentDetails.paymentMethod === "cash" && paymentDetails.paidAmount < paymentDetails.totalAmount) ||
                (!selectedCustomer && (!newCustomer.name || !newCustomer.phone))
              }
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Processing...
                </>
              ) : (
                <>
                  <Receipt className="h-4 w-4 mr-2" />
                  Complete Payment
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create New Patient Dialog */}
      <Dialog open={showCreatePatientDialog} onOpenChange={setShowCreatePatientDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Patient</DialogTitle>
            <DialogDescription>Add a new patient to the system for direct sales</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Patient Name *</Label>
              <Input
                placeholder="Enter patient name"
                value={newPatientData.name}
                onChange={(e) => setNewPatientData((prev) => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label>Phone Number *</Label>
              <Input
                placeholder="+91 XXXXXXXXXX"
                value={newPatientData.phone}
                onChange={(e) => setNewPatientData((prev) => ({ ...prev, phone: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Age *</Label>
                <Input
                  type="number"
                  placeholder="25"
                  value={newPatientData.age}
                  onChange={(e) =>
                    setNewPatientData((prev) => ({ ...prev, age: Number.parseInt(e.target.value) || 0 }))
                  }
                />
              </div>
              <div>
                <Label>Gender *</Label>
                <Select onValueChange={(value) => setNewPatientData((prev) => ({ ...prev, gender: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Address *</Label>
              <Textarea
                placeholder="Enter complete address"
                value={newPatientData.address}
                onChange={(e) => setNewPatientData((prev) => ({ ...prev, address: e.target.value }))}
                rows={3}
              />
            </div>
            <div>
              <Label>Emergency Contact (Optional)</Label>
              <Input
                placeholder="+91 XXXXXXXXXX"
                value={newPatientData.emergencyContact}
                onChange={(e) => setNewPatientData((prev) => ({ ...prev, emergencyContact: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreatePatientDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateNewPatient} disabled={creatingPatient}>
              {creatingPatient ? "Creating..." : "Create Patient"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      </div>
    </PrivateRoute>
  )
}

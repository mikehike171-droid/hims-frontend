"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  ArrowRightLeft,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Search,
  Filter,
  Plus,
  User,
  MapPin,
  Calendar,
  FileText,
  Bed,
} from "lucide-react"

const transferRequests = [
  {
    id: "TR001",
    patient: {
      name: "John Smith",
      age: 45,
      ipNumber: "IP001234",
      currentBed: "General Ward A - 101A",
    },
    requestedBy: "Dr. Sarah Wilson",
    requestDate: "2024-01-18 10:30",
    fromWard: "General Ward A",
    toWard: "ICU",
    reason: "Patient condition deteriorated, requires intensive monitoring",
    priority: "urgent",
    status: "pending",
    approvedBy: null,
    notes: "Patient showing signs of respiratory distress",
  },
  {
    id: "TR002",
    patient: {
      name: "Mary Johnson",
      age: 32,
      ipNumber: "IP001235",
      currentBed: "ICU - 201A",
    },
    requestedBy: "Dr. Michael Chen",
    requestDate: "2024-01-18 09:15",
    fromWard: "ICU",
    toWard: "General Ward A",
    reason: "Patient stable, no longer requires intensive care",
    priority: "normal",
    status: "approved",
    approvedBy: "Dr. Emily Brown",
    notes: "Vitals stable for 24 hours, ready for step-down",
  },
  {
    id: "TR003",
    patient: {
      name: "Robert Davis",
      age: 67,
      ipNumber: "IP001236",
      currentBed: "General Ward A - 102B",
    },
    requestedBy: "Dr. Sarah Wilson",
    requestDate: "2024-01-18 08:45",
    fromWard: "General Ward A",
    toWard: "Isolation Ward",
    reason: "Suspected infectious disease, requires isolation",
    priority: "urgent",
    status: "completed",
    approvedBy: "Dr. Emily Brown",
    notes: "Transfer completed at 11:30 AM",
  },
  {
    id: "TR004",
    patient: {
      name: "Lisa Brown",
      age: 28,
      ipNumber: "IP001237",
      currentBed: "Pediatric Ward - 301A",
    },
    requestedBy: "Dr. James Smith",
    requestDate: "2024-01-18 11:20",
    fromWard: "Pediatric Ward",
    toWard: "General Ward A",
    reason: "Patient turned 18, requires adult ward placement",
    priority: "normal",
    status: "rejected",
    approvedBy: "Dr. Emily Brown",
    notes: "No available beds in General Ward A",
  },
]

const availableBeds = [
  { ward: "General Ward A", beds: ["101B", "102A", "103B"] },
  { ward: "ICU", beds: ["202A", "203B"] },
  { ward: "Isolation Ward", beds: ["501A", "502A"] },
  { ward: "Maternity Ward", beds: ["401B", "402A"] },
]

export default function TransferRequests() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [showNewRequestDialog, setShowNewRequestDialog] = useState(false)
  const [selectedRequest, setSelectedRequest] = useState<any>(null)

  const filteredRequests = transferRequests.filter((request) => {
    const matchesSearch =
      request.patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.patient.ipNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.id.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || request.status === statusFilter
    const matchesPriority = priorityFilter === "all" || request.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "approved":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "rejected":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-100 text-red-800"
      case "normal":
        return "bg-blue-100 text-blue-800"
      case "low":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "approved":
        return <CheckCircle className="h-4 w-4" />
      case "completed":
        return <CheckCircle className="h-4 w-4" />
      case "rejected":
        return <XCircle className="h-4 w-4" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  const handleApproveTransfer = (requestId: string) => {
    console.log("Approving transfer:", requestId)
    // Implementation for approving transfer
  }

  const handleRejectTransfer = (requestId: string) => {
    console.log("Rejecting transfer:", requestId)
    // Implementation for rejecting transfer
  }

  const pendingCount = transferRequests.filter((r) => r.status === "pending").length
  const approvedCount = transferRequests.filter((r) => r.status === "approved").length
  const completedCount = transferRequests.filter((r) => r.status === "completed").length

  return (
    <PrivateRoute modulePath="admin/inpatient/transfers" action="view">
      <div className="min-h-screen bg-gray-50">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Transfer Requests</h1>
            <p className="text-gray-600">Manage patient transfers between wards</p>
          </div>
          <Dialog open={showNewRequestDialog} onOpenChange={setShowNewRequestDialog}>
            <DialogTrigger asChild>
              <Button className="bg-red-600 hover:bg-red-700">
                <Plus className="h-4 w-4 mr-2" />
                New Transfer Request
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Transfer Request</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="patient">Patient</Label>
                    <Input id="patient" placeholder="Search patient..." />
                  </div>
                  <div>
                    <Label htmlFor="fromWard">From Ward</Label>
                    <select id="fromWard" className="w-full px-3 py-2 border border-gray-300 rounded-md">
                      <option value="">Select ward...</option>
                      <option value="general">General Ward A</option>
                      <option value="icu">ICU</option>
                      <option value="pediatric">Pediatric Ward</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="toWard">To Ward</Label>
                    <select id="toWard" className="w-full px-3 py-2 border border-gray-300 rounded-md">
                      <option value="">Select ward...</option>
                      <option value="general">General Ward A</option>
                      <option value="icu">ICU</option>
                      <option value="isolation">Isolation Ward</option>
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="priority">Priority</Label>
                    <select id="priority" className="w-full px-3 py-2 border border-gray-300 rounded-md">
                      <option value="normal">Normal</option>
                      <option value="urgent">Urgent</option>
                      <option value="low">Low</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="reason">Reason for Transfer</Label>
                  <Textarea id="reason" placeholder="Enter reason for transfer..." rows={3} />
                </div>
                <div>
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea id="notes" placeholder="Any additional notes..." rows={2} />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowNewRequestDialog(false)}>
                    Cancel
                  </Button>
                  <Button className="bg-red-600 hover:bg-red-700">Create Request</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-yellow-600">{pendingCount}</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Approved</p>
                  <p className="text-2xl font-bold text-blue-600">{approvedCount}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Completed</p>
                  <p className="text-2xl font-bold text-green-600">{completedCount}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Requests</p>
                  <p className="text-2xl font-bold">{transferRequests.length}</p>
                </div>
                <ArrowRightLeft className="h-8 w-8 text-gray-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search requests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="completed">Completed</option>
            <option value="rejected">Rejected</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Priority</option>
            <option value="urgent">Urgent</option>
            <option value="normal">Normal</option>
            <option value="low">Low</option>
          </select>

          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            More Filters
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Transfer Requests List */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Transfer Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredRequests.map((request) => (
                    <div
                      key={request.id}
                      className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => setSelectedRequest(request)}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-lg">{request.patient.name}</h3>
                          <p className="text-sm text-gray-600">
                            {request.patient.ipNumber} • {request.patient.currentBed}
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          <Badge className={getPriorityColor(request.priority)}>{request.priority}</Badge>
                          <Badge className={getStatusColor(request.status)}>
                            {getStatusIcon(request.status)}
                            <span className="ml-1">{request.status}</span>
                          </Badge>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4 mb-3">
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">{request.fromWard}</span>
                        </div>
                        <ArrowRightLeft className="h-4 w-4 text-gray-400" />
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">{request.toWard}</span>
                        </div>
                      </div>

                      <p className="text-sm text-gray-700 mb-3">{request.reason}</p>

                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-4">
                          <span>Requested by: {request.requestedBy}</span>
                          <span>{new Date(request.requestDate).toLocaleString()}</span>
                        </div>
                        {request.status === "pending" && (
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={(e) => {
                                e.stopPropagation()
                                handleApproveTransfer(request.id)
                              }}
                            >
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation()
                                handleRejectTransfer(request.id)
                              }}
                            >
                              Reject
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Selected Request Details */}
            {selectedRequest && (
              <Card>
                <CardHeader>
                  <CardTitle>Request Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold">{selectedRequest.patient.name}</h3>
                    <p className="text-sm text-gray-600">{selectedRequest.id}</p>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Current Bed:</span>
                      <span className="font-medium">{selectedRequest.patient.currentBed}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>From Ward:</span>
                      <span>{selectedRequest.fromWard}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>To Ward:</span>
                      <span>{selectedRequest.toWard}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Priority:</span>
                      <Badge className={getPriorityColor(selectedRequest.priority)}>{selectedRequest.priority}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge className={getStatusColor(selectedRequest.status)}>{selectedRequest.status}</Badge>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-semibold mb-2">Reason</h4>
                    <p className="text-sm text-gray-700">{selectedRequest.reason}</p>
                  </div>

                  {selectedRequest.notes && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-2">Notes</h4>
                      <p className="text-sm text-gray-700">{selectedRequest.notes}</p>
                    </div>
                  )}

                  <div className="border-t pt-4">
                    <h4 className="font-semibold mb-2">Request Details</h4>
                    <div className="space-y-1 text-sm">
                      <p>Requested by: {selectedRequest.requestedBy}</p>
                      <p>Date: {new Date(selectedRequest.requestDate).toLocaleString()}</p>
                      {selectedRequest.approvedBy && <p>Approved by: {selectedRequest.approvedBy}</p>}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Available Beds */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bed className="h-5 w-5 mr-2 text-blue-600" />
                  Available Beds
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {availableBeds.map((ward) => (
                    <div key={ward.ward} className="border rounded-lg p-3">
                      <h4 className="font-semibold text-sm mb-2">{ward.ward}</h4>
                      <div className="flex flex-wrap gap-1">
                        {ward.beds.map((bed) => (
                          <Badge key={bed} variant="outline" className="text-xs">
                            {bed}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <User className="h-4 w-4 mr-2" />
                  View Patient Profile
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Transfer
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

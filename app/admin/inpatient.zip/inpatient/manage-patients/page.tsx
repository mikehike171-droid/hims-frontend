"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Search,
  User,
  Bed,
  Calendar,
  Phone,
  Stethoscope,
  XCircle,
  RefreshCw,
  CheckCircle,
  FileText,
  Baby,
  Users,
  DollarSign,
} from "lucide-react"

interface AdmittedPatient {
  id: string
  ipNumber: string
  name: string
  age: number
  gender: string
  phone: string
  ward: string
  room: string
  bed: string
  admissionDate: string
  doctor: string
  department: string
  diagnosis: string
  currentAdvance: number
  totalBilled: number
  balanceAmount: number
  status: "active" | "discharged" | "transferred"
  isPregnant?: boolean
  hasCradle?: boolean
  emergencyContact: string
  emergencyPhone: string
}

const mockAdmittedPatients: AdmittedPatient[] = [
  {
    id: "1",
    ipNumber: "IP001234",
    name: "John Smith",
    age: 45,
    gender: "Male",
    phone: "+91-9876543210",
    ward: "General Ward A",
    room: "101",
    bed: "A",
    admissionDate: "2024-01-15",
    doctor: "Dr. Rajesh Kumar",
    department: "Cardiology",
    diagnosis: "Acute Myocardial Infarction",
    currentAdvance: 15000,
    totalBilled: 8500,
    balanceAmount: 6500,
    status: "active",
    emergencyContact: "Jane Smith",
    emergencyPhone: "+91-9876543299",
  },
  {
    id: "2",
    ipNumber: "IP001235",
    name: "Mary Johnson",
    age: 32,
    gender: "Female",
    phone: "+91-9876543211",
    ward: "Maternity",
    room: "201",
    bed: "B",
    admissionDate: "2024-01-18",
    doctor: "Dr. Priya Sharma",
    department: "Obstetrics",
    diagnosis: "Normal Delivery",
    currentAdvance: 25000,
    totalBilled: 12000,
    balanceAmount: 13000,
    status: "active",
    isPregnant: true,
    hasCradle: true,
    emergencyContact: "Robert Johnson",
    emergencyPhone: "+91-9876543288",
  },
  {
    id: "3",
    ipNumber: "IP001236",
    name: "Sarah Wilson",
    age: 28,
    gender: "Female",
    phone: "+91-9876543212",
    ward: "Maternity",
    room: "202",
    bed: "A",
    admissionDate: "2024-01-19",
    doctor: "Dr. Priya Sharma",
    department: "Obstetrics",
    diagnosis: "Pregnancy - 38 weeks",
    currentAdvance: 30000,
    totalBilled: 5000,
    balanceAmount: 25000,
    status: "active",
    isPregnant: true,
    hasCradle: false,
    emergencyContact: "David Wilson",
    emergencyPhone: "+91-9876543277",
  },
]

export default function ManagePatients() {
  const [patients, setPatients] = useState<AdmittedPatient[]>(mockAdmittedPatients)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedPatient, setSelectedPatient] = useState<AdmittedPatient | null>(null)
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false)
  const [isDischargeDialogOpen, setIsDischargeDialogOpen] = useState(false)
  const [isCradleDialogOpen, setIsCradleDialogOpen] = useState(false)
  const [isRefundDialogOpen, setIsRefundDialogOpen] = useState(false)

  // Transfer form state
  const [transferWard, setTransferWard] = useState("")
  const [transferRoom, setTransferRoom] = useState("")
  const [transferBed, setTransferBed] = useState("")
  const [transferReason, setTransferReason] = useState("")

  // Discharge form state
  const [dischargeReason, setDischargeReason] = useState("")
  const [dischargeSummary, setDischargeSummary] = useState("")

  // Cradle form state
  const [cradleAction, setCradleAction] = useState("add")
  const [cradleRemarks, setCradleRemarks] = useState("")

  // Refund form state
  const [refundAmount, setRefundAmount] = useState("")
  const [refundReason, setRefundReason] = useState("")
  const [refundMethod, setRefundMethod] = useState("cash")

  const filteredPatients = patients.filter((patient) => {
    const matchesSearch =
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.ipNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.phone.includes(searchTerm)
    const matchesStatus = statusFilter === "all" || patient.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleTransferPatient = () => {
    if (!selectedPatient || !transferWard || !transferRoom || !transferBed) {
      alert("Please fill all required fields")
      return
    }

    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? {
              ...patient,
              ward: transferWard,
              room: transferRoom,
              bed: transferBed,
              status: "transferred" as const,
            }
          : patient,
      ),
    )

    alert(
      `Patient ${selectedPatient.name} transferred successfully to ${transferWard} - Room ${transferRoom}${transferBed}`,
    )
    resetTransferForm()
  }

  const handleDischargePatient = () => {
    if (!selectedPatient || !dischargeReason) {
      alert("Please provide discharge reason")
      return
    }

    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id ? { ...patient, status: "discharged" as const } : patient,
      ),
    )

    alert(`Patient ${selectedPatient.name} discharged successfully`)
    resetDischargeForm()
  }

  const handleCradleManagement = () => {
    if (!selectedPatient) return

    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? {
              ...patient,
              hasCradle: cradleAction === "add" ? true : false,
            }
          : patient,
      ),
    )

    alert(`Cradle ${cradleAction === "add" ? "added" : "removed"} for ${selectedPatient.name}`)
    resetCradleForm()
  }

  const handleRefundProcess = () => {
    if (!selectedPatient || !refundAmount || !refundReason) {
      alert("Please fill all required fields")
      return
    }

    const refundAmountNum = Number.parseFloat(refundAmount)
    if (refundAmountNum > selectedPatient.balanceAmount) {
      alert("Refund amount cannot exceed balance amount")
      return
    }

    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? {
              ...patient,
              currentAdvance: patient.currentAdvance - refundAmountNum,
              balanceAmount: patient.balanceAmount - refundAmountNum,
            }
          : patient,
      ),
    )

    alert(`Refund of ₹${refundAmount} processed successfully for ${selectedPatient.name}`)
    resetRefundForm()
  }

  const resetTransferForm = () => {
    setTransferWard("")
    setTransferRoom("")
    setTransferBed("")
    setTransferReason("")
    setIsTransferDialogOpen(false)
    setSelectedPatient(null)
  }

  const resetDischargeForm = () => {
    setDischargeReason("")
    setDischargeSummary("")
    setIsDischargeDialogOpen(false)
    setSelectedPatient(null)
  }

  const resetCradleForm = () => {
    setCradleAction("add")
    setCradleRemarks("")
    setIsCradleDialogOpen(false)
    setSelectedPatient(null)
  }

  const resetRefundForm = () => {
    setRefundAmount("")
    setRefundReason("")
    setRefundMethod("cash")
    setIsRefundDialogOpen(false)
    setSelectedPatient(null)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "discharged":
        return "bg-blue-100 text-blue-800"
      case "transferred":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const stats = {
    total: filteredPatients.length,
    active: filteredPatients.filter((p) => p.status === "active").length,
    discharged: filteredPatients.filter((p) => p.status === "discharged").length,
    transferred: filteredPatients.filter((p) => p.status === "transferred").length,
    withCradle: filteredPatients.filter((p) => p.hasCradle).length,
  }

  return (
    <PrivateRoute modulePath="admin/inpatient/manage-patients" action="edit">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Manage Admitted Patients</h1>
          <p className="text-gray-600">Transfer, discharge, and manage admitted patients</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active</p>
                <p className="text-2xl font-bold text-green-600">{stats.active}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Discharged</p>
                <p className="text-2xl font-bold text-blue-600">{stats.discharged}</p>
              </div>
              <XCircle className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Transferred</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.transferred}</p>
              </div>
              <RefreshCw className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">With Cradle</p>
                <p className="text-2xl font-bold text-pink-600">{stats.withCradle}</p>
              </div>
              <Baby className="h-8 w-8 text-pink-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search patients..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="discharged">Discharged</SelectItem>
                <SelectItem value="transferred">Transferred</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Patients Table */}
      <Card>
        <CardHeader>
          <CardTitle>Admitted Patients ({filteredPatients.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient Details</TableHead>
                  <TableHead>Location & Status</TableHead>
                  <TableHead>Medical Info</TableHead>
                  <TableHead>Financial Status</TableHead>
                  <TableHead>Emergency Contact</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPatients.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium flex items-center gap-2">
                            {patient.name}
                            {patient.hasCradle && <Baby className="h-4 w-4 text-pink-600" />}
                          </div>
                          <div className="text-sm text-gray-500">
                            {patient.ipNumber} • {patient.age}Y {patient.gender}
                          </div>
                          <div className="text-sm text-gray-500 flex items-center">
                            <Phone className="h-3 w-3 mr-1" />
                            {patient.phone}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="flex items-center mb-1">
                          <Bed className="h-4 w-4 mr-1 text-gray-400" />
                          <span className="font-medium">{patient.ward}</span>
                        </div>
                        <div className="text-sm text-gray-500 mb-2">
                          Room {patient.room}
                          {patient.bed}
                        </div>
                        <Badge className={getStatusColor(patient.status)}>{patient.status}</Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="flex items-center mb-1">
                          <Stethoscope className="h-4 w-4 mr-1 text-gray-400" />
                          <span className="font-medium">{patient.doctor}</span>
                        </div>
                        <div className="text-sm text-gray-500 mb-1">{patient.department}</div>
                        <div className="text-sm text-gray-600">{patient.diagnosis}</div>
                        <div className="flex items-center text-sm text-gray-500 mt-1">
                          <Calendar className="h-3 w-3 mr-1" />
                          {patient.admissionDate}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Advance:</span>
                          <span className="font-medium text-green-600">₹{patient.currentAdvance.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Billed:</span>
                          <span className="font-medium text-purple-600">₹{patient.totalBilled.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Balance:</span>
                          <span className="font-medium text-orange-600">₹{patient.balanceAmount.toLocaleString()}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{patient.emergencyContact}</div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <Phone className="h-3 w-3 mr-1" />
                          {patient.emergencyPhone}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedPatient(patient)
                              setIsTransferDialogOpen(true)
                            }}
                            disabled={patient.status !== "active"}
                          >
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Transfer
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedPatient(patient)
                              setIsDischargeDialogOpen(true)
                            }}
                            disabled={patient.status !== "active"}
                          >
                            <XCircle className="h-3 w-3 mr-1" />
                            Discharge
                          </Button>
                        </div>
                        <div className="flex gap-1">
                          {patient.isPregnant && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedPatient(patient)
                                setIsCradleDialogOpen(true)
                              }}
                              className="text-pink-600 hover:text-pink-700"
                            >
                              <Baby className="h-3 w-3 mr-1" />
                              Cradle
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedPatient(patient)
                              setIsRefundDialogOpen(true)
                            }}
                            disabled={patient.balanceAmount <= 0}
                            className="text-red-600 hover:text-red-700"
                          >
                            <DollarSign className="h-3 w-3 mr-1" />
                            Refund
                          </Button>
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {filteredPatients.length === 0 && (
              <div className="text-center py-8">
                <Users className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-500">No patients found matching your criteria</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Transfer Patient Dialog */}
      <Dialog open={isTransferDialogOpen} onOpenChange={setIsTransferDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Transfer Patient</DialogTitle>
            <DialogDescription>Transfer {selectedPatient?.name} to a different ward/room</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>New Ward *</Label>
                <Select value={transferWard} onValueChange={setTransferWard}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select ward" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="General Ward A">General Ward A</SelectItem>
                    <SelectItem value="General Ward B">General Ward B</SelectItem>
                    <SelectItem value="ICU">ICU</SelectItem>
                    <SelectItem value="Maternity">Maternity</SelectItem>
                    <SelectItem value="Pediatrics">Pediatrics</SelectItem>
                    <SelectItem value="Private Rooms">Private Rooms</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Room Number *</Label>
                <Input
                  value={transferRoom}
                  onChange={(e) => setTransferRoom(e.target.value)}
                  placeholder="Enter room number"
                />
              </div>
              <div>
                <Label>Bed *</Label>
                <Select value={transferBed} onValueChange={setTransferBed}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select bed" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Bed A</SelectItem>
                    <SelectItem value="B">Bed B</SelectItem>
                    <SelectItem value="C">Bed C</SelectItem>
                    <SelectItem value="D">Bed D</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Transfer Reason</Label>
              <Input
                value={transferReason}
                onChange={(e) => setTransferReason(e.target.value)}
                placeholder="Reason for transfer"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={resetTransferForm}>
                Cancel
              </Button>
              <Button onClick={handleTransferPatient} className="bg-blue-600 hover:bg-blue-700">
                <RefreshCw className="h-4 w-4 mr-2" />
                Transfer Patient
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Discharge Patient Dialog */}
      <Dialog open={isDischargeDialogOpen} onOpenChange={setIsDischargeDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Discharge Patient</DialogTitle>
            <DialogDescription>Discharge {selectedPatient?.name} from the hospital</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Discharge Reason *</Label>
              <Select value={dischargeReason} onValueChange={setDischargeReason}>
                <SelectTrigger>
                  <SelectValue placeholder="Select discharge reason" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recovered">Patient Recovered</SelectItem>
                  <SelectItem value="referred">Referred to Another Hospital</SelectItem>
                  <SelectItem value="lama">Left Against Medical Advice</SelectItem>
                  <SelectItem value="death">Death</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Discharge Summary</Label>
              <textarea
                className="w-full p-3 border rounded-md"
                rows={4}
                value={dischargeSummary}
                onChange={(e) => setDischargeSummary(e.target.value)}
                placeholder="Enter discharge summary and instructions..."
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={resetDischargeForm}>
                Cancel
              </Button>
              <Button onClick={handleDischargePatient} className="bg-red-600 hover:bg-red-700">
                <XCircle className="h-4 w-4 mr-2" />
                Discharge Patient
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Cradle Management Dialog */}
      <Dialog open={isCradleDialogOpen} onOpenChange={setIsCradleDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cradle Management</DialogTitle>
            <DialogDescription>Manage cradle for {selectedPatient?.name}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Action *</Label>
              <Select value={cradleAction} onValueChange={setCradleAction}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="add">Add Cradle</SelectItem>
                  <SelectItem value="remove">Remove Cradle</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Remarks</Label>
              <Input
                value={cradleRemarks}
                onChange={(e) => setCradleRemarks(e.target.value)}
                placeholder="Enter remarks"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={resetCradleForm}>
                Cancel
              </Button>
              <Button onClick={handleCradleManagement} className="bg-pink-600 hover:bg-pink-700">
                <Baby className="h-4 w-4 mr-2" />
                {cradleAction === "add" ? "Add" : "Remove"} Cradle
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Refund Dialog */}
      <Dialog open={isRefundDialogOpen} onOpenChange={setIsRefundDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Process Refund</DialogTitle>
            <DialogDescription>Process refund for {selectedPatient?.name}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-sm">
                Available Balance:{" "}
                <span className="font-medium text-green-600">₹{selectedPatient?.balanceAmount.toLocaleString()}</span>
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Refund Amount (₹) *</Label>
                <Input
                  type="number"
                  value={refundAmount}
                  onChange={(e) => setRefundAmount(e.target.value)}
                  placeholder="Enter amount"
                  max={selectedPatient?.balanceAmount}
                />
              </div>
              <div>
                <Label>Refund Method *</Label>
                <Select value={refundMethod} onValueChange={setRefundMethod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                    <SelectItem value="cheque">Cheque</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Refund Reason *</Label>
              <Input
                value={refundReason}
                onChange={(e) => setRefundReason(e.target.value)}
                placeholder="Enter reason for refund"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={resetRefundForm}>
                Cancel
              </Button>
              <Button onClick={handleRefundProcess} className="bg-red-600 hover:bg-red-700">
                <DollarSign className="h-4 w-4 mr-2" />
                Process Refund
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Users,
  Bed,
  TrendingUp,
  TrendingDown,
  Calendar,
  Download,
  Search,
  Filter,
  Clock,
  UserCheck,
  UserX,
  AlertTriangle,
} from "lucide-react"

const wardCensusData = [
  {
    id: 1,
    ward: "General Ward A",
    floor: 1,
    totalBeds: 30,
    occupiedBeds: 24,
    admissions: 3,
    discharges: 2,
    transfers: { in: 1, out: 2 },
    occupancyRate: 80,
    avgLengthOfStay: 4.2,
    turnoverRate: 0.8,
    nurseToPatientRatio: "1:6",
    criticalPatients: 2,
  },
  {
    id: 2,
    ward: "ICU",
    floor: 2,
    totalBeds: 12,
    occupiedBeds: 10,
    admissions: 2,
    discharges: 1,
    transfers: { in: 0, out: 1 },
    occupancyRate: 83,
    avgLengthOfStay: 6.8,
    turnoverRate: 0.3,
    nurseToPatientRatio: "1:2",
    criticalPatients: 8,
  },
  {
    id: 3,
    ward: "Pediatric Ward",
    floor: 3,
    totalBeds: 20,
    occupiedBeds: 15,
    admissions: 4,
    discharges: 3,
    transfers: { in: 2, out: 1 },
    occupancyRate: 75,
    avgLengthOfStay: 3.5,
    turnoverRate: 1.2,
    nurseToPatientRatio: "1:4",
    criticalPatients: 1,
  },
  {
    id: 4,
    ward: "Maternity Ward",
    floor: 4,
    totalBeds: 15,
    occupiedBeds: 12,
    admissions: 5,
    discharges: 4,
    transfers: { in: 0, out: 0 },
    occupancyRate: 80,
    avgLengthOfStay: 2.8,
    turnoverRate: 1.5,
    nurseToPatientRatio: "1:3",
    criticalPatients: 0,
  },
  {
    id: 5,
    ward: "Isolation Ward",
    floor: 1,
    totalBeds: 8,
    occupiedBeds: 3,
    admissions: 1,
    discharges: 2,
    transfers: { in: 0, out: 1 },
    occupancyRate: 38,
    avgLengthOfStay: 7.2,
    turnoverRate: 0.4,
    nurseToPatientRatio: "1:2",
    criticalPatients: 2,
  },
]

const recentActivities = [
  {
    id: 1,
    type: "admission",
    patient: "Sarah Johnson",
    ward: "General Ward A",
    time: "2024-01-18 14:30",
    doctor: "Dr. Wilson",
  },
  {
    id: 2,
    type: "discharge",
    patient: "Mike Davis",
    ward: "ICU",
    time: "2024-01-18 13:15",
    doctor: "Dr. Chen",
  },
  {
    id: 3,
    type: "transfer",
    patient: "Lisa Brown",
    from: "General Ward A",
    to: "ICU",
    time: "2024-01-18 12:45",
    doctor: "Dr. Wilson",
  },
  {
    id: 4,
    type: "admission",
    patient: "Robert Wilson",
    ward: "Pediatric Ward",
    time: "2024-01-18 11:20",
    doctor: "Dr. Smith",
  },
]

export default function WardCensus() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedWard, setSelectedWard] = useState("all")

  const totalBeds = wardCensusData.reduce((sum, ward) => sum + ward.totalBeds, 0)
  const totalOccupied = wardCensusData.reduce((sum, ward) => sum + ward.occupiedBeds, 0)
  const totalAdmissions = wardCensusData.reduce((sum, ward) => sum + ward.admissions, 0)
  const totalDischarges = wardCensusData.reduce((sum, ward) => sum + ward.discharges, 0)
  const overallOccupancy = Math.round((totalOccupied / totalBeds) * 100)

  const getOccupancyColor = (rate: number) => {
    if (rate >= 90) return "text-red-600"
    if (rate >= 80) return "text-yellow-600"
    return "text-green-600"
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "admission":
        return <UserCheck className="h-4 w-4 text-green-600" />
      case "discharge":
        return <UserX className="h-4 w-4 text-blue-600" />
      case "transfer":
        return <AlertTriangle className="h-4 w-4 text-orange-600" />
      default:
        return <Clock className="h-4 w-4 text-gray-600" />
    }
  }

  const filteredWards = wardCensusData.filter((ward) => {
    const matchesSearch = ward.ward.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesWard = selectedWard === "all" || ward.ward === selectedWard
    return matchesSearch && matchesWard
  })

  return (
    <PrivateRoute modulePath="admin/inpatient/census" action="view">
      <div className="min-h-screen bg-gray-50">
        <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Ward Census</h1>
            <p className="text-gray-600">Real-time ward occupancy and patient flow analytics</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
            <Button className="bg-red-600 hover:bg-red-700">
              <Calendar className="h-4 w-4 mr-2" />
              Schedule Report
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Beds</p>
                  <p className="text-2xl font-bold">{totalBeds}</p>
                </div>
                <Bed className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Occupied</p>
                  <p className="text-2xl font-bold">{totalOccupied}</p>
                  <p className={`text-sm font-medium ${getOccupancyColor(overallOccupancy)}`}>
                    {overallOccupancy}% occupancy
                  </p>
                </div>
                <Users className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Today's Admissions</p>
                  <p className="text-2xl font-bold text-green-600">{totalAdmissions}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Today's Discharges</p>
                  <p className="text-2xl font-bold text-blue-600">{totalDischarges}</p>
                </div>
                <TrendingDown className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search wards..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>

          <select
            value={selectedWard}
            onChange={(e) => setSelectedWard(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Wards</option>
            {wardCensusData.map((ward) => (
              <option key={ward.id} value={ward.ward}>
                {ward.ward}
              </option>
            ))}
          </select>

          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          />

          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            More Filters
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Ward Census Table */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Ward Census Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">Ward</th>
                        <th className="text-left p-3">Occupancy</th>
                        <th className="text-left p-3">Admissions</th>
                        <th className="text-left p-3">Discharges</th>
                        <th className="text-left p-3">Transfers</th>
                        <th className="text-left p-3">Avg LOS</th>
                        <th className="text-left p-3">Critical</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredWards.map((ward) => (
                        <tr key={ward.id} className="border-b hover:bg-gray-50">
                          <td className="p-3">
                            <div>
                              <p className="font-medium">{ward.ward}</p>
                              <p className="text-xs text-gray-500">Floor {ward.floor}</p>
                            </div>
                          </td>
                          <td className="p-3">
                            <div>
                              <p className="font-medium">
                                {ward.occupiedBeds}/{ward.totalBeds}
                              </p>
                              <p className={`text-xs ${getOccupancyColor(ward.occupancyRate)}`}>
                                {ward.occupancyRate}%
                              </p>
                            </div>
                          </td>
                          <td className="p-3">
                            <Badge className="bg-green-100 text-green-800">{ward.admissions}</Badge>
                          </td>
                          <td className="p-3">
                            <Badge className="bg-blue-100 text-blue-800">{ward.discharges}</Badge>
                          </td>
                          <td className="p-3">
                            <div className="text-xs">
                              <p>In: {ward.transfers.in}</p>
                              <p>Out: {ward.transfers.out}</p>
                            </div>
                          </td>
                          <td className="p-3">
                            <p className="font-medium">{ward.avgLengthOfStay} days</p>
                          </td>
                          <td className="p-3">
                            {ward.criticalPatients > 0 ? (
                              <Badge className="bg-red-100 text-red-800">{ward.criticalPatients}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent Activities */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-blue-600" />
                  Recent Activities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivities.map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                      {getActivityIcon(activity.type)}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{activity.patient}</p>
                        <p className="text-xs text-gray-600">
                          {activity.type === "transfer" ? `${activity.from} → ${activity.to}` : activity.ward}
                        </p>
                        <p className="text-xs text-gray-500">{new Date(activity.time).toLocaleString()}</p>
                        <p className="text-xs text-gray-500">{activity.doctor}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Ward Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Overall Occupancy</span>
                      <span className="font-medium">{overallOccupancy}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-red-600 h-2 rounded-full" style={{ width: `${overallOccupancy}%` }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Bed Turnover Rate</span>
                      <span className="font-medium">0.8/day</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: "80%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Average Length of Stay</span>
                      <span className="font-medium">4.5 days</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: "65%" }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-orange-600" />
                  Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm font-medium text-red-800">High Occupancy</p>
                    <p className="text-xs text-red-600">ICU at 83% capacity</p>
                  </div>
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-sm font-medium text-yellow-800">Staffing Alert</p>
                    <p className="text-xs text-yellow-600">General Ward A needs additional nurse</p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm font-medium text-blue-800">Discharge Ready</p>
                    <p className="text-xs text-blue-600">3 patients ready for discharge</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        </div>
      </div>
    </PrivateRoute>
  )
}

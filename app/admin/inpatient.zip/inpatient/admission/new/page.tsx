"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Progress } from "@/components/ui/progress"
import { Checkbox } from "@/components/ui/checkbox"
import {
  User,
  Bed,
  CheckCircle,
  CalendarIcon,
  Shield,
  Stethoscope,
  CreditCard,
  ArrowLeft,
  Save,
  FileText,
  Phone,
  MapPin,
  Building,
  Users,
  AlertCircle,
  DollarSign,
  Calculator,
} from "lucide-react"
import { format } from "date-fns"
import Link from "next/link"

type AdmissionStep = "patient" | "medical" | "bed" | "payment" | "complete"

interface AdvancePayment {
  amount: number
  method: string
  reference?: string
  notes?: string
}

export default function NewPatientAdmissionPage() {
  const [currentStep, setCurrentStep] = useState<AdmissionStep>("patient")
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [selectedTPA, setSelectedTPA] = useState("")
  const [selectedInsurance, setSelectedInsurance] = useState("")
  const [selectedCompany, setSelectedCompany] = useState("")
  const [selectedDepartment, setSelectedDepartment] = useState("")
  const [primaryDoctor, setPrimaryDoctor] = useState("")
  const [secondaryDoctor, setSecondaryDoctor] = useState("")
  const [gipsaType, setGipsaType] = useState("")
  const [customerType, setCustomerType] = useState("cash")
  const [selectedBed, setSelectedBed] = useState("")
  const [customDiscount, setCustomDiscount] = useState(0)
  const [companyDiscount, setCompanyDiscount] = useState(0)
  const [collectAdvance, setCollectAdvance] = useState(true)
  const [advancePayment, setAdvancePayment] = useState<AdvancePayment>({
    amount: 10000,
    method: "cash",
    reference: "",
    notes: "",
  })

  // Form data state
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    dob: "",
    gender: "",
    aadhar: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    emergencyName: "",
    emergencyPhone: "",
    relationship: "",
    chiefComplaint: "",
    provisionalDiagnosis: "",
    medicalHistory: "",
    allergies: "",
    currentMedications: "",
    policyNumber: "",
    policyAmount: "",
    paymentMethod: "",
    paymentRemarks: "",
  })

  // Master data
  const tpaList = [
    { id: "1", name: "Medi Assist", code: "MA001", contact: "+91-80-12345678" },
    { id: "2", name: "Vidal Health", code: "VH002", contact: "+91-80-23456789" },
    { id: "3", name: "Paramount Health", code: "PH003", contact: "+91-80-34567890" },
    { id: "4", name: "Good Health", code: "GH004", contact: "+91-80-45678901" },
    { id: "5", name: "Family Health Plan", code: "FHP005", contact: "+91-80-56789012" },
  ]

  const insuranceList = [
    { id: "1", name: "Star Health Insurance", code: "SHI001", type: "Health" },
    { id: "2", name: "HDFC ERGO", code: "HE002", type: "General" },
    { id: "3", name: "ICICI Lombard", code: "IL003", type: "General" },
    { id: "4", name: "New India Assurance", code: "NIA004", type: "Public" },
    { id: "5", name: "Oriental Insurance", code: "OI005", type: "Public" },
    { id: "6", name: "United India Insurance", code: "UII006", type: "Public" },
  ]

  const companies = [
    { id: "1", name: "TCS Limited", discount: 15, type: "corporate", employees: "500+" },
    { id: "2", name: "Infosys Limited", discount: 12, type: "corporate", employees: "300+" },
    { id: "3", name: "Wipro Technologies", discount: 10, type: "corporate", employees: "200+" },
    { id: "4", name: "Government Employee", discount: 20, type: "government", employees: "All" },
    { id: "5", name: "ISRO", discount: 18, type: "government", employees: "All" },
    { id: "6", name: "Indian Railways", discount: 16, type: "government", employees: "All" },
  ]

  const departments = [
    { id: "1", name: "Cardiology", code: "CARD", head: "Dr. Rajesh Kumar" },
    { id: "2", name: "Orthopedics", code: "ORTHO", head: "Dr. Priya Sharma" },
    { id: "3", name: "General Medicine", code: "GM", head: "Dr. Amit Singh" },
    { id: "4", name: "Pediatrics", code: "PED", head: "Dr. Sunita Patel" },
    { id: "5", name: "Emergency", code: "ER", head: "Dr. Ravi Mehta" },
    { id: "6", name: "ICU", code: "ICU", head: "Dr. Michael Chen" },
    { id: "7", name: "Neurology", code: "NEURO", head: "Dr. Sarah Wilson" },
    { id: "8", name: "Oncology", code: "ONCO", head: "Dr. David Brown" },
  ]

  const doctors = [
    {
      id: "1",
      name: "Dr. Rajesh Kumar",
      department: "1",
      specialization: "Interventional Cardiology",
      experience: "15 years",
    },
    { id: "2", name: "Dr. Priya Sharma", department: "2", specialization: "Joint Replacement", experience: "12 years" },
    { id: "3", name: "Dr. Amit Singh", department: "3", specialization: "Internal Medicine", experience: "10 years" },
    { id: "4", name: "Dr. Sunita Patel", department: "4", specialization: "Pediatric Care", experience: "8 years" },
    { id: "5", name: "Dr. Michael Chen", department: "6", specialization: "Critical Care", experience: "18 years" },
    { id: "6", name: "Dr. Sarah Wilson", department: "7", specialization: "Neurosurgery", experience: "14 years" },
    { id: "7", name: "Dr. David Brown", department: "8", specialization: "Medical Oncology", experience: "16 years" },
    { id: "8", name: "Dr. Ravi Mehta", department: "5", specialization: "Emergency Medicine", experience: "9 years" },
  ]

  const bedTypes = [
    {
      id: "1",
      name: "General Ward",
      category: "Standard",
      cashPrice: 1500,
      insurancePrice: 2000,
      sharing: "4-bed sharing",
      amenities: ["Basic bed", "Shared bathroom", "Visitor chair", "Locker"],
      available: 8,
    },
    {
      id: "2",
      name: "Semi-Private",
      category: "Premium",
      cashPrice: 3000,
      insurancePrice: 3500,
      sharing: "2-bed sharing",
      amenities: ["Comfortable bed", "Shared bathroom", "TV", "Visitor sofa", "AC"],
      available: 5,
    },
    {
      id: "3",
      name: "Private Room",
      category: "Deluxe",
      cashPrice: 5000,
      insurancePrice: 6000,
      sharing: "Single occupancy",
      amenities: ["Premium bed", "Private bathroom", "TV", "Refrigerator", "Visitor bed", "AC"],
      available: 3,
    },
    {
      id: "4",
      name: "ICU Bed",
      category: "Critical",
      cashPrice: 8000,
      insurancePrice: 10000,
      sharing: "Single occupancy",
      amenities: ["ICU bed", "Ventilator support", "24/7 monitoring", "Specialized equipment"],
      available: 2,
    },
    {
      id: "5",
      name: "Suite",
      category: "Luxury",
      cashPrice: 12000,
      insurancePrice: 15000,
      sharing: "Single occupancy",
      amenities: ["Luxury bed", "Private bathroom", "Living area", "Kitchenette", "Attendant bed", "Premium AC"],
      available: 1,
    },
  ]

  const availableBeds = [
    { id: "101A", type: "1", ward: "General Ward A", room: "101", bed: "A", status: "available", floor: "1st Floor" },
    { id: "101B", type: "1", ward: "General Ward A", room: "101", bed: "B", status: "available", floor: "1st Floor" },
    {
      id: "102A",
      type: "2",
      ward: "Semi-Private Wing",
      room: "102",
      bed: "A",
      status: "available",
      floor: "1st Floor",
    },
    { id: "201A", type: "3", ward: "Private Wing", room: "201", bed: "A", status: "available", floor: "2nd Floor" },
    { id: "301A", type: "4", ward: "ICU", room: "301", bed: "A", status: "available", floor: "3rd Floor" },
    { id: "401A", type: "5", ward: "VIP Suite", room: "401", bed: "A", status: "available", floor: "4th Floor" },
  ]

  const getStepIcon = (step: AdmissionStep) => {
    switch (step) {
      case "patient":
        return <User className="h-5 w-5" />
      case "medical":
        return <Stethoscope className="h-5 w-5" />
      case "bed":
        return <Bed className="h-5 w-5" />
      case "payment":
        return <CreditCard className="h-5 w-5" />
      case "complete":
        return <CheckCircle className="h-5 w-5" />
    }
  }

  const steps = [
    { key: "patient", label: "Patient Details", completed: currentStep !== "patient" },
    { key: "medical", label: "Medical Info", completed: ["bed", "payment", "complete"].includes(currentStep) },
    { key: "bed", label: "Bed Selection", completed: ["payment", "complete"].includes(currentStep) },
    { key: "payment", label: "Payment & Advance", completed: currentStep === "complete" },
    { key: "complete", label: "Complete", completed: false },
  ]

  const calculateBedPrice = () => {
    const bedType = bedTypes.find((b) => b.id === selectedBed)
    if (!bedType) return 0

    const basePrice = customerType === "cash" ? bedType.cashPrice : bedType.insurancePrice
    const companyDiscountAmount = (basePrice * companyDiscount) / 100
    const customDiscountAmount = customDiscount

    return Math.max(0, basePrice - companyDiscountAmount - customDiscountAmount)
  }

  const getStepProgress = () => {
    const stepIndex = steps.findIndex((step) => step.key === currentStep)
    return ((stepIndex + 1) / steps.length) * 100
  }

  const updateFormData = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const calculateTotalCharges = () => {
    const bedPrice = calculateBedPrice()
    const registrationFee = 500
    const advanceAmount = collectAdvance ? advancePayment.amount : 0

    return {
      bedPrice,
      registrationFee,
      advanceAmount,
      total: bedPrice + registrationFee + advanceAmount,
    }
  }

  return (
    <PrivateRoute modulePath="admin/inpatient/admission" action="add">
      <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/inpatient">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">New Patient Admission</h1>
              <p className="text-gray-600">Complete patient admission with advance payment collection</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Save className="h-4 w-4 mr-2" />
              Save Draft
            </Button>
            <Badge variant="outline" className="px-3 py-1">
              Step {steps.findIndex((step) => step.key === currentStep) + 1} of {steps.length}
            </Badge>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white px-6 py-4 border-b border-gray-200">
        <div className="mb-4">
          <Progress value={getStepProgress()} className="h-2" />
        </div>
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.key} className="flex items-center">
              <div
                className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                  step.completed
                    ? "bg-green-500 border-green-500 text-white"
                    : currentStep === step.key
                      ? "bg-red-500 border-red-500 text-white"
                      : "border-gray-300 text-gray-500"
                }`}
              >
                {step.completed ? <CheckCircle className="h-5 w-5" /> : getStepIcon(step.key as AdmissionStep)}
              </div>
              <span
                className={`ml-2 text-sm font-medium ${
                  step.completed || currentStep === step.key ? "text-gray-900" : "text-gray-500"
                }`}
              >
                {step.label}
              </span>
              {index < steps.length - 1 && (
                <div className={`w-16 h-0.5 mx-4 ${step.completed ? "bg-green-500" : "bg-gray-300"}`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6">
        {/* Patient Details Step */}
        {currentStep === "patient" && (
          <div className="max-w-6xl mx-auto space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2 text-blue-600" />
                  Basic Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      placeholder="Enter first name"
                      value={formData.firstName}
                      onChange={(e) => updateFormData("firstName", e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      placeholder="Enter last name"
                      value={formData.lastName}
                      onChange={(e) => updateFormData("lastName", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      placeholder="+91-XXXXXXXXXX"
                      value={formData.phone}
                      onChange={(e) => updateFormData("phone", e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter email"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="dob">Date of Birth</Label>
                    <Input
                      id="dob"
                      type="date"
                      value={formData.dob}
                      onChange={(e) => updateFormData("dob", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="gender">Gender</Label>
                    <Select value={formData.gender} onValueChange={(value) => updateFormData("gender", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="aadhar">Aadhar Number *</Label>
                    <Input
                      id="aadhar"
                      placeholder="XXXX-XXXX-XXXX"
                      value={formData.aadhar}
                      onChange={(e) => updateFormData("aadhar", e.target.value)}
                      required
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Insurance & Company Details */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-blue-600" />
                  Insurance & Company Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div>
                    <Label htmlFor="customerType">Customer Type *</Label>
                    <Select value={customerType} onValueChange={setCustomerType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select customer type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash Customer</SelectItem>
                        <SelectItem value="insurance">Insurance Customer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="tpa">TPA (Third Party Administrator)</Label>
                    <Select value={selectedTPA} onValueChange={setSelectedTPA}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select TPA" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No TPA</SelectItem>
                        {tpaList.map((tpa) => (
                          <SelectItem key={tpa.id} value={tpa.id}>
                            <div className="flex flex-col">
                              <span>
                                {tpa.name} ({tpa.code})
                              </span>
                              <span className="text-xs text-gray-500">{tpa.contact}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="insurance">Insurance Company</Label>
                    <Select value={selectedInsurance} onValueChange={setSelectedInsurance}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select insurance" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Insurance</SelectItem>
                        {insuranceList.map((insurance) => (
                          <SelectItem key={insurance.id} value={insurance.id}>
                            <div className="flex flex-col">
                              <span>
                                {insurance.name} ({insurance.code})
                              </span>
                              <span className="text-xs text-gray-500">{insurance.type} Insurance</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="company">Company/Organization</Label>
                    <Select
                      value={selectedCompany}
                      onValueChange={(value) => {
                        setSelectedCompany(value)
                        const company = companies.find((c) => c.id === value)
                        setCompanyDiscount(company?.discount || 0)
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select company" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Company</SelectItem>
                        {companies.map((company) => (
                          <SelectItem key={company.id} value={company.id}>
                            <div className="flex flex-col">
                              <span>{company.name}</span>
                              <span className="text-xs text-gray-500">
                                {company.discount}% discount • {company.employees} employees
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="companyDiscount">Company Discount (%)</Label>
                    <Input
                      id="companyDiscount"
                      type="number"
                      value={companyDiscount}
                      onChange={(e) => setCompanyDiscount(Number(e.target.value))}
                      placeholder="0"
                      min="0"
                      max="100"
                    />
                  </div>
                  <div>
                    <Label htmlFor="customDiscount">Custom Discount (₹)</Label>
                    <Input
                      id="customDiscount"
                      type="number"
                      value={customDiscount}
                      onChange={(e) => setCustomDiscount(Number(e.target.value))}
                      placeholder="0"
                      min="0"
                    />
                  </div>
                  <div>
                    <Label htmlFor="gipsa">GIPSA Classification</Label>
                    <Select value={gipsaType} onValueChange={setGipsaType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select GIPSA type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gipsa">GIPSA</SelectItem>
                        <SelectItem value="non-gipsa">Non GIPSA</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="policyNumber">Policy Number</Label>
                    <Input
                      id="policyNumber"
                      placeholder="Enter policy number"
                      value={formData.policyNumber}
                      onChange={(e) => updateFormData("policyNumber", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="policyAmount">Policy Amount (₹)</Label>
                    <Input
                      id="policyAmount"
                      type="number"
                      placeholder="Enter policy amount"
                      value={formData.policyAmount}
                      onChange={(e) => updateFormData("policyAmount", e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Address Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-green-600" />
                  Address Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="address">Complete Address</Label>
                    <Textarea
                      id="address"
                      placeholder="Enter complete address"
                      value={formData.address}
                      onChange={(e) => updateFormData("address", e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        placeholder="Enter city"
                        value={formData.city}
                        onChange={(e) => updateFormData("city", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        placeholder="Enter state"
                        value={formData.state}
                        onChange={(e) => updateFormData("state", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="pincode">Pincode</Label>
                      <Input
                        id="pincode"
                        placeholder="Enter pincode"
                        value={formData.pincode}
                        onChange={(e) => updateFormData("pincode", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Contact */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Phone className="h-5 w-5 mr-2 text-red-600" />
                  Emergency Contact
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="emergencyName">Contact Name</Label>
                    <Input
                      id="emergencyName"
                      placeholder="Enter contact name"
                      value={formData.emergencyName}
                      onChange={(e) => updateFormData("emergencyName", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="emergencyPhone">Contact Phone</Label>
                    <Input
                      id="emergencyPhone"
                      placeholder="+91-XXXXXXXXXX"
                      value={formData.emergencyPhone}
                      onChange={(e) => updateFormData("emergencyPhone", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="relationship">Relationship</Label>
                    <Select
                      value={formData.relationship}
                      onValueChange={(value) => updateFormData("relationship", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select relationship" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="spouse">Spouse</SelectItem>
                        <SelectItem value="parent">Parent</SelectItem>
                        <SelectItem value="child">Child</SelectItem>
                        <SelectItem value="sibling">Sibling</SelectItem>
                        <SelectItem value="friend">Friend</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-end pt-4">
              <Button onClick={() => setCurrentStep("medical")} className="bg-red-600 hover:bg-red-700">
                Next: Medical Information
              </Button>
            </div>
          </div>
        )}

        {/* Medical Information Step */}
        {currentStep === "medical" && (
          <div className="max-w-6xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Stethoscope className="h-5 w-5 mr-2 text-red-600" />
                  Medical Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label>Department *</Label>
                      <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {departments.map((dept) => (
                            <SelectItem key={dept.id} value={dept.id}>
                              <div className="flex flex-col">
                                <span>
                                  {dept.name} ({dept.code})
                                </span>
                                <span className="text-xs text-gray-500">Head: {dept.head}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Admission Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal bg-transparent"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} initialFocus />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label>Primary Doctor *</Label>
                      <Select value={primaryDoctor} onValueChange={setPrimaryDoctor}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select primary doctor" />
                        </SelectTrigger>
                        <SelectContent>
                          {doctors
                            .filter((doctor) => !selectedDepartment || doctor.department === selectedDepartment)
                            .map((doctor) => (
                              <SelectItem key={doctor.id} value={doctor.id}>
                                <div className="flex flex-col">
                                  <span>{doctor.name}</span>
                                  <span className="text-xs text-gray-500">
                                    {doctor.specialization} • {doctor.experience}
                                  </span>
                                </div>
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Secondary Doctor</Label>
                      <Select value={secondaryDoctor} onValueChange={setSecondaryDoctor}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select secondary doctor" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No Secondary Doctor</SelectItem>
                          {doctors
                            .filter((doctor) => doctor.id !== primaryDoctor)
                            .map((doctor) => (
                              <SelectItem key={doctor.id} value={doctor.id}>
                                <div className="flex flex-col">
                                  <span>{doctor.name}</span>
                                  <span className="text-xs text-gray-500">
                                    {doctor.specialization} • {doctor.experience}
                                  </span>
                                </div>
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label>Chief Complaint</Label>
                      <Textarea
                        placeholder="Enter patient's main complaint"
                        value={formData.chiefComplaint}
                        onChange={(e) => updateFormData("chiefComplaint", e.target.value)}
                        rows={4}
                      />
                    </div>
                    <div>
                      <Label>Provisional Diagnosis</Label>
                      <Textarea
                        placeholder="Enter provisional diagnosis"
                        value={formData.provisionalDiagnosis}
                        onChange={(e) => updateFormData("provisionalDiagnosis", e.target.value)}
                        rows={4}
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Medical History</Label>
                    <Textarea
                      placeholder="Enter relevant medical history"
                      value={formData.medicalHistory}
                      onChange={(e) => updateFormData("medicalHistory", e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label>Allergies</Label>
                      <Textarea
                        placeholder="Enter known allergies"
                        value={formData.allergies}
                        onChange={(e) => updateFormData("allergies", e.target.value)}
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label>Current Medications</Label>
                      <Textarea
                        placeholder="Enter current medications"
                        value={formData.currentMedications}
                        onChange={(e) => updateFormData("currentMedications", e.target.value)}
                        rows={3}
                      />
                    </div>
                  </div>

                  <div className="flex justify-between pt-4">
                    <Button variant="outline" onClick={() => setCurrentStep("patient")}>
                      Back
                    </Button>
                    <Button onClick={() => setCurrentStep("bed")} className="bg-red-600 hover:bg-red-700">
                      Next: Bed Selection
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Bed Selection Step */}
        {currentStep === "bed" && (
          <div className="max-w-6xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bed className="h-5 w-5 mr-2 text-red-600" />
                  Bed Selection & Pricing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Bed Types */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Available Bed Types</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {bedTypes.map((bedType) => {
                        const price = customerType === "cash" ? bedType.cashPrice : bedType.insurancePrice
                        const finalPrice = selectedBed === bedType.id ? calculateBedPrice() : price
                        const isSelected = selectedBed === bedType.id

                        return (
                          <div
                            key={bedType.id}
                            className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                              isSelected ? "border-red-500 bg-red-50" : "border-gray-200 hover:border-gray-300"
                            }`}
                            onClick={() => setSelectedBed(bedType.id)}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-semibold">{bedType.name}</h3>
                              <Badge variant={isSelected ? "default" : "secondary"}>{bedType.category}</Badge>
                            </div>
                            <p className="text-sm text-gray-600 mb-2">{bedType.sharing}</p>
                            <div className="space-y-1 mb-3">
                              <div className="flex justify-between text-sm">
                                <span>Base Price:</span>
                                <span>₹{price.toLocaleString()}/day</span>
                              </div>
                              {isSelected && companyDiscount > 0 && (
                                <div className="flex justify-between text-sm text-green-600">
                                  <span>Company Discount:</span>
                                  <span>-{companyDiscount}%</span>
                                </div>
                              )}
                              {isSelected && customDiscount > 0 && (
                                <div className="flex justify-between text-sm text-blue-600">
                                  <span>Custom Discount:</span>
                                  <span>-₹{customDiscount}</span>
                                </div>
                              )}
                              <div className="flex justify-between font-semibold">
                                <span>Final Price:</span>
                                <span>₹{finalPrice.toLocaleString()}/day</span>
                              </div>
                            </div>
                            <div className="text-xs text-gray-500 mb-2">
                              <p className="font-medium mb-1">Amenities:</p>
                              <ul className="list-disc list-inside space-y-0.5">
                                {bedType.amenities.map((amenity, index) => (
                                  <li key={index}>{amenity}</li>
                                ))}
                              </ul>
                            </div>
                            <div className="flex items-center justify-between">
                              <Badge variant="outline" className="bg-green-50 text-green-700">
                                {bedType.available} Available
                              </Badge>
                              {isSelected && <CheckCircle className="h-5 w-5 text-red-600" />}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  {/* Available Beds */}
                  {selectedBed && (
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Select Specific Bed</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {availableBeds
                          .filter((bed) => bed.type === selectedBed)
                          .map((bed) => (
                            <div key={bed.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                              <div className="flex items-center justify-between mb-2">
                                <span className="font-medium">{bed.ward}</span>
                                <Badge variant="outline" className="bg-green-50 text-green-700">
                                  Available
                                </Badge>
                              </div>
                              <div className="space-y-1 text-sm text-gray-600 mb-3">
                                <p className="flex items-center">
                                  <Building className="h-3 w-3 mr-1" />
                                  {bed.floor}
                                </p>
                                <p className="flex items-center">
                                  <Bed className="h-3 w-3 mr-1" />
                                  Room {bed.room}, Bed {bed.bed}
                                </p>
                              </div>
                              <Button size="sm" className="w-full bg-red-600 hover:bg-red-700">
                                Select This Bed
                              </Button>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between pt-4">
                    <Button variant="outline" onClick={() => setCurrentStep("medical")}>
                      Back
                    </Button>
                    <Button
                      onClick={() => setCurrentStep("payment")}
                      className="bg-red-600 hover:bg-red-700"
                      disabled={!selectedBed}
                    >
                      Next: Payment & Advance
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Payment & Advance Step */}
        {currentStep === "payment" && (
          <div className="max-w-6xl mx-auto space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Payment Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calculator className="h-5 w-5 mr-2 text-red-600" />
                    Admission Charges Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                      <div className="flex justify-between">
                        <span>Bed Charges (per day):</span>
                        <span>₹{calculateBedPrice().toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Registration Fee:</span>
                        <span>₹500</span>
                      </div>
                      {companyDiscount > 0 && (
                        <div className="flex justify-between text-green-600">
                          <span>Company Discount Applied:</span>
                          <span>-{companyDiscount}%</span>
                        </div>
                      )}
                      {customDiscount > 0 && (
                        <div className="flex justify-between text-blue-600">
                          <span>Custom Discount Applied:</span>
                          <span>-₹{customDiscount}</span>
                        </div>
                      )}
                      <Separator />
                      <div className="flex justify-between font-bold text-lg">
                        <span>Daily Charges:</span>
                        <span>₹{(calculateBedPrice() + 500).toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Patient Summary */}
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Patient Summary</h4>
                      <div className="space-y-1 text-sm">
                        <p>
                          <strong>Name:</strong> {formData.firstName} {formData.lastName}
                        </p>
                        <p>
                          <strong>Phone:</strong> {formData.phone}
                        </p>
                        <p>
                          <strong>Department:</strong> {departments.find((d) => d.id === selectedDepartment)?.name}
                        </p>
                        <p>
                          <strong>Primary Doctor:</strong> {doctors.find((d) => d.id === primaryDoctor)?.name}
                        </p>
                        <p>
                          <strong>Bed Type:</strong> {bedTypes.find((b) => b.id === selectedBed)?.name}
                        </p>
                        <p>
                          <strong>Customer Type:</strong>{" "}
                          {customerType === "cash" ? "Cash Customer" : "Insurance Customer"}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Advance Payment Collection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="h-5 w-5 mr-2 text-green-600" />
                    Advance Payment Collection
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="collectAdvance" checked={collectAdvance} onCheckedChange={setCollectAdvance} />
                      <Label htmlFor="collectAdvance" className="font-medium">
                        Collect Advance Payment
                      </Label>
                    </div>

                    {collectAdvance && (
                      <div className="space-y-4 p-4 border rounded-lg bg-green-50">
                        <div>
                          <Label>Advance Amount (₹)</Label>
                          <Input
                            type="number"
                            value={advancePayment.amount}
                            onChange={(e) => setAdvancePayment((prev) => ({ ...prev, amount: Number(e.target.value) }))}
                            placeholder="Enter advance amount"
                            min="0"
                          />
                          <p className="text-sm text-gray-600 mt-1">Recommended: ₹10,000 - ₹50,000 based on bed type</p>
                        </div>

                        <div>
                          <Label>Payment Method</Label>
                          <Select
                            value={advancePayment.method}
                            onValueChange={(value) => setAdvancePayment((prev) => ({ ...prev, method: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="cash">Cash</SelectItem>
                              <SelectItem value="card">Credit/Debit Card</SelectItem>
                              <SelectItem value="upi">UPI</SelectItem>
                              <SelectItem value="netbanking">Net Banking</SelectItem>
                              <SelectItem value="cheque">Cheque</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {(advancePayment.method === "card" ||
                          advancePayment.method === "upi" ||
                          advancePayment.method === "netbanking") && (
                          <div>
                            <Label>Transaction Reference</Label>
                            <Input
                              placeholder="Enter transaction ID/reference"
                              value={advancePayment.reference || ""}
                              onChange={(e) => setAdvancePayment((prev) => ({ ...prev, reference: e.target.value }))}
                            />
                          </div>
                        )}

                        {advancePayment.method === "cheque" && (
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Cheque Number</Label>
                              <Input
                                placeholder="Cheque number"
                                value={advancePayment.reference || ""}
                                onChange={(e) => setAdvancePayment((prev) => ({ ...prev, reference: e.target.value }))}
                              />
                            </div>
                            <div>
                              <Label>Bank Name</Label>
                              <Input placeholder="Bank name" />
                            </div>
                          </div>
                        )}

                        <div>
                          <Label>Payment Notes</Label>
                          <Textarea
                            placeholder="Enter any payment notes or remarks"
                            value={advancePayment.notes || ""}
                            onChange={(e) => setAdvancePayment((prev) => ({ ...prev, notes: e.target.value }))}
                            rows={3}
                          />
                        </div>

                        <div className="p-3 bg-blue-50 border border-blue-200 rounded">
                          <div className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-blue-600" />
                            <span className="text-sm font-medium text-blue-800">Advance Payment Benefits</span>
                          </div>
                          <ul className="text-sm text-blue-700 mt-1 space-y-1">
                            <li>• Secures bed reservation</li>
                            <li>• Reduces discharge settlement time</li>
                            <li>• Covers emergency procedures</li>
                            <li>• Refundable upon discharge</li>
                          </ul>
                        </div>
                      </div>
                    )}

                    {/* Total Summary */}
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-semibold mb-3">Total Collection Summary</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Registration Fee:</span>
                          <span>₹500</span>
                        </div>
                        {collectAdvance && (
                          <div className="flex justify-between">
                            <span>Advance Payment:</span>
                            <span>₹{advancePayment.amount.toLocaleString()}</span>
                          </div>
                        )}
                        <Separator />
                        <div className="flex justify-between font-bold text-lg">
                          <span>Total Collection:</span>
                          <span className="text-green-600">
                            ₹{(500 + (collectAdvance ? advancePayment.amount : 0)).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Important Notes */}
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-start">
                        <AlertCircle className="h-5 w-5 text-yellow-600 mr-2 mt-0.5" />
                        <div className="text-sm">
                          <p className="font-medium text-yellow-800 mb-1">Important Notes:</p>
                          <ul className="text-yellow-700 space-y-1">
                            <li>• Daily bed charges will be calculated from admission time</li>
                            <li>• Additional charges for procedures will be billed separately</li>
                            <li>• Insurance pre-authorization may be required</li>
                            <li>• Advance amount is adjustable against final bill</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <Button
                      onClick={() => setCurrentStep("complete")}
                      className="w-full bg-green-600 hover:bg-green-700"
                      size="lg"
                    >
                      Process Admission & Payment
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setCurrentStep("bed")}>
                Back
              </Button>
            </div>
          </div>
        )}

        {/* Complete Step */}
        {currentStep === "complete" && (
          <div className="max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-green-600 text-center justify-center">
                  <CheckCircle className="h-6 w-6 mr-2" />
                  Admission Successfully Completed!
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-6">
                  <div className="p-6 bg-green-50 border border-green-200 rounded-lg">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-green-800">Patient Successfully Admitted</h3>
                      <p className="text-green-600 text-lg">
                        IP Number: <strong>IP001238</strong>
                      </p>
                      <p className="text-green-600">
                        Bed Assignment: {availableBeds.find((b) => b.type === selectedBed)?.ward} - Room{" "}
                        {availableBeds.find((b) => b.type === selectedBed)?.room}
                        {availableBeds.find((b) => b.type === selectedBed)?.bed}
                      </p>
                      <p className="text-green-600">Admission Date: {format(selectedDate, "PPP")}</p>
                      <p className="text-green-600">
                        Total Amount Collected: ₹{(500 + (collectAdvance ? advancePayment.amount : 0)).toLocaleString()}
                      </p>
                      {collectAdvance && (
                        <p className="text-blue-600">
                          Advance Payment: ₹{advancePayment.amount.toLocaleString()} via {advancePayment.method}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Button variant="outline" className="flex items-center justify-center bg-transparent">
                      <FileText className="h-4 w-4 mr-2" />
                      Print Admission Form
                    </Button>
                    <Button variant="outline" className="flex items-center justify-center bg-transparent">
                      <Phone className="h-4 w-4 mr-2" />
                      Send WhatsApp Notification
                    </Button>
                    <Button variant="outline" className="flex items-center justify-center bg-transparent">
                      <Users className="h-4 w-4 mr-2" />
                      View Patient Profile
                    </Button>
                  </div>

                  {/* Next Steps */}
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-left">
                    <h4 className="font-semibold text-blue-800 mb-2">Next Steps:</h4>
                    <ul className="text-blue-700 space-y-1 text-sm">
                      <li>• Patient wristband will be prepared and provided</li>
                      <li>• Nursing staff will be notified for bed preparation</li>
                      <li>• Primary doctor will be informed about the admission</li>
                      <li>• Insurance verification process will begin (if applicable)</li>
                      <li>• Patient orientation will be conducted by nursing staff</li>
                      {collectAdvance && <li>• Advance payment receipt will be generated</li>}
                    </ul>
                  </div>

                  <div className="flex justify-center gap-4">
                    <Link href="/inpatient">
                      <Button variant="outline">Back to Dashboard</Button>
                    </Link>
                    <Button onClick={() => setCurrentStep("patient")} className="bg-red-600 hover:bg-red-700">
                      Admit Another Patient
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
      </div>
    </PrivateRoute>
  )
}

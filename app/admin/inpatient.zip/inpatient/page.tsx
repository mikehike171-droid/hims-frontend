"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Users,
  Bed,
  UserPlus,
  Activity,
  Clock,
  AlertCircle,
  ArrowUpRight,
  Calendar,
  Stethoscope,
  FileText,
  Bell,
  Search,
  Filter,
  Download,
  RefreshCw,
} from "lucide-react"
import { TransferRequestDialog } from "@/components/inpatient/transfer-request-dialog"
import { NotificationDialog } from "@/components/inpatient/notification-dialog"
import Link from "next/link"

export default function InpatientDashboard() {
  const [showTransferDialog, setShowTransferDialog] = useState(false)
  const [showNotificationDialog, setShowNotificationDialog] = useState(false)

  const stats = [
    {
      title: "Total Patients",
      value: "156",
      change: "+12%",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "Available Beds",
      value: "24",
      change: "-8%",
      icon: Bed,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "New Admissions",
      value: "8",
      change: "+25%",
      icon: UserPlus,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      title: "Critical Patients",
      value: "3",
      change: "0%",
      icon: Activity,
      color: "text-red-600",
      bgColor: "bg-red-50",
    },
  ]

  const recentAdmissions = [
    {
      id: "IP001234",
      name: "John Smith",
      age: 45,
      gender: "Male",
      ward: "General Ward A",
      room: "101",
      bed: "A",
      admissionDate: "2024-01-15",
      doctor: "Dr. Rajesh Kumar",
      condition: "Stable",
      insurance: "Star Health",
      tpa: "Medi Assist",
    },
    {
      id: "IP001235",
      name: "Mary Johnson",
      age: 32,
      gender: "Female",
      ward: "Maternity",
      room: "201",
      bed: "B",
      admissionDate: "2024-01-14",
      doctor: "Dr. Priya Sharma",
      condition: "Good",
      insurance: "HDFC ERGO",
      tpa: "Vidal Health",
    },
    {
      id: "IP001236",
      name: "Robert Davis",
      age: 67,
      gender: "Male",
      ward: "ICU",
      room: "301",
      bed: "A",
      admissionDate: "2024-01-13",
      doctor: "Dr. Michael Chen",
      condition: "Critical",
      insurance: "Cash Patient",
      tpa: "N/A",
    },
  ]

  const bedOccupancy = [
    { ward: "General Ward A", total: 20, occupied: 18, available: 2, occupancy: 90 },
    { ward: "General Ward B", total: 20, occupied: 15, available: 5, occupancy: 75 },
    { ward: "ICU", total: 10, occupied: 8, available: 2, occupancy: 80 },
    { ward: "Maternity", total: 15, occupied: 12, available: 3, occupancy: 80 },
    { ward: "Pediatrics", total: 12, occupied: 8, available: 4, occupancy: 67 },
    { ward: "Private Rooms", total: 25, occupied: 20, available: 5, occupancy: 80 },
  ]

  const pendingTasks = [
    { id: 1, task: "Discharge approval for IP001230", priority: "high", time: "2 hours ago" },
    { id: 2, task: "Bed transfer request for IP001228", priority: "medium", time: "4 hours ago" },
    { id: 3, task: "Insurance verification for IP001240", priority: "low", time: "6 hours ago" },
    { id: 4, task: "Lab results review for IP001235", priority: "high", time: "1 hour ago" },
  ]

  const getConditionColor = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "critical":
        return "bg-red-100 text-red-800"
      case "stable":
        return "bg-yellow-100 text-yellow-800"
      case "good":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-600"
      case "medium":
        return "text-yellow-600"
      case "low":
        return "text-green-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <PrivateRoute modulePath="admin/inpatient" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Inpatient Dashboard</h1>
          <p className="text-gray-600">Manage inpatient admissions, beds, and patient care</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Link href="/inpatient/admission/new">
            <Button className="bg-red-600 hover:bg-red-700">
              <UserPlus className="h-4 w-4 mr-2" />
              New Admission
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p
                    className={`text-sm ${stat.change.startsWith("+") ? "text-green-600" : stat.change.startsWith("-") ? "text-red-600" : "text-gray-600"}`}
                  >
                    {stat.change} from last month
                  </p>
                </div>
                <div className={`p-3 rounded-full ${stat.bgColor}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Admissions */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-red-600" />
                  Recent Admissions
                </CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Search className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentAdmissions.map((patient) => (
                  <div key={patient.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 bg-red-100 rounded-full flex items-center justify-center">
                          <Users className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{patient.name}</h3>
                          <p className="text-sm text-gray-600">
                            {patient.age}Y, {patient.gender} • {patient.id}
                          </p>
                        </div>
                      </div>
                      <Badge className={getConditionColor(patient.condition)}>{patient.condition}</Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center">
                        <Bed className="h-4 w-4 mr-1 text-gray-400" />
                        <span>
                          {patient.ward} - {patient.room}
                          {patient.bed}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <Stethoscope className="h-4 w-4 mr-1 text-gray-400" />
                        <span>{patient.doctor}</span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                        <span>{patient.admissionDate}</span>
                      </div>
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 mr-1 text-gray-400" />
                        <span>{patient.insurance}</span>
                      </div>
                    </div>
                    {patient.tpa !== "N/A" && <div className="mt-2 text-sm text-blue-600">TPA: {patient.tpa}</div>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Pending Tasks */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2 text-orange-600" />
                Pending Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingTasks.map((task) => (
                  <div key={task.id} className="p-3 border rounded-lg">
                    <div className="flex items-start justify-between mb-1">
                      <p className="text-sm font-medium">{task.task}</p>
                      <AlertCircle className={`h-4 w-4 ${getPriorityColor(task.priority)}`} />
                    </div>
                    <p className="text-xs text-gray-500">{task.time}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={() => setShowTransferDialog(true)}
                >
                  <ArrowUpRight className="h-4 w-4 mr-2" />
                  Transfer Patient
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <FileText className="h-4 w-4 mr-2" />
                  Discharge Patient
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={() => setShowNotificationDialog(true)}
                >
                  <Bell className="h-4 w-4 mr-2" />
                  Send Notification
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bed Occupancy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bed className="h-5 w-5 mr-2 text-blue-600" />
            Bed Occupancy by Ward
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {bedOccupancy.map((ward, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{ward.ward}</span>
                  <span className="text-sm text-gray-600">
                    {ward.occupied}/{ward.total} beds ({ward.occupancy}%)
                  </span>
                </div>
                <Progress value={ward.occupancy} className="h-2" />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Occupied: {ward.occupied}</span>
                  <span>Available: {ward.available}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

        {/* Dialogs */}
        <TransferRequestDialog open={showTransferDialog} onOpenChange={setShowTransferDialog} />
        <NotificationDialog open={showNotificationDialog} onOpenChange={setShowNotificationDialog} />
      </div>
    </PrivateRoute>
  )
}

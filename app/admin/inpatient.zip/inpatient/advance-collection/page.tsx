"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Search,
  DollarSign,
  CreditCard,
  Receipt,
  User,
  Bed,
  Calendar,
  Phone,
  AlertCircle,
  CheckCircle,
  FileText,
} from "lucide-react"

interface AdmittedPatient {
  id: string
  ipNumber: string
  name: string
  age: number
  gender: string
  phone: string
  ward: string
  room: string
  bed: string
  admissionDate: string
  doctor: string
  department: string
  diagnosis: string
  currentAdvance: number
  totalBilled: number
  balanceAmount: number
  status: "active" | "discharged" | "transferred"
}

interface AdvanceCollection {
  id: string
  patientId: string
  amount: number
  paymentMethod: string
  transactionId?: string
  collectedBy: string
  collectedDate: string
  remarks: string
  receiptNumber: string
}

const mockAdmittedPatients: AdmittedPatient[] = [
  {
    id: "1",
    ipNumber: "IP001234",
    name: "John Smith",
    age: 45,
    gender: "Male",
    phone: "+91-9876543210",
    ward: "General Ward A",
    room: "101",
    bed: "A",
    admissionDate: "2024-01-15",
    doctor: "Dr. Rajesh Kumar",
    department: "Cardiology",
    diagnosis: "Acute Myocardial Infarction",
    currentAdvance: 15000,
    totalBilled: 8500,
    balanceAmount: 6500,
    status: "active",
  },
  {
    id: "2",
    ipNumber: "IP001235",
    name: "Mary Johnson",
    age: 32,
    gender: "Female",
    phone: "+91-9876543211",
    ward: "Maternity",
    room: "201",
    bed: "B",
    admissionDate: "2024-01-18",
    doctor: "Dr. Priya Sharma",
    department: "Obstetrics",
    diagnosis: "Normal Delivery",
    currentAdvance: 25000,
    totalBilled: 12000,
    balanceAmount: 13000,
    status: "active",
  },
  {
    id: "3",
    ipNumber: "IP001236",
    name: "Robert Davis",
    age: 67,
    gender: "Male",
    phone: "+91-9876543212",
    ward: "ICU",
    room: "301",
    bed: "A",
    admissionDate: "2024-01-16",
    doctor: "Dr. Michael Chen",
    department: "Critical Care",
    diagnosis: "Respiratory Failure",
    currentAdvance: 50000,
    totalBilled: 45000,
    balanceAmount: 5000,
    status: "active",
  },
]

export default function AdvanceCollection() {
  const [patients, setPatients] = useState<AdmittedPatient[]>(mockAdmittedPatients)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<AdmittedPatient | null>(null)
  const [isCollectionDialogOpen, setIsCollectionDialogOpen] = useState(false)
  const [collectionAmount, setCollectionAmount] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("cash")
  const [transactionId, setTransactionId] = useState("")
  const [remarks, setRemarks] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.ipNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.phone.includes(searchTerm),
  )

  const handleCollectAdvance = async () => {
    if (!selectedPatient || !collectionAmount || Number.parseFloat(collectionAmount) <= 0) {
      alert("Please enter a valid amount")
      return
    }

    setIsProcessing(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const newAdvanceCollection: AdvanceCollection = {
      id: Date.now().toString(),
      patientId: selectedPatient.id,
      amount: Number.parseFloat(collectionAmount),
      paymentMethod,
      transactionId: transactionId || undefined,
      collectedBy: "Current User",
      collectedDate: new Date().toISOString(),
      remarks,
      receiptNumber: `ADV${Date.now()}`,
    }

    // Update patient's advance amount
    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? {
              ...patient,
              currentAdvance: patient.currentAdvance + Number.parseFloat(collectionAmount),
              balanceAmount: patient.balanceAmount + Number.parseFloat(collectionAmount),
            }
          : patient,
      ),
    )

    alert(`Advance of ₹${collectionAmount} collected successfully!
Receipt Number: ${newAdvanceCollection.receiptNumber}`)

    // Reset form
    setCollectionAmount("")
    setPaymentMethod("cash")
    setTransactionId("")
    setRemarks("")
    setIsCollectionDialogOpen(false)
    setSelectedPatient(null)
    setIsProcessing(false)
  }

  const openCollectionDialog = (patient: AdmittedPatient) => {
    setSelectedPatient(patient)
    setIsCollectionDialogOpen(true)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "discharged":
        return "bg-blue-100 text-blue-800"
      case "transferred":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getBalanceColor = (balance: number) => {
    if (balance > 10000) return "text-green-600"
    if (balance > 5000) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <PrivateRoute modulePath="admin/inpatient/advance-collection" action="add">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Advance Collection</h1>
          <p className="text-gray-600">Collect additional advance payments from admitted patients</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Collection Report
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Patients</p>
                <p className="text-2xl font-bold text-gray-900">
                  {patients.filter((p) => p.status === "active").length}
                </p>
              </div>
              <User className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Advance</p>
                <p className="text-2xl font-bold text-green-600">
                  ₹{patients.reduce((sum, p) => sum + p.currentAdvance, 0).toLocaleString()}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Billed</p>
                <p className="text-2xl font-bold text-purple-600">
                  ₹{patients.reduce((sum, p) => sum + p.totalBilled, 0).toLocaleString()}
                </p>
              </div>
              <Receipt className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Balance Available</p>
                <p className="text-2xl font-bold text-orange-600">
                  ₹{patients.reduce((sum, p) => sum + p.balanceAmount, 0).toLocaleString()}
                </p>
              </div>
              <CreditCard className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by patient name, IP number, or phone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Patients Table */}
      <Card>
        <CardHeader>
          <CardTitle>Admitted Patients ({filteredPatients.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient Details</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Doctor</TableHead>
                  <TableHead>Admission</TableHead>
                  <TableHead>Financial Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPatients.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{patient.name}</div>
                        <div className="text-sm text-gray-500">
                          {patient.ipNumber} • {patient.age}Y {patient.gender}
                        </div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <Phone className="h-3 w-3 mr-1" />
                          {patient.phone}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Bed className="h-4 w-4 mr-1 text-gray-400" />
                        <div>
                          <div className="font-medium">{patient.ward}</div>
                          <div className="text-sm text-gray-500">
                            Room {patient.room}
                            {patient.bed}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{patient.doctor}</div>
                        <div className="text-sm text-gray-500">{patient.department}</div>
                        <div className="text-sm text-gray-500">{patient.diagnosis}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                        <div>
                          <div className="font-medium">{patient.admissionDate}</div>
                          <Badge className={getStatusColor(patient.status)}>{patient.status}</Badge>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Advance:</span>
                          <span className="font-medium text-green-600">₹{patient.currentAdvance.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Billed:</span>
                          <span className="font-medium text-purple-600">₹{patient.totalBilled.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Balance:</span>
                          <span className={`font-medium ${getBalanceColor(patient.balanceAmount)}`}>
                            ₹{patient.balanceAmount.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          onClick={() => openCollectionDialog(patient)}
                          className="bg-green-600 hover:bg-green-700"
                          disabled={patient.status !== "active"}
                        >
                          <DollarSign className="h-3 w-3 mr-1" />
                          Collect
                        </Button>
                        <Button size="sm" variant="outline">
                          <Receipt className="h-3 w-3 mr-1" />
                          History
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {filteredPatients.length === 0 && (
              <div className="text-center py-8">
                <User className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-500">No patients found matching your search</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Advance Collection Dialog */}
      <Dialog open={isCollectionDialogOpen} onOpenChange={setIsCollectionDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Collect Advance Payment</DialogTitle>
            <DialogDescription>Collect additional advance payment from {selectedPatient?.name}</DialogDescription>
          </DialogHeader>

          {selectedPatient && (
            <div className="space-y-6">
              {/* Patient Summary */}
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium">{selectedPatient.name}</p>
                    <p className="text-gray-600">{selectedPatient.ipNumber}</p>
                    <p className="text-gray-600">
                      {selectedPatient.ward} - {selectedPatient.room}
                      {selectedPatient.bed}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-600">
                      Current Advance:{" "}
                      <span className="font-medium text-green-600">
                        ₹{selectedPatient.currentAdvance.toLocaleString()}
                      </span>
                    </p>
                    <p className="text-gray-600">
                      Total Billed:{" "}
                      <span className="font-medium text-purple-600">
                        ₹{selectedPatient.totalBilled.toLocaleString()}
                      </span>
                    </p>
                    <p className="text-gray-600">
                      Balance:{" "}
                      <span className={`font-medium ${getBalanceColor(selectedPatient.balanceAmount)}`}>
                        ₹{selectedPatient.balanceAmount.toLocaleString()}
                      </span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Collection Form */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="amount">Collection Amount (₹) *</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={collectionAmount}
                      onChange={(e) => setCollectionAmount(e.target.value)}
                      placeholder="Enter amount"
                      min="1"
                      step="1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="payment-method">Payment Method *</Label>
                    <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="card">Credit/Debit Card</SelectItem>
                        <SelectItem value="upi">UPI</SelectItem>
                        <SelectItem value="netbanking">Net Banking</SelectItem>
                        <SelectItem value="cheque">Cheque</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {(paymentMethod === "card" || paymentMethod === "upi" || paymentMethod === "netbanking") && (
                  <div>
                    <Label htmlFor="transaction-id">Transaction ID/Reference</Label>
                    <Input
                      id="transaction-id"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      placeholder="Enter transaction ID or reference number"
                    />
                  </div>
                )}

                {paymentMethod === "cheque" && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="cheque-number">Cheque Number</Label>
                      <Input
                        id="cheque-number"
                        value={transactionId}
                        onChange={(e) => setTransactionId(e.target.value)}
                        placeholder="Enter cheque number"
                      />
                    </div>
                    <div>
                      <Label htmlFor="bank-name">Bank Name</Label>
                      <Input id="bank-name" placeholder="Enter bank name" />
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="remarks">Remarks</Label>
                  <Textarea
                    id="remarks"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Enter any remarks or notes for this collection..."
                    rows={3}
                  />
                </div>
              </div>

              {/* Important Notes */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-blue-800 mb-1">Important Notes:</p>
                    <ul className="text-blue-700 space-y-1">
                      <li>• Advance amount will be added to patient's account balance</li>
                      <li>• Receipt will be generated automatically</li>
                      <li>• Patient and attendants will be notified</li>
                      <li>• Amount is adjustable against final discharge bill</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsCollectionDialogOpen(false)} disabled={isProcessing}>
                  Cancel
                </Button>
                <Button
                  onClick={handleCollectAdvance}
                  disabled={!collectionAmount || Number.parseFloat(collectionAmount) <= 0 || isProcessing}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Collect ₹{collectionAmount || "0"}
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      </div>
    </PrivateRoute>
  )
}

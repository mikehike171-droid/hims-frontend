"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Bed,
  Search,
  MapPin,
  Users,
  AlertTriangle,
  CheckCircle,
  Clock,
  Wrench,
  Ban,
  User,
  Calendar,
} from "lucide-react"
import Link from "next/link"

// Mock data
const wards = [
  { id: 1, name: "General Ward A", total: 20, occupied: 18, available: 2 },
  { id: 2, name: "ICU", total: 10, occupied: 8, available: 2 },
  { id: 3, name: "Pediatric Ward", total: 15, occupied: 10, available: 5 },
  { id: 4, name: "Maternity Ward", total: 12, occupied: 7, available: 5 },
  { id: 5, name: "Isolation Ward", total: 8, occupied: 3, available: 5 },
]

const beds = [
  {
    id: 1,
    ward: "General Ward A",
    room: "101",
    bed: "A",
    status: "occupied",
    patient: {
      name: "John Smith",
      age: 45,
      ipNumber: "IP001234",
      admissionDate: "2024-01-15",
      doctor: "Dr. Sarah Wilson",
      phone: "+91 9876543210",
    },
    type: "Standard",
    rate: 1500,
  },
  {
    id: 2,
    ward: "General Ward A",
    room: "101",
    bed: "B",
    status: "vacant",
    patient: null,
    type: "Standard",
    rate: 1500,
  },
  {
    id: 3,
    ward: "General Ward A",
    room: "102",
    bed: "A",
    status: "cleaning",
    patient: null,
    type: "Standard",
    rate: 1500,
    cleaningScheduled: "2024-01-18 14:00",
  },
  {
    id: 4,
    ward: "ICU",
    room: "201",
    bed: "A",
    status: "occupied",
    patient: {
      name: "Robert Davis",
      age: 67,
      ipNumber: "IP001236",
      admissionDate: "2024-01-14",
      doctor: "Dr. Michael Chen",
      phone: "+91 9876543212",
    },
    type: "ICU",
    rate: 5000,
  },
  {
    id: 5,
    ward: "ICU",
    room: "202",
    bed: "A",
    status: "vacant",
    patient: null,
    type: "ICU",
    rate: 5000,
  },
  {
    id: 6,
    ward: "Maternity Ward",
    room: "401",
    bed: "A",
    status: "occupied",
    patient: {
      name: "Mary Johnson",
      age: 32,
      ipNumber: "IP001235",
      admissionDate: "2024-01-16",
      doctor: "Dr. Emily Brown",
      phone: "+91 9876543211",
    },
    type: "Deluxe",
    rate: 3000,
  },
  {
    id: 7,
    ward: "Pediatric Ward",
    room: "301",
    bed: "A",
    status: "maintenance",
    patient: null,
    type: "Pediatric",
    rate: 1200,
    maintenanceReason: "Bed motor repair",
  },
  {
    id: 8,
    ward: "Isolation Ward",
    room: "501",
    bed: "A",
    status: "blocked",
    patient: null,
    type: "Isolation",
    rate: 4000,
    blockReason: "Deep cleaning protocol",
  },
]

const pendingAdmissions = [
  {
    id: 1,
    patientName: "Alice Cooper",
    age: 29,
    gender: "Female",
    diagnosis: "Gastritis",
    doctor: "Dr. Sarah Wilson",
    priority: "normal",
    requestedWard: "General Ward A",
    requestTime: "2024-01-18 10:30",
  },
  {
    id: 2,
    patientName: "David Wilson",
    age: 55,
    gender: "Male",
    diagnosis: "Chest Pain",
    doctor: "Dr. Michael Chen",
    priority: "high",
    requestedWard: "ICU",
    requestTime: "2024-01-18 11:15",
  },
]

export default function BedManagement() {
  const [selectedWard, setSelectedWard] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedBed, setSelectedBed] = useState<any>(null)

  const filteredBeds = beds.filter((bed) => {
    const matchesWard = selectedWard === "all" || bed.ward === selectedWard
    const matchesStatus = statusFilter === "all" || bed.status === statusFilter
    const matchesSearch =
      bed.room.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bed.bed.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bed.patient?.name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesWard && matchesStatus && matchesSearch
  })

  const getBedStatusColor = (status: string) => {
    switch (status) {
      case "occupied":
        return "bg-red-100 text-red-800 border-red-200"
      case "vacant":
        return "bg-green-100 text-green-800 border-green-200"
      case "cleaning":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "maintenance":
        return "bg-orange-100 text-orange-800 border-orange-200"
      case "blocked":
        return "bg-gray-100 text-gray-800 border-gray-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getBedStatusIcon = (status: string) => {
    switch (status) {
      case "occupied":
        return <User className="h-4 w-4" />
      case "vacant":
        return <CheckCircle className="h-4 w-4" />
      case "cleaning":
        return <Clock className="h-4 w-4" />
      case "maintenance":
        return <Wrench className="h-4 w-4" />
      case "blocked":
        return <Ban className="h-4 w-4" />
      default:
        return <Bed className="h-4 w-4" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "normal":
        return "bg-blue-100 text-blue-800"
      case "low":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <PrivateRoute modulePath="admin/inpatient/beds" action="view">
      <div className="min-h-screen bg-gray-50">
        <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Bed Management</h1>
          <p className="text-gray-600">Monitor and manage hospital bed allocation</p>
        </div>

        {/* Ward Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
          {wards.map((ward) => (
            <Card key={ward.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-sm">{ward.name}</h3>
                  <MapPin className="h-4 w-4 text-gray-400" />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Occupied:</span>
                    <span className="font-medium">
                      {ward.occupied}/{ward.total}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-red-600 h-2 rounded-full"
                      style={{ width: `${(ward.occupied / ward.total) * 100}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-500">{ward.available} beds available</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search beds, rooms, or patients..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>

          <select
            value={selectedWard}
            onChange={(e) => setSelectedWard(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Wards</option>
            {wards.map((ward) => (
              <option key={ward.id} value={ward.name}>
                {ward.name}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Status</option>
            <option value="occupied">Occupied</option>
            <option value="vacant">Vacant</option>
            <option value="cleaning">Cleaning</option>
            <option value="maintenance">Maintenance</option>
            <option value="blocked">Blocked</option>
          </select>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Bed Grid */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Bed Status Map</span>
                  <Badge variant="outline">{filteredBeds.length} beds</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                  {filteredBeds.map((bed) => (
                    <div
                      key={bed.id}
                      className={`p-4 border-2 rounded-lg cursor-pointer transition-all hover:shadow-md ${getBedStatusColor(bed.status)} ${
                        selectedBed?.id === bed.id ? "ring-2 ring-red-600" : ""
                      }`}
                      onClick={() => setSelectedBed(bed)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-1">
                          {getBedStatusIcon(bed.status)}
                          <span className="font-semibold text-sm">
                            {bed.room}
                            {bed.bed}
                          </span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {bed.type}
                        </Badge>
                      </div>

                      <div className="text-xs space-y-1">
                        <p className="font-medium">{bed.ward}</p>
                        {bed.patient ? (
                          <>
                            <p className="text-gray-700">{bed.patient.name}</p>
                            <p className="text-gray-500">IP: {bed.patient.ipNumber}</p>
                          </>
                        ) : (
                          <p className="text-gray-500 capitalize">{bed.status}</p>
                        )}
                        <p className="font-medium">₹{bed.rate}/day</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Bed Details */}
            {selectedBed && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bed Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg">
                      {selectedBed.ward} - {selectedBed.room}
                      {selectedBed.bed}
                    </h3>
                    <div className="flex items-center space-x-2 mt-1">
                      {getBedStatusIcon(selectedBed.status)}
                      <Badge className={getBedStatusColor(selectedBed.status)}>
                        {selectedBed.status.charAt(0).toUpperCase() + selectedBed.status.slice(1)}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Bed Type:</span>
                      <span className="font-medium">{selectedBed.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Daily Rate:</span>
                      <span className="font-medium">₹{selectedBed.rate}</span>
                    </div>
                  </div>

                  {selectedBed.patient && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-2">Current Patient</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Name:</span>
                          <span className="font-medium">{selectedBed.patient.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Age:</span>
                          <span>{selectedBed.patient.age}Y</span>
                        </div>
                        <div className="flex justify-between">
                          <span>IP Number:</span>
                          <span>{selectedBed.patient.ipNumber}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Doctor:</span>
                          <span>{selectedBed.patient.doctor}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Admitted:</span>
                          <span>{new Date(selectedBed.patient.admissionDate).toLocaleDateString()}</span>
                        </div>
                      </div>

                      <div className="mt-4 space-y-2">
                        <Link href={`/inpatient/patient/${selectedBed.patient.ipNumber}`}>
                          <Button size="sm" className="w-full bg-red-600 hover:bg-red-700">
                            View Patient Profile
                          </Button>
                        </Link>
                      </div>
                    </div>
                  )}

                  {selectedBed.status === "cleaning" && selectedBed.cleaningScheduled && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-2">Cleaning Schedule</h4>
                      <p className="text-sm text-gray-600">
                        Scheduled: {new Date(selectedBed.cleaningScheduled).toLocaleString()}
                      </p>
                    </div>
                  )}

                  {selectedBed.status === "maintenance" && selectedBed.maintenanceReason && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-2">Maintenance</h4>
                      <p className="text-sm text-gray-600">{selectedBed.maintenanceReason}</p>
                    </div>
                  )}

                  {selectedBed.status === "blocked" && selectedBed.blockReason && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-2">Blocked</h4>
                      <p className="text-sm text-gray-600">{selectedBed.blockReason}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Pending Admissions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-orange-600" />
                  Pending Admissions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {pendingAdmissions.map((admission) => (
                    <div key={admission.id} className="p-3 border rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-sm">{admission.patientName}</h4>
                          <p className="text-xs text-gray-600">
                            {admission.age}Y, {admission.gender}
                          </p>
                        </div>
                        <Badge className={getPriorityColor(admission.priority)}>{admission.priority}</Badge>
                      </div>
                      <div className="text-xs text-gray-600 space-y-1">
                        <p>
                          <strong>Diagnosis:</strong> {admission.diagnosis}
                        </p>
                        <p>
                          <strong>Doctor:</strong> {admission.doctor}
                        </p>
                        <p>
                          <strong>Requested:</strong> {admission.requestedWard}
                        </p>
                        <p>
                          <strong>Time:</strong> {new Date(admission.requestTime).toLocaleString()}
                        </p>
                      </div>
                      <Button size="sm" className="w-full mt-2 bg-red-600 hover:bg-red-700">
                        Assign Bed
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/inpatient">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Users className="h-4 w-4 mr-2" />
                    View All Patients
                  </Button>
                </Link>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Calendar className="h-4 w-4 mr-2" />
                  Cleaning Schedule
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Wrench className="h-4 w-4 mr-2" />
                  Maintenance Log
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
        </div>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  User,
  MapPin,
  Calendar,
  Phone,
  FileText,
  Stethoscope,
  Activity,
  TestTube,
  Download,
  ArrowLeft,
  Edit,
  Save,
  Mic,
  Brain,
  Clock,
  AlertTriangle,
} from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"

// Mock patient data
const patientData = {
  id: 1,
  name: "John Smith",
  age: 45,
  gender: "Male",
  ipNumber: "IP001234",
  uhid: "UH001234",
  phone: "+91 9876543210",
  ward: "General Ward A",
  room: "101",
  bed: "A",
  doctor: "Dr. Sarah Wilson",
  admissionDate: "2024-01-15T10:30:00",
  diagnosis: "Pneumonia",
  condition: "Stable",
  daysAdmitted: 3,
  emergencyContact: "Jane Smith (Wife)",
  emergencyPhone: "+91 9876543211",
  insurance: "HDFC ERGO - POL123456",
  estimatedDischarge: "2024-01-20",
  vitals: {
    temperature: "98.6°F",
    bloodPressure: "120/80",
    heartRate: "72 bpm",
    spO2: "98%",
    respiratoryRate: "16/min",
    lastUpdated: "2024-01-18T14:30:00",
  },
  dischargePredicton: {
    estimatedDate: "2024-01-20",
    confidence: 85,
    readyForDischarge: false,
    factors: ["Stable vitals", "Responding to treatment", "No complications"],
  },
}

const admissionNotes = [
  {
    id: 1,
    date: "2024-01-15T10:30:00",
    doctor: "Dr. Sarah Wilson",
    type: "Admission",
    content: {
      reasonForAdmission: "Patient presented with fever, cough, and difficulty breathing for 3 days",
      historyPresentIllness:
        "45-year-old male with 3-day history of fever (101°F), productive cough with yellowish sputum, and progressive shortness of breath. No chest pain or hemoptysis.",
      provisionalDiagnosis: "Community-acquired pneumonia",
      initialPlan:
        "1. Chest X-ray\n2. CBC, CRP, Procalcitonin\n3. Blood cultures\n4. Start empirical antibiotics\n5. Oxygen support as needed",
    },
  },
]

const progressNotes = [
  {
    id: 1,
    date: "2024-01-18T09:00:00",
    doctor: "Dr. Sarah Wilson",
    subjective: "Patient reports feeling better, less shortness of breath, cough improving",
    objective: "Vitals stable, chest clear on auscultation, no fever for 24 hours",
    assessment: "Pneumonia responding well to treatment",
    plan: "Continue current antibiotics, chest physiotherapy, monitor vitals",
  },
  {
    id: 2,
    date: "2024-01-17T09:00:00",
    doctor: "Dr. Sarah Wilson",
    subjective: "Patient reports slight improvement in breathing, still has cough",
    objective: "Temperature 99.2°F, BP 125/82, HR 78, SpO2 96% on 2L O2",
    assessment: "Pneumonia, stable, responding to treatment",
    plan: "Continue antibiotics, reduce oxygen support gradually",
  },
]

const nursingNotes = [
  {
    id: 1,
    date: "2024-01-18T06:00:00",
    shift: "Morning",
    nurse: "Nurse Mary",
    painLevel: 2,
    vitals: {
      temperature: "98.6°F",
      bp: "120/80",
      hr: "72",
      spo2: "98%",
      rr: "16",
    },
    observations: "Patient slept well, appetite improving, ambulating without assistance",
    medications: ["Amoxicillin 500mg PO", "Paracetamol 500mg PO"],
    intakeOutput: {
      intake: "1200ml",
      output: "800ml",
    },
  },
  {
    id: 2,
    date: "2024-01-17T22:00:00",
    shift: "Night",
    nurse: "Nurse John",
    painLevel: 3,
    vitals: {
      temperature: "99.1°F",
      bp: "125/82",
      hr: "76",
      spo2: "96%",
      rr: "18",
    },
    observations: "Patient comfortable, minimal cough during night",
    medications: ["Amoxicillin 500mg PO", "Cough syrup 10ml"],
    intakeOutput: {
      intake: "800ml",
      output: "600ml",
    },
  },
]

const labResults = [
  {
    id: 1,
    date: "2024-01-18T08:00:00",
    test: "Complete Blood Count",
    results: {
      WBC: "8,500/μL (Normal)",
      RBC: "4.2 million/μL (Normal)",
      Hemoglobin: "13.5 g/dL (Normal)",
      Platelets: "250,000/μL (Normal)",
    },
    status: "Normal",
  },
  {
    id: 2,
    date: "2024-01-17T08:00:00",
    test: "C-Reactive Protein",
    results: {
      CRP: "15 mg/L (Elevated)",
    },
    status: "Abnormal",
  },
]

export default function PatientProfile() {
  const params = useParams()
  const [activeTab, setActiveTab] = useState("admission")
  const [isEditing, setIsEditing] = useState(false)
  const [newNote, setNewNote] = useState("")
  const [voiceRecording, setVoiceRecording] = useState(false)

  const tabs = [
    { id: "admission", label: "Admission Details", icon: FileText },
    { id: "doctor", label: "Doctor Notes", icon: Stethoscope },
    { id: "nursing", label: "Nursing Notes", icon: Activity },
    { id: "lab", label: "Lab/Radiology", icon: TestTube },
    { id: "discharge", label: "Discharge Summary", icon: Download },
  ]

  const getConditionColor = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "critical":
        return "bg-red-100 text-red-800"
      case "stable":
        return "bg-green-100 text-green-800"
      case "good":
        return "bg-blue-100 text-blue-800"
      case "recovering":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleSaveNote = () => {
    // Save the new note
    console.log("Saving note:", newNote)
    setNewNote("")
    setIsEditing(false)
  }

  const toggleVoiceRecording = () => {
    setVoiceRecording(!voiceRecording)
    // Implement voice recording logic
  }

  const generateAISummary = () => {
    // Implement AI summary generation
    console.log("Generating AI summary...")
  }

  return (
    <PrivateRoute modulePath="admin/inpatient/patient" action="view">
      <div className="min-h-screen bg-gray-50 lg:ml-64">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <Link href="/inpatient">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Patient Profile</h1>
              <p className="text-gray-600">Comprehensive inpatient care management</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button className="bg-red-600 hover:bg-red-700">
              <Edit className="h-4 w-4 mr-2" />
              Update
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar Navigation */}
          <div className="space-y-6">
            {/* Patient Info Card */}
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-4">
                  <div className="h-16 w-16 bg-red-100 rounded-full flex items-center justify-center">
                    <User className="h-8 w-8 text-red-600" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">{patientData.name}</h2>
                    <p className="text-gray-600">
                      {patientData.age}Y, {patientData.gender}
                    </p>
                    <Badge className={getConditionColor(patientData.condition)}>{patientData.condition}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">IP Number</p>
                    <p className="font-medium">{patientData.ipNumber}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">UHID</p>
                    <p className="font-medium">{patientData.uhid}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Doctor</p>
                    <p className="font-medium">{patientData.doctor}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Days Admitted</p>
                    <p className="font-medium">{patientData.daysAdmitted} days</p>
                  </div>
                </div>

                <div className="pt-3 border-t">
                  <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                    <MapPin className="h-4 w-4" />
                    <span>
                      {patientData.ward} - {patientData.room}
                      {patientData.bed}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                    <Calendar className="h-4 w-4" />
                    <span>Admitted: {new Date(patientData.admissionDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Phone className="h-4 w-4" />
                    <span>{patientData.phone}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Current Vitals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Current Vitals
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-gray-500">Temperature</p>
                    <p className="font-medium">{patientData.vitals.temperature}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">BP</p>
                    <p className="font-medium">{patientData.vitals.bloodPressure}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Heart Rate</p>
                    <p className="font-medium">{patientData.vitals.heartRate}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">SpO2</p>
                    <p className="font-medium">{patientData.vitals.spO2}</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500">
                  Last updated: {new Date(patientData.vitals.lastUpdated).toLocaleString()}
                </p>
              </CardContent>
            </Card>

            {/* AI Discharge Prediction */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="h-5 w-5 mr-2 text-purple-600" />
                  AI Discharge Prediction
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{patientData.dischargePredicton.confidence}%</div>
                  <p className="text-sm text-gray-600">Confidence Score</p>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Estimated Discharge:</span>
                    <span className="font-medium">
                      {new Date(patientData.dischargePredicton.estimatedDate).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Ready for Discharge:</span>
                    <Badge
                      className={
                        patientData.dischargePredicton.readyForDischarge
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }
                    >
                      {patientData.dischargePredicton.readyForDischarge ? "Yes" : "Not Yet"}
                    </Badge>
                  </div>
                </div>

                <div className="pt-3 border-t">
                  <p className="text-xs text-gray-600 mb-2">Key Factors:</p>
                  <ul className="text-xs text-gray-600 space-y-1">
                    {patientData.dischargePredicton.factors.map((factor, index) => (
                      <li key={index} className="flex items-center">
                        <div className="w-1 h-1 bg-purple-600 rounded-full mr-2"></div>
                        {factor}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button size="sm" className="w-full bg-purple-600 hover:bg-purple-700">
                  Initiate Discharge Summary
                </Button>
              </CardContent>
            </Card>

            {/* Navigation Tabs */}
            <Card>
              <CardHeader>
                <CardTitle>Patient Records</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <nav className="space-y-1">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-none transition-colors ${
                        activeTab === tab.id
                          ? "bg-red-50 text-red-700 border-r-2 border-red-600"
                          : "text-gray-700 hover:bg-gray-50 hover:text-red-600"
                      }`}
                    >
                      <tab.icon className="mr-3 h-4 w-4" />
                      {tab.label}
                    </button>
                  ))}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{tabs.find((tab) => tab.id === activeTab)?.label}</span>
                  {activeTab === "doctor" && (
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={toggleVoiceRecording}
                        className={voiceRecording ? "bg-red-50 text-red-600" : ""}
                      >
                        <Mic className="h-4 w-4 mr-2" />
                        {voiceRecording ? "Stop Recording" : "Voice Input"}
                      </Button>
                      <Button size="sm" variant="outline" onClick={generateAISummary}>
                        <Brain className="h-4 w-4 mr-2" />
                        AI Summary
                      </Button>
                    </div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Admission Details Tab */}
                {activeTab === "admission" && (
                  <div className="space-y-6">
                    {admissionNotes.map((note) => (
                      <div key={note.id} className="border rounded-lg p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h3 className="font-semibold text-lg">{note.type} Notes</h3>
                            <p className="text-sm text-gray-600">
                              {new Date(note.date).toLocaleString()} • {note.doctor}
                            </p>
                          </div>
                          <Badge variant="outline">{note.type}</Badge>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Reason for Admission</h4>
                            <p className="text-sm text-gray-900">{note.content.reasonForAdmission}</p>
                          </div>

                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">History of Present Illness</h4>
                            <p className="text-sm text-gray-900">{note.content.historyPresentIllness}</p>
                          </div>

                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Provisional Diagnosis</h4>
                            <p className="text-sm text-gray-900">{note.content.provisionalDiagnosis}</p>
                          </div>

                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Initial Plan</h4>
                            <pre className="text-sm text-gray-900 whitespace-pre-wrap">{note.content.initialPlan}</pre>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Doctor Notes Tab */}
                {activeTab === "doctor" && (
                  <div className="space-y-6">
                    {/* Add New Note */}
                    {isEditing && (
                      <div className="border rounded-lg p-4 bg-blue-50">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-semibold">New Progress Note</h3>
                          <div className="flex space-x-2">
                            <Button size="sm" onClick={handleSaveNote}>
                              <Save className="h-4 w-4 mr-2" />
                              Save
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                              Cancel
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="subjective">Subjective</Label>
                            <Textarea id="subjective" placeholder="Patient's complaints and symptoms..." rows={3} />
                          </div>
                          <div>
                            <Label htmlFor="objective">Objective</Label>
                            <Textarea id="objective" placeholder="Physical examination findings..." rows={3} />
                          </div>
                          <div>
                            <Label htmlFor="assessment">Assessment</Label>
                            <Textarea id="assessment" placeholder="Clinical assessment and diagnosis..." rows={3} />
                          </div>
                          <div>
                            <Label htmlFor="plan">Plan</Label>
                            <Textarea id="plan" placeholder="Treatment plan and orders..." rows={3} />
                          </div>
                        </div>
                      </div>
                    )}

                    {!isEditing && (
                      <Button onClick={() => setIsEditing(true)} className="bg-red-600 hover:bg-red-700">
                        <Edit className="h-4 w-4 mr-2" />
                        Add Progress Note
                      </Button>
                    )}

                    {/* Existing Progress Notes */}
                    {progressNotes.map((note) => (
                      <div key={note.id} className="border rounded-lg p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h3 className="font-semibold">Progress Note</h3>
                            <p className="text-sm text-gray-600">
                              {new Date(note.date).toLocaleString()} • {note.doctor}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-gray-400" />
                            <span className="text-sm text-gray-500">
                              {Math.floor(
                                (new Date().getTime() - new Date(note.date).getTime()) / (1000 * 60 * 60 * 24),
                              )}{" "}
                              days ago
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Subjective</h4>
                            <p className="text-sm text-gray-900">{note.subjective}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Objective</h4>
                            <p className="text-sm text-gray-900">{note.objective}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Assessment</h4>
                            <p className="text-sm text-gray-900">{note.assessment}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Plan</h4>
                            <p className="text-sm text-gray-900">{note.plan}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Nursing Notes Tab */}
                {activeTab === "nursing" && (
                  <div className="space-y-6">
                    {nursingNotes.map((note) => (
                      <div key={note.id} className="border rounded-lg p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h3 className="font-semibold">{note.shift} Shift</h3>
                            <p className="text-sm text-gray-600">
                              {new Date(note.date).toLocaleString()} • {note.nurse}
                            </p>
                          </div>
                          <Badge variant="outline" className="capitalize">
                            {note.shift}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          {/* Vitals */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-3">Vital Signs</h4>
                            <div className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <span>Temperature:</span>
                                <span className="font-medium">{note.vitals.temperature}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>BP:</span>
                                <span className="font-medium">{note.vitals.bp}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>HR:</span>
                                <span className="font-medium">{note.vitals.hr}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>SpO2:</span>
                                <span className="font-medium">{note.vitals.spo2}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>RR:</span>
                                <span className="font-medium">{note.vitals.rr}</span>
                              </div>
                            </div>
                          </div>

                          {/* Assessment */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-3">Assessment</h4>
                            <div className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <span>Pain Level:</span>
                                <Badge
                                  className={
                                    note.painLevel <= 3
                                      ? "bg-green-100 text-green-800"
                                      : note.painLevel <= 6
                                        ? "bg-yellow-100 text-yellow-800"
                                        : "bg-red-100 text-red-800"
                                  }
                                >
                                  {note.painLevel}/10
                                </Badge>
                              </div>
                              <div>
                                <p className="text-gray-700 mb-2">Observations:</p>
                                <p className="text-gray-900">{note.observations}</p>
                              </div>
                            </div>
                          </div>

                          {/* Medications & I/O */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-3">Medications Given</h4>
                            <ul className="text-sm space-y-1 mb-4">
                              {note.medications.map((med, index) => (
                                <li key={index} className="flex items-center">
                                  <div className="w-1 h-1 bg-blue-600 rounded-full mr-2"></div>
                                  {med}
                                </li>
                              ))}
                            </ul>

                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Intake/Output</h4>
                            <div className="text-sm space-y-1">
                              <div className="flex justify-between">
                                <span>Intake:</span>
                                <span className="font-medium">{note.intakeOutput.intake}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Output:</span>
                                <span className="font-medium">{note.intakeOutput.output}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Lab/Radiology Tab */}
                {activeTab === "lab" && (
                  <div className="space-y-6">
                    {labResults.map((result) => (
                      <div key={result.id} className="border rounded-lg p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h3 className="font-semibold">{result.test}</h3>
                            <p className="text-sm text-gray-600">{new Date(result.date).toLocaleString()}</p>
                          </div>
                          <Badge
                            className={
                              result.status === "Normal" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                            }
                          >
                            {result.status}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {Object.entries(result.results).map(([key, value]) => (
                            <div key={key} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                              <span className="font-medium">{key}:</span>
                              <span
                                className={
                                  value.includes("Elevated") || value.includes("High")
                                    ? "text-red-600 font-medium"
                                    : "text-gray-900"
                                }
                              >
                                {value}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Discharge Summary Tab */}
                {activeTab === "discharge" && (
                  <div className="space-y-6">
                    <div className="text-center py-12">
                      <AlertTriangle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Discharge Summary Not Ready</h3>
                      <p className="text-gray-600 mb-6">
                        Patient is still under treatment. Discharge summary will be available when discharge is
                        initiated.
                      </p>
                      <Button className="bg-purple-600 hover:bg-purple-700">
                        <Brain className="h-4 w-4 mr-2" />
                        Generate AI Discharge Prediction
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      {/* Notification Dialog */}
      {/* <NotificationDialog
        open={showNotification}
        onOpenChange={setShowNotification}
        patient={{
          id: patientData.id,
          name: patientData.name,
          ward: patientData.admission.ward,
          room: patientData.admission.room,
          bed: patientData.admission.bed,
          admissionDate: patientData.admission.date,
          emergencyContact: patientData.emergencyContact,
        }}
        notificationType="admission"
      /> */}
      </div>
    </PrivateRoute>
  )
}

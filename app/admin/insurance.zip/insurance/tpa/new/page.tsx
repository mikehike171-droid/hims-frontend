'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Checkbox } from '@/components/ui/checkbox'
import { ArrowLeft, CalendarIcon, Save } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { format } from 'date-fns'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

export default function NewTPA() {
  const [contractStartDate, setContractStartDate] = useState<Date>()
  const [contractEndDate, setContractEndDate] = useState<Date>()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))

    toast({
      title: "TPA Added",
      description: "The TPA has been added successfully.",
    })

    setIsSubmitting(false)
    router.push('/insurance/tpa')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/insurance/tpa">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to TPAs
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Add New TPA</h1>
          <p className="text-muted-foreground">Register a new Third Party Administrator</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
            <CardDescription>Enter TPA company details and contact information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="tpaName">TPA Name *</Label>
                  <Input id="tpaName" placeholder="Enter TPA name" required />
                </div>
                <div>
                  <Label htmlFor="tpaCode">TPA Code *</Label>
                  <Input id="tpaCode" placeholder="Enter unique TPA code" required />
                </div>
                <div>
                  <Label htmlFor="registrationNumber">Registration Number</Label>
                  <Input id="registrationNumber" placeholder="Enter registration number" />
                </div>
                <div>
                  <Label htmlFor="licenseNumber">License Number</Label>
                  <Input id="licenseNumber" placeholder="Enter license number" />
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="contactPerson">Contact Person *</Label>
                  <Input id="contactPerson" placeholder="Enter contact person name" required />
                </div>
                <div>
                  <Label htmlFor="designation">Designation</Label>
                  <Input id="designation" placeholder="Enter designation" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input id="phone" placeholder="Enter phone number" required />
                </div>
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input id="email" type="email" placeholder="Enter email address" required />
                </div>
              </div>
            </div>
            <div>
              <Label htmlFor="address">Address</Label>
              <Textarea 
                id="address" 
                placeholder="Enter complete address"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contract Details</CardTitle>
            <CardDescription>Set up contract terms and validity period</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label>Contract Start Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !contractStartDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {contractStartDate ? format(contractStartDate, "PPP") : "Select start date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={contractStartDate}
                      onSelect={setContractStartDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <Label>Contract End Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !contractEndDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {contractEndDate ? format(contractEndDate, "PPP") : "Select end date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={contractEndDate}
                      onSelect={setContractEndDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="contractValue">Contract Value</Label>
                <Input id="contractValue" type="number" placeholder="Enter contract value" />
              </div>
              <div>
                <Label htmlFor="commissionRate">Commission Rate (%)</Label>
                <Input id="commissionRate" type="number" step="0.01" placeholder="Enter commission rate" />
              </div>
            </div>
            <div>
              <Label htmlFor="contractTerms">Contract Terms & Conditions</Label>
              <Textarea 
                id="contractTerms" 
                placeholder="Enter contract terms and conditions"
                rows={4}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Service Configuration</CardTitle>
            <CardDescription>Configure TPA services and processing parameters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="maxClaimAmount">Maximum Claim Amount</Label>
                <Input id="maxClaimAmount" type="number" placeholder="Enter maximum claim amount" />
              </div>
              <div>
                <Label htmlFor="processingTime">Standard Processing Time (days)</Label>
                <Input id="processingTime" type="number" placeholder="Enter processing time" />
              </div>
            </div>
            <div className="space-y-4">
              <Label>Services Offered</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="cashless" />
                  <Label htmlFor="cashless">Cashless Claims</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="reimbursement" />
                  <Label htmlFor="reimbursement">Reimbursement</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="preauth" />
                  <Label htmlFor="preauth">Pre-authorization</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="investigation" />
                  <Label htmlFor="investigation">Claim Investigation</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="settlement" />
                  <Label htmlFor="settlement">Direct Settlement</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="support" />
                  <Label htmlFor="support">24/7 Support</Label>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Additional Information</CardTitle>
            <CardDescription>Optional details and special instructions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="website">Website</Label>
                <Input id="website" type="url" placeholder="Enter website URL" />
              </div>
              <div>
                <Label htmlFor="status">Initial Status</Label>
                <Select defaultValue="active">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea 
                id="notes" 
                placeholder="Enter any additional notes or special instructions"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Link href="/insurance/tpa">
            <Button type="button" variant="outline">Cancel</Button>
          </Link>
          <Button type="submit" disabled={isSubmitting}>
            <Save className="mr-2 h-4 w-4" />
            {isSubmitting ? 'Adding TPA...' : 'Add TPA'}
          </Button>
        </div>
      </form>
    </div>
  )
}

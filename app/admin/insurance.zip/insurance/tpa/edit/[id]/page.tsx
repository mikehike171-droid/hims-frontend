'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Save, CheckCircle, XCircle, Clock } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

interface TPAEditProps {
  params: {
    id: string
  }
}

export default function EditTPA({ params }: TPAEditProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [tpaData, setTpaData] = useState<any>(null)
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    // Simulate loading TPA data
    setTimeout(() => {
      setTpaData({
        id: params.id,
        name: 'Star Health TPA',
        code: 'STAR001',
        contactPerson: 'Rajesh Kumar',
        phone: '+91-9876543210',
        email: 'rajesh@starhealth.com',
        address: 'Chennai, Tamil Nadu',
        status: 'active',
        contractStartDate: '2023-01-01',
        contractEndDate: '2025-12-31',
        commissionRate: 2.5,
        maxClaimAmount: 1000000,
        processingTime: 3
      })
      setIsLoading(false)
    }, 1000)
  }, [params.id])

  const handleSave = async () => {
    setIsSaving(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    toast({
      title: "TPA Updated",
      description: "The TPA information has been updated successfully.",
    })
    
    setIsSaving(false)
    router.push('/insurance/tpa')
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'inactive': return <XCircle className="h-4 w-4 text-red-500" />
      case 'suspended': return <Clock className="h-4 w-4 text-orange-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/insurance/tpa">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to TPAs
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit TPA - {tpaData.name}</h1>
          <p className="text-muted-foreground">Update TPA information and settings</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Current Status
              <Badge className="flex items-center gap-1">
                {getStatusIcon(tpaData.status)}
                {tpaData.status.toUpperCase()}
              </Badge>
            </CardTitle>
            <CardDescription>Update TPA status and basic information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="status">TPA Status</Label>
                <Select defaultValue={tpaData.status}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tpaCode">TPA Code</Label>
                <Input 
                  id="tpaCode" 
                  defaultValue={tpaData.code}
                  readOnly
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
            <CardDescription>TPA company details and contact information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="tpaName">TPA Name</Label>
                <Input id="tpaName" defaultValue={tpaData.name} />
              </div>
              <div>
                <Label htmlFor="contactPerson">Contact Person</Label>
                <Input id="contactPerson" defaultValue={tpaData.contactPerson} />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" defaultValue={tpaData.phone} />
              </div>
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" defaultValue={tpaData.email} />
              </div>
            </div>
            <div>
              <Label htmlFor="address">Address</Label>
              <Textarea 
                id="address" 
                defaultValue={tpaData.address}
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contract & Service Details</CardTitle>
            <CardDescription>Contract terms and service configuration</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="commissionRate">Commission Rate (%)</Label>
                <Input 
                  id="commissionRate" 
                  type="number" 
                  step="0.01"
                  defaultValue={tpaData.commissionRate}
                />
              </div>
              <div>
                <Label htmlFor="maxClaimAmount">Max Claim Amount</Label>
                <Input 
                  id="maxClaimAmount" 
                  type="number" 
                  defaultValue={tpaData.maxClaimAmount}
                />
              </div>
              <div>
                <Label htmlFor="processingTime">Processing Time (days)</Label>
                <Input 
                  id="processingTime" 
                  type="number" 
                  defaultValue={tpaData.processingTime}
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="contractStart">Contract Start Date</Label>
                <Input 
                  id="contractStart" 
                  type="date"
                  defaultValue={tpaData.contractStartDate}
                />
              </div>
              <div>
                <Label htmlFor="contractEnd">Contract End Date</Label>
                <Input 
                  id="contractEnd" 
                  type="date"
                  defaultValue={tpaData.contractEndDate}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end gap-4">
        <Link href="/insurance/tpa">
          <Button variant="outline">Cancel</Button>
        </Link>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </div>
  )
}

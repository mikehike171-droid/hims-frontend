'use client'

import { useState } from 'react'
import PrivateRoute from '@/components/auth/PrivateRoute'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Building2, Phone, Mail, MapPin, Plus, Search, Filter, Download, Eye, Edit, CheckCircle, XCircle, Clock, TrendingUp, Users, DollarSign } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Link from 'next/link'

interface TPA {
  id: string
  name: string
  code: string
  contactPerson: string
  phone: string
  email: string
  address: string
  status: 'active' | 'inactive' | 'suspended'
  contractStartDate: string
  contractEndDate: string
  totalClaims: number
  approvedClaims: number
  rejectedClaims: number
  totalClaimAmount: number
  approvedAmount: number
  avgProcessingTime: number
  approvalRate: number
}

const mockTPAs: TPA[] = [
  {
    id: '1',
    name: 'Star Health TPA',
    code: 'STAR001',
    contactPerson: 'Rajesh Kumar',
    phone: '+91-9876543210',
    email: 'rajesh@starhealth.com',
    address: 'Chennai, Tamil Nadu',
    status: 'active',
    contractStartDate: '2023-01-01',
    contractEndDate: '2025-12-31',
    totalClaims: 150,
    approvedClaims: 135,
    rejectedClaims: 15,
    totalClaimAmount: 2500000,
    approvedAmount: 2250000,
    avgProcessingTime: 3.5,
    approvalRate: 90
  },
  {
    id: '2',
    name: 'Medi Assist TPA',
    code: 'MEDI001',
    contactPerson: 'Priya Sharma',
    phone: '+91-9876543211',
    email: 'priya@mediassist.com',
    address: 'Bangalore, Karnataka',
    status: 'active',
    contractStartDate: '2023-06-01',
    contractEndDate: '2026-05-31',
    totalClaims: 120,
    approvedClaims: 108,
    rejectedClaims: 12,
    totalClaimAmount: 1800000,
    approvedAmount: 1620000,
    avgProcessingTime: 2.8,
    approvalRate: 90
  },
  {
    id: '3',
    name: 'Vidal Health TPA',
    code: 'VIDAL001',
    contactPerson: 'Amit Patel',
    phone: '+91-9876543212',
    email: 'amit@vidalhealth.com',
    address: 'Mumbai, Maharashtra',
    status: 'suspended',
    contractStartDate: '2022-01-01',
    contractEndDate: '2024-12-31',
    totalClaims: 80,
    approvedClaims: 64,
    rejectedClaims: 16,
    totalClaimAmount: 1200000,
    approvedAmount: 960000,
    avgProcessingTime: 5.2,
    approvalRate: 80
  }
]

export default function TPAManagement() {
  const [tpas, setTpas] = useState<TPA[]>(mockTPAs)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedTPA, setSelectedTPA] = useState<TPA | null>(null)
  const { toast } = useToast()

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'inactive': return <XCircle className="h-4 w-4 text-red-500" />
      case 'suspended': return <Clock className="h-4 w-4 text-orange-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-red-100 text-red-800',
      suspended: 'bg-orange-100 text-orange-800'
    }
    return variants[status as keyof typeof variants] || 'bg-gray-100 text-gray-800'
  }

  const filteredTPAs = tpas.filter(tpa => {
    const matchesSearch = tpa.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tpa.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tpa.contactPerson.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || tpa.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalTPAs = tpas.length
  const activeTPAs = tpas.filter(t => t.status === 'active').length
  const totalClaims = tpas.reduce((sum, tpa) => sum + tpa.totalClaims, 0)
  const avgApprovalRate = tpas.reduce((sum, tpa) => sum + tpa.approvalRate, 0) / tpas.length

  return (
    <PrivateRoute modulePath="admin/insurance/tpa" action="view">
      <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">TPA Management</h1>
          <p className="text-muted-foreground">Manage Third Party Administrators and their contracts</p>
        </div>
        <Link href="/insurance/tpa/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add TPA
          </Button>
        </Link>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total TPAs</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTPAs}</div>
            <p className="text-xs text-muted-foreground">{activeTPAs} active</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Claims</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalClaims}</div>
            <p className="text-xs text-muted-foreground">Across all TPAs</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Approval Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgApprovalRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">Overall performance</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ₹{tpas.reduce((sum, tpa) => sum + tpa.approvedAmount, 0).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">Approved amount</p>
          </CardContent>
        </Card>
      </div>

      {/* TPA List */}
      <Card>
        <CardHeader>
          <CardTitle>TPA Directory</CardTitle>
          <CardDescription>View and manage all registered TPAs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search TPAs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>TPA Name</TableHead>
                  <TableHead>Contact Person</TableHead>
                  <TableHead>Contact Info</TableHead>
                  <TableHead>Claims</TableHead>
                  <TableHead>Approval Rate</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTPAs.map((tpa) => (
                  <TableRow key={tpa.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{tpa.name}</div>
                        <div className="text-sm text-muted-foreground">{tpa.code}</div>
                      </div>
                    </TableCell>
                    <TableCell>{tpa.contactPerson}</TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm">
                          <Phone className="h-3 w-3" />
                          {tpa.phone}
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Mail className="h-3 w-3" />
                          {tpa.email}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{tpa.totalClaims}</div>
                        <div className="text-sm text-muted-foreground">
                          {tpa.approvedClaims} approved
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="font-medium">{tpa.approvalRate}%</div>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full" 
                            style={{ width: `${tpa.approvalRate}%` }}
                          />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusBadge(tpa.status)}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(tpa.status)}
                          {tpa.status.toUpperCase()}
                        </div>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedTPA(tpa)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl">
                            <DialogHeader>
                              <DialogTitle>TPA Details - {tpa.name}</DialogTitle>
                              <DialogDescription>
                                Complete TPA information and performance metrics
                              </DialogDescription>
                            </DialogHeader>
                            {selectedTPA && (
                              <Tabs defaultValue="details" className="w-full">
                                <TabsList>
                                  <TabsTrigger value="details">Details</TabsTrigger>
                                  <TabsTrigger value="performance">Performance</TabsTrigger>
                                  <TabsTrigger value="contract">Contract</TabsTrigger>
                                </TabsList>
                                <TabsContent value="details" className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <h4 className="font-medium mb-2">Contact Information</h4>
                                      <div className="space-y-2">
                                        <div className="flex items-center gap-2">
                                          <Building2 className="h-4 w-4 text-muted-foreground" />
                                          <span>{selectedTPA.name}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          <Phone className="h-4 w-4 text-muted-foreground" />
                                          <span>{selectedTPA.phone}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          <Mail className="h-4 w-4 text-muted-foreground" />
                                          <span>{selectedTPA.email}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          <MapPin className="h-4 w-4 text-muted-foreground" />
                                          <span>{selectedTPA.address}</span>
                                        </div>
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-medium mb-2">Performance Metrics</h4>
                                      <div className="space-y-2">
                                        <p><strong>Total Claims:</strong> {selectedTPA.totalClaims}</p>
                                        <p><strong>Approved:</strong> {selectedTPA.approvedClaims}</p>
                                        <p><strong>Rejected:</strong> {selectedTPA.rejectedClaims}</p>
                                        <p><strong>Approval Rate:</strong> {selectedTPA.approvalRate}%</p>
                                        <p><strong>Avg Processing Time:</strong> {selectedTPA.avgProcessingTime} days</p>
                                      </div>
                                    </div>
                                  </div>
                                </TabsContent>
                                <TabsContent value="performance">
                                  <div className="text-center py-8">
                                    <TrendingUp className="mx-auto h-12 w-12 text-muted-foreground" />
                                    <p className="mt-2 text-muted-foreground">Performance analytics coming soon</p>
                                  </div>
                                </TabsContent>
                                <TabsContent value="contract">
                                  <div className="text-center py-8">
                                    <Building2 className="mx-auto h-12 w-12 text-muted-foreground" />
                                    <p className="mt-2 text-muted-foreground">Contract details coming soon</p>
                                  </div>
                                </TabsContent>
                              </Tabs>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Link href={`/insurance/tpa/edit/${tpa.id}`}>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { FileText, Download, Calendar, TrendingUp, TrendingDown, Shield, Building2 } from 'lucide-react'

export default function InsuranceReports() {
  const [selectedReport, setSelectedReport] = useState("claims_summary")
  const [selectedPeriod, setSelectedPeriod] = useState("last_month")

  const handleGenerateReport = () => {
    alert(`Generating ${selectedReport} report for ${selectedPeriod}...`)
  }

  return (
    <PrivateRoute modulePath="admin/insurance/reports" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Insurance Reports & Analytics</h1>
          <p className="text-gray-600 mt-1">Generate reports and analyze insurance-related data</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export All
          </Button>
        </div>
      </div>

      {/* Report Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Report Selection</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="reportType">Report Type</Label>
              <Select value={selectedReport} onValueChange={setSelectedReport}>
                <SelectTrigger>
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="claims_summary">Claims Summary Report</SelectItem>
                  <SelectItem value="preauth_summary">Pre-Authorization Summary Report</SelectItem>
                  <SelectItem value="tpa_performance">TPA Performance Report</SelectItem>
                  <SelectItem value="insurance_company">Insurance Company Report</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="reportPeriod">Report Period</Label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select report period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="last_week">Last Week</SelectItem>
                  <SelectItem value="last_month">Last Month</SelectItem>
                  <SelectItem value="last_quarter">Last Quarter</SelectItem>
                  <SelectItem value="last_year">Last Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={handleGenerateReport} className="w-full bg-red-600 hover:bg-red-700">
            <Calendar className="h-4 w-4 mr-2" />
            Generate Report
          </Button>
        </CardContent>
      </Card>

      {/* Report Preview (Placeholder) */}
      <Card>
        <CardHeader>
          <CardTitle>Report Preview</CardTitle>
          <CardDescription>A preview of the selected report will be displayed here</CardDescription>
        </CardHeader>
        <CardContent className="p-8 text-center">
          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">Select a report type and period to generate a preview</p>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

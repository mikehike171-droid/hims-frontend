"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shield, FileText, Clock, DollarSign, Search, Plus, Eye } from "lucide-react"
import Link from "next/link"

// Mock data
const dashboardStats = {
  totalPreAuths: 156,
  pendingPreAuths: 23,
  approvedPreAuths: 98,
  rejectedPreAuths: 12,
  totalClaims: 89,
  pendingClaims: 15,
  settledClaims: 67,
  claimValue: 2450000,
}

const recentPreAuths = [
  {
    id: 1,
    authNumber: "PA2024001",
    patientName: "Rajesh Kumar",
    tpaName: "Medi Assist",
    diagnosis: "Appendectomy",
    amount: 45000,
    status: "approved",
    submittedDate: "2024-01-15",
    priority: "high",
  },
  {
    id: 2,
    authNumber: "PA2024002",
    patientName: "Priya Sharma",
    tpaName: "Vidal Health",
    diagnosis: "Normal Delivery",
    amount: 25000,
    status: "pending",
    submittedDate: "2024-01-14",
    priority: "urgent",
  },
  {
    id: 3,
    authNumber: "PA2024003",
    patientName: "Amit Patel",
    tpaName: "Good Health",
    diagnosis: "Cataract Surgery",
    amount: 35000,
    status: "query",
    submittedDate: "2024-01-13",
    priority: "normal",
  },
]

const recentClaims = [
  {
    id: 1,
    claimNumber: "CL2024001",
    patientName: "Sunita Reddy",
    tpaName: "Paramount Health",
    claimedAmount: 67000,
    approvedAmount: 62000,
    status: "settled",
    submittedDate: "2024-01-10",
  },
  {
    id: 2,
    claimNumber: "CL2024002",
    patientName: "Vikram Singh",
    tpaName: "Medi Assist",
    claimedAmount: 89000,
    approvedAmount: 0,
    status: "pending",
    submittedDate: "2024-01-12",
  },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "approved":
    case "settled":
      return "bg-green-100 text-green-800"
    case "pending":
      return "bg-yellow-100 text-yellow-800"
    case "rejected":
      return "bg-red-100 text-red-800"
    case "query":
      return "bg-blue-100 text-blue-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "urgent":
      return "bg-red-100 text-red-800"
    case "high":
      return "bg-orange-100 text-orange-800"
    case "normal":
      return "bg-blue-100 text-blue-800"
    case "low":
      return "bg-gray-100 text-gray-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export default function InsuranceDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  return (
    <PrivateRoute modulePath="admin/insurance" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Insurance & TPA Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage pre-authorizations, claims, and TPA relationships</p>
        </div>
        <div className="flex space-x-3">
          <Link href="/insurance/pre-auth/new">
            <Button className="bg-red-600 hover:bg-red-700">
              <Plus className="h-4 w-4 mr-2" />
              New Pre-Auth
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pre-Auths</CardTitle>
            <Shield className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.totalPreAuths}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12%</span> from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Pre-Auths</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.pendingPreAuths}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-yellow-600">3 urgent</span> need attention
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Claims</CardTitle>
            <FileText className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.totalClaims}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+8%</span> from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Claim Value</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{(dashboardStats.claimValue / 100000).toFixed(1)}L</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+15%</span> from last month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Pre-Authorization Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Approved</span>
                <div className="flex items-center space-x-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: "63%" }}></div>
                  </div>
                  <span className="text-sm font-medium">{dashboardStats.approvedPreAuths}</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Pending</span>
                <div className="flex items-center space-x-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-yellow-600 h-2 rounded-full" style={{ width: "15%" }}></div>
                  </div>
                  <span className="text-sm font-medium">{dashboardStats.pendingPreAuths}</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Rejected</span>
                <div className="flex items-center space-x-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-red-600 h-2 rounded-full" style={{ width: "8%" }}></div>
                  </div>
                  <span className="text-sm font-medium">{dashboardStats.rejectedPreAuths}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Claim Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Settled</span>
                <div className="flex items-center space-x-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: "75%" }}></div>
                  </div>
                  <span className="text-sm font-medium">{dashboardStats.settledClaims}</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Pending</span>
                <div className="flex items-center space-x-2">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div className="bg-yellow-600 h-2 rounded-full" style={{ width: "17%" }}></div>
                  </div>
                  <span className="text-sm font-medium">{dashboardStats.pendingClaims}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">TPA Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Medi Assist</span>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-green-100 text-green-800">92%</Badge>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Vidal Health</span>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-green-100 text-green-800">88%</Badge>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Good Health</span>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-yellow-100 text-yellow-800">76%</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity Tabs */}
      <Tabs defaultValue="pre-auths" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pre-auths">Recent Pre-Authorizations</TabsTrigger>
          <TabsTrigger value="claims">Recent Claims</TabsTrigger>
        </TabsList>

        <TabsContent value="pre-auths" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Recent Pre-Authorization Requests</CardTitle>
                <div className="flex space-x-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search pre-auths..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentPreAuths.map((preAuth) => (
                  <div
                    key={preAuth.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Shield className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium">{preAuth.authNumber}</h4>
                          <Badge className={getPriorityColor(preAuth.priority)}>{preAuth.priority}</Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          {preAuth.patientName} • {preAuth.diagnosis}
                        </p>
                        <p className="text-xs text-gray-500">
                          {preAuth.tpaName} • ₹{preAuth.amount.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={getStatusColor(preAuth.status)}>{preAuth.status}</Badge>
                      <span className="text-sm text-gray-500">{preAuth.submittedDate}</span>
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Link href="/insurance/pre-auth">
                  <Button variant="outline">View All Pre-Authorizations</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="claims" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Insurance Claims</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentClaims.map((claim) => (
                  <div
                    key={claim.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="h-10 w-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <FileText className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{claim.claimNumber}</h4>
                        <p className="text-sm text-gray-600">
                          {claim.patientName} • {claim.tpaName}
                        </p>
                        <p className="text-xs text-gray-500">
                          Claimed: ₹{claim.claimedAmount.toLocaleString()}
                          {claim.approvedAmount > 0 && ` • Approved: ₹${claim.approvedAmount.toLocaleString()}`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={getStatusColor(claim.status)}>{claim.status}</Badge>
                      <span className="text-sm text-gray-500">{claim.submittedDate}</span>
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Link href="/insurance/claims">
                  <Button variant="outline">View All Claims</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </PrivateRoute>
  )
}

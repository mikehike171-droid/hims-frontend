'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Checkbox } from '@/components/ui/checkbox'
import { ArrowLeft, CalendarIcon, Save, Plus, Trash2, Calculator } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { format } from 'date-fns'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

interface RateItem {
  id: string
  serviceName: string
  hospitalRate: number
  agreedRate: number
  discountPercent: number
}

export default function NewRateAgreement() {
  const [validFrom, setValidFrom] = useState<Date>()
  const [validTo, setValidTo] = useState<Date>()
  const [rateItems, setRateItems] = useState<RateItem[]>([
    { id: '1', serviceName: '', hospitalRate: 0, agreedRate: 0, discountPercent: 0 }
  ])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const addRateItem = () => {
    const newItem: RateItem = {
      id: Date.now().toString(),
      serviceName: '',
      hospitalRate: 0,
      agreedRate: 0,
      discountPercent: 0
    }
    setRateItems([...rateItems, newItem])
  }

  const removeRateItem = (id: string) => {
    setRateItems(rateItems.filter(item => item.id !== id))
  }

  const updateRateItem = (id: string, field: keyof RateItem, value: string | number) => {
    setRateItems(rateItems.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value }
        
        // Auto-calculate discount percentage when rates change
        if (field === 'hospitalRate' || field === 'agreedRate') {
          const hospitalRate = field === 'hospitalRate' ? Number(value) : item.hospitalRate
          const agreedRate = field === 'agreedRate' ? Number(value) : item.agreedRate
          
          if (hospitalRate > 0) {
            updatedItem.discountPercent = Math.round(((hospitalRate - agreedRate) / hospitalRate) * 100)
          }
        }
        
        // Auto-calculate agreed rate when discount percentage changes
        if (field === 'discountPercent' && item.hospitalRate > 0) {
          updatedItem.agreedRate = Math.round(item.hospitalRate * (1 - Number(value) / 100))
        }
        
        return updatedItem
      }
      return item
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))

    toast({
      title: "Rate Agreement Created",
      description: "The rate agreement has been created successfully.",
    })

    setIsSubmitting(false)
    router.push('/insurance/rates')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/insurance/rates">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Agreements
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">New Rate Agreement</h1>
          <p className="text-muted-foreground">Create a new rate agreement with TPA</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Agreement Details</CardTitle>
            <CardDescription>Basic information about the rate agreement</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="agreementNumber">Agreement Number *</Label>
                  <Input id="agreementNumber" placeholder="Enter agreement number" required />
                </div>
                <div>
                  <Label htmlFor="tpa">TPA *</Label>
                  <Select required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select TPA" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="star-health">Star Health TPA</SelectItem>
                      <SelectItem value="medi-assist">Medi Assist TPA</SelectItem>
                      <SelectItem value="vidal-health">Vidal Health TPA</SelectItem>
                      <SelectItem value="paramount">Paramount TPA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Select required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="surgery">Surgery</SelectItem>
                      <SelectItem value="consultation">Consultation</SelectItem>
                      <SelectItem value="investigation">Investigation</SelectItem>
                      <SelectItem value="procedure">Procedure</SelectItem>
                      <SelectItem value="medication">Medication</SelectItem>
                      <SelectItem value="room-charges">Room Charges</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="packageName">Package/Service Name *</Label>
                  <Input id="packageName" placeholder="Enter package or service name" required />
                </div>
                <div>
                  <Label htmlFor="department">Department</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cardiology">Cardiology</SelectItem>
                      <SelectItem value="neurology">Neurology</SelectItem>
                      <SelectItem value="orthopedics">Orthopedics</SelectItem>
                      <SelectItem value="general-medicine">General Medicine</SelectItem>
                      <SelectItem value="surgery">Surgery</SelectItem>
                      <SelectItem value="pediatrics">Pediatrics</SelectItem>
                      <SelectItem value="radiology">Radiology</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="agreementType">Agreement Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select agreement type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="package">Package Rate</SelectItem>
                      <SelectItem value="individual">Individual Service</SelectItem>
                      <SelectItem value="bulk">Bulk Discount</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Validity Period</CardTitle>
            <CardDescription>Set the validity period for this rate agreement</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label>Valid From *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !validFrom && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {validFrom ? format(validFrom, "PPP") : "Select start date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={validFrom}
                      onSelect={setValidFrom}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <Label>Valid To *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !validTo && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {validTo ? format(validTo, "PPP") : "Select end date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={validTo}
                      onSelect={setValidTo}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Rate Structure</CardTitle>
            <CardDescription>Define the rates and discounts for services</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {rateItems.map((item, index) => (
              <div key={item.id} className="border rounded-lg p-4 space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">Service {index + 1}</h4>
                  {rateItems.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeRateItem(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label>Service/Item Name</Label>
                    <Input
                      value={item.serviceName}
                      onChange={(e) => updateRateItem(item.id, 'serviceName', e.target.value)}
                      placeholder="Enter service name"
                    />
                  </div>
                  <div>
                    <Label>Hospital Rate (₹)</Label>
                    <Input
                      type="number"
                      value={item.hospitalRate}
                      onChange={(e) => updateRateItem(item.id, 'hospitalRate', parseFloat(e.target.value) || 0)}
                      placeholder="Enter hospital rate"
                    />
                  </div>
                  <div>
                    <Label>Agreed Rate (₹)</Label>
                    <Input
                      type="number"
                      value={item.agreedRate}
                      onChange={(e) => updateRateItem(item.id, 'agreedRate', parseFloat(e.target.value) || 0)}
                      placeholder="Enter agreed rate"
                    />
                  </div>
                  <div>
                    <Label>Discount (%)</Label>
                    <Input
                      type="number"
                      value={item.discountPercent}
                      onChange={(e) => updateRateItem(item.id, 'discountPercent', parseFloat(e.target.value) || 0)}
                      placeholder="Discount %"
                      max="100"
                    />
                  </div>
                </div>
                {item.hospitalRate > 0 && item.agreedRate > 0 && (
                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="flex justify-between text-sm">
                      <span>Savings per service:</span>
                      <span className="font-medium text-green-600">
                        ₹{(item.hospitalRate - item.agreedRate).toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ))}
            
            <Button type="button" variant="outline" onClick={addRateItem}>
              <Plus className="mr-2 h-4 w-4" />
              Add Service
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Terms & Conditions</CardTitle>
            <CardDescription>Additional terms and special conditions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="minimumVolume">Minimum Volume Commitment</Label>
                <Input id="minimumVolume" type="number" placeholder="Enter minimum cases per month" />
              </div>
              <div>
                <Label htmlFor="paymentTerms">Payment Terms (days)</Label>
                <Input id="paymentTerms" type="number" placeholder="Enter payment terms" />
              </div>
            </div>
            <div>
              <Label htmlFor="specialConditions">Special Conditions</Label>
              <Textarea 
                id="specialConditions" 
                placeholder="Enter any special conditions or terms"
                rows={4}
              />
            </div>
            <div className="space-y-4">
              <Label>Additional Terms</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="autoRenewal" />
                  <Label htmlFor="autoRenewal">Auto-renewal clause</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="volumeDiscount" />
                  <Label htmlFor="volumeDiscount">Volume-based additional discount</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="exclusiveRate" />
                  <Label htmlFor="exclusiveRate">Exclusive rate agreement</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="emergencyRate" />
                  <Label htmlFor="emergencyRate">Emergency service rates</Label>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Link href="/insurance/rates">
            <Button type="button" variant="outline">Cancel</Button>
          </Link>
          <Button type="submit" disabled={isSubmitting}>
            <Save className="mr-2 h-4 w-4" />
            {isSubmitting ? 'Creating Agreement...' : 'Create Agreement'}
          </Button>
        </div>
      </form>
    </div>
  )
}

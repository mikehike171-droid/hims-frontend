'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Save, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

interface RateAgreementEditProps {
  params: {
    id: string
  }
}

export default function EditRateAgreement({ params }: RateAgreementEditProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [agreementData, setAgreementData] = useState<any>(null)
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    // Simulate loading agreement data
    setTimeout(() => {
      setAgreementData({
        id: params.id,
        agreementNumber: 'RA-2024-001',
        tpaName: 'Star Health TPA',
        packageName: 'Cardiac Surgery Package',
        category: 'Surgery',
        department: 'Cardiology',
        hospitalRate: 150000,
        agreedRate: 135000,
        discountPercent: 10,
        validFrom: '2024-01-01',
        validTo: '2024-12-31',
        status: 'active',
        utilizationCount: 25,
        totalRevenue: 3375000
      })
      setIsLoading(false)
    }, 1000)
  }, [params.id])

  const handleSave = async () => {
    setIsSaving(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    toast({
      title: "Rate Agreement Updated",
      description: "The rate agreement has been updated successfully.",
    })
    
    setIsSaving(false)
    router.push('/insurance/rates')
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'expired': return <XCircle className="h-4 w-4 text-red-500" />
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />
      case 'suspended': return <AlertTriangle className="h-4 w-4 text-orange-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/insurance/rates">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Agreements
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit Rate Agreement - {agreementData.agreementNumber}</h1>
          <p className="text-muted-foreground">Update rate agreement information and terms</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Current Status
              <Badge className="flex items-center gap-1">
                {getStatusIcon(agreementData.status)}
                {agreementData.status.toUpperCase()}
              </Badge>
            </CardTitle>
            <CardDescription>Update agreement status and validity</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="status">Agreement Status</Label>
                <Select defaultValue={agreementData.status}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="agreementNumber">Agreement Number</Label>
                <Input 
                  id="agreementNumber" 
                  defaultValue={agreementData.agreementNumber}
                  readOnly
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Agreement Details</CardTitle>
            <CardDescription>Basic agreement information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="tpaName">TPA Name</Label>
                <Input id="tpaName" defaultValue={agreementData.tpaName} readOnly />
              </div>
              <div>
                <Label htmlFor="packageName">Package Name</Label>
                <Input id="packageName" defaultValue={agreementData.packageName} />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Select defaultValue={agreementData.category}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Surgery">Surgery</SelectItem>
                    <SelectItem value="Consultation">Consultation</SelectItem>
                    <SelectItem value="Investigation">Investigation</SelectItem>
                    <SelectItem value="Procedure">Procedure</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="department">Department</Label>
                <Select defaultValue={agreementData.department}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Cardiology">Cardiology</SelectItem>
                    <SelectItem value="Neurology">Neurology</SelectItem>
                    <SelectItem value="Orthopedics">Orthopedics</SelectItem>
                    <SelectItem value="General Medicine">General Medicine</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Rate Information</CardTitle>
            <CardDescription>Update rates and discount information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="hospitalRate">Hospital Rate (₹)</Label>
                <Input 
                  id="hospitalRate" 
                  type="number" 
                  defaultValue={agreementData.hospitalRate}
                />
              </div>
              <div>
                <Label htmlFor="agreedRate">Agreed Rate (₹)</Label>
                <Input 
                  id="agreedRate" 
                  type="number" 
                  defaultValue={agreementData.agreedRate}
                />
              </div>
              <div>
                <Label htmlFor="discountPercent">Discount (%)</Label>
                <Input 
                  id="discountPercent" 
                  type="number" 
                  defaultValue={agreementData.discountPercent}
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="validFrom">Valid From</Label>
                <Input 
                  id="validFrom" 
                  type="date"
                  defaultValue={agreementData.validFrom}
                />
              </div>
              <div>
                <Label htmlFor="validTo">Valid To</Label>
                <Input 
                  id="validTo" 
                  type="date"
                  defaultValue={agreementData.validTo}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Performance Metrics</CardTitle>
            <CardDescription>Current utilization and revenue information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Total Utilizations</Label>
                <div className="text-2xl font-bold">{agreementData.utilizationCount}</div>
              </div>
              <div>
                <Label>Total Revenue</Label>
                <div className="text-2xl font-bold text-green-600">
                  ₹{agreementData.totalRevenue.toLocaleString()}
                </div>
              </div>
              <div>
                <Label>Avg Revenue per Case</Label>
                <div className="text-2xl font-bold">
                  ₹{agreementData.utilizationCount > 0 ? 
                    Math.round(agreementData.totalRevenue / agreementData.utilizationCount).toLocaleString() : 
                    '0'}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end gap-4">
        <Link href="/insurance/rates">
          <Button variant="outline">Cancel</Button>
        </Link>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </div>
  )
}

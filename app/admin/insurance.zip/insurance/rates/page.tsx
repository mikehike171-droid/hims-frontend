'use client'

import { useState } from 'react'
import PrivateRoute from '@/components/auth/PrivateRoute'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { FileText, Plus, Search, Filter, Download, Eye, Edit, CheckCircle, XCircle, Clock, AlertTriangle, TrendingUp, DollarSign, Percent } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Link from 'next/link'

interface RateAgreement {
  id: string
  agreementNumber: string
  tpaName: string
  packageName: string
  category: string
  department: string
  hospitalRate: number
  agreedRate: number
  discountPercent: number
  validFrom: string
  validTo: string
  status: 'active' | 'expired' | 'pending' | 'suspended'
  utilizationCount: number
  totalRevenue: number
}

const mockRateAgreements: RateAgreement[] = [
  {
    id: '1',
    agreementNumber: 'RA-2024-001',
    tpaName: 'Star Health TPA',
    packageName: 'Cardiac Surgery Package',
    category: 'Surgery',
    department: 'Cardiology',
    hospitalRate: 150000,
    agreedRate: 135000,
    discountPercent: 10,
    validFrom: '2024-01-01',
    validTo: '2024-12-31',
    status: 'active',
    utilizationCount: 25,
    totalRevenue: 3375000
  },
  {
    id: '2',
    agreementNumber: 'RA-2024-002',
    tpaName: 'Medi Assist TPA',
    packageName: 'General Consultation',
    category: 'Consultation',
    department: 'General Medicine',
    hospitalRate: 1500,
    agreedRate: 1350,
    discountPercent: 10,
    validFrom: '2024-01-01',
    validTo: '2024-12-31',
    status: 'active',
    utilizationCount: 150,
    totalRevenue: 202500
  },
  {
    id: '3',
    agreementNumber: 'RA-2023-015',
    tpaName: 'Vidal Health TPA',
    packageName: 'Orthopedic Surgery',
    category: 'Surgery',
    department: 'Orthopedics',
    hospitalRate: 80000,
    agreedRate: 72000,
    discountPercent: 10,
    validFrom: '2023-01-01',
    validTo: '2023-12-31',
    status: 'expired',
    utilizationCount: 18,
    totalRevenue: 1296000
  },
  {
    id: '4',
    agreementNumber: 'RA-2024-003',
    tpaName: 'Paramount TPA',
    packageName: 'Diagnostic Package',
    category: 'Investigation',
    department: 'Radiology',
    hospitalRate: 5000,
    agreedRate: 4500,
    discountPercent: 10,
    validFrom: '2024-02-01',
    validTo: '2025-01-31',
    status: 'pending',
    utilizationCount: 0,
    totalRevenue: 0
  }
]

export default function RateAgreements() {
  const [agreements, setAgreements] = useState<RateAgreement[]>(mockRateAgreements)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [selectedAgreement, setSelectedAgreement] = useState<RateAgreement | null>(null)
  const { toast } = useToast()

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'expired': return <XCircle className="h-4 w-4 text-red-500" />
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />
      case 'suspended': return <AlertTriangle className="h-4 w-4 text-orange-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      active: 'bg-green-100 text-green-800',
      expired: 'bg-red-100 text-red-800',
      pending: 'bg-yellow-100 text-yellow-800',
      suspended: 'bg-orange-100 text-orange-800'
    }
    return variants[status as keyof typeof variants] || 'bg-gray-100 text-gray-800'
  }

  const filteredAgreements = agreements.filter(agreement => {
    const matchesSearch = agreement.packageName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         agreement.tpaName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         agreement.agreementNumber.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || agreement.status === statusFilter
    const matchesCategory = categoryFilter === 'all' || agreement.category === categoryFilter
    return matchesSearch && matchesStatus && matchesCategory
  })

  const totalAgreements = agreements.length
  const activeAgreements = agreements.filter(a => a.status === 'active').length
  const totalRevenue = agreements.reduce((sum, agreement) => sum + agreement.totalRevenue, 0)
  const avgDiscount = agreements.reduce((sum, agreement) => sum + agreement.discountPercent, 0) / agreements.length

  return (
    <PrivateRoute modulePath="admin/insurance/rates" action="view">
      <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Rate Agreements</h1>
          <p className="text-muted-foreground">Manage negotiated rates and package agreements with TPAs</p>
        </div>
        <Link href="/insurance/rates/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Agreement
          </Button>
        </Link>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Agreements</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalAgreements}</div>
            <p className="text-xs text-muted-foreground">{activeAgreements} active</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">From all agreements</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Discount</CardTitle>
            <Percent className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgDiscount.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">Average discount rate</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Utilization</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {agreements.reduce((sum, agreement) => sum + agreement.utilizationCount, 0)}
            </div>
            <p className="text-xs text-muted-foreground">Total utilizations</p>
          </CardContent>
        </Card>
      </div>

      {/* Agreements List */}
      <Card>
        <CardHeader>
          <CardTitle>Rate Agreements</CardTitle>
          <CardDescription>View and manage all rate agreements with TPAs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search agreements..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Surgery">Surgery</SelectItem>
                <SelectItem value="Consultation">Consultation</SelectItem>
                <SelectItem value="Investigation">Investigation</SelectItem>
                <SelectItem value="Procedure">Procedure</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Agreement</TableHead>
                  <TableHead>TPA</TableHead>
                  <TableHead>Package</TableHead>
                  <TableHead>Rates</TableHead>
                  <TableHead>Discount</TableHead>
                  <TableHead>Utilization</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAgreements.map((agreement) => (
                  <TableRow key={agreement.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{agreement.agreementNumber}</div>
                        <div className="text-sm text-muted-foreground">{agreement.category}</div>
                      </div>
                    </TableCell>
                    <TableCell>{agreement.tpaName}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{agreement.packageName}</div>
                        <div className="text-sm text-muted-foreground">{agreement.department}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="text-sm text-muted-foreground line-through">
                          ₹{agreement.hospitalRate.toLocaleString()}
                        </div>
                        <div className="font-medium text-green-600">
                          ₹{agreement.agreedRate.toLocaleString()}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {agreement.discountPercent}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{agreement.utilizationCount}</div>
                        <div className="text-sm text-muted-foreground">
                          ₹{agreement.totalRevenue.toLocaleString()}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusBadge(agreement.status)}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(agreement.status)}
                          {agreement.status.toUpperCase()}
                        </div>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedAgreement(agreement)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl">
                            <DialogHeader>
                              <DialogTitle>Agreement Details - {agreement.agreementNumber}</DialogTitle>
                              <DialogDescription>
                                Complete rate agreement information and utilization history
                              </DialogDescription>
                            </DialogHeader>
                            {selectedAgreement && (
                              <Tabs defaultValue="details" className="w-full">
                                <TabsList>
                                  <TabsTrigger value="details">Details</TabsTrigger>
                                  <TabsTrigger value="utilization">Utilization</TabsTrigger>
                                  <TabsTrigger value="history">History</TabsTrigger>
                                </TabsList>
                                <TabsContent value="details" className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <h4 className="font-medium mb-2">Agreement Information</h4>
                                      <div className="space-y-2">
                                        <p><strong>Agreement Number:</strong> {selectedAgreement.agreementNumber}</p>
                                        <p><strong>TPA:</strong> {selectedAgreement.tpaName}</p>
                                        <p><strong>Package:</strong> {selectedAgreement.packageName}</p>
                                        <p><strong>Category:</strong> {selectedAgreement.category}</p>
                                        <p><strong>Department:</strong> {selectedAgreement.department}</p>
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-medium mb-2">Financial Details</h4>
                                      <div className="space-y-2">
                                        <p><strong>Hospital Rate:</strong> ₹{selectedAgreement.hospitalRate.toLocaleString()}</p>
                                        <p><strong>Agreed Rate:</strong> ₹{selectedAgreement.agreedRate.toLocaleString()}</p>
                                        <p><strong>Discount:</strong> {selectedAgreement.discountPercent}%</p>
                                        <p><strong>Total Revenue:</strong> ₹{selectedAgreement.totalRevenue.toLocaleString()}</p>
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-medium mb-2">Validity Period</h4>
                                      <div className="space-y-2">
                                        <p><strong>Valid From:</strong> {new Date(selectedAgreement.validFrom).toLocaleDateString()}</p>
                                        <p><strong>Valid To:</strong> {new Date(selectedAgreement.validTo).toLocaleDateString()}</p>
                                        <p><strong>Status:</strong> {selectedAgreement.status.toUpperCase()}</p>
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-medium mb-2">Utilization Stats</h4>
                                      <div className="space-y-2">
                                        <p><strong>Total Utilizations:</strong> {selectedAgreement.utilizationCount}</p>
                                        <p><strong>Avg per Month:</strong> {Math.round(selectedAgreement.utilizationCount / 12)}</p>
                                      </div>
                                    </div>
                                  </div>
                                </TabsContent>
                                <TabsContent value="utilization">
                                  <div className="text-center py-8">
                                    <TrendingUp className="mx-auto h-12 w-12 text-muted-foreground" />
                                    <p className="mt-2 text-muted-foreground">Utilization analytics coming soon</p>
                                  </div>
                                </TabsContent>
                                <TabsContent value="history">
                                  <div className="text-center py-8">
                                    <Clock className="mx-auto h-12 w-12 text-muted-foreground" />
                                    <p className="mt-2 text-muted-foreground">Agreement history coming soon</p>
                                  </div>
                                </TabsContent>
                              </Tabs>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Link href={`/insurance/rates/edit/${agreement.id}`}>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

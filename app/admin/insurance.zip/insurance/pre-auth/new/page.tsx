"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Shield,
  User,
  FileText,
  Upload,
  Search,
  DollarSign,
  Stethoscope,
  AlertCircle,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
} from "lucide-react"

// Mock data
const patients = [
  { id: 1, name: "Rajesh Kumar", patientId: "P001", phone: "+91-9876543210", hasInsurance: true },
  { id: 2, name: "Priya Sharma", patientId: "P002", phone: "+91-9876543211", hasInsurance: true },
  { id: 3, name: "Amit Patel", patientId: "P003", phone: "+91-9876543212", hasInsurance: false },
]

const tpaList = [
  { id: 1, name: "Medi Assist India TPA", code: "MEDI", slaHours: 72 },
  { id: 2, name: "Vidal Health TPA", code: "VIDAL", slaHours: 48 },
  { id: 3, name: "Good Health TPA Services", code: "GOOD", slaHours: 96 },
  { id: 4, name: "Paramount Health Services", code: "PARAM", slaHours: 72 },
]

const doctors = [
  { id: 1, name: "Dr. Priya Sharma", department: "General Surgery", specialization: "Laparoscopic Surgery" },
  { id: 2, name: "Dr. Amit Patel", department: "Obstetrics & Gynecology", specialization: "High Risk Pregnancy" },
  { id: 3, name: "Dr. Sunita Reddy", department: "Ophthalmology", specialization: "Cataract & Retina" },
  { id: 4, name: "Dr. Vikram Singh", department: "Cardiology", specialization: "Interventional Cardiology" },
]

const procedureCodes = [
  { code: "APPEND_LAP", name: "Laparoscopic Appendectomy", estimatedCost: 45000 },
  { code: "NORM_DEL", name: "Normal Vaginal Delivery", estimatedCost: 25000 },
  { code: "CAESAR_DEL", name: "Caesarean Delivery", estimatedCost: 40000 },
  { code: "CATARACT", name: "Cataract Surgery (Phacoemulsification)", estimatedCost: 35000 },
  { code: "PTCA", name: "PTCA with Stent", estimatedCost: 125000 },
]

const documentTypes = [
  { type: "consultation_notes", name: "Consultation Notes", mandatory: true },
  { type: "lab_reports", name: "Lab Reports", mandatory: false },
  { type: "radiology_reports", name: "Radiology Reports", mandatory: false },
  { type: "previous_discharge_summary", name: "Previous Discharge Summary", mandatory: false },
  { type: "fitness_certificate", name: "Fitness Certificate", mandatory: false },
  { type: "other", name: "Other Documents", mandatory: false },
]

export default function NewPreAuthorizationPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [patientSearch, setPatientSearch] = useState("")
  const [showPatientDialog, setShowPatientDialog] = useState(false)

  // Form data
  const [formData, setFormData] = useState({
    // Step 1: Patient Selection
    patientId: "",
    insuranceId: "",

    // Step 2: Medical Details
    admissionType: "",
    diagnosisPrimary: "",
    diagnosisSecondary: "",
    icdCodes: [],
    proposedProcedure: "",
    procedureCodes: [],
    estimatedLos: "",
    doctorId: "",
    roomCategoryRequested: "",
    priority: "normal",

    // Step 3: Cost Estimation
    estimatedRoomCharges: "",
    estimatedDoctorCharges: "",
    estimatedInvestigationCharges: "",
    estimatedMedicineCharges: "",
    estimatedOtherCharges: "",
    totalEstimatedAmount: "",

    // Step 4: Documents & Submission
    tpaId: "",
    tpaCoordinator: "",
    submissionMode: "email",
    uploadedDocuments: [],
    specialInstructions: "",
  })

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(patientSearch.toLowerCase()) ||
      patient.patientId.toLowerCase().includes(patientSearch.toLowerCase()),
  )

  const calculateTotalAmount = () => {
    const room = Number.parseFloat(formData.estimatedRoomCharges) || 0
    const doctor = Number.parseFloat(formData.estimatedDoctorCharges) || 0
    const investigation = Number.parseFloat(formData.estimatedInvestigationCharges) || 0
    const medicine = Number.parseFloat(formData.estimatedMedicineCharges) || 0
    const other = Number.parseFloat(formData.estimatedOtherCharges) || 0

    const total = room + doctor + investigation + medicine + other
    setFormData((prev) => ({ ...prev, totalEstimatedAmount: total.toString() }))
  }

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSubmit = () => {
    // Handle form submission
    console.log("Submitting pre-authorization request:", formData)
    // Redirect to pre-auth list or show success message
  }

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center space-x-4 mb-8">
      {[1, 2, 3, 4].map((step) => (
        <div key={step} className="flex items-center">
          <div
            className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
              step <= currentStep ? "bg-red-600 border-red-600 text-white" : "border-gray-300 text-gray-500"
            }`}
          >
            {step < currentStep ? <CheckCircle className="h-5 w-5" /> : step}
          </div>
          {step < 4 && <div className={`w-16 h-1 mx-2 ${step < currentStep ? "bg-red-600" : "bg-gray-300"}`} />}
        </div>
      ))}
    </div>
  )

  const renderStep1 = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <User className="h-5 w-5 mr-2" />
          Step 1: Patient Selection & Insurance Details
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Patient Selection */}
        <div>
          <Label className="text-base font-medium">Select Patient</Label>
          <div className="mt-2">
            {selectedPatient ? (
              <div className="flex items-center justify-between p-4 border rounded-lg bg-green-50">
                <div>
                  <h4 className="font-medium">{selectedPatient.name}</h4>
                  <p className="text-sm text-gray-600">
                    {selectedPatient.patientId} • {selectedPatient.phone}
                  </p>
                  {selectedPatient.hasInsurance && (
                    <Badge className="bg-green-100 text-green-800 mt-1">Insurance Available</Badge>
                  )}
                </div>
                <Button variant="outline" onClick={() => setSelectedPatient(null)}>
                  Change Patient
                </Button>
              </div>
            ) : (
              <Dialog open={showPatientDialog} onOpenChange={setShowPatientDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Search className="h-4 w-4 mr-2" />
                    Search & Select Patient
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Select Patient</DialogTitle>
                    <DialogDescription>Search and select a patient for pre-authorization request</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        placeholder="Search by name or patient ID..."
                        value={patientSearch}
                        onChange={(e) => setPatientSearch(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <div className="max-h-64 overflow-y-auto space-y-2">
                      {filteredPatients.map((patient) => (
                        <div
                          key={patient.id}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                          onClick={() => {
                            setSelectedPatient(patient)
                            setShowPatientDialog(false)
                            setFormData((prev) => ({ ...prev, patientId: patient.id.toString() }))
                          }}
                        >
                          <div>
                            <h4 className="font-medium">{patient.name}</h4>
                            <p className="text-sm text-gray-600">
                              {patient.patientId} • {patient.phone}
                            </p>
                          </div>
                          {patient.hasInsurance && <Badge className="bg-green-100 text-green-800">Insurance</Badge>}
                        </div>
                      ))}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        {/* Insurance Details */}
        {selectedPatient?.hasInsurance && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="insuranceCompany">Insurance Company</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select insurance company" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="icici">ICICI Lombard General Insurance</SelectItem>
                  <SelectItem value="hdfc">HDFC ERGO General Insurance</SelectItem>
                  <SelectItem value="star">Star Health and Allied Insurance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="policyNumber">Policy Number</Label>
              <Input id="policyNumber" placeholder="Enter policy number" />
            </div>
            <div>
              <Label htmlFor="sumInsured">Sum Insured</Label>
              <Input id="sumInsured" placeholder="Enter sum insured amount" />
            </div>
            <div>
              <Label htmlFor="sumAvailable">Sum Available</Label>
              <Input id="sumAvailable" placeholder="Enter available amount" />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderStep2 = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Stethoscope className="h-5 w-5 mr-2" />
          Step 2: Medical Details
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="admissionType">Admission Type</Label>
            <Select
              value={formData.admissionType}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, admissionType: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select admission type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="emergency">Emergency</SelectItem>
                <SelectItem value="planned">Planned</SelectItem>
                <SelectItem value="day_care">Day Care</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="priority">Priority</Label>
            <Select
              value={formData.priority}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, priority: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="diagnosisPrimary">Primary Diagnosis</Label>
          <Input
            id="diagnosisPrimary"
            value={formData.diagnosisPrimary}
            onChange={(e) => setFormData((prev) => ({ ...prev, diagnosisPrimary: e.target.value }))}
            placeholder="Enter primary diagnosis"
          />
        </div>

        <div>
          <Label htmlFor="diagnosisSecondary">Secondary Diagnosis (Optional)</Label>
          <Textarea
            id="diagnosisSecondary"
            value={formData.diagnosisSecondary}
            onChange={(e) => setFormData((prev) => ({ ...prev, diagnosisSecondary: e.target.value }))}
            placeholder="Enter secondary diagnosis if any"
            rows={3}
          />
        </div>

        <div>
          <Label htmlFor="proposedProcedure">Proposed Procedure</Label>
          <Select
            value={formData.proposedProcedure}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, proposedProcedure: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select procedure" />
            </SelectTrigger>
            <SelectContent>
              {procedureCodes.map((procedure) => (
                <SelectItem key={procedure.code} value={procedure.code}>
                  {procedure.name} - ₹{procedure.estimatedCost.toLocaleString()}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="doctorId">Consulting Doctor</Label>
            <Select
              value={formData.doctorId}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, doctorId: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select doctor" />
              </SelectTrigger>
              <SelectContent>
                {doctors.map((doctor) => (
                  <SelectItem key={doctor.id} value={doctor.id.toString()}>
                    {doctor.name} - {doctor.department}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="estimatedLos">Estimated Length of Stay (Days)</Label>
            <Input
              id="estimatedLos"
              type="number"
              value={formData.estimatedLos}
              onChange={(e) => setFormData((prev) => ({ ...prev, estimatedLos: e.target.value }))}
              placeholder="Enter number of days"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="roomCategoryRequested">Room Category Requested</Label>
          <Select
            value={formData.roomCategoryRequested}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, roomCategoryRequested: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select room category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="general">General Ward</SelectItem>
              <SelectItem value="semi_private">Semi Private</SelectItem>
              <SelectItem value="private">Private Room</SelectItem>
              <SelectItem value="deluxe">Deluxe Room</SelectItem>
              <SelectItem value="suite">Suite</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  )

  const renderStep3 = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <DollarSign className="h-5 w-5 mr-2" />
          Step 3: Cost Estimation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="estimatedRoomCharges">Room Charges</Label>
            <Input
              id="estimatedRoomCharges"
              type="number"
              value={formData.estimatedRoomCharges}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, estimatedRoomCharges: e.target.value }))
                setTimeout(calculateTotalAmount, 100)
              }}
              placeholder="Enter room charges"
            />
          </div>
          <div>
            <Label htmlFor="estimatedDoctorCharges">Doctor Charges</Label>
            <Input
              id="estimatedDoctorCharges"
              type="number"
              value={formData.estimatedDoctorCharges}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, estimatedDoctorCharges: e.target.value }))
                setTimeout(calculateTotalAmount, 100)
              }}
              placeholder="Enter doctor charges"
            />
          </div>
          <div>
            <Label htmlFor="estimatedInvestigationCharges">Investigation Charges</Label>
            <Input
              id="estimatedInvestigationCharges"
              type="number"
              value={formData.estimatedInvestigationCharges}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, estimatedInvestigationCharges: e.target.value }))
                setTimeout(calculateTotalAmount, 100)
              }}
              placeholder="Enter investigation charges"
            />
          </div>
          <div>
            <Label htmlFor="estimatedMedicineCharges">Medicine Charges</Label>
            <Input
              id="estimatedMedicineCharges"
              type="number"
              value={formData.estimatedMedicineCharges}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, estimatedMedicineCharges: e.target.value }))
                setTimeout(calculateTotalAmount, 100)
              }}
              placeholder="Enter medicine charges"
            />
          </div>
          <div>
            <Label htmlFor="estimatedOtherCharges">Other Charges</Label>
            <Input
              id="estimatedOtherCharges"
              type="number"
              value={formData.estimatedOtherCharges}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, estimatedOtherCharges: e.target.value }))
                setTimeout(calculateTotalAmount, 100)
              }}
              placeholder="Enter other charges"
            />
          </div>
          <div>
            <Label htmlFor="totalEstimatedAmount">Total Estimated Amount</Label>
            <Input
              id="totalEstimatedAmount"
              type="number"
              value={formData.totalEstimatedAmount}
              readOnly
              className="bg-gray-50 font-medium"
              placeholder="Auto-calculated total"
            />
          </div>
        </div>

        {formData.totalEstimatedAmount && (
          <div className="p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-blue-600 mr-2" />
              <span className="font-medium text-blue-900">
                Total Estimated Amount: ₹{Number.parseFloat(formData.totalEstimatedAmount).toLocaleString()}
              </span>
            </div>
            <p className="text-sm text-blue-700 mt-1">This amount will be submitted for pre-authorization approval.</p>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderStep4 = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="h-5 w-5 mr-2" />
          Step 4: Documents & Submission
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* TPA Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="tpaId">Select TPA</Label>
            <Select
              value={formData.tpaId}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, tpaId: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select TPA" />
              </SelectTrigger>
              <SelectContent>
                {tpaList.map((tpa) => (
                  <SelectItem key={tpa.id} value={tpa.id.toString()}>
                    {tpa.name} ({tpa.code}) - {tpa.slaHours}h SLA
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="tpaCoordinator">TPA Coordinator</Label>
            <Input
              id="tpaCoordinator"
              value={formData.tpaCoordinator}
              onChange={(e) => setFormData((prev) => ({ ...prev, tpaCoordinator: e.target.value }))}
              placeholder="Enter coordinator name"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="submissionMode">Submission Mode</Label>
          <Select
            value={formData.submissionMode}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, submissionMode: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select submission mode" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="portal">TPA Portal</SelectItem>
              <SelectItem value="api">API Integration</SelectItem>
              <SelectItem value="manual">Manual Submission</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Document Upload */}
        <div>
          <Label className="text-base font-medium">Required Documents</Label>
          <div className="mt-3 space-y-3">
            {documentTypes.map((docType) => (
              <div key={docType.type} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Checkbox id={docType.type} />
                  <div>
                    <label htmlFor={docType.type} className="font-medium cursor-pointer">
                      {docType.name}
                    </label>
                    {docType.mandatory && <Badge className="ml-2 bg-red-100 text-red-800">Required</Badge>}
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div>
          <Label htmlFor="specialInstructions">Special Instructions (Optional)</Label>
          <Textarea
            id="specialInstructions"
            value={formData.specialInstructions}
            onChange={(e) => setFormData((prev) => ({ ...prev, specialInstructions: e.target.value }))}
            placeholder="Enter any special instructions for the TPA"
            rows={4}
          />
        </div>

        {/* Summary */}
        <div className="p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-3">Pre-Authorization Summary</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Patient:</span> {selectedPatient?.name}
            </div>
            <div>
              <span className="text-gray-600">Diagnosis:</span> {formData.diagnosisPrimary}
            </div>
            <div>
              <span className="text-gray-600">Procedure:</span> {formData.proposedProcedure}
            </div>
            <div>
              <span className="text-gray-600">Estimated Amount:</span> ₹
              {Number.parseFloat(formData.totalEstimatedAmount || "0").toLocaleString()}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">New Pre-Authorization Request</h1>
        <p className="text-gray-600 mt-1">Create a new insurance pre-authorization request</p>
      </div>

      {/* Step Indicator */}
      {renderStepIndicator()}

      {/* Step Content */}
      <div className="mb-8">
        {currentStep === 1 && renderStep1()}
        {currentStep === 2 && renderStep2()}
        {currentStep === 3 && renderStep3()}
        {currentStep === 4 && renderStep4()}
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <Button variant="outline" onClick={handlePrevious} disabled={currentStep === 1}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Previous
        </Button>

        <div className="flex space-x-3">
          {currentStep < 4 ? (
            <Button
              onClick={handleNext}
              disabled={currentStep === 1 && !selectedPatient}
              className="bg-red-600 hover:bg-red-700"
            >
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
              <Shield className="h-4 w-4 mr-2" />
              Submit Pre-Authorization
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

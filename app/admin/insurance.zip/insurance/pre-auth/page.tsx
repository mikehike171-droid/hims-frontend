"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Shield,
  Search,
  Filter,
  Plus,
  Eye,
  Edit,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Download,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"

// Mock data for pre-authorization requests
const preAuthRequests = [
  {
    id: 1,
    authNumber: "PA2024001",
    patientName: "Rajesh Kumar",
    patientId: "P001",
    tpaName: "Medi Assist",
    insuranceCompany: "ICICI Lombard",
    diagnosis: "Appendectomy",
    procedure: "Laparoscopic Appendectomy",
    estimatedAmount: 45000,
    approvedAmount: 42000,
    status: "approved",
    priority: "high",
    submittedDate: "2024-01-15",
    approvalDate: "2024-01-16",
    slaStatus: "within_sla",
    coordinator: "Dr. Priya Sharma",
  },
  {
    id: 2,
    authNumber: "PA2024002",
    patientName: "Priya Sharma",
    patientId: "P002",
    tpaName: "Vidal Health",
    insuranceCompany: "HDFC ERGO",
    diagnosis: "Normal Delivery",
    procedure: "Normal Vaginal Delivery",
    estimatedAmount: 25000,
    approvedAmount: 0,
    status: "pending",
    priority: "urgent",
    submittedDate: "2024-01-14",
    approvalDate: null,
    slaStatus: "approaching_sla",
    coordinator: "Dr. Amit Patel",
  },
  {
    id: 3,
    authNumber: "PA2024003",
    patientName: "Amit Patel",
    patientId: "P003",
    tpaName: "Good Health",
    insuranceCompany: "Star Health",
    diagnosis: "Cataract Surgery",
    procedure: "Phacoemulsification",
    estimatedAmount: 35000,
    approvedAmount: 0,
    status: "query_raised",
    priority: "normal",
    submittedDate: "2024-01-13",
    approvalDate: null,
    slaStatus: "within_sla",
    coordinator: "Dr. Sunita Reddy",
  },
  {
    id: 4,
    authNumber: "PA2024004",
    patientName: "Sunita Reddy",
    patientId: "P004",
    tpaName: "Paramount Health",
    insuranceCompany: "ICICI Lombard",
    diagnosis: "Hysterectomy",
    procedure: "Total Abdominal Hysterectomy",
    estimatedAmount: 75000,
    approvedAmount: 0,
    status: "rejected",
    priority: "normal",
    submittedDate: "2024-01-12",
    approvalDate: "2024-01-14",
    slaStatus: "within_sla",
    coordinator: "Dr. Vikram Singh",
  },
  {
    id: 5,
    authNumber: "PA2024005",
    patientName: "Vikram Singh",
    patientId: "P005",
    tpaName: "Medi Assist",
    insuranceCompany: "HDFC ERGO",
    diagnosis: "Coronary Angioplasty",
    procedure: "PTCA with Stent",
    estimatedAmount: 125000,
    approvedAmount: 120000,
    status: "approved",
    priority: "urgent",
    submittedDate: "2024-01-11",
    approvalDate: "2024-01-12",
    slaStatus: "within_sla",
    coordinator: "Dr. Meera Joshi",
  },
]

const getStatusIcon = (status: string) => {
  switch (status) {
    case "approved":
      return <CheckCircle className="h-4 w-4 text-green-600" />
    case "pending":
      return <Clock className="h-4 w-4 text-yellow-600" />
    case "rejected":
      return <XCircle className="h-4 w-4 text-red-600" />
    case "query_raised":
      return <AlertCircle className="h-4 w-4 text-blue-600" />
    default:
      return <Clock className="h-4 w-4 text-gray-600" />
  }
}

const getStatusColor = (status: string) => {
  switch (status) {
    case "approved":
      return "bg-green-100 text-green-800"
    case "pending":
      return "bg-yellow-100 text-yellow-800"
    case "rejected":
      return "bg-red-100 text-red-800"
    case "query_raised":
      return "bg-blue-100 text-blue-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "urgent":
      return "bg-red-100 text-red-800"
    case "high":
      return "bg-orange-100 text-orange-800"
    case "normal":
      return "bg-blue-100 text-blue-800"
    case "low":
      return "bg-gray-100 text-gray-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

const getSlaStatusColor = (slaStatus: string) => {
  switch (slaStatus) {
    case "within_sla":
      return "bg-green-100 text-green-800"
    case "approaching_sla":
      return "bg-yellow-100 text-yellow-800"
    case "overdue":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export default function PreAuthorizationPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [tpaFilter, setTpaFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")

  const filteredRequests = preAuthRequests.filter((request) => {
    const matchesSearch =
      request.authNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.diagnosis.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || request.status === statusFilter
    const matchesTpa = tpaFilter === "all" || request.tpaName === tpaFilter
    const matchesPriority = priorityFilter === "all" || request.priority === priorityFilter

    return matchesSearch && matchesStatus && matchesTpa && matchesPriority
  })

  return (
    <PrivateRoute modulePath="admin/insurance/pre-auth" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Pre-Authorization Management</h1>
          <p className="text-gray-600 mt-1">Manage and track insurance pre-authorization requests</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Link href="/insurance/pre-auth/new">
            <Button className="bg-red-600 hover:bg-red-700">
              <Plus className="h-4 w-4 mr-2" />
              New Pre-Authorization
            </Button>
          </Link>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search pre-auths..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="query_raised">Query Raised</SelectItem>
              </SelectContent>
            </Select>
            <Select value={tpaFilter} onValueChange={setTpaFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All TPAs" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All TPAs</SelectItem>
                <SelectItem value="Medi Assist">Medi Assist</SelectItem>
                <SelectItem value="Vidal Health">Vidal Health</SelectItem>
                <SelectItem value="Good Health">Good Health</SelectItem>
                <SelectItem value="Paramount Health">Paramount Health</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Priorities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="w-full bg-transparent">
              <Filter className="h-4 w-4 mr-2" />
              Clear Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Pre-Authorization Table */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Pre-Authorization Requests ({filteredRequests.length})</CardTitle>
            <div className="flex space-x-2">
              <Badge variant="outline">Pending: {filteredRequests.filter((r) => r.status === "pending").length}</Badge>
              <Badge variant="outline">
                Approved: {filteredRequests.filter((r) => r.status === "approved").length}
              </Badge>
              <Badge variant="outline">
                Queries: {filteredRequests.filter((r) => r.status === "query_raised").length}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Auth Number</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>TPA / Insurance</TableHead>
                  <TableHead>Diagnosis & Procedure</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>SLA</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRequests.map((request) => (
                  <TableRow key={request.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(request.status)}
                        <span className="font-medium">{request.authNumber}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{request.patientName}</div>
                        <div className="text-sm text-gray-500">{request.patientId}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{request.tpaName}</div>
                        <div className="text-sm text-gray-500">{request.insuranceCompany}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{request.diagnosis}</div>
                        <div className="text-sm text-gray-500">{request.procedure}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">₹{request.estimatedAmount.toLocaleString()}</div>
                        {request.approvedAmount > 0 && (
                          <div className="text-sm text-green-600">
                            Approved: ₹{request.approvedAmount.toLocaleString()}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(request.status)}>{request.status.replace("_", " ")}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getPriorityColor(request.priority)}>{request.priority}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getSlaStatusColor(request.slaStatus)}>
                        {request.slaStatus.replace("_", " ")}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{request.submittedDate}</div>
                        {request.approvalDate && <div className="text-gray-500">Approved: {request.approvalDate}</div>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredRequests.length === 0 && (
            <div className="text-center py-8">
              <Shield className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No pre-authorization requests found</h3>
              <p className="text-gray-500 mb-4">
                Try adjusting your search criteria or create a new pre-authorization request.
              </p>
              <Link href="/insurance/pre-auth/new">
                <Button className="bg-red-600 hover:bg-red-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Create New Pre-Authorization
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Save, CheckCircle, XCircle, AlertCircle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

interface ClaimEditProps {
  params: {
    id: string
  }
}

export default function EditClaim({ params }: ClaimEditProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [claimData, setClaimData] = useState<any>(null)
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    // Simulate loading claim data
    setTimeout(() => {
      setClaimData({
        id: params.id,
        claimNumber: 'CLM-2024-001',
        patientName: 'John Doe',
        patientId: 'PAT-001',
        tpaName: 'Star Health TPA',
        policyNumber: 'SH-123456789',
        claimAmount: 45000,
        approvedAmount: 42000,
        status: 'approved',
        submissionDate: '2024-01-15',
        diagnosis: 'Acute Myocardial Infarction',
        treatmentType: 'Inpatient',
        doctorName: 'Dr. Smith',
        department: 'Cardiology'
      })
      setIsLoading(false)
    }, 1000)
  }, [params.id])

  const handleSave = async () => {
    setIsSaving(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    toast({
      title: "Claim Updated",
      description: "The claim has been updated successfully.",
    })
    
    setIsSaving(false)
    router.push('/insurance/claims')
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'rejected': return <XCircle className="h-4 w-4 text-red-500" />
      case 'query_raised': return <AlertCircle className="h-4 w-4 text-orange-500" />
      default: return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/insurance/claims">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Claims
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit Claim - {claimData.claimNumber}</h1>
          <p className="text-muted-foreground">Update claim information and status</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Current Status
              <Badge className="flex items-center gap-1">
                {getStatusIcon(claimData.status)}
                {claimData.status.replace('_', ' ').toUpperCase()}
              </Badge>
            </CardTitle>
            <CardDescription>Update claim status and processing information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="status">Claim Status</Label>
                <Select defaultValue={claimData.status}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="query_raised">Query Raised</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="approvedAmount">Approved Amount</Label>
                <Input 
                  id="approvedAmount" 
                  type="number" 
                  defaultValue={claimData.approvedAmount}
                  placeholder="Enter approved amount"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="remarks">Processing Remarks</Label>
              <Textarea 
                id="remarks" 
                placeholder="Enter processing remarks or queries"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Claim Information</CardTitle>
            <CardDescription>Patient and treatment details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="patientName">Patient Name</Label>
                <Input id="patientName" defaultValue={claimData.patientName} readOnly />
              </div>
              <div>
                <Label htmlFor="patientId">Patient ID</Label>
                <Input id="patientId" defaultValue={claimData.patientId} readOnly />
              </div>
              <div>
                <Label htmlFor="tpaName">TPA</Label>
                <Input id="tpaName" defaultValue={claimData.tpaName} readOnly />
              </div>
              <div>
                <Label htmlFor="policyNumber">Policy Number</Label>
                <Input id="policyNumber" defaultValue={claimData.policyNumber} readOnly />
              </div>
              <div>
                <Label htmlFor="diagnosis">Diagnosis</Label>
                <Input id="diagnosis" defaultValue={claimData.diagnosis} />
              </div>
              <div>
                <Label htmlFor="treatmentType">Treatment Type</Label>
                <Input id="treatmentType" defaultValue={claimData.treatmentType} readOnly />
              </div>
              <div>
                <Label htmlFor="doctorName">Doctor</Label>
                <Input id="doctorName" defaultValue={claimData.doctorName} readOnly />
              </div>
              <div>
                <Label htmlFor="department">Department</Label>
                <Input id="department" defaultValue={claimData.department} readOnly />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Financial Details</CardTitle>
            <CardDescription>Claim amount and approval information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="claimAmount">Claim Amount</Label>
                <Input 
                  id="claimAmount" 
                  type="number" 
                  defaultValue={claimData.claimAmount}
                  readOnly
                />
              </div>
              <div>
                <Label htmlFor="approvedAmountEdit">Approved Amount</Label>
                <Input 
                  id="approvedAmountEdit" 
                  type="number" 
                  defaultValue={claimData.approvedAmount}
                />
              </div>
              <div>
                <Label htmlFor="deductible">Deductible</Label>
                <Input 
                  id="deductible" 
                  type="number" 
                  placeholder="Enter deductible amount"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end gap-4">
        <Link href="/insurance/claims">
          <Button variant="outline">Cancel</Button>
        </Link>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </div>
  )
}

'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Checkbox } from '@/components/ui/checkbox'
import { ArrowLeft, CalendarIcon, Upload, Plus, Trash2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { format } from 'date-fns'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

interface ClaimItem {
  id: string
  description: string
  amount: number
  category: string
}

export default function NewClaim() {
  const [admissionDate, setAdmissionDate] = useState<Date>()
  const [dischargeDate, setDischargeDate] = useState<Date>()
  const [claimItems, setClaimItems] = useState<ClaimItem[]>([
    { id: '1', description: '', amount: 0, category: 'consultation' }
  ])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const addClaimItem = () => {
    const newItem: ClaimItem = {
      id: Date.now().toString(),
      description: '',
      amount: 0,
      category: 'consultation'
    }
    setClaimItems([...claimItems, newItem])
  }

  const removeClaimItem = (id: string) => {
    setClaimItems(claimItems.filter(item => item.id !== id))
  }

  const updateClaimItem = (id: string, field: keyof ClaimItem, value: string | number) => {
    setClaimItems(claimItems.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ))
  }

  const totalAmount = claimItems.reduce((sum, item) => sum + item.amount, 0)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))

    toast({
      title: "Claim Submitted",
      description: "Your insurance claim has been submitted successfully.",
    })

    setIsSubmitting(false)
    router.push('/insurance/claims')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/insurance/claims">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Claims
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">New Insurance Claim</h1>
          <p className="text-muted-foreground">Submit a new insurance claim for patient treatment</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Tabs defaultValue="patient" className="space-y-6">
          <TabsList>
            <TabsTrigger value="patient">Patient & Policy</TabsTrigger>
            <TabsTrigger value="treatment">Treatment Details</TabsTrigger>
            <TabsTrigger value="billing">Billing Items</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
          </TabsList>

          <TabsContent value="patient">
            <Card>
              <CardHeader>
                <CardTitle>Patient & Policy Information</CardTitle>
                <CardDescription>Enter patient details and insurance policy information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="patientId">Patient ID *</Label>
                      <Input id="patientId" placeholder="Enter patient ID" required />
                    </div>
                    <div>
                      <Label htmlFor="patientName">Patient Name *</Label>
                      <Input id="patientName" placeholder="Enter patient name" required />
                    </div>
                    <div>
                      <Label htmlFor="patientAge">Age</Label>
                      <Input id="patientAge" type="number" placeholder="Enter age" />
                    </div>
                    <div>
                      <Label htmlFor="patientGender">Gender</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select gender" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="tpa">TPA *</Label>
                      <Select required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select TPA" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="star-health">Star Health TPA</SelectItem>
                          <SelectItem value="medi-assist">Medi Assist TPA</SelectItem>
                          <SelectItem value="vidal-health">Vidal Health TPA</SelectItem>
                          <SelectItem value="paramount">Paramount TPA</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="policyNumber">Policy Number *</Label>
                      <Input id="policyNumber" placeholder="Enter policy number" required />
                    </div>
                    <div>
                      <Label htmlFor="policyType">Policy Type</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select policy type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="individual">Individual</SelectItem>
                          <SelectItem value="family">Family Floater</SelectItem>
                          <SelectItem value="group">Group</SelectItem>
                          <SelectItem value="corporate">Corporate</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="sumInsured">Sum Insured</Label>
                      <Input id="sumInsured" type="number" placeholder="Enter sum insured" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="treatment">
            <Card>
              <CardHeader>
                <CardTitle>Treatment Details</CardTitle>
                <CardDescription>Enter treatment and medical information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="treatmentType">Treatment Type *</Label>
                      <Select required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select treatment type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="inpatient">Inpatient</SelectItem>
                          <SelectItem value="outpatient">Outpatient</SelectItem>
                          <SelectItem value="daycare">Day Care</SelectItem>
                          <SelectItem value="emergency">Emergency</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="department">Department *</Label>
                      <Select required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cardiology">Cardiology</SelectItem>
                          <SelectItem value="neurology">Neurology</SelectItem>
                          <SelectItem value="orthopedics">Orthopedics</SelectItem>
                          <SelectItem value="general-medicine">General Medicine</SelectItem>
                          <SelectItem value="surgery">Surgery</SelectItem>
                          <SelectItem value="pediatrics">Pediatrics</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="doctorName">Consulting Doctor *</Label>
                      <Input id="doctorName" placeholder="Enter doctor name" required />
                    </div>
                    <div>
                      <Label>Admission Date *</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !admissionDate && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {admissionDate ? format(admissionDate, "PPP") : "Select admission date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={admissionDate}
                            onSelect={setAdmissionDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="primaryDiagnosis">Primary Diagnosis *</Label>
                      <Input id="primaryDiagnosis" placeholder="Enter primary diagnosis" required />
                    </div>
                    <div>
                      <Label htmlFor="icdCode">ICD Code</Label>
                      <Input id="icdCode" placeholder="Enter ICD-10 code" />
                    </div>
                    <div>
                      <Label htmlFor="secondaryDiagnosis">Secondary Diagnosis</Label>
                      <Input id="secondaryDiagnosis" placeholder="Enter secondary diagnosis" />
                    </div>
                    <div>
                      <Label>Discharge Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !dischargeDate && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {dischargeDate ? format(dischargeDate, "PPP") : "Select discharge date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={dischargeDate}
                            onSelect={setDischargeDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="treatmentSummary">Treatment Summary</Label>
                  <Textarea 
                    id="treatmentSummary" 
                    placeholder="Enter detailed treatment summary"
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing">
            <Card>
              <CardHeader>
                <CardTitle>Billing Items</CardTitle>
                <CardDescription>Add all billable items for this claim</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {claimItems.map((item, index) => (
                  <div key={item.id} className="border rounded-lg p-4 space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Item {index + 1}</h4>
                      {claimItems.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeClaimItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label>Category</Label>
                        <Select 
                          value={item.category}
                          onValueChange={(value) => updateClaimItem(item.id, 'category', value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="consultation">Consultation</SelectItem>
                            <SelectItem value="investigation">Investigation</SelectItem>
                            <SelectItem value="procedure">Procedure</SelectItem>
                            <SelectItem value="medication">Medication</SelectItem>
                            <SelectItem value="room-charges">Room Charges</SelectItem>
                            <SelectItem value="surgery">Surgery</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Description</Label>
                        <Input
                          value={item.description}
                          onChange={(e) => updateClaimItem(item.id, 'description', e.target.value)}
                          placeholder="Enter item description"
                        />
                      </div>
                      <div>
                        <Label>Amount (₹)</Label>
                        <Input
                          type="number"
                          value={item.amount}
                          onChange={(e) => updateClaimItem(item.id, 'amount', parseFloat(e.target.value) || 0)}
                          placeholder="Enter amount"
                        />
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="flex justify-between items-center">
                  <Button type="button" variant="outline" onClick={addClaimItem}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Item
                  </Button>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Total Claim Amount</p>
                    <p className="text-2xl font-bold">₹{totalAmount.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents">
            <Card>
              <CardHeader>
                <CardTitle>Supporting Documents</CardTitle>
                <CardDescription>Upload required documents for claim processing</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label>Discharge Summary</Label>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <p className="mt-2 text-sm text-gray-600">Click to upload or drag and drop</p>
                        <p className="text-xs text-gray-500">PDF, DOC up to 10MB</p>
                      </div>
                    </div>
                    <div>
                      <Label>Investigation Reports</Label>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <p className="mt-2 text-sm text-gray-600">Click to upload or drag and drop</p>
                        <p className="text-xs text-gray-500">PDF, DOC up to 10MB</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label>Bills & Receipts</Label>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <p className="mt-2 text-sm text-gray-600">Click to upload or drag and drop</p>
                        <p className="text-xs text-gray-500">PDF, DOC up to 10MB</p>
                      </div>
                    </div>
                    <div>
                      <Label>Other Documents</Label>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <p className="mt-2 text-sm text-gray-600">Click to upload or drag and drop</p>
                        <p className="text-xs text-gray-500">PDF, DOC up to 10MB</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="terms" />
                    <Label htmlFor="terms" className="text-sm">
                      I confirm that all information provided is accurate and complete
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="consent" />
                    <Label htmlFor="consent" className="text-sm">
                      I consent to share medical information with the insurance provider
                    </Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-4">
          <Link href="/insurance/claims">
            <Button type="button" variant="outline">Cancel</Button>
          </Link>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Submitting...' : 'Submit Claim'}
          </Button>
        </div>
      </form>
    </div>
  )
}

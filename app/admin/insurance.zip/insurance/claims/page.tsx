'use client'

import { useState } from 'react'
import PrivateRoute from '@/components/auth/PrivateRoute'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CalendarDays, FileText, Plus, Search, Filter, Download, Eye, Edit, CheckCircle, XCircle, Clock, AlertCircle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Link from 'next/link'

interface Claim {
  id: string
  claimNumber: string
  patientName: string
  patientId: string
  tpaName: string
  policyNumber: string
  claimAmount: number
  approvedAmount: number
  status: 'pending' | 'approved' | 'rejected' | 'query_raised' | 'processing'
  submissionDate: string
  approvalDate?: string
  diagnosis: string
  treatmentType: string
  admissionDate: string
  dischargeDate: string
  doctorName: string
  department: string
}

const mockClaims: Claim[] = [
  {
    id: '1',
    claimNumber: 'CLM-2024-001',
    patientName: 'John Doe',
    patientId: 'PAT-001',
    tpaName: 'Star Health TPA',
    policyNumber: 'SH-123456789',
    claimAmount: 45000,
    approvedAmount: 42000,
    status: 'approved',
    submissionDate: '2024-01-15',
    approvalDate: '2024-01-18',
    diagnosis: 'Acute Myocardial Infarction',
    treatmentType: 'Inpatient',
    admissionDate: '2024-01-10',
    dischargeDate: '2024-01-14',
    doctorName: 'Dr. Smith',
    department: 'Cardiology'
  },
  {
    id: '2',
    claimNumber: 'CLM-2024-002',
    patientName: 'Jane Smith',
    patientId: 'PAT-002',
    tpaName: 'Medi Assist TPA',
    policyNumber: 'MA-987654321',
    claimAmount: 25000,
    approvedAmount: 0,
    status: 'pending',
    submissionDate: '2024-01-20',
    diagnosis: 'Diabetes Mellitus Type 2',
    treatmentType: 'Outpatient',
    admissionDate: '2024-01-19',
    dischargeDate: '2024-01-19',
    doctorName: 'Dr. Johnson',
    department: 'Endocrinology'
  },
  {
    id: '3',
    claimNumber: 'CLM-2024-003',
    patientName: 'Robert Wilson',
    patientId: 'PAT-003',
    tpaName: 'Vidal Health TPA',
    policyNumber: 'VH-456789123',
    claimAmount: 75000,
    approvedAmount: 0,
    status: 'query_raised',
    submissionDate: '2024-01-22',
    diagnosis: 'Coronary Artery Disease',
    treatmentType: 'Inpatient',
    admissionDate: '2024-01-18',
    dischargeDate: '2024-01-21',
    doctorName: 'Dr. Brown',
    department: 'Cardiology'
  }
]

export default function ClaimsManagement() {
  const [claims, setClaims] = useState<Claim[]>(mockClaims)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedClaim, setSelectedClaim] = useState<Claim | null>(null)
  const { toast } = useToast()

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'rejected': return <XCircle className="h-4 w-4 text-red-500" />
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />
      case 'query_raised': return <AlertCircle className="h-4 w-4 text-orange-500" />
      case 'processing': return <Clock className="h-4 w-4 text-blue-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      approved: 'bg-green-100 text-green-800 border-green-200',
      rejected: 'bg-red-100 text-red-800 border-red-200',
      pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      query_raised: 'bg-orange-100 text-orange-800 border-orange-200',
      processing: 'bg-blue-100 text-blue-800 border-blue-200'
    }
    return variants[status as keyof typeof variants] || 'bg-gray-100 text-gray-800 border-gray-200'
  }

  const filteredClaims = claims.filter(claim => {
    const matchesSearch = claim.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         claim.claimNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         claim.tpaName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || claim.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalClaims = claims.length
  const approvedClaims = claims.filter(c => c.status === 'approved').length
  const pendingClaims = claims.filter(c => c.status === 'pending').length
  const rejectedClaims = claims.filter(c => c.status === 'rejected').length
  const totalClaimAmount = claims.reduce((sum, claim) => sum + claim.claimAmount, 0)
  const totalApprovedAmount = claims.reduce((sum, claim) => sum + claim.approvedAmount, 0)

  return (
    <PrivateRoute modulePath="admin/insurance/claims" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Claims Management</h1>
          <p className="text-gray-600 mt-1">Manage insurance claims and track approvals</p>
        </div>
        <Link href="/insurance/claims/new">
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <Plus className="mr-2 h-4 w-4" />
            New Claim
          </Button>
        </Link>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Claims</CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{totalClaims}</div>
            <p className="text-xs text-gray-500 mt-1">All time claims</p>
          </CardContent>
        </Card>
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approvedClaims}</div>
            <p className="text-xs text-gray-500 mt-1">
              {totalClaims > 0 ? Math.round((approvedClaims / totalClaims) * 100) : 0}% approval rate
            </p>
          </CardContent>
        </Card>
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingClaims}</div>
            <p className="text-xs text-gray-500 mt-1">Awaiting approval</p>
          </CardContent>
        </Card>
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Claim Amount</CardTitle>
            <CalendarDays className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">₹{totalClaimAmount.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">
              ₹{totalApprovedAmount.toLocaleString()} approved
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Claims List */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle className="text-gray-900">Claims List</CardTitle>
          <CardDescription className="text-gray-600">View and manage all insurance claims</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search claims..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-gray-200 focus:border-red-500 focus:ring-red-500"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px] border-gray-200">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="query_raised">Query Raised</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="border-gray-200">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>

          <div className="rounded-lg border border-gray-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="font-semibold text-gray-700">Claim Number</TableHead>
                  <TableHead className="font-semibold text-gray-700">Patient</TableHead>
                  <TableHead className="font-semibold text-gray-700">TPA</TableHead>
                  <TableHead className="font-semibold text-gray-700">Claim Amount</TableHead>
                  <TableHead className="font-semibold text-gray-700">Approved Amount</TableHead>
                  <TableHead className="font-semibold text-gray-700">Status</TableHead>
                  <TableHead className="font-semibold text-gray-700">Submission Date</TableHead>
                  <TableHead className="font-semibold text-gray-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClaims.map((claim) => (
                  <TableRow key={claim.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium text-gray-900">{claim.claimNumber}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium text-gray-900">{claim.patientName}</div>
                        <div className="text-sm text-gray-500">{claim.patientId}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-700">{claim.tpaName}</TableCell>
                    <TableCell className="font-medium text-gray-900">₹{claim.claimAmount.toLocaleString()}</TableCell>
                    <TableCell className="font-medium text-green-600">
                      {claim.approvedAmount > 0 ? `₹${claim.approvedAmount.toLocaleString()}` : '-'}
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getStatusBadge(claim.status)} border`}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(claim.status)}
                          {claim.status.replace('_', ' ').toUpperCase()}
                        </div>
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-700">{new Date(claim.submissionDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedClaim(claim)}
                              className="border-gray-200 hover:bg-gray-50"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl">
                            <DialogHeader>
                              <DialogTitle>Claim Details - {claim.claimNumber}</DialogTitle>
                              <DialogDescription>
                                Complete claim information and processing history
                              </DialogDescription>
                            </DialogHeader>
                            {selectedClaim && (
                              <Tabs defaultValue="details" className="w-full">
                                <TabsList>
                                  <TabsTrigger value="details">Details</TabsTrigger>
                                  <TabsTrigger value="documents">Documents</TabsTrigger>
                                  <TabsTrigger value="history">History</TabsTrigger>
                                </TabsList>
                                <TabsContent value="details" className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <Label className="text-sm font-medium">Patient Information</Label>
                                      <div className="mt-1 space-y-1">
                                        <p><strong>Name:</strong> {selectedClaim.patientName}</p>
                                        <p><strong>Patient ID:</strong> {selectedClaim.patientId}</p>
                                        <p><strong>Policy Number:</strong> {selectedClaim.policyNumber}</p>
                                      </div>
                                    </div>
                                    <div>
                                      <Label className="text-sm font-medium">Treatment Information</Label>
                                      <div className="mt-1 space-y-1">
                                        <p><strong>Diagnosis:</strong> {selectedClaim.diagnosis}</p>
                                        <p><strong>Doctor:</strong> {selectedClaim.doctorName}</p>
                                        <p><strong>Department:</strong> {selectedClaim.department}</p>
                                        <p><strong>Type:</strong> {selectedClaim.treatmentType}</p>
                                      </div>
                                    </div>
                                    <div>
                                      <Label className="text-sm font-medium">Financial Information</Label>
                                      <div className="mt-1 space-y-1">
                                        <p><strong>Claim Amount:</strong> ₹{selectedClaim.claimAmount.toLocaleString()}</p>
                                        <p><strong>Approved Amount:</strong> {selectedClaim.approvedAmount > 0 ? `₹${selectedClaim.approvedAmount.toLocaleString()}` : 'Pending'}</p>
                                        <p><strong>TPA:</strong> {selectedClaim.tpaName}</p>
                                      </div>
                                    </div>
                                    <div>
                                      <Label className="text-sm font-medium">Timeline</Label>
                                      <div className="mt-1 space-y-1">
                                        <p><strong>Admission:</strong> {new Date(selectedClaim.admissionDate).toLocaleDateString()}</p>
                                        <p><strong>Discharge:</strong> {new Date(selectedClaim.dischargeDate).toLocaleDateString()}</p>
                                        <p><strong>Submitted:</strong> {new Date(selectedClaim.submissionDate).toLocaleDateString()}</p>
                                        {selectedClaim.approvalDate && (
                                          <p><strong>Approved:</strong> {new Date(selectedClaim.approvalDate).toLocaleDateString()}</p>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </TabsContent>
                                <TabsContent value="documents">
                                  <div className="text-center py-8">
                                    <FileText className="mx-auto h-12 w-12 text-gray-400" />
                                    <p className="mt-2 text-gray-500">Document management coming soon</p>
                                  </div>
                                </TabsContent>
                                <TabsContent value="history">
                                  <div className="text-center py-8">
                                    <Clock className="mx-auto h-12 w-12 text-gray-400" />
                                    <p className="mt-2 text-gray-500">Processing history coming soon</p>
                                  </div>
                                </TabsContent>
                              </Tabs>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Link href={`/insurance/claims/edit/${claim.id}`}>
                          <Button variant="outline" size="sm" className="border-gray-200 hover:bg-gray-50">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

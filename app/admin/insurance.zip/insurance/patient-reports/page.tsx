"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Download, Eye, FileText, User, Calendar, TestTube, Stethoscope, Receipt, Filter } from "lucide-react"

interface PatientReport {
  id: string
  patientId: string
  patientName: string
  reportType: "lab" | "radiology" | "prescription" | "discharge" | "consultation"
  reportTitle: string
  date: string
  doctor: string
  department: string
  status: "completed" | "pending" | "in-progress"
  fileUrl: string
  fileSize: string
  insuranceProvider?: string
  claimNumber?: string
}

const mockReports: PatientReport[] = [
  {
    id: "1",
    patientId: "P001234",
    patientName: "John Smith",
    reportType: "lab",
    reportTitle: "Complete Blood Count",
    date: "2024-01-20",
    doctor: "Dr. Rajesh Kumar",
    department: "Pathology",
    status: "completed",
    fileUrl: "/reports/cbc_001234.pdf",
    fileSize: "2.3 MB",
    insuranceProvider: "Star Health",
    claimNumber: "SH2024001234",
  },
  {
    id: "2",
    patientId: "P001235",
    patientName: "Mary Johnson",
    reportType: "radiology",
    reportTitle: "Chest X-Ray",
    date: "2024-01-19",
    doctor: "Dr. Priya Sharma",
    department: "Radiology",
    status: "completed",
    fileUrl: "/reports/xray_001235.pdf",
    fileSize: "5.1 MB",
    insuranceProvider: "HDFC ERGO",
    claimNumber: "HE2024001235",
  },
  {
    id: "3",
    patientId: "P001236",
    patientName: "Robert Davis",
    reportType: "prescription",
    reportTitle: "Cardiology Prescription",
    date: "2024-01-18",
    doctor: "Dr. Michael Chen",
    department: "Cardiology",
    status: "completed",
    fileUrl: "/reports/prescription_001236.pdf",
    fileSize: "1.2 MB",
    insuranceProvider: "ICICI Lombard",
    claimNumber: "IL2024001236",
  },
  {
    id: "4",
    patientId: "P001237",
    patientName: "Sarah Wilson",
    reportType: "discharge",
    reportTitle: "Discharge Summary",
    date: "2024-01-17",
    doctor: "Dr. Amit Singh",
    department: "General Medicine",
    status: "completed",
    fileUrl: "/reports/discharge_001237.pdf",
    fileSize: "3.8 MB",
    insuranceProvider: "New India Assurance",
    claimNumber: "NIA2024001237",
  },
  {
    id: "5",
    patientId: "P001238",
    patientName: "David Brown",
    reportType: "consultation",
    reportTitle: "Orthopedic Consultation",
    date: "2024-01-16",
    doctor: "Dr. Sunita Gupta",
    department: "Orthopedics",
    status: "completed",
    fileUrl: "/reports/consultation_001238.pdf",
    fileSize: "2.7 MB",
    insuranceProvider: "Oriental Insurance",
    claimNumber: "OI2024001238",
  },
]

export default function PatientReports() {
  const [reports, setReports] = useState<PatientReport[]>(mockReports)
  const [searchTerm, setSearchTerm] = useState("")
  const [reportTypeFilter, setReportTypeFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("all")

  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      report.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.reportTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.doctor.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesType = reportTypeFilter === "all" || report.reportType === reportTypeFilter
    const matchesStatus = statusFilter === "all" || report.status === statusFilter

    return matchesSearch && matchesType && matchesStatus
  })

  const getReportTypeIcon = (type: string) => {
    switch (type) {
      case "lab":
        return <TestTube className="h-4 w-4" />
      case "radiology":
        return <FileText className="h-4 w-4" />
      case "prescription":
        return <Receipt className="h-4 w-4" />
      case "discharge":
        return <FileText className="h-4 w-4" />
      case "consultation":
        return <Stethoscope className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const getReportTypeColor = (type: string) => {
    switch (type) {
      case "lab":
        return "bg-blue-100 text-blue-800"
      case "radiology":
        return "bg-purple-100 text-purple-800"
      case "prescription":
        return "bg-green-100 text-green-800"
      case "discharge":
        return "bg-orange-100 text-orange-800"
      case "consultation":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleViewReport = (report: PatientReport) => {
    // Simulate opening report in new tab
    alert(`Opening ${report.reportTitle} for ${report.patientName}`)
  }

  const handleDownloadReport = (report: PatientReport) => {
    // Simulate download
    alert(`Downloading ${report.reportTitle} (${report.fileSize})`)
  }

  const handleBulkDownload = () => {
    const selectedReports = filteredReports.filter((report) => report.status === "completed")
    alert(`Downloading ${selectedReports.length} reports as ZIP file`)
  }

  const stats = {
    total: filteredReports.length,
    lab: filteredReports.filter((r) => r.reportType === "lab").length,
    radiology: filteredReports.filter((r) => r.reportType === "radiology").length,
    prescription: filteredReports.filter((r) => r.reportType === "prescription").length,
    discharge: filteredReports.filter((r) => r.reportType === "discharge").length,
    consultation: filteredReports.filter((r) => r.reportType === "consultation").length,
  }

  return (
    <PrivateRoute modulePath="admin/insurance/patient-reports" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Patient Reports</h1>
          <p className="text-gray-600">View and download patient reports for insurance claims</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleBulkDownload} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Bulk Download
          </Button>
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Advanced Filter
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Reports</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <FileText className="h-8 w-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Lab Reports</p>
                <p className="text-2xl font-bold text-blue-600">{stats.lab}</p>
              </div>
              <TestTube className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Radiology</p>
                <p className="text-2xl font-bold text-purple-600">{stats.radiology}</p>
              </div>
              <FileText className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Prescriptions</p>
                <p className="text-2xl font-bold text-green-600">{stats.prescription}</p>
              </div>
              <Receipt className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Discharge</p>
                <p className="text-2xl font-bold text-orange-600">{stats.discharge}</p>
              </div>
              <FileText className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Consultation</p>
                <p className="text-2xl font-bold text-gray-600">{stats.consultation}</p>
              </div>
              <Stethoscope className="h-8 w-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search reports..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={reportTypeFilter} onValueChange={setReportTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="lab">Lab Reports</SelectItem>
                <SelectItem value="radiology">Radiology</SelectItem>
                <SelectItem value="prescription">Prescriptions</SelectItem>
                <SelectItem value="discharge">Discharge</SelectItem>
                <SelectItem value="consultation">Consultation</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
              </SelectContent>
            </Select>

            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by date" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Dates</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Reports Table */}
      <Card>
        <CardHeader>
          <CardTitle>Patient Reports ({filteredReports.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient & Report</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Doctor & Department</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Insurance Info</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredReports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium">{report.patientName}</div>
                          <div className="text-sm text-gray-500">{report.patientId}</div>
                          <div className="text-sm font-medium text-gray-700">{report.reportTitle}</div>
                          <div className="text-xs text-gray-500">{report.fileSize}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getReportTypeColor(report.reportType)}>
                        {getReportTypeIcon(report.reportType)}
                        <span className="ml-1 capitalize">{report.reportType}</span>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{report.doctor}</div>
                        <div className="text-sm text-gray-500">{report.department}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                        <span>{report.date}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {report.insuranceProvider && (
                        <div>
                          <div className="font-medium text-sm">{report.insuranceProvider}</div>
                          <div className="text-xs text-gray-500">{report.claimNumber}</div>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(report.status)}>{report.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" onClick={() => handleViewReport(report)}>
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownloadReport(report)}
                          disabled={report.status !== "completed"}
                        >
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {filteredReports.length === 0 && (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-500">No reports found matching your criteria</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

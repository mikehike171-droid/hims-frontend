"use client"

import { useState, useEffect, useCallback } from "react"
import { labMastersApi, Unit, Investigation, Test, TestGroup } from "@/lib/labMastersApi"
import authService from "@/lib/authService"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, Edit, Trash2, TestTube, Beaker, FlaskConical, Users } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function MastersPage() {
  const [activeTab, setActiveTab] = useState("units")
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(false)
  const [selectedBranchId, setSelectedBranchId] = useState(authService.getSelectedBranchId())
  
  // Data states
  const [units, setUnits] = useState<Unit[]>([])
  const [investigations, setInvestigations] = useState<Investigation[]>([])
  const [tests, setTests] = useState<Test[]>([])
  const [testGroups, setTestGroups] = useState<TestGroup[]>([])
  
  // Dialog states
  const [isUnitDialogOpen, setIsUnitDialogOpen] = useState(false)
  const [isInvestigationDialogOpen, setIsInvestigationDialogOpen] = useState(false)
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null)
  const [selectedInvestigation, setSelectedInvestigation] = useState<Investigation | null>(null)
  const [isNewUnit, setIsNewUnit] = useState(false)
  const [isNewInvestigation, setIsNewInvestigation] = useState(false)

  // Fetch functions
  const fetchUnits = useCallback(async () => {
    try {
      setLoading(true)
      const selectedBranchId = authService.getSelectedBranchId()
      const locationId = selectedBranchId ? parseInt(selectedBranchId) : undefined
      console.log('Fetching units for locationId:', locationId)
      const data = await labMastersApi.getUnits(locationId)
      console.log('Received units data:', data)
      setUnits(data)
    } catch (error) {
      console.error('Error fetching units:', error)
      toast({
        title: "Error",
        description: "Failed to fetch units",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }, [])

  const fetchInvestigations = useCallback(async () => {
    try {
      setLoading(true)
      const selectedBranchId = authService.getSelectedBranchId()
      const locationId = selectedBranchId ? parseInt(selectedBranchId) : undefined
      console.log('Fetching investigations for locationId:', locationId)
      const data = await labMastersApi.getInvestigations(locationId)
      console.log('Received investigations data:', data)
      setInvestigations(data)
    } catch (error) {
      console.error('Error fetching investigations:', error)
      toast({
        title: "Error",
        description: "Failed to fetch investigations",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUnits()
    fetchInvestigations()
  }, [fetchUnits, fetchInvestigations])

  useEffect(() => {
    const handleStorageChange = () => {
      const currentBranchId = authService.getSelectedBranchId()
      if (currentBranchId !== selectedBranchId) {
        setSelectedBranchId(currentBranchId)
        fetchUnits()
      }
    }

    window.addEventListener('storage', handleStorageChange)
    
    const interval = setInterval(() => {
      const currentBranchId = authService.getSelectedBranchId()
      if (currentBranchId !== selectedBranchId) {
        setSelectedBranchId(currentBranchId)
        fetchUnits()
        fetchInvestigations()
      }
    }, 500)

    return () => {
      window.removeEventListener('storage', handleStorageChange)
      clearInterval(interval)
    }
  }, [selectedBranchId, fetchUnits, fetchInvestigations])

  // CRUD handlers
  const handleUnitSave = async () => {
    try {
      setLoading(true)
      if (isNewUnit) {
        await labMastersApi.createUnit(selectedUnit!)
      } else {
        await labMastersApi.updateUnit(selectedUnit!.id, selectedUnit!)
      }
      toast({
        title: isNewUnit ? "Unit Created" : "Unit Updated",
        description: `Unit has been ${isNewUnit ? "created" : "updated"} successfully.`,
      })
      setIsUnitDialogOpen(false)
      setSelectedUnit(null)
      fetchUnits()
    } catch (error) {
      console.error('Error saving unit:', error)
      toast({
        title: "Error",
        description: `Failed to ${isNewUnit ? "create" : "update"} unit`,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleUnitDelete = async (id: number) => {
    try {
      setLoading(true)
      await labMastersApi.deleteUnit(id)
      toast({
        title: "Unit Deleted",
        description: "Unit has been deleted successfully.",
        variant: "destructive",
      })
      fetchUnits()
    } catch (error) {
      console.error('Error deleting unit:', error)
      toast({
        title: "Error",
        description: "Failed to delete unit",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleInvestigationSave = async () => {
    try {
      setLoading(true)
      if (isNewInvestigation) {
        await labMastersApi.createInvestigation(selectedInvestigation!)
      } else {
        await labMastersApi.updateInvestigation(selectedInvestigation!.id, selectedInvestigation!)
      }
      toast({
        title: isNewInvestigation ? "Investigation Created" : "Investigation Updated",
        description: `Investigation has been ${isNewInvestigation ? "created" : "updated"} successfully.`,
      })
      setIsInvestigationDialogOpen(false)
      setSelectedInvestigation(null)
      fetchInvestigations()
    } catch (error) {
      console.error('Error saving investigation:', error)
      toast({
        title: "Error",
        description: `Failed to ${isNewInvestigation ? "create" : "update"} investigation`,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleInvestigationDelete = async (id: number) => {
    try {
      setLoading(true)
      await labMastersApi.deleteInvestigation(id)
      toast({
        title: "Investigation Deleted",
        description: "Investigation has been deleted successfully.",
        variant: "destructive",
      })
      fetchInvestigations()
    } catch (error) {
      console.error('Error deleting investigation:', error)
      toast({
        title: "Error",
        description: "Failed to delete investigation",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredUnits = units.filter(
    (unit) => unit.description.toLowerCase().includes(searchTerm.toLowerCase()) || unit.code.includes(searchTerm)
  )

  return (
    <PrivateRoute modulePath="admin/laboratory" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Laboratory Masters</h1>
            <p className="text-gray-600">Manage laboratory units, investigations, tests, and test groups</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="units" className="flex items-center space-x-2">
              <TestTube className="h-4 w-4" />
              <span>Units</span>
            </TabsTrigger>
            <TabsTrigger value="investigations" className="flex items-center space-x-2">
              <Beaker className="h-4 w-4" />
              <span>Investigations</span>
            </TabsTrigger>
            <TabsTrigger value="tests" className="flex items-center space-x-2">
              <FlaskConical className="h-4 w-4" />
              <span>Tests</span>
            </TabsTrigger>
            <TabsTrigger value="groups" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>Test Groups</span>
            </TabsTrigger>
          </TabsList>

          {/* Units Tab */}
          <TabsContent value="units" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <TestTube className="h-5 w-5" />
                    <span>Units Management</span>
                  </CardTitle>
                  <Button
                    onClick={() => {
                      const selectedBranchId = authService.getSelectedBranchId()
                      setSelectedUnit({
                        id: 0,
                        code: "",
                        description: "",
                        status: "A",
                        locationId: selectedBranchId ? parseInt(selectedBranchId) : undefined,
                        isActive: true,
                        createdAt: "",
                        updatedAt: ""
                      })
                      setIsNewUnit(true)
                      setIsUnitDialogOpen(true)
                    }}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Unit
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* Search */}
                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search units by code or description..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Units Table */}
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center">
                            Loading units...
                          </TableCell>
                        </TableRow>
                      ) : filteredUnits.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-gray-500">
                            No units found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredUnits.map((unit) => (
                          <TableRow key={unit.id}>
                            <TableCell className="font-medium">{unit.code}</TableCell>
                            <TableCell>{unit.description}</TableCell>
                            <TableCell>
                              <Badge variant={unit.isActive ? "default" : "secondary"}>
                                {unit.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedUnit(unit)
                                    setIsNewUnit(false)
                                    setIsUnitDialogOpen(true)
                                  }}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="ghost" size="sm" className="text-red-600">
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Delete Unit</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Are you sure you want to delete this unit? This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => handleUnitDelete(unit.id)}
                                        className="bg-red-600 hover:bg-red-700"
                                      >
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Investigations Tab */}
          <TabsContent value="investigations" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Beaker className="h-5 w-5" />
                    <span>Investigation Management</span>
                  </CardTitle>
                  <Button
                    onClick={() => {
                      const selectedBranchId = authService.getSelectedBranchId()
                      setSelectedInvestigation({
                        id: 0,
                        code: "",
                        description: "",
                        method: "",
                        unitId: undefined,
                        resultType: "",
                        defaultValue: "",
                        locationId: selectedBranchId ? parseInt(selectedBranchId) : undefined,
                        status: "1",
                        isActive: true,
                        createdAt: "",
                        updatedAt: ""
                      })
                      setIsNewInvestigation(true)
                      setIsInvestigationDialogOpen(true)
                    }}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Investigation
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search investigations by code or description..."
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Investigation Code</TableHead>
                        <TableHead>Investigation Description</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead>Result Type</TableHead>
                        <TableHead>Default Value</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center">
                            Loading investigations...
                          </TableCell>
                        </TableRow>
                      ) : investigations.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-gray-500">
                            No investigations found
                          </TableCell>
                        </TableRow>
                      ) : (
                        investigations.filter(inv => 
                          inv.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          inv.description.toLowerCase().includes(searchTerm.toLowerCase())
                        ).map((investigation) => (
                          <TableRow key={investigation.id}>
                            <TableCell className="font-medium">{investigation.code}</TableCell>
                            <TableCell>{investigation.description}</TableCell>
                            <TableCell>{investigation.method || '-'}</TableCell>
                            <TableCell>{investigation.unitDescription || '-'}</TableCell>
                            <TableCell>{investigation.resultType || '-'}</TableCell>
                            <TableCell>{investigation.defaultValue || '-'}</TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedInvestigation(investigation)
                                    setIsNewInvestigation(false)
                                    setIsInvestigationDialogOpen(true)
                                  }}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="ghost" size="sm" className="text-red-600">
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Delete Investigation</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Are you sure you want to delete this investigation? This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => handleInvestigationDelete(investigation.id)}
                                        className="bg-red-600 hover:bg-red-700"
                                      >
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tests Tab */}
          <TabsContent value="tests" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <FlaskConical className="h-5 w-5" />
                    <span>Test Management</span>
                  </CardTitle>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Test
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search tests by name or code..."
                      className="pl-10"
                    />
                  </div>
                  <select className="border rounded px-3 py-2">
                    <option value="all">All Categories</option>
                    <option value="Hematology">Hematology</option>
                    <option value="Biochemistry">Biochemistry</option>
                    <option value="Microbiology">Microbiology</option>
                  </select>
                </div>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Sample Type</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead>Units</TableHead>
                        <TableHead>Cost</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell colSpan={9} className="text-center text-gray-500">
                          No tests found
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Test Groups Tab */}
          <TabsContent value="groups" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>Test Group Management</span>
                  </CardTitle>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Test Group
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search test groups by name or code..."
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Tests Count</TableHead>
                        <TableHead>Cost</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-gray-500">
                          No test groups found
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Unit Dialog */}
        <Dialog open={isUnitDialogOpen} onOpenChange={setIsUnitDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{isNewUnit ? "Add New Unit" : "Edit Unit"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="unitCode">Code</Label>
                <Input
                  id="unitCode"
                  value={selectedUnit?.code || ""}
                  onChange={(e) => setSelectedUnit(prev => ({ ...prev!, code: e.target.value }))}
                  placeholder="Enter unit code"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unitDescription">Description</Label>
                <Input
                  id="unitDescription"
                  value={selectedUnit?.description || ""}
                  onChange={(e) => setSelectedUnit(prev => ({ ...prev!, description: e.target.value }))}
                  placeholder="Enter unit description"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="unitActive">Active Status</Label>
                <Switch
                  id="unitActive"
                  checked={selectedUnit?.isActive || false}
                  onCheckedChange={(checked) => setSelectedUnit(prev => ({ ...prev!, isActive: checked }))}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsUnitDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUnitSave} disabled={loading}>
                  {loading ? "Saving..." : (isNewUnit ? "Create Unit" : "Update Unit")}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Investigation Dialog */}
        <Dialog open={isInvestigationDialogOpen} onOpenChange={setIsInvestigationDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{isNewInvestigation ? "Add New Investigation" : "Edit Investigation"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="invCode">Code</Label>
                  <Input
                    id="invCode"
                    value={selectedInvestigation?.code || ""}
                    onChange={(e) => setSelectedInvestigation(prev => ({ ...prev!, code: e.target.value }))}
                    placeholder="Enter investigation code"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="invDescription">Description</Label>
                  <Input
                    id="invDescription"
                    value={selectedInvestigation?.description || ""}
                    onChange={(e) => setSelectedInvestigation(prev => ({ ...prev!, description: e.target.value }))}
                    placeholder="Enter investigation description"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="invMethod">Method</Label>
                  <Input
                    id="invMethod"
                    value={selectedInvestigation?.method || ""}
                    onChange={(e) => setSelectedInvestigation(prev => ({ ...prev!, method: e.target.value }))}
                    placeholder="Enter method"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Unit</Label>
                  <Select
                    value={selectedInvestigation?.unitId?.toString()}
                    onValueChange={(value) => setSelectedInvestigation(prev => ({ ...prev!, unitId: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit.id} value={unit.id.toString()}>
                          {unit.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Result Type</Label>
                <Select
                  value={selectedInvestigation?.resultType}
                  onValueChange={(value) => setSelectedInvestigation(prev => ({ ...prev!, resultType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select result type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="One Line Text">One Line Text</SelectItem>
                    <SelectItem value="Normal Value">Normal Value</SelectItem>
                    <SelectItem value="Numeric">Numeric</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="invDefaultValue">Default Value</Label>
                <Input
                  id="invDefaultValue"
                  value={selectedInvestigation?.defaultValue || ""}
                  onChange={(e) => setSelectedInvestigation(prev => ({ ...prev!, defaultValue: e.target.value }))}
                  placeholder="Enter default value"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="invActive">Active Status</Label>
                <Switch
                  id="invActive"
                  checked={selectedInvestigation?.isActive || false}
                  onCheckedChange={(checked) => setSelectedInvestigation(prev => ({ ...prev!, isActive: checked }))}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsInvestigationDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleInvestigationSave} disabled={loading}>
                  {loading ? "Saving..." : (isNewInvestigation ? "Create Investigation" : "Update Investigation")}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </PrivateRoute>
  )
}

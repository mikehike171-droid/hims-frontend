import { Skeleton } from "@/components/ui/skeleton"

export default function SampleAcceptanceLoading() {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-10 w-64" />
      </div>

      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="border border-gray-300 rounded-lg overflow-hidden">
            <div className="bg-green-500 px-4 py-3">
              <Skeleton className="h-6 w-full bg-white bg-opacity-20" />
              <Skeleton className="h-4 w-3/4 mt-2 bg-white bg-opacity-20" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

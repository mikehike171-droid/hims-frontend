"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface TestResult {
  testCode: string
  testDescription: string
  investigationCode: string
  investigation: string
  value: string
  unit: string
  lowerLimit: string
  upperLimit: string
  defaultValue: string
  valueType: string
}

const mockPatientData = {
  mrNumber: "MR2500028234",
  ipNumber: "PHS-IP2500005202",
  name: "THATAPUDI PRUDHVI RAJ",
  patientCategory: "INSURANCE",
  bedCategory: "SHARING",
  tariffCategory: "Hospital",
  refCustomer: "",
  age: "32 Y:0 M:0 Da",
  sex: "M",
  nursingStationFloor: "3A NURSING STATION",
  wardNo: "3A WARD",
  bedNo: "A303",
  orderedBy: "VISHNUCHAND ZAMPANI",
  reportedTo: "VISHNUCHAND ZAMPANI",
  number: "",
  date: "",
  labCode: "",
  labDept: "BIOCHEMISTRY",
  sampleNumber: "PHS-LB25-031323",
  sampleDate: "22/09/2025 12:54:09",
  acceptanceNumber: "PHS-SA25-028569",
}

const mockTestResults: TestResult[] = [
  {
    testCode: "SR0019",
    testDescription: "WIDAL",
    investigationCode: "SER021",
    investigation: 'S.PARATYPHI " BH "',
    value: "1:80",
    unit: "",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "1:20 Dilution",
    valueType: "FV",
  },
  {
    testCode: "SR0027",
    testDescription: "SERUM CREATININE",
    investigationCode: "BIO018",
    investigation: "SERUM CREATININE",
    value: "",
    unit: "mg/dl",
    lowerLimit: "0.60",
    upperLimit: "1.25",
    defaultValue: "",
    valueType: "NV",
  },
  {
    testCode: "SR0067",
    testDescription: "SERUM ELECTROLYTES",
    investigationCode: "BIO019",
    investigation: "SERUM SODIUM",
    value: "",
    unit: "mmol/l",
    lowerLimit: "135.00",
    upperLimit: "146.00",
    defaultValue: "",
    valueType: "NV",
  },
  {
    testCode: "SR0067",
    testDescription: "SERUM ELECTROLYTES",
    investigationCode: "BIO038",
    investigation: "SERUM POTASSIUM",
    value: "",
    unit: "mmol/l",
    lowerLimit: "3.50",
    upperLimit: "5.50",
    defaultValue: "",
    valueType: "NV",
  },
  {
    testCode: "SR0067",
    testDescription: "SERUM ELECTROLYTES",
    investigationCode: "BIO040",
    investigation: "SERUM CHLORIDE",
    value: "",
    unit: "mmol/l",
    lowerLimit: "98.00",
    upperLimit: "107.00",
    defaultValue: "",
    valueType: "NV",
  },
  {
    testCode: "SR0030",
    testDescription: "COMPLETE URINE EXAMINATION",
    investigationCode: "CLI024",
    investigation: "PHYSICAL EXAMINATION",
    value: "",
    unit: "",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "",
    valueType: "HD",
  },
  {
    testCode: "SR0030",
    testDescription: "COMPLETE URINE EXAMINATION",
    investigationCode: "CLI025",
    investigation: "QUANTITY",
    value: "",
    unit: "ml",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "",
    valueType: "FV",
  },
  {
    testCode: "SR0030",
    testDescription: "COMPLETE URINE EXAMINATION",
    investigationCode: "CLI002",
    investigation: "COLOUR",
    value: "",
    unit: "",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "P.YELLOW",
    valueType: "OL",
  },
  {
    testCode: "SR0030",
    testDescription: "COMPLETE URINE EXAMINATION",
    investigationCode: "CLI027",
    investigation: "APPEARANCE",
    value: "",
    unit: "",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "CLEAR",
    valueType: "OL",
  },
  {
    testCode: "SR0030",
    testDescription: "COMPLETE URINE EXAMINATION",
    investigationCode: "CLI028",
    investigation: "REACTION",
    value: "",
    unit: "",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "ACIDIC",
    valueType: "OL",
  },
  {
    testCode: "SR0030",
    testDescription: "COMPLETE URINE EXAMINATION",
    investigationCode: "CLI029",
    investigation: "SPECIFIC GRAVITY",
    value: "",
    unit: "",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "1.005-1.020",
    valueType: "OL",
  },
]

export default function ReportEntryPage() {
  const searchParams = useSearchParams()

  const [patientData, setPatientData] = useState(mockPatientData)
  const [testResults, setTestResults] = useState<TestResult[]>(mockTestResults)
  const [note, setNote] = useState("")

  useEffect(() => {
    const mrNumber = searchParams.get("mrNumber")
    const ipNumber = searchParams.get("ipNumber")
    const name = searchParams.get("name")
    const sampleNumber = searchParams.get("sampleNumber")

    if (mrNumber || ipNumber || name || sampleNumber) {
      setPatientData((prev) => ({
        ...prev,
        ...(mrNumber && { mrNumber }),
        ...(ipNumber && { ipNumber }),
        ...(name && { name }),
        ...(sampleNumber && { sampleNumber }),
      }))
    }
  }, [searchParams])

  const handlePatientDataChange = (field: string, value: string) => {
    setPatientData((prev) => ({ ...prev, [field]: value }))
  }

  const handleValueChange = (index: number, value: string) => {
    setTestResults((prev) => prev.map((result, i) => (i === index ? { ...result, value } : result)))
  }

  const handleSave = () => {
    alert("Test results saved successfully!")
  }

  const handleClear = () => {
    setTestResults((prev) => prev.map((result) => ({ ...result, value: "" })))
    setNote("")
  }

  return (
    <div className="container mx-auto p-4 md:p-6 space-y-4 min-h-screen">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Report Regular</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* PATIENT DETAILS Section */}
        <fieldset className="border border-gray-300 rounded-lg lg:col-span-2">
          <legend className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium ml-4">PATIENT DETAILS</legend>
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">MR Number</Label>
                <Input
                  value={patientData.mrNumber}
                  onChange={(e) => handlePatientDataChange("mrNumber", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">IP Number</Label>
                <Input
                  value={patientData.ipNumber}
                  onChange={(e) => handlePatientDataChange("ipNumber", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Name</Label>
                <Input
                  value={patientData.name}
                  onChange={(e) => handlePatientDataChange("name", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Patient Category</Label>
                <Select
                  value={patientData.patientCategory}
                  onValueChange={(value) => handlePatientDataChange("patientCategory", value)}
                >
                  <SelectTrigger className="flex-1 h-8 text-sm bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INSURANCE">INSURANCE</SelectItem>
                    <SelectItem value="CASH">CASH</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Bed Category</Label>
                <Select
                  value={patientData.bedCategory}
                  onValueChange={(value) => handlePatientDataChange("bedCategory", value)}
                >
                  <SelectTrigger className="flex-1 h-8 text-sm bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SHARING">SHARING</SelectItem>
                    <SelectItem value="PRIVATE">PRIVATE</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Tariff Category</Label>
                <Select
                  value={patientData.tariffCategory}
                  onValueChange={(value) => handlePatientDataChange("tariffCategory", value)}
                >
                  <SelectTrigger className="flex-1 h-8 text-sm bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Hospital">Hospital</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Attachments</Label>
                <Input type="file" className="flex-1 h-8 text-sm bg-white" />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Ref Customer</Label>
                <Input
                  value={patientData.refCustomer}
                  onChange={(e) => handlePatientDataChange("refCustomer", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Age</Label>
                <Input
                  value={patientData.age}
                  onChange={(e) => handlePatientDataChange("age", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Sex</Label>
                <Input
                  value={patientData.sex}
                  onChange={(e) => handlePatientDataChange("sex", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Nursing Station/Floor</Label>
                <Select
                  value={patientData.nursingStationFloor}
                  onValueChange={(value) => handlePatientDataChange("nursingStationFloor", value)}
                >
                  <SelectTrigger className="flex-1 h-8 text-sm bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3A NURSING STATION">3A NURSING STATION</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Ward No</Label>
                <Input
                  value={patientData.wardNo}
                  onChange={(e) => handlePatientDataChange("wardNo", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Bed No</Label>
                <Input
                  value={patientData.bedNo}
                  onChange={(e) => handlePatientDataChange("bedNo", e.target.value)}
                  className="flex-1 h-8 text-sm bg-white"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Ordered By</Label>
                <Select
                  value={patientData.orderedBy}
                  onValueChange={(value) => handlePatientDataChange("orderedBy", value)}
                >
                  <SelectTrigger className="flex-1 h-8 text-sm bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="VISHNUCHAND ZAMPANI">VISHNUCHAND ZAMPANI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Label className="text-sm font-medium w-40">Reported To</Label>
                <Select
                  value={patientData.reportedTo}
                  onValueChange={(value) => handlePatientDataChange("reportedTo", value)}
                >
                  <SelectTrigger className="flex-1 h-8 text-sm bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="VISHNUCHAND ZAMPANI">VISHNUCHAND ZAMPANI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </fieldset>

        {/* RESULT Section */}
        <fieldset className="border border-gray-300 rounded-lg">
          <legend className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium ml-4">RESULT</legend>
          <div className="p-4 space-y-2">
            <div className="flex items-center space-x-2">
              <Label className="text-sm font-medium w-32">Number</Label>
              <Input
                value={patientData.number}
                onChange={(e) => handlePatientDataChange("number", e.target.value)}
                className="flex-1 h-8 text-sm bg-white"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Label className="text-sm font-medium w-32">Date</Label>
              <Input
                value={patientData.date}
                onChange={(e) => handlePatientDataChange("date", e.target.value)}
                className="flex-1 h-8 text-sm bg-white"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Label className="text-sm font-medium w-32">Lab Code</Label>
              <Input
                value={patientData.labCode}
                onChange={(e) => handlePatientDataChange("labCode", e.target.value)}
                className="flex-1 h-8 text-sm bg-white"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Label className="text-sm font-medium w-32">Lab Dept</Label>
              <Select value={patientData.labDept} onValueChange={(value) => handlePatientDataChange("labDept", value)}>
                <SelectTrigger className="flex-1 h-8 text-sm bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BIOCHEMISTRY">BIOCHEMISTRY</SelectItem>
                  <SelectItem value="HEMATOLOGY">HEMATOLOGY</SelectItem>
                  <SelectItem value="MICROBIOLOGY">MICROBIOLOGY</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Label className="text-sm font-medium w-32">Sample Number</Label>
              <Input
                value={patientData.sampleNumber}
                onChange={(e) => handlePatientDataChange("sampleNumber", e.target.value)}
                className="flex-1 h-8 text-sm bg-white"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Label className="text-sm font-medium w-32">Sample Date</Label>
              <Input
                value={patientData.sampleDate}
                onChange={(e) => handlePatientDataChange("sampleDate", e.target.value)}
                className="flex-1 h-8 text-sm bg-white"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Label className="text-sm font-medium w-32">Acceptance Number</Label>
              <Input
                value={patientData.acceptanceNumber}
                onChange={(e) => handlePatientDataChange("acceptanceNumber", e.target.value)}
                className="flex-1 h-8 text-sm bg-white"
              />
            </div>
          </div>
        </fieldset>
      </div>

      <div className="overflow-x-auto border border-gray-300 rounded-lg">
        <table className="w-full border-collapse text-black">
          <thead>
            <tr className="bg-gray-100 text-black">
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">TEST CODE</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">TEST DESCRIPTION</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">INVESTIGATION CODE</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">INVESTIGATION</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">VALUE</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">UNIT</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">LOWER LIMIT</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">UPPER LIMIT</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">DEFAULT VALUE</th>
              <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">VALUE TYPE</th>
            </tr>
          </thead>
          <tbody>
            {testResults.map((result, index) => (
              <tr key={index} className="hover:bg-gray-200">
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.testCode}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.testDescription}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.investigationCode}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.investigation}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">
                  {result.valueType === "FV" ? (
                    <Select value={result.value} onValueChange={(value) => handleValueChange(index, value)}>
                      <SelectTrigger className="h-8 text-sm bg-white">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1:20">1:20</SelectItem>
                        <SelectItem value="1:40">1:40</SelectItem>
                        <SelectItem value="1:80">1:80</SelectItem>
                        <SelectItem value="1:160">1:160</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      value={result.value}
                      onChange={(e) => handleValueChange(index, e.target.value)}
                      className="h-8 text-sm bg-white"
                      placeholder="Enter value"
                    />
                  )}
                </td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.unit}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.lowerLimit}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.upperLimit}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.defaultValue}</td>
                <td className="border border-gray-300 px-3 py-2 text-sm">{result.valueType}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium">Note</Label>
        <Textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Enter any notes here..."
          className="min-h-[100px] bg-white"
        />
      </div>

      <div className="flex justify-center space-x-2 pb-4">
        <Button onClick={handleSave} className="bg-black">
          Save
        </Button>
        <Button onClick={handleClear} variant="outline">
          Clear
        </Button>
        <Button variant="outline">print</Button>
        <Button variant="outline">Combaine Print</Button>
        <Button variant="outline">Print With Header</Button>
        <Button variant="outline">Print With Header1</Button>
        <Button variant="outline">Close</Button>
      </div>
    </div>
  )
}

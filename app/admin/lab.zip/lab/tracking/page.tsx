"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, TestTube, Clock, CheckCircle, AlertCircle, Truck, RefreshCw, MapPin, User, Calendar } from 'lucide-react'
import { useToast } from "@/hooks/use-toast"

interface TimelineStep {
  status: string
  time: string
  date: string
  completed: boolean
  current?: boolean
  location?: string
  user?: string
}

interface TrackingSample {
  id: number
  sampleId: string
  orderNo: string
  patientName: string
  patientId: string
  tests: string[]
  currentStatus: string
  priority: string
  estimatedCompletion: string
  timeline: TimelineStep[]
}

const initialTrackingData: TrackingSample[] = [
  {
    id: 1,
    sampleId: "S001234",
    orderNo: "LAB001234",
    patientName: "John Doe",
    patientId: "P001234",
    tests: ["Hemoglobin", "Blood Sugar"],
    currentStatus: "Processing",
    priority: "Routine",
    estimatedCompletion: "01:30 PM",
    timeline: [
      { status: "Created", time: "09:30 AM", date: "Today", completed: true, location: "OPD", user: "Dr. Kumar" },
      { status: "Collected", time: "10:15 AM", date: "Today", completed: true, location: "Collection Room", user: "Nurse Priya" },
      { status: "In Transit", time: "10:30 AM", date: "Today", completed: true, location: "Lab Transport", user: "Tech Amit" },
      { status: "Received", time: "10:45 AM", date: "Today", completed: true, location: "Lab Reception", user: "Lab Assistant" },
      { status: "Processing", time: "11:00 AM", date: "Today", completed: true, current: true, location: "Hematology Lab", user: "Tech Rajesh" },
      { status: "Validated", time: "Expected: 01:00 PM", date: "Today", completed: false, location: "Lab", user: "Dr. Pathologist" },
      { status: "Released", time: "Expected: 01:30 PM", date: "Today", completed: false, location: "Reports", user: "System" },
    ]
  },
  {
    id: 2,
    sampleId: "S001235",
    orderNo: "LAB001235",
    patientName: "Jane Smith",
    patientId: "P001235",
    tests: ["CBC", "LFT"],
    currentStatus: "In Transit",
    priority: "Urgent",
    estimatedCompletion: "04:30 PM",
    timeline: [
      { status: "Created", time: "10:15 AM", date: "Today", completed: true, location: "IPD Ward 1", user: "Dr. Sharma" },
      { status: "Collected", time: "11:00 AM", date: "Today", completed: true, location: "Ward 1", user: "Nurse Sunita" },
      { status: "In Transit", time: "11:15 AM", date: "Today", completed: true, current: true, location: "Lab Transport", user: "Tech Amit" },
      { status: "Received", time: "Expected: 11:45 AM", date: "Today", completed: false, location: "Lab Reception", user: "Lab Assistant" },
      { status: "Processing", time: "Expected: 12:00 PM", date: "Today", completed: false, location: "Biochemistry Lab", user: "Tech Team" },
      { status: "Validated", time: "Expected: 04:00 PM", date: "Today", completed: false, location: "Lab", user: "Dr. Pathologist" },
      { status: "Released", time: "Expected: 04:30 PM", date: "Today", completed: false, location: "Reports", user: "System" },
    ]
  },
  {
    id: 3,
    sampleId: "S001236",
    orderNo: "LAB001236",
    patientName: "Mike Johnson",
    patientId: "P001236",
    tests: ["Urine Routine"],
    currentStatus: "Validated",
    priority: "STAT",
    estimatedCompletion: "12:00 PM",
    timeline: [
      { status: "Created", time: "08:45 AM", date: "Today", completed: true, location: "Emergency", user: "Dr. Singh" },
      { status: "Collected", time: "09:30 AM", date: "Today", completed: true, location: "Emergency", user: "Nurse Priya" },
      { status: "In Transit", time: "09:45 AM", date: "Today", completed: true, location: "Lab Transport", user: "Tech Amit" },
      { status: "Received", time: "10:00 AM", date: "Today", completed: true, location: "Lab Reception", user: "Lab Assistant" },
      { status: "Processing", time: "10:15 AM", date: "Today", completed: true, location: "Pathology Lab", user: "Tech Rajesh" },
      { status: "Validated", time: "11:45 AM", date: "Today", completed: true, current: true, location: "Lab", user: "Dr. Pathologist" },
      { status: "Released", time: "Expected: 12:00 PM", date: "Today", completed: false, location: "Reports", user: "System" },
    ]
  },
  {
    id: 4,
    sampleId: "S001237",
    orderNo: "LAB001237",
    patientName: "Sarah Wilson",
    patientId: "P001237",
    tests: ["Thyroid Profile", "Vitamin D"],
    currentStatus: "Collected",
    priority: "Routine",
    estimatedCompletion: "06:00 PM",
    timeline: [
      { status: "Created", time: "11:30 AM", date: "Today", completed: true, location: "OPD", user: "Dr. Patel" },
      { status: "Collected", time: "12:15 PM", date: "Today", completed: true, current: true, location: "Collection Room", user: "Nurse Sunita" },
      { status: "In Transit", time: "Expected: 12:30 PM", date: "Today", completed: false, location: "Lab Transport", user: "Tech Amit" },
      { status: "Received", time: "Expected: 12:45 PM", date: "Today", completed: false, location: "Lab Reception", user: "Lab Assistant" },
      { status: "Processing", time: "Expected: 01:00 PM", date: "Today", completed: false, location: "Immunology Lab", user: "Tech Team" },
      { status: "Validated", time: "Expected: 05:30 PM", date: "Today", completed: false, location: "Lab", user: "Dr. Pathologist" },
      { status: "Released", time: "Expected: 06:00 PM", date: "Today", completed: false, location: "Reports", user: "System" },
    ]
  }
]

const getStatusIcon = (status: string) => {
  switch (status) {
    case "Created": return <TestTube className="h-4 w-4" />
    case "Collected": return <CheckCircle className="h-4 w-4" />
    case "In Transit": return <Truck className="h-4 w-4" />
    case "Received": return <CheckCircle className="h-4 w-4" />
    case "Processing": return <Clock className="h-4 w-4" />
    case "Validated": return <CheckCircle className="h-4 w-4" />
    case "Released": return <CheckCircle className="h-4 w-4" />
    default: return <AlertCircle className="h-4 w-4" />
  }
}

const getStatusColor = (status: string, completed: boolean, current: boolean) => {
  if (current) return "text-blue-600 bg-blue-50 border-blue-200"
  if (completed) return "text-green-600 bg-green-50 border-green-200"
  return "text-gray-400 bg-gray-50 border-gray-200"
}

const getBadgeVariant = (status: string) => {
  switch (status) {
    case "Processing": return "secondary"
    case "Validated": return "outline"
    case "Released": return "default"
    case "In Transit": return "secondary"
    case "Collected": return "outline"
    default: return "secondary"
  }
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "STAT": return "destructive"
    case "Urgent": return "secondary"
    default: return "outline"
  }
}

export default function SampleTrackingWorkflow() {
  const [trackingData, setTrackingData] = useState<TrackingSample[]>(initialTrackingData)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [selectedTab, setSelectedTab] = useState("all")
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const { toast } = useToast()

  const filteredData = trackingData.filter(sample => {
    const matchesSearch = sample.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.sampleId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.orderNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.patientId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || sample.currentStatus === statusFilter
    const matchesPriority = priorityFilter === "all" || sample.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  const getTabData = (tab: string) => {
    switch (tab) {
      case "collection": return filteredData.filter(s => s.currentStatus === "Collected" || s.currentStatus === "Created")
      case "transit": return filteredData.filter(s => s.currentStatus === "In Transit")
      case "processing": return filteredData.filter(s => s.currentStatus === "Processing" || s.currentStatus === "Received")
      case "validation": return filteredData.filter(s => s.currentStatus === "Validated")
      default: return filteredData
    }
  }

  const handleRefresh = async () => {
    toast({
      title: "Refreshing",
      description: "Updating sample tracking status...",
    })
    
    // Simulate refresh with some status updates
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setLastRefresh(new Date())
    
    toast({
      title: "Refreshed",
      description: "Sample tracking status updated successfully",
    })
  }

  const handleStatusUpdate = (sampleId: number, newStatus: string) => {
    setTrackingData(prev => prev.map(sample => {
      if (sample.id === sampleId) {
        const updatedTimeline = sample.timeline.map(step => {
          if (step.status === newStatus) {
            return { ...step, completed: true, current: true, time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) }
          }
          if (step.current) {
            return { ...step, current: false }
          }
          return step
        })
        
        return {
          ...sample,
          currentStatus: newStatus,
          timeline: updatedTimeline
        }
      }
      return sample
    }))

    toast({
      title: "Status Updated",
      description: `Sample status updated to ${newStatus}`,
    })
  }

  const stats = {
    collection: getTabData("collection").length,
    transit: getTabData("transit").length,
    processing: getTabData("processing").length,
    validation: getTabData("validation").length,
    total: filteredData.length
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sample Tracking Workflow</h1>
          <p className="text-gray-600">Track samples through the complete laboratory workflow</p>
          <p className="text-sm text-gray-500">Last updated: {lastRefresh.toLocaleTimeString()}</p>
        </div>
        <Button variant="outline" onClick={handleRefresh}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Status
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by patient name, sample ID, order number, or patient ID..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Created">Created</SelectItem>
                <SelectItem value="Collected">Collected</SelectItem>
                <SelectItem value="In Transit">In Transit</SelectItem>
                <SelectItem value="Processing">Processing</SelectItem>
                <SelectItem value="Validated">Validated</SelectItem>
                <SelectItem value="Released">Released</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="STAT">STAT</SelectItem>
                <SelectItem value="Urgent">Urgent</SelectItem>
                <SelectItem value="Routine">Routine</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Status Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => setSelectedTab("collection")}>
          <CardContent className="p-4 text-center">
            <TestTube className="h-6 w-6 mx-auto mb-2 text-orange-600" />
            <p className="text-sm font-medium text-gray-600">Collection</p>
            <p className="text-xl font-bold text-orange-600">{stats.collection}</p>
          </CardContent>
        </Card>
        
        <Card className="cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => setSelectedTab("transit")}>
          <CardContent className="p-4 text-center">
            <Truck className="h-6 w-6 mx-auto mb-2 text-blue-600" />
            <p className="text-sm font-medium text-gray-600">In Transit</p>
            <p className="text-xl font-bold text-blue-600">{stats.transit}</p>
          </CardContent>
        </Card>
        
        <Card className="cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => setSelectedTab("processing")}>
          <CardContent className="p-4 text-center">
            <Clock className="h-6 w-6 mx-auto mb-2 text-yellow-600" />
            <p className="text-sm font-medium text-gray-600">Processing</p>
            <p className="text-xl font-bold text-yellow-600">{stats.processing}</p>
          </CardContent>
        </Card>
        
        <Card className="cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => setSelectedTab("validation")}>
          <CardContent className="p-4 text-center">
            <CheckCircle className="h-6 w-6 mx-auto mb-2 text-green-600" />
            <p className="text-sm font-medium text-gray-600">Validated</p>
            <p className="text-xl font-bold text-green-600">{stats.validation}</p>
          </CardContent>
        </Card>
        
        <Card className="cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => setSelectedTab("all")}>
          <CardContent className="p-4 text-center">
            <TestTube className="h-6 w-6 mx-auto mb-2 text-gray-600" />
            <p className="text-sm font-medium text-gray-600">Total Samples</p>
            <p className="text-xl font-bold text-gray-600">{stats.total}</p>
          </CardContent>
        </Card>
      </div>

      {/* Tracking Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">All Samples</TabsTrigger>
          <TabsTrigger value="collection">Collection</TabsTrigger>
          <TabsTrigger value="transit">In Transit</TabsTrigger>
          <TabsTrigger value="processing">Processing</TabsTrigger>
          <TabsTrigger value="validation">Validation</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedTab} className="space-y-4">
          {getTabData(selectedTab).map((sample) => (
            <Card key={sample.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{sample.patientName}</CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>Sample ID: {sample.sampleId}</span>
                      <span>Order: {sample.orderNo}</span>
                      <span>Patient ID: {sample.patientId}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={getPriorityColor(sample.priority)}>
                      {sample.priority}
                    </Badge>
                    <Badge variant={getBadgeVariant(sample.currentStatus)}>
                      {sample.currentStatus}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Tests */}
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-2">Tests:</p>
                    <div className="flex flex-wrap gap-2">
                      {sample.tests.map((test, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {test}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Expected Completion */}
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Expected Completion:</span>
                    <span className="font-medium flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {sample.estimatedCompletion}
                    </span>
                  </div>

                  {/* Timeline */}
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-3">Sample Workflow:</p>
                    <div className="flex items-center space-x-2 overflow-x-auto pb-2">
                      {sample.timeline.map((step, index) => (
                        <div key={index} className="flex items-center space-x-2 min-w-max">
                          <div className={`flex flex-col items-center space-y-2 p-3 rounded-lg border ${
                            step.current ? 'bg-blue-50 border-blue-200' : 
                            step.completed ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
                          }`}>
                            <div className={`${getStatusColor(step.status, step.completed, step.current || false)}`}>
                              {getStatusIcon(step.status)}
                            </div>
                            <div className="text-center">
                              <p className={`text-xs font-medium ${
                                step.current ? 'text-blue-600' : 
                                step.completed ? 'text-green-600' : 'text-gray-400'
                              }`}>
                                {step.status}
                              </p>
                              <p className="text-xs text-gray-500">{step.time}</p>
                              {step.location && (
                                <p className="text-xs text-gray-400 flex items-center">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  {step.location}
                                </p>
                              )}
                              {step.user && (
                                <p className="text-xs text-gray-400 flex items-center">
                                  <User className="h-3 w-3 mr-1" />
                                  {step.user}
                                </p>
                              )}
                              {step.current && (
                                <Badge className="text-xs bg-blue-100 text-blue-800 mt-1">
                                  Current
                                </Badge>
                              )}
                            </div>
                          </div>
                          {index < sample.timeline.length - 1 && (
                            <div className={`w-8 h-px ${
                              sample.timeline[index + 1].completed ? 'bg-green-300' : 'bg-gray-300'
                            }`} />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex justify-end space-x-2 pt-2">
                    {sample.currentStatus === "Collected" && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleStatusUpdate(sample.id, "In Transit")}
                      >
                        Mark In Transit
                      </Button>
                    )}
                    {sample.currentStatus === "In Transit" && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleStatusUpdate(sample.id, "Received")}
                      >
                        Mark Received
                      </Button>
                    )}
                    {sample.currentStatus === "Received" && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleStatusUpdate(sample.id, "Processing")}
                      >
                        Start Processing
                      </Button>
                    )}
                    {sample.currentStatus === "Processing" && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleStatusUpdate(sample.id, "Validated")}
                      >
                        Mark Validated
                      </Button>
                    )}
                    {sample.currentStatus === "Validated" && (
                      <Button 
                        size="sm" 
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleStatusUpdate(sample.id, "Released")}
                      >
                        Release Report
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {getTabData(selectedTab).length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <TestTube className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-500">No samples found for the selected criteria</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

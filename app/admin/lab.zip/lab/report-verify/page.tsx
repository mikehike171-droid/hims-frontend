"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Calendar, Printer } from "lucide-react"

interface TestResult {
  testCode: string
  testDescription: string
  investigationCode: string
  investigation: string
  value: string
  unit: string
  lowerLimit: string
  upperLimit: string
  defaultValue: string
  valueType: string
}

const mockTestResults: TestResult[] = [
  {
    testCode: "SR0019",
    testDescription: "WIDAL",
    investigationCode: "SER021",
    investigation: 'S.PARATYPHI "BH "',
    value: "1:80",
    unit: "",
    lowerLimit: "",
    upperLimit: "",
    defaultValue: "1:20 Dilution",
    valueType: "FV",
  },
  {
    testCode: "SR0027",
    testDescription: "SERUM CREATININE",
    investigationCode: "BIO018",
    investigation: "SERUM CREATININE",
    value: "0.95",
    unit: "mg/dl",
    lowerLimit: "0.60",
    upperLimit: "1.25",
    defaultValue: "",
    valueType: "NV",
  },
  {
    testCode: "SR0067",
    testDescription: "SERUM ELECTROLYTES",
    investigationCode: "BIO019",
    investigation: "SERUM SODIUM",
    value: "140.5",
    unit: "mmol/l",
    lowerLimit: "135.00",
    upperLimit: "146.00",
    defaultValue: "",
    valueType: "NV",
  },
  {
    testCode: "SR0067",
    testDescription: "SERUM ELECTROLYTES",
    investigationCode: "BIO038",
    investigation: "SERUM POTASSIUM",
    value: "4.2",
    unit: "mmol/l",
    lowerLimit: "3.50",
    upperLimit: "5.50",
    defaultValue: "",
    valueType: "NV",
  },
  {
    testCode: "SR0067",
    testDescription: "SERUM ELECTROLYTES",
    investigationCode: "BIO040",
    investigation: "SERUM CHLORIDE",
    value: "102",
    unit: "mmol/l",
    lowerLimit: "98.00",
    upperLimit: "107.00",
    defaultValue: "",
    valueType: "NV",
  },
]

export default function ReportVerifyPage() {
  const [testResults, setTestResults] = useState<TestResult[]>(mockTestResults)
  const [filters, setFilters] = useState({
    branch: "Pranaam Hospital",
    department: "",
    fromDate: "29/09/2025",
    toDate: "29/09/2025",
    sampleType: "acceptance",
    patientType: "all",
    priority: "all",
  })

  const handleShow = () => {
    console.log("[v0] Filtering with:", filters)
  }

  const handleClear = () => {
    setFilters({
      branch: "Pranaam Hospital",
      department: "",
      fromDate: "",
      toDate: "",
      sampleType: "acceptance",
      patientType: "all",
      priority: "all",
    })
    setTestResults([])
  }

  const handlePrint = () => {
    window.print()
  }

  return (
    <div className="container mx-auto p-4 space-y-6 min-h-screen">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Report Verify</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* ORDER DETAILS Section */}
        <div className="border border-gray-300 rounded-lg p-4">
          <div className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium mb-4 inline-block">
            ORDER DETAILS
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">Branch*</Label>
                <Select
                  value={filters.branch}
                  onValueChange={(value) => setFilters((prev) => ({ ...prev, branch: value }))}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pranaam Hospital">Pranaam Hospital</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium">Department</Label>
                <Select
                  value={filters.department}
                  onValueChange={(value) => setFilters((prev) => ({ ...prev, department: value }))}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="--Select--" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="laboratory">Laboratory</SelectItem>
                    <SelectItem value="radiology">Radiology</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">From Date</Label>
                <div className="relative">
                  <Input
                    type="text"
                    value={filters.fromDate}
                    onChange={(e) => setFilters((prev) => ({ ...prev, fromDate: e.target.value }))}
                    className="pr-8 h-9"
                  />
                  <Calendar className="absolute right-2 top-2.5 h-4 w-4 text-gray-400" />
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">To Date</Label>
                <div className="relative">
                  <Input
                    type="text"
                    value={filters.toDate}
                    onChange={(e) => setFilters((prev) => ({ ...prev, toDate: e.target.value }))}
                    className="pr-8 h-9"
                  />
                  <Calendar className="absolute right-2 top-2.5 h-4 w-4 text-gray-400" />
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleShow} className="bg-black">
                Show
              </Button>
              <Button onClick={handleClear} variant="outline">
                Clear
              </Button>
            </div>
          </div>
        </div>

        {/* SEARCH CRITERIA Section */}
        <div className="border border-gray-300 rounded-lg p-4">
          <div className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium mb-4 inline-block">
            SEARCH CRITERIA
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label className="text-sm font-medium mb-2 block">Sample Type</Label>
              <RadioGroup
                value={filters.sampleType}
                onValueChange={(value) => setFilters((prev) => ({ ...prev, sampleType: value }))}
                className="flex flex-col space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="collected" id="collected" />
                  <Label htmlFor="collected" className="text-sm">
                    Collected
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="acceptance" id="acceptance" />
                  <Label htmlFor="acceptance" className="text-sm">
                    Acceptance
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="sample-all" />
                  <Label htmlFor="sample-all" className="text-sm">
                    All
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Patient Type</Label>
              <RadioGroup
                value={filters.patientType}
                onValueChange={(value) => setFilters((prev) => ({ ...prev, patientType: value }))}
                className="flex flex-col space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="ip" id="ip" />
                  <Label htmlFor="ip" className="text-sm">
                    IP
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="op" id="op" />
                  <Label htmlFor="op" className="text-sm">
                    OP
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="diagnostics" id="diagnostics" />
                  <Label htmlFor="diagnostics" className="text-sm">
                    Diagnostics
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="patient-all" />
                  <Label htmlFor="patient-all" className="text-sm">
                    All
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Priority</Label>
              <RadioGroup
                value={filters.priority}
                onValueChange={(value) => setFilters((prev) => ({ ...prev, priority: value }))}
                className="flex flex-col space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="emergency" id="emergency" />
                  <Label htmlFor="emergency" className="text-sm">
                    Emergency
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="regular" id="regular" />
                  <Label htmlFor="regular" className="text-sm">
                    Regular
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="priority-all" />
                  <Label htmlFor="priority-all" className="text-sm">
                    All
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        </div>
      </div>

      {testResults.length > 0 && (
        <>
          <div className="border border-gray-300 rounded-lg overflow-hidden">
            <div className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium ml-4 mb-4 inline-block">
              TEST RESULTS
            </div>

            <div className="overflow-x-auto p-4">
              <table className="w-full border-collapse border border-gray-300 text-black">
                <thead>
                  <tr className="bg-gray-100 text-black">
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">TEST CODE</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">TEST DESCRIPTION</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">
                      INVESTIGATION CODE
                    </th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">INVESTIGATION</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">VALUE</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">UNIT</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">LOWER LIMIT</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">UPPER LIMIT</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">DEFAULT VALUE</th>
                    <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">VALUE TYPE</th>
                  </tr>
                </thead>
                <tbody className="text-black">
                  {testResults.map((result, index) => (
                    <tr key={index} className="hover:bg-gray-200">
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.testCode}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.testDescription}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.investigationCode}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.investigation}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm font-medium">{result.value}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.unit}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.lowerLimit}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.upperLimit}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.defaultValue}</td>
                      <td className="border border-gray-300 px-3 py-2 text-sm">{result.valueType}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={handlePrint} className="bg-black flex items-center gap-2">
              <Printer className="h-4 w-4" />
              Print
            </Button>
          </div>
        </>
      )}

      {testResults.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No test results found. Please use the search criteria above to filter results.
        </div>
      )}
    </div>
  )
}

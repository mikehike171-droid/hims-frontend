"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Calendar, Search } from "lucide-react"
import { useRouter } from "next/navigation"

interface Order {
  orderNo: string
  orderDate: string
  orderTime: string
  mrNumber: string
  ipNumber: string
  patientName: string
  sampleStatus: string
  priority: string
  age: string
}

interface Test {
  orderNo: string
  testCode: string
  testDescription: string
  laboratory: string
  specimen: string
  container: string
  sampleNumber: string
  collectedDate: string
  checked: boolean
}

const mockOrders: Order[] = [
  {
    orderNo: "PHS-DL25-026047",
    orderDate: "29 Sep 2025",
    orderTime: "01:00:43",
    mrNumber: "MR2500028876",
    ipNumber: "PHS-IP2500005343",
    patientName: "YUVAN",
    sampleStatus: "RE",
    priority: "R",
    age: "0 Y:4 M:14 Days",
  },
  {
    orderNo: "PHS-DL25-026048",
    orderDate: "29 Sep 2025",
    orderTime: "02:14:01",
    mrNumber: "MR2500028883",
    ipNumber: "",
    patientName: "CHANDANI",
    sampleStatus: "RE",
    priority: "R",
    age: "19 Y:0 M:1 Days",
  },
  {
    orderNo: "PHS-DL25-026049",
    orderDate: "29 Sep 2025",
    orderTime: "03:36:35",
    mrNumber: "MR2500013658",
    ipNumber: "",
    patientName: "KEERTHI",
    sampleStatus: "RE",
    priority: "R",
    age: "30 Y:7 M:8 Days",
  },
]

const mockTests: Test[] = [
  {
    orderNo: "PHS-DL25-026048",
    testCode: "SR0026",
    testDescription: "COMPLETE BLOOD PICTURE",
    laboratory: "HAEMATOLOGY and CL.PATHOLOGY",
    specimen: "WB-EDTA(3ml)",
    container: "",
    sampleNumber: "PHS-LB25-032561",
    collectedDate: "9/29/2025 12:00:00 AM",
    checked: false,
  },
  {
    orderNo: "PHS-DL25-026048",
    testCode: "SR0035",
    testDescription: "CRP (C- REACTIVE PROTEIN )",
    laboratory: "MICROBIOLOGY and SEROLOGY",
    specimen: "Serum (1ml)",
    container: "",
    sampleNumber: "PHS-LB25-032561",
    collectedDate: "9/29/2025 12:00:00 AM",
    checked: false,
  },
]

export default function SampleCollectionPage() {
  const router = useRouter()
  const [orders] = useState<Order[]>(mockOrders)
  const [tests, setTests] = useState<Test[]>(mockTests)
  const [searchTerm, setSearchTerm] = useState("")
  const [filters, setFilters] = useState({
    branch: "Pranaam Hospital",
    department: "",
    fromDate: "29/09/2025",
    toDate: "29/09/2025",
    sampleType: "all",
    patientType: "all",
    priority: "all",
  })

  const handleCheckAll = () => {
    const allChecked = tests.every((test) => test.checked)
    setTests((prev) => prev.map((test) => ({ ...test, checked: !allChecked })))
  }

  const handleIndividualCheck = (index: number) => {
    setTests((prev) => prev.map((test, i) => (i === index ? { ...test, checked: !test.checked } : test)))
  }

  const handleTestClick = (test: Test) => {
    const selectedOrder = orders.find((order) => order.orderNo === test.orderNo)
    if (selectedOrder) {
      sessionStorage.setItem(
        "reportEntryData",
        JSON.stringify({
          test,
          order: selectedOrder,
        }),
      )
      router.push("/lab/report-entry")
    }
  }

  const handleCollect = () => {
    const collectedTests = tests.filter((test) => test.checked)
    if (collectedTests.length > 0) {
      sessionStorage.setItem("collectedTests", JSON.stringify(collectedTests))
      setTests((prev) => prev.map((test) => (test.checked ? { ...test, sampleStatus: "Collected" } : test)))
    }
  }

  const filteredOrders = orders.filter(
    (order) =>
      order.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.orderNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.mrNumber.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="container mx-auto p-4 space-y-6 min-h-screen">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Sample Collection</h1>
      </div>

      {/* ORDER DETAILS Section */}
      <div className="border border-gray-300 rounded-lg p-4">
        <div className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium mb-4 inline-block">
          ORDER DETAILS
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <Label className="text-sm font-medium">Branch*</Label>
            <Select
              value={filters.branch}
              onValueChange={(value) => setFilters((prev) => ({ ...prev, branch: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Pranaam Hospital">Pranaam Hospital</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium">Department</Label>
            <Select
              value={filters.department}
              onValueChange={(value) => setFilters((prev) => ({ ...prev, department: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="--Select--" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="laboratory">Laboratory</SelectItem>
                <SelectItem value="radiology">Radiology</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium">From Date</Label>
            <div className="relative">
              <Input
                type="text"
                value={filters.fromDate}
                onChange={(e) => setFilters((prev) => ({ ...prev, fromDate: e.target.value }))}
                className="pr-8"
              />
              <Calendar className="absolute right-2 top-2.5 h-4 w-4 text-gray-400" />
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium">To Date</Label>
            <div className="relative">
              <Input
                type="text"
                value={filters.toDate}
                onChange={(e) => setFilters((prev) => ({ ...prev, toDate: e.target.value }))}
                className="pr-8"
              />
              <Calendar className="absolute right-2 top-2.5 h-4 w-4 text-gray-400" />
            </div>
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <Button className="bg-black">Show</Button>
          <Button variant="outline">Clear</Button>
        </div>
      </div>

      {/* SEARCH CRITERIA Section */}
      <div className="border border-gray-300 rounded-lg p-4">
        <div className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium mb-4 inline-block">
          SEARCH CRITERIA
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <Label className="text-sm font-medium mb-2 block">Sample Type</Label>
            <RadioGroup
              value={filters.sampleType}
              onValueChange={(value) => setFilters((prev) => ({ ...prev, sampleType: value }))}
              className="flex flex-col space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="collected" id="collected" />
                <Label htmlFor="collected">Collected</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="acceptance" id="acceptance" />
                <Label htmlFor="acceptance">Acceptance</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="sample-all" />
                <Label htmlFor="sample-all">All</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <Label className="text-sm font-medium mb-2 block">Patient Type</Label>
            <RadioGroup
              value={filters.patientType}
              onValueChange={(value) => setFilters((prev) => ({ ...prev, patientType: value }))}
              className="flex flex-col space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="ip" id="ip" />
                <Label htmlFor="ip">IP</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="op" id="op" />
                <Label htmlFor="op">OP</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="diagnostics" id="diagnostics" />
                <Label htmlFor="diagnostics">Diagnostics</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="patient-all" />
                <Label htmlFor="patient-all">All</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <Label className="text-sm font-medium mb-2 block">Priority</Label>
            <RadioGroup
              value={filters.priority}
              onValueChange={(value) => setFilters((prev) => ({ ...prev, priority: value }))}
              className="flex flex-col space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="emergency" id="emergency" />
                <Label htmlFor="emergency">Emergency</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="regular" id="regular" />
                <Label htmlFor="regular">Regular</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="priority-all" />
                <Label htmlFor="priority-all">All</Label>
              </div>
            </RadioGroup>
          </div>
        </div>
      </div>

      {/* ORDERS Section */}
      <div className="border border-gray-300 rounded-lg overflow-hidden">
        <div className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium ml-4 mb-4 inline-block">
          ORDERS
        </div>

        <div className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <Label>SEARCH:</Label>
            <div className="relative">
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
                placeholder="Search orders..."
              />
              <Search className="absolute right-2 top-2.5 h-4 w-4 text-gray-400" />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100 text-black">
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">ORDER NO</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">ORDER DATE</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">ORDER TIME</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">MR.NUMBER</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">IP.NUMBER</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">PATIENT NAME</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">SAMPLE STATUS</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">PRIORITY</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">AGE</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.orderNo}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.orderDate}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.orderTime}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.mrNumber}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.ipNumber}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.patientName}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.sampleStatus}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.priority}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{order.age}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center mt-4">
            <div className="flex items-center gap-2">
              <span className="text-sm">Previous</span>
              <Button variant="outline" size="sm">
                1
              </Button>
              <Button variant="outline" size="sm">
                2
              </Button>
              <Button variant="outline" size="sm">
                3
              </Button>
              <Button variant="outline" size="sm">
                4
              </Button>
              <Button variant="outline" size="sm">
                5
              </Button>
              <span className="text-sm">Next</span>
            </div>
          </div>
        </div>
      </div>

      {/* TESTS Section */}
      <div className="border border-gray-300 rounded-lg overflow-hidden">
        <div className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium ml-4 mb-4 inline-block">TESTS</div>

        <div className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <Label>SEARCH:</Label>
            <Input className="w-64" placeholder="Search tests..." />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300 bg-gray-100 text-black">
              <thead>
                <tr className="bg-gray-100 text-black">
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">
                    <Checkbox
                      checked={tests.length > 0 && tests.every((test) => test.checked)}
                      onCheckedChange={handleCheckAll}
                      className="border-black data-[state=checked]:bg-black data-[state=checked]:text-white"
                    />
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">ORDER NO</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">TEST CODE</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">TEST DESCRIPTION</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">LABORATORY</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">SPECIMEN</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">CONTAINER</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">SAMPLE NUMBER</th>
                  <th className="border border-gray-300 px-3 py-2 text-left text-sm font-medium">COLLECTED DATE</th>
                </tr>
              </thead>
              <tbody className="bg-gray-100 text-black">
                {tests.map((test, index) => (
                  <tr key={index} className="hover:bg-gray-200 bg-gray-100 text-black">
                    <td className="border border-gray-300 px-3 py-2 text-sm">
                      <Checkbox
                        checked={test.checked}
                        onCheckedChange={() => handleIndividualCheck(index)}
                        className="border-black data-[state=checked]:bg-black data-[state=checked]:text-white"
                      />
                    </td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{test.orderNo}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{test.testCode}</td>
                    <td
                      className="border border-gray-300 px-3 py-2 text-sm cursor-pointer hover:text-blue-600 hover:underline"
                      onClick={() => handleTestClick(test)}
                    >
                      {test.testDescription}
                    </td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{test.laboratory}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{test.specimen}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{test.container}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{test.sampleNumber}</td>
                    <td className="border border-gray-300 px-3 py-2 text-sm">{test.collectedDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Collect Button */}
      <div className="flex justify-end">
        <Button
          onClick={handleCollect}
          className="bg-green-600 hover:bg-green-700"
          disabled={!tests.some((test) => test.checked)}
        >
          Collect
        </Button>
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Plus, Search, Edit, Trash2, TestTube, Save, X, AlertCircle } from 'lucide-react'
import { useToast } from "@/hooks/use-toast"

interface Test {
  id: number
  code: string
  name: string
  category: string
  department: string
  sampleType: string
  method: string
  units: string
  referenceRange: string
  normalRange: string
  criticalLow: string
  criticalHigh: string
  turnaroundTime: number
  cost: number
  isActive: boolean
  createdDate: string
  lastModified: string
}

interface TestGroup {
  id: number
  name: string
  code: string
  description: string
  tests: number[]
  cost: number
  isActive: boolean
}

const initialTestData: Test[] = [
  {
    id: 1,
    code: "HB001",
    name: "Hemoglobin",
    category: "Hematology",
    department: "Pathology",
    sampleType: "Blood",
    method: "Automated Analyzer",
    units: "g/dL",
    referenceRange: "13.5-17.5 (M), 12.0-15.5 (F)",
    normalRange: "12.0-17.5",
    criticalLow: "7.0",
    criticalHigh: "20.0",
    turnaroundTime: 60,
    cost: 150,
    isActive: true,
    createdDate: "2024-01-01",
    lastModified: "2024-01-08"
  },
  {
    id: 2,
    code: "GLU001",
    name: "Random Blood Sugar",
    category: "Biochemistry",
    department: "Pathology",
    sampleType: "Blood",
    method: "Glucose Oxidase",
    units: "mg/dL",
    referenceRange: "70-140",
    normalRange: "70-140",
    criticalLow: "50",
    criticalHigh: "400",
    turnaroundTime: 30,
    cost: 80,
    isActive: true,
    createdDate: "2024-01-01",
    lastModified: "2024-01-08"
  },
  {
    id: 3,
    code: "CRE001",
    name: "Serum Creatinine",
    category: "Biochemistry",
    department: "Pathology",
    sampleType: "Blood",
    method: "Jaffe Method",
    units: "mg/dL",
    referenceRange: "0.7-1.3 (M), 0.6-1.1 (F)",
    normalRange: "0.6-1.3",
    criticalLow: "0.3",
    criticalHigh: "5.0",
    turnaroundTime: 45,
    cost: 120,
    isActive: true,
    createdDate: "2024-01-01",
    lastModified: "2024-01-08"
  }
]

const initialGroupData: TestGroup[] = [
  {
    id: 1,
    name: "Complete Blood Count",
    code: "CBC001",
    description: "Complete blood count with differential",
    tests: [1],
    cost: 300,
    isActive: true
  },
  {
    id: 2,
    name: "Basic Metabolic Panel",
    code: "BMP001",
    description: "Basic metabolic panel including glucose and creatinine",
    tests: [2, 3],
    cost: 450,
    isActive: true
  }
]

export default function TestMasterManagement() {
  const [testData, setTestData] = useState<Test[]>(initialTestData)
  const [groupData, setGroupData] = useState<TestGroup[]>(initialGroupData)
  const [isTestDialogOpen, setIsTestDialogOpen] = useState(false)
  const [isGroupDialogOpen, setIsGroupDialogOpen] = useState(false)
  const [editingTest, setEditingTest] = useState<Test | null>(null)
  const [editingGroup, setEditingGroup] = useState<TestGroup | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("tests")
  const { toast } = useToast()

  const [testForm, setTestForm] = useState({
    code: "",
    name: "",
    category: "",
    department: "",
    sampleType: "",
    method: "",
    units: "",
    referenceRange: "",
    normalRange: "",
    criticalLow: "",
    criticalHigh: "",
    turnaroundTime: "",
    cost: "",
    isActive: true
  })

  const [groupForm, setGroupForm] = useState({
    name: "",
    code: "",
    description: "",
    tests: [] as number[],
    cost: "",
    isActive: true
  })

  const categories = ["Hematology", "Biochemistry", "Microbiology", "Immunology", "Pathology"]
  const departments = ["Pathology", "Microbiology", "Biochemistry", "Hematology"]
  const sampleTypes = ["Blood", "Urine", "Stool", "Sputum", "CSF", "Other"]

  const filteredTests = testData.filter(test => {
    const matchesSearch = test.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         test.code.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || test.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const resetTestForm = () => {
    setTestForm({
      code: "",
      name: "",
      category: "",
      department: "",
      sampleType: "",
      method: "",
      units: "",
      referenceRange: "",
      normalRange: "",
      criticalLow: "",
      criticalHigh: "",
      turnaroundTime: "",
      cost: "",
      isActive: true
    })
    setEditingTest(null)
  }

  const resetGroupForm = () => {
    setGroupForm({
      name: "",
      code: "",
      description: "",
      tests: [],
      cost: "",
      isActive: true
    })
    setEditingGroup(null)
  }

  const handleTestSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validation
    if (!testForm.code || !testForm.name || !testForm.category) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields (Code, Name, Category)",
        variant: "destructive"
      })
      return
    }

    // Check for duplicate code
    const isDuplicate = testData.some(test => 
      test.code.toLowerCase() === testForm.code.toLowerCase() && 
      (!editingTest || test.id !== editingTest.id)
    )

    if (isDuplicate) {
      toast({
        title: "Duplicate Code",
        description: "A test with this code already exists",
        variant: "destructive"
      })
      return
    }

    try {
      if (editingTest) {
        // Update existing test
        setTestData(prev => prev.map(test => 
          test.id === editingTest.id 
            ? {
                ...test,
                ...testForm,
                turnaroundTime: parseInt(testForm.turnaroundTime) || 0,
                cost: parseFloat(testForm.cost) || 0,
                lastModified: new Date().toISOString().split('T')[0]
              }
            : test
        ))
        toast({
          title: "Test Updated",
          description: `${testForm.name} has been updated successfully`
        })
      } else {
        // Add new test
        const newTest: Test = {
          id: Math.max(...testData.map(t => t.id)) + 1,
          ...testForm,
          turnaroundTime: parseInt(testForm.turnaroundTime) || 0,
          cost: parseFloat(testForm.cost) || 0,
          createdDate: new Date().toISOString().split('T')[0],
          lastModified: new Date().toISOString().split('T')[0]
        }
        setTestData(prev => [...prev, newTest])
        toast({
          title: "Test Added",
          description: `${testForm.name} has been added successfully`
        })
      }

      setIsTestDialogOpen(false)
      resetTestForm()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save test. Please try again.",
        variant: "destructive"
      })
    }
  }

  const handleGroupSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validation
    if (!groupForm.name || !groupForm.code || groupForm.tests.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields and select at least one test",
        variant: "destructive"
      })
      return
    }

    // Check for duplicate code
    const isDuplicate = groupData.some(group => 
      group.code.toLowerCase() === groupForm.code.toLowerCase() && 
      (!editingGroup || group.id !== editingGroup.id)
    )

    if (isDuplicate) {
      toast({
        title: "Duplicate Code",
        description: "A test group with this code already exists",
        variant: "destructive"
      })
      return
    }

    try {
      if (editingGroup) {
        // Update existing group
        setGroupData(prev => prev.map(group => 
          group.id === editingGroup.id 
            ? {
                ...group,
                ...groupForm,
                cost: parseFloat(groupForm.cost) || 0
              }
            : group
        ))
        toast({
          title: "Test Group Updated",
          description: `${groupForm.name} has been updated successfully`
        })
      } else {
        // Add new group
        const newGroup: TestGroup = {
          id: Math.max(...groupData.map(g => g.id)) + 1,
          ...groupForm,
          cost: parseFloat(groupForm.cost) || 0
        }
        setGroupData(prev => [...prev, newGroup])
        toast({
          title: "Test Group Added",
          description: `${groupForm.name} has been added successfully`
        })
      }

      setIsGroupDialogOpen(false)
      resetGroupForm()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save test group. Please try again.",
        variant: "destructive"
      })
    }
  }

  const handleEditTest = (test: Test) => {
    setEditingTest(test)
    setTestForm({
      code: test.code,
      name: test.name,
      category: test.category,
      department: test.department,
      sampleType: test.sampleType,
      method: test.method,
      units: test.units,
      referenceRange: test.referenceRange,
      normalRange: test.normalRange,
      criticalLow: test.criticalLow,
      criticalHigh: test.criticalHigh,
      turnaroundTime: test.turnaroundTime.toString(),
      cost: test.cost.toString(),
      isActive: test.isActive
    })
    setIsTestDialogOpen(true)
  }

  const handleEditGroup = (group: TestGroup) => {
    setEditingGroup(group)
    setGroupForm({
      name: group.name,
      code: group.code,
      description: group.description,
      tests: group.tests,
      cost: group.cost.toString(),
      isActive: group.isActive
    })
    setIsGroupDialogOpen(true)
  }

  const handleDeleteTest = (id: number) => {
    setTestData(prev => prev.filter(test => test.id !== id))
    toast({
      title: "Test Deleted",
      description: "Test has been deleted successfully"
    })
  }

  const handleDeleteGroup = (id: number) => {
    setGroupData(prev => prev.filter(group => group.id !== id))
    toast({
      title: "Test Group Deleted",
      description: "Test group has been deleted successfully"
    })
  }

  const getTestName = (testId: number) => {
    const test = testData.find(t => t.id === testId)
    return test ? test.name : `Test ${testId}`
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Test Master Management</h1>
          <p className="text-gray-600">Manage laboratory tests and test groups</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="tests">Individual Tests</TabsTrigger>
          <TabsTrigger value="groups">Test Groups</TabsTrigger>
        </TabsList>

        {/* Individual Tests Tab */}
        <TabsContent value="tests" className="space-y-4">
          {/* Filters and Add Button */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="flex flex-col md:flex-row gap-4 flex-1">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search tests by name or code..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Dialog open={isTestDialogOpen} onOpenChange={(open) => {
                  setIsTestDialogOpen(open)
                  if (!open) resetTestForm()
                }}>
                  <DialogTrigger asChild>
                    <Button className="bg-red-600 hover:bg-red-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add New Test
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingTest ? "Edit Test" : "Add New Test"}
                      </DialogTitle>
                      <DialogDescription>
                        {editingTest ? "Update test information" : "Create a new laboratory test"}
                      </DialogDescription>
                    </DialogHeader>
                    
                    <form onSubmit={handleTestSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="code">Test Code *</Label>
                          <Input
                            id="code"
                            placeholder="e.g., HB001"
                            value={testForm.code}
                            onChange={(e) => setTestForm(prev => ({ ...prev, code: e.target.value }))}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="name">Test Name *</Label>
                          <Input
                            id="name"
                            placeholder="e.g., Hemoglobin"
                            value={testForm.name}
                            onChange={(e) => setTestForm(prev => ({ ...prev, name: e.target.value }))}
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="category">Category *</Label>
                          <Select value={testForm.category} onValueChange={(value) => setTestForm(prev => ({ ...prev, category: value }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map(category => (
                                <SelectItem key={category} value={category}>{category}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="department">Department</Label>
                          <Select value={testForm.department} onValueChange={(value) => setTestForm(prev => ({ ...prev, department: value }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select department" />
                            </SelectTrigger>
                            <SelectContent>
                              {departments.map(dept => (
                                <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="sampleType">Sample Type</Label>
                          <Select value={testForm.sampleType} onValueChange={(value) => setTestForm(prev => ({ ...prev, sampleType: value }))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select sample type" />
                            </SelectTrigger>
                            <SelectContent>
                              {sampleTypes.map(type => (
                                <SelectItem key={type} value={type}>{type}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="method">Method</Label>
                          <Input
                            id="method"
                            placeholder="e.g., Automated Analyzer"
                            value={testForm.method}
                            onChange={(e) => setTestForm(prev => ({ ...prev, method: e.target.value }))}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="units">Units</Label>
                          <Input
                            id="units"
                            placeholder="e.g., g/dL, mg/dL"
                            value={testForm.units}
                            onChange={(e) => setTestForm(prev => ({ ...prev, units: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="referenceRange">Reference Range</Label>
                          <Input
                            id="referenceRange"
                            placeholder="e.g., 13.5-17.5 (M), 12.0-15.5 (F)"
                            value={testForm.referenceRange}
                            onChange={(e) => setTestForm(prev => ({ ...prev, referenceRange: e.target.value }))}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="criticalLow">Critical Low</Label>
                          <Input
                            id="criticalLow"
                            placeholder="e.g., 7.0"
                            value={testForm.criticalLow}
                            onChange={(e) => setTestForm(prev => ({ ...prev, criticalLow: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="criticalHigh">Critical High</Label>
                          <Input
                            id="criticalHigh"
                            placeholder="e.g., 20.0"
                            value={testForm.criticalHigh}
                            onChange={(e) => setTestForm(prev => ({ ...prev, criticalHigh: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="turnaroundTime">TAT (minutes)</Label>
                          <Input
                            id="turnaroundTime"
                            type="number"
                            placeholder="e.g., 60"
                            value={testForm.turnaroundTime}
                            onChange={(e) => setTestForm(prev => ({ ...prev, turnaroundTime: e.target.value }))}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="cost">Cost (₹)</Label>
                          <Input
                            id="cost"
                            type="number"
                            step="0.01"
                            placeholder="e.g., 150.00"
                            value={testForm.cost}
                            onChange={(e) => setTestForm(prev => ({ ...prev, cost: e.target.value }))}
                          />
                        </div>
                        <div className="flex items-center space-x-2 pt-6">
                          <Checkbox
                            id="isActive"
                            checked={testForm.isActive}
                            onCheckedChange={(checked) => setTestForm(prev => ({ ...prev, isActive: checked as boolean }))}
                          />
                          <Label htmlFor="isActive">Active</Label>
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2 pt-4">
                        <Button type="button" variant="outline" onClick={() => {
                          setIsTestDialogOpen(false)
                          resetTestForm()
                        }}>
                          Cancel
                        </Button>
                        <Button type="submit" className="bg-green-600 hover:bg-green-700">
                          <Save className="h-4 w-4 mr-2" />
                          {editingTest ? "Update Test" : "Add Test"}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>

          {/* Tests Table */}
          <Card>
            <CardHeader>
              <CardTitle>Laboratory Tests ({filteredTests.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Sample Type</TableHead>
                      <TableHead>Units</TableHead>
                      <TableHead>Reference Range</TableHead>
                      <TableHead>TAT</TableHead>
                      <TableHead>Cost</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTests.map((test) => (
                      <TableRow key={test.id}>
                        <TableCell className="font-medium">{test.code}</TableCell>
                        <TableCell>{test.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{test.category}</Badge>
                        </TableCell>
                        <TableCell>{test.sampleType}</TableCell>
                        <TableCell>{test.units}</TableCell>
                        <TableCell className="max-w-48 truncate" title={test.referenceRange}>
                          {test.referenceRange}
                        </TableCell>
                        <TableCell>{test.turnaroundTime} min</TableCell>
                        <TableCell>₹{test.cost}</TableCell>
                        <TableCell>
                          <Badge variant={test.isActive ? "default" : "secondary"}>
                            {test.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditTest(test)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteTest(test.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Test Groups Tab */}
        <TabsContent value="groups" className="space-y-4">
          {/* Add Group Button */}
          <div className="flex justify-end">
            <Dialog open={isGroupDialogOpen} onOpenChange={(open) => {
              setIsGroupDialogOpen(open)
              if (!open) resetGroupForm()
            }}>
              <DialogTrigger asChild>
                <Button className="bg-red-600 hover:bg-red-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Test Group
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>
                    {editingGroup ? "Edit Test Group" : "Add New Test Group"}
                  </DialogTitle>
                  <DialogDescription>
                    {editingGroup ? "Update test group information" : "Create a new test group"}
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={handleGroupSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="groupCode">Group Code *</Label>
                      <Input
                        id="groupCode"
                        placeholder="e.g., CBC001"
                        value={groupForm.code}
                        onChange={(e) => setGroupForm(prev => ({ ...prev, code: e.target.value }))}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="groupName">Group Name *</Label>
                      <Input
                        id="groupName"
                        placeholder="e.g., Complete Blood Count"
                        value={groupForm.name}
                        onChange={(e) => setGroupForm(prev => ({ ...prev, name: e.target.value }))}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      placeholder="Brief description of the test group"
                      value={groupForm.description}
                      onChange={(e) => setGroupForm(prev => ({ ...prev, description: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Select Tests *</Label>
                    <div className="border rounded-md p-4 max-h-48 overflow-y-auto">
                      {testData.filter(test => test.isActive).map((test) => (
                        <div key={test.id} className="flex items-center space-x-2 py-1">
                          <Checkbox
                            id={`test-${test.id}`}
                            checked={groupForm.tests.includes(test.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setGroupForm(prev => ({ 
                                  ...prev, 
                                  tests: [...prev.tests, test.id] 
                                }))
                              } else {
                                setGroupForm(prev => ({ 
                                  ...prev, 
                                  tests: prev.tests.filter(id => id !== test.id) 
                                }))
                              }
                            }}
                          />
                          <Label htmlFor={`test-${test.id}`} className="text-sm">
                            {test.name} ({test.code}) - ₹{test.cost}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="groupCost">Group Cost (₹)</Label>
                      <Input
                        id="groupCost"
                        type="number"
                        step="0.01"
                        placeholder="e.g., 450.00"
                        value={groupForm.cost}
                        onChange={(e) => setGroupForm(prev => ({ ...prev, cost: e.target.value }))}
                      />
                    </div>
                    <div className="flex items-center space-x-2 pt-6">
                      <Checkbox
                        id="groupActive"
                        checked={groupForm.isActive}
                        onCheckedChange={(checked) => setGroupForm(prev => ({ ...prev, isActive: checked as boolean }))}
                      />
                      <Label htmlFor="groupActive">Active</Label>
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => {
                      setIsGroupDialogOpen(false)
                      resetGroupForm()
                    }}>
                      Cancel
                    </Button>
                    <Button type="submit" className="bg-green-600 hover:bg-green-700">
                      <Save className="h-4 w-4 mr-2" />
                      {editingGroup ? "Update Group" : "Add Group"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Groups Table */}
          <Card>
            <CardHeader>
              <CardTitle>Test Groups ({groupData.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {groupData.map((group) => (
                  <div key={group.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-lg">{group.name}</h3>
                        <p className="text-sm text-gray-600">Code: {group.code}</p>
                        {group.description && (
                          <p className="text-sm text-gray-500 mt-1">{group.description}</p>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={group.isActive ? "default" : "secondary"}>
                          {group.isActive ? "Active" : "Inactive"}
                        </Badge>
                        <span className="font-semibold text-green-600">₹{group.cost}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditGroup(group)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteGroup(group.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-2">
                        Included Tests ({group.tests.length}):
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {group.tests.map((testId) => (
                          <Badge key={testId} variant="outline" className="text-xs">
                            {getTestName(testId)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

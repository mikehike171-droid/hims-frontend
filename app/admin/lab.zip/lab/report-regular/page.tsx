"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

interface TestDetail {
  testCode: string
  testDescription: string
  orderNo: string
  patientName: string
  mrNumber: string
  age: string
  gender: string
  specimen: string
  collectedDate: string
  reportedDate: string
  reportedBy: string
  verifiedBy: string
  comments: string
}

export default function ReportRegularPage() {
  const searchParams = useSearchParams()
  const testCode = searchParams.get("testCode")
  const orderNo = searchParams.get("orderNo")

  const [testDetail, setTestDetail] = useState<TestDetail>({
    testCode: testCode || "",
    testDescription: "COMPLETE BLOOD PICTURE",
    orderNo: orderNo || "",
    patientName: "CHANDANI",
    mrNumber: "MR2500028883",
    age: "19 Y:0 M:1 Days",
    gender: "Female",
    specimen: "WB-EDTA(3ml)",
    collectedDate: "9/29/2025 12:00:00 AM",
    reportedDate: "",
    reportedBy: "",
    verifiedBy: "",
    comments: "",
  })

  const handleInputChange = (field: keyof TestDetail, value: string) => {
    setTestDetail((prev) => ({ ...prev, [field]: value }))
  }

  const handleSave = () => {
    console.log("Saving test details:", testDetail)
  }

  const handleSubmit = () => {
    console.log("Submitting test report:", testDetail)
  }

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Report Regular</h1>
      </div>

      {/* Test Information */}
      <div className="border border-gray-300 rounded-lg p-4">
        <div className="bg-blue-600 text-white px-3 py-1 rounded text-sm font-medium mb-4 inline-block">
          TEST INFORMATION
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium">Test Code</Label>
            <Input value={testDetail.testCode} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">Test Description</Label>
            <Input value={testDetail.testDescription} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">Order No</Label>
            <Input value={testDetail.orderNo} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">Patient Name</Label>
            <Input value={testDetail.patientName} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">MR Number</Label>
            <Input value={testDetail.mrNumber} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">Age</Label>
            <Input value={testDetail.age} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">Gender</Label>
            <Input value={testDetail.gender} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">Specimen</Label>
            <Input value={testDetail.specimen} readOnly className="bg-gray-50" />
          </div>
          <div>
            <Label className="text-sm font-medium">Collected Date</Label>
            <Input value={testDetail.collectedDate} readOnly className="bg-gray-50" />
          </div>
        </div>
      </div>

      {/* Report Details */}
      <div className="border border-gray-300 rounded-lg p-4">
        <div className="bg-blue-600 text-white px-3 py-1 rounded text-sm font-medium mb-4 inline-block">
          REPORT DETAILS
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium">Reported Date</Label>
            <Input
              value={testDetail.reportedDate}
              onChange={(e) => handleInputChange("reportedDate", e.target.value)}
              placeholder="Enter reported date"
            />
          </div>
          <div>
            <Label className="text-sm font-medium">Reported By</Label>
            <Input
              value={testDetail.reportedBy}
              onChange={(e) => handleInputChange("reportedBy", e.target.value)}
              placeholder="Enter reported by"
            />
          </div>
          <div>
            <Label className="text-sm font-medium">Verified By</Label>
            <Input
              value={testDetail.verifiedBy}
              onChange={(e) => handleInputChange("verifiedBy", e.target.value)}
              placeholder="Enter verified by"
            />
          </div>
        </div>

        <div className="mt-4">
          <Label className="text-sm font-medium">Comments</Label>
          <Textarea
            value={testDetail.comments}
            onChange={(e) => handleInputChange("comments", e.target.value)}
            placeholder="Enter comments"
            rows={4}
          />
        </div>

        <div className="flex justify-end space-x-2 mt-4">
          <Button variant="outline" onClick={handleSave}>
            Save
          </Button>
          <Button variant="outline">Print</Button>
          <Button variant="outline">Clear</Button>
          <Button className="bg-green-600 hover:bg-green-700" onClick={handleSubmit}>
            Submit Report
          </Button>
        </div>
      </div>
    </div>
  )
}

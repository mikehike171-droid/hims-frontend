"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { Plus, Search, Clock, FileText, User, Calendar, X, Check, Printer } from 'lucide-react'
import { useToast } from "@/hooks/use-toast"

interface Test {
  id: number
  code: string
  name: string
  price: number
  tat: number
  department: string
  sampleType: string
}

interface TestGroup {
  id: number
  code: string
  name: string
  price: number
  tat: number
  testsCount: number
  tests: Test[]
}

interface Patient {
  id: string
  name: string
  age: number
  gender: string
  phone: string
}

interface Doctor {
  id: string
  name: string
  department: string
}

const availableTests: Test[] = [
  { id: 1, code: "HB001", name: "Hemoglobin", price: 150, tat: 2, department: "Hematology", sampleType: "Blood" },
  { id: 2, code: "GLU001", name: "Random Blood Sugar", price: 100, tat: 1, department: "Biochemistry", sampleType: "Blood" },
  { id: 3, code: "CRE001", name: "Serum Creatinine", price: 200, tat: 4, department: "Biochemistry", sampleType: "Blood" },
  { id: 4, code: "URI001", name: "Urine Routine", price: 120, tat: 2, department: "Pathology", sampleType: "Urine" },
  { id: 5, code: "TSH001", name: "Thyroid Stimulating Hormone", price: 300, tat: 6, department: "Immunology", sampleType: "Blood" },
]

const availableGroups: TestGroup[] = [
  { 
    id: 1, 
    code: "CBC", 
    name: "Complete Blood Count", 
    price: 500, 
    tat: 4, 
    testsCount: 15,
    tests: [
      { id: 101, code: "HB001", name: "Hemoglobin", price: 150, tat: 2, department: "Hematology", sampleType: "Blood" },
      { id: 102, code: "WBC001", name: "White Blood Cell Count", price: 100, tat: 2, department: "Hematology", sampleType: "Blood" },
      { id: 103, code: "RBC001", name: "Red Blood Cell Count", price: 100, tat: 2, department: "Hematology", sampleType: "Blood" },
    ]
  },
  { 
    id: 2, 
    code: "LFT", 
    name: "Liver Function Test", 
    price: 800, 
    tat: 6, 
    testsCount: 8,
    tests: [
      { id: 201, code: "ALT001", name: "ALT/SGPT", price: 150, tat: 4, department: "Biochemistry", sampleType: "Blood" },
      { id: 202, code: "AST001", name: "AST/SGOT", price: 150, tat: 4, department: "Biochemistry", sampleType: "Blood" },
      { id: 203, code: "BIL001", name: "Total Bilirubin", price: 120, tat: 4, department: "Biochemistry", sampleType: "Blood" },
    ]
  },
  { 
    id: 3, 
    code: "KFT", 
    name: "Kidney Function Test", 
    price: 600, 
    tat: 6, 
    testsCount: 6,
    tests: [
      { id: 301, code: "CRE001", name: "Serum Creatinine", price: 200, tat: 4, department: "Biochemistry", sampleType: "Blood" },
      { id: 302, code: "URE001", name: "Blood Urea", price: 150, tat: 4, department: "Biochemistry", sampleType: "Blood" },
    ]
  },
]

const patients: Patient[] = [
  { id: "P001234", name: "John Doe", age: 45, gender: "Male", phone: "9876543210" },
  { id: "P001235", name: "Jane Smith", age: 32, gender: "Female", phone: "9876543211" },
  { id: "P001236", name: "Mike Johnson", age: 28, gender: "Male", phone: "9876543212" },
  { id: "P001237", name: "Sarah Wilson", age: 55, gender: "Female", phone: "9876543213" },
]

const doctors: Doctor[] = [
  { id: "D001", name: "Dr. Rajesh Kumar", department: "Cardiology" },
  { id: "D002", name: "Dr. Priya Sharma", department: "Internal Medicine" },
  { id: "D003", name: "Dr. Amit Singh", department: "General Practice" },
  { id: "D004", name: "Dr. Sunita Patel", department: "Pediatrics" },
]

export default function LabOrderEntry() {
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null)
  const [selectedTests, setSelectedTests] = useState<Test[]>([])
  const [selectedGroups, setSelectedGroups] = useState<TestGroup[]>([])
  const [sourceType, setSourceType] = useState("OPD")
  const [priority, setPriority] = useState("Routine")
  const [clinicalNotes, setClinicalNotes] = useState("")
  const [isPatientOpen, setIsPatientOpen] = useState(false)
  const [isDoctorOpen, setIsDoctorOpen] = useState(false)
  const [isTestsOpen, setIsTestsOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleTestSelection = (test: Test) => {
    if (selectedTests.find(t => t.id === test.id)) {
      setSelectedTests(selectedTests.filter(t => t.id !== test.id))
    } else {
      setSelectedTests([...selectedTests, test])
    }
  }

  const handleGroupSelection = (group: TestGroup) => {
    if (selectedGroups.find(g => g.id === group.id)) {
      setSelectedGroups(selectedGroups.filter(g => g.id !== group.id))
    } else {
      setSelectedGroups([...selectedGroups, group])
    }
  }

  const removeTest = (testId: number) => {
    setSelectedTests(selectedTests.filter(t => t.id !== testId))
  }

  const removeGroup = (groupId: number) => {
    setSelectedGroups(selectedGroups.filter(g => g.id !== groupId))
  }

  const calculateTotal = () => {
    const testsTotal = selectedTests.reduce((sum, test) => sum + test.price, 0)
    const groupsTotal = selectedGroups.reduce((sum, group) => sum + group.price, 0)
    return testsTotal + groupsTotal
  }

  const calculateMaxTAT = () => {
    const testsTAT = selectedTests.length > 0 ? Math.max(...selectedTests.map(t => t.tat)) : 0
    const groupsTAT = selectedGroups.length > 0 ? Math.max(...selectedGroups.map(g => g.tat)) : 0
    return Math.max(testsTAT, groupsTAT)
  }

  const generateOrderNumber = () => {
    const timestamp = Date.now()
    return `LAB${timestamp.toString().slice(-6)}`
  }

  const handleSubmitOrder = async () => {
    if (!selectedPatient) {
      toast({
        title: "Error",
        description: "Please select a patient",
        variant: "destructive"
      })
      return
    }

    if (!selectedDoctor) {
      toast({
        title: "Error",
        description: "Please select a referring doctor",
        variant: "destructive"
      })
      return
    }

    if (selectedTests.length === 0 && selectedGroups.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one test or test group",
        variant: "destructive"
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const orderNumber = generateOrderNumber()
      
      toast({
        title: "Success",
        description: `Lab order ${orderNumber} submitted successfully!`,
      })

      // Reset form
      setSelectedPatient(null)
      setSelectedDoctor(null)
      setSelectedTests([])
      setSelectedGroups([])
      setClinicalNotes("")
      setSourceType("OPD")
      setPriority("Routine")
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit lab order. Please try again.",
        variant: "destructive"
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSaveDraft = () => {
    toast({
      title: "Draft Saved",
      description: "Lab order saved as draft successfully",
    })
  }

  const handlePrintTRF = () => {
    if (!selectedPatient || (selectedTests.length === 0 && selectedGroups.length === 0)) {
      toast({
        title: "Error",
        description: "Please complete the order details before printing TRF",
        variant: "destructive"
      })
      return
    }
    
    toast({
      title: "TRF Generated",
      description: "Test Requisition Form is being printed...",
    })
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Lab Order Entry</h1>
          <p className="text-gray-600">Create new lab requisitions and test orders</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            View Order History
          </Button>
          <Button variant="outline" onClick={handlePrintTRF}>
            <Printer className="h-4 w-4 mr-2" />
            Print TRF
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Patient and Doctor Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2" />
                Patient & Doctor Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Select Patient *</Label>
                  <Popover open={isPatientOpen} onOpenChange={setIsPatientOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start">
                        {selectedPatient ? (
                          <div className="flex items-center">
                            <div>
                              <p className="font-medium">{selectedPatient.name}</p>
                              <p className="text-sm text-gray-500">{selectedPatient.id} • {selectedPatient.age}Y • {selectedPatient.gender}</p>
                            </div>
                          </div>
                        ) : (
                          "Search patient..."
                        )}
                        <Search className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0" align="start">
                      <Command>
                        <CommandInput placeholder="Search patient..." />
                        <CommandEmpty>No patient found.</CommandEmpty>
                        <CommandGroup>
                          {patients.map((patient) => (
                            <CommandItem 
                              key={patient.id}
                              onSelect={() => {
                                setSelectedPatient(patient)
                                setIsPatientOpen(false)
                              }}
                            >
                              <div>
                                <p className="font-medium">{patient.name}</p>
                                <p className="text-sm text-gray-500">{patient.id} • {patient.age}Y • {patient.gender} • {patient.phone}</p>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label>Referring Doctor *</Label>
                  <Popover open={isDoctorOpen} onOpenChange={setIsDoctorOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start">
                        {selectedDoctor ? (
                          <div>
                            <p className="font-medium">{selectedDoctor.name}</p>
                            <p className="text-sm text-gray-500">{selectedDoctor.department}</p>
                          </div>
                        ) : (
                          "Select doctor..."
                        )}
                        <Search className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0" align="start">
                      <Command>
                        <CommandInput placeholder="Search doctor..." />
                        <CommandEmpty>No doctor found.</CommandEmpty>
                        <CommandGroup>
                          {doctors.map((doctor) => (
                            <CommandItem 
                              key={doctor.id}
                              onSelect={() => {
                                setSelectedDoctor(doctor)
                                setIsDoctorOpen(false)
                              }}
                            >
                              <div>
                                <p className="font-medium">{doctor.name}</p>
                                <p className="text-sm text-gray-500">{doctor.department}</p>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Source</Label>
                  <Select value={sourceType} onValueChange={setSourceType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="OPD">OPD</SelectItem>
                      <SelectItem value="IPD">IPD</SelectItem>
                      <SelectItem value="Emergency">Emergency</SelectItem>
                      <SelectItem value="Walk-in">Walk-in</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Routine">Routine</SelectItem>
                      <SelectItem value="Urgent">Urgent</SelectItem>
                      <SelectItem value="STAT">STAT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Test Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Test Selection</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Dialog open={isTestsOpen} onOpenChange={setIsTestsOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Tests or Groups
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Select Tests and Groups</DialogTitle>
                    <DialogDescription>
                      Choose individual tests or test groups for this order
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Individual Tests */}
                    <div className="space-y-4">
                      <h3 className="font-semibold">Individual Tests</h3>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {availableTests.map((test) => (
                          <div key={test.id} className="flex items-center space-x-2 p-3 border rounded hover:bg-gray-50">
                            <Checkbox
                              checked={selectedTests.find(t => t.id === test.id) !== undefined}
                              onCheckedChange={() => handleTestSelection(test)}
                            />
                            <div className="flex-1">
                              <p className="font-medium">{test.name}</p>
                              <p className="text-sm text-gray-500">
                                {test.code} • ₹{test.price} • {test.tat}h TAT • {test.department}
                              </p>
                              <Badge variant="outline" className="text-xs mt-1">
                                {test.sampleType}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Test Groups */}
                    <div className="space-y-4">
                      <h3 className="font-semibold">Test Groups/Profiles</h3>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {availableGroups.map((group) => (
                          <div key={group.id} className="flex items-center space-x-2 p-3 border rounded hover:bg-gray-50">
                            <Checkbox
                              checked={selectedGroups.find(g => g.id === group.id) !== undefined}
                              onCheckedChange={() => handleGroupSelection(group)}
                            />
                            <div className="flex-1">
                              <p className="font-medium">{group.name}</p>
                              <p className="text-sm text-gray-500">
                                {group.code} • ₹{group.price} • {group.testsCount} tests • {group.tat}h TAT
                              </p>
                              <div className="flex flex-wrap gap-1 mt-2">
                                {group.tests.slice(0, 3).map((test, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {test.name}
                                  </Badge>
                                ))}
                                {group.tests.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{group.tests.length - 3} more
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2 pt-4">
                    <Button variant="outline" onClick={() => setIsTestsOpen(false)}>
                      Done
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              {/* Selected Tests Display */}
              {(selectedTests.length > 0 || selectedGroups.length > 0) && (
                <div className="space-y-3">
                  <h4 className="font-medium">Selected Tests:</h4>
                  
                  {selectedTests.map((test) => (
                    <div key={test.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div>
                        <p className="font-medium">{test.name}</p>
                        <p className="text-sm text-gray-600">{test.code} • {test.department}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="text-right">
                          <p className="font-medium">₹{test.price}</p>
                          <p className="text-sm text-gray-500">{test.tat}h TAT</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => removeTest(test.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}

                  {selectedGroups.map((group) => (
                    <div key={group.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div>
                        <p className="font-medium">{group.name}</p>
                        <p className="text-sm text-gray-600">{group.code} ({group.testsCount} tests)</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {group.tests.slice(0, 2).map((test, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {test.name}
                            </Badge>
                          ))}
                          {group.tests.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{group.tests.length - 2} more
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="text-right">
                          <p className="font-medium">₹{group.price}</p>
                          <p className="text-sm text-gray-500">{group.tat}h TAT</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => removeGroup(group.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-2">
                <Label>Clinical Notes</Label>
                <Textarea 
                  placeholder="Any relevant clinical history or notes..." 
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Order Summary */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Order Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Patient:</span>
                  <span className="text-sm font-medium">
                    {selectedPatient ? selectedPatient.name : "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Doctor:</span>
                  <span className="text-sm font-medium">
                    {selectedDoctor ? selectedDoctor.name : "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Source:</span>
                  <Badge variant="outline">{sourceType}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Priority:</span>
                  <Badge variant={priority === 'STAT' ? 'destructive' : priority === 'Urgent' ? 'secondary' : 'default'}>
                    {priority}
                  </Badge>
                </div>
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Individual Tests:</span>
                  <span className="text-sm font-medium">{selectedTests.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Test Groups:</span>
                  <span className="text-sm font-medium">{selectedGroups.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Total Amount:</span>
                  <span className="text-lg font-bold text-red-600">₹{calculateTotal()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Estimated TAT:</span>
                  <Badge className="bg-orange-100 text-orange-800">
                    <Clock className="h-3 w-3 mr-1" />
                    {calculateMaxTAT()}h
                  </Badge>
                </div>
              </div>

              <div className="pt-4 space-y-2">
                <Button 
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={handleSubmitOrder}
                  disabled={!selectedPatient || !selectedDoctor || (selectedTests.length === 0 && selectedGroups.length === 0) || isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Generate TRF & Submit Order
                    </>
                  )}
                </Button>
                <Button variant="outline" className="w-full" onClick={handleSaveDraft}>
                  Save as Draft
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Completion Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              {calculateMaxTAT() > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Expected Completion:</span>
                    <span className="font-medium">
                      {new Date(Date.now() + calculateMaxTAT() * 60 * 60 * 1000).toLocaleDateString("en-IN", {
                        weekday: "short",
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500">
                    Based on {calculateMaxTAT()} hours TAT for selected tests
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-red-600 h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${Math.min((selectedTests.length + selectedGroups.length) * 10, 100)}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

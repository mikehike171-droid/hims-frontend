"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { useState } from "react"

export default function TestDetailsPage() {
  const router = useRouter()

  const [formData, setFormData] = useState({
    refCustomer: "",
    nursingStation: "3A NURSING STATION",
    wardNo: "3A WARD",
    bedNo: "A303",
    resultNumber: "",
    resultDate: "",
    labCode: "",
    notes: "",
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const mockTestResults = [
    {
      testCode: "SR0019",
      testDescription: "WIDAL",
      investigationCode: "SER021",
      investigation: 'S.PARATYPHI "BH "',
      value: "1:80",
      unit: "",
      lowerLimit: "",
      upperLimit: "",
      defaultValue: "1:20 Dilution",
      valueType: "FV",
    },
    {
      testCode: "SR0027",
      testDescription: "SERUM CREATININE",
      investigationCode: "BIO018",
      investigation: "SERUM CREATININE",
      value: "",
      unit: "mg/dl",
      lowerLimit: "0.60",
      upperLimit: "1.25",
      defaultValue: "",
      valueType: "NV",
    },
    {
      testCode: "SR0067",
      testDescription: "SERUM ELECTROLYTES",
      investigationCode: "BIO019",
      investigation: "SERUM SODIUM",
      value: "",
      unit: "mmol/l",
      lowerLimit: "135.00",
      upperLimit: "146.00",
      defaultValue: "",
      valueType: "NV",
    },
    {
      testCode: "SR0067",
      testDescription: "SERUM ELECTROLYTES",
      investigationCode: "BIO038",
      investigation: "SERUM POTASSIUM",
      value: "",
      unit: "mmol/l",
      lowerLimit: "3.50",
      upperLimit: "5.50",
      defaultValue: "",
      valueType: "NV",
    },
    {
      testCode: "SR0067",
      testDescription: "SERUM ELECTROLYTES",
      investigationCode: "BIO040",
      investigation: "SERUM CHLORIDE",
      value: "",
      unit: "mmol/l",
      lowerLimit: "98.00",
      upperLimit: "107.00",
      defaultValue: "",
      valueType: "NV",
    },
    {
      testCode: "SR0030",
      testDescription: "COMPLETE URINE EXAMINATION",
      investigationCode: "CL024",
      investigation: "PHYSICAL EXAMINATION",
      value: "",
      unit: "",
      lowerLimit: "",
      upperLimit: "",
      defaultValue: "",
      valueType: "HD",
    },
    {
      testCode: "SR0030",
      testDescription: "COMPLETE URINE EXAMINATION",
      investigationCode: "CL025",
      investigation: "QUANTITY",
      value: "",
      unit: "ml",
      lowerLimit: "",
      upperLimit: "",
      defaultValue: "",
      valueType: "FV",
    },
    {
      testCode: "SR0030",
      testDescription: "COMPLETE URINE EXAMINATION",
      investigationCode: "CL002",
      investigation: "COLOUR",
      value: "",
      unit: "",
      lowerLimit: "",
      upperLimit: "",
      defaultValue: "P.YELLOW",
      valueType: "OL",
    },
    {
      testCode: "SR0030",
      testDescription: "COMPLETE URINE EXAMINATION",
      investigationCode: "CL027",
      investigation: "APPEARANCE",
      value: "",
      unit: "",
      lowerLimit: "",
      upperLimit: "",
      defaultValue: "CLEAR",
      valueType: "OL",
    },
    {
      testCode: "SR0030",
      testDescription: "COMPLETE URINE EXAMINATION",
      investigationCode: "CL028",
      investigation: "REACTION",
      value: "",
      unit: "",
      lowerLimit: "",
      upperLimit: "",
      defaultValue: "ACIDIC",
      valueType: "OL",
    },
    {
      testCode: "SR0030",
      testDescription: "COMPLETE URINE EXAMINATION",
      investigationCode: "CL029",
      investigation: "SPECIFIC GRAVITY",
      value: "",
      unit: "",
      lowerLimit: "",
      upperLimit: "",
      defaultValue: "1.005-1.020",
      valueType: "OL",
    },
  ]

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b p-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()} className="flex items-center space-x-2">
            <ArrowLeft className="h-4 w-4" />
            <span>Back</span>
          </Button>
          <h1 className="text-lg font-semibold">Report Regular</h1>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Patient Details */}
          <fieldset className="border border-gray-300 rounded-lg p-4 bg-white">
            <legend className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium">PATIENT DETAILS</legend>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              <div>
                <Label>MR Number</Label>
                <Input defaultValue="MR250002234" readOnly className="bg-gray-50" />
              </div>
              <div>
                <Label>Ref Customer</Label>
                <Input
                  value={formData.refCustomer}
                  onChange={(e) => handleInputChange("refCustomer", e.target.value)}
                />
              </div>
              <div>
                <Label>IP Number</Label>
                <Input defaultValue="PHS-IP2500005202" readOnly className="bg-gray-50" />
              </div>
              <div>
                <Label>Age</Label>
                <Input defaultValue="32 Y:0 M:0 Da" readOnly className="bg-gray-50" />
              </div>
              <div>
                <Label>Name</Label>
                <Input defaultValue="THATAPUDI PRUDHVI RAJ" readOnly className="bg-gray-50" />
              </div>
              <div>
                <Label>Sex</Label>
                <Input defaultValue="M" readOnly className="bg-gray-50" />
              </div>
              <div>
                <Label>Patient Category</Label>
                <Select defaultValue="insurance">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="insurance">INSURANCE</SelectItem>
                    <SelectItem value="cash">CASH</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Nursing Station/Floor</Label>
                <Input
                  value={formData.nursingStation}
                  onChange={(e) => handleInputChange("nursingStation", e.target.value)}
                />
              </div>
              <div>
                <Label>Bed Category</Label>
                <Select defaultValue="sharing">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sharing">SHARING</SelectItem>
                    <SelectItem value="private">PRIVATE</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Ward No</Label>
                <Input value={formData.wardNo} onChange={(e) => handleInputChange("wardNo", e.target.value)} />
              </div>
              <div>
                <Label>Tariff Category</Label>
                <Select defaultValue="hospital">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hospital">Hospital</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Bed No</Label>
                <Input value={formData.bedNo} onChange={(e) => handleInputChange("bedNo", e.target.value)} />
              </div>
              <div>
                <Label>Attachments</Label>
                <div className="flex items-center space-x-2">
                  <Input type="file" className="hidden" id="attachments" />
                  <Button variant="outline" size="sm" onClick={() => document.getElementById("attachments")?.click()}>
                    Choose Files
                  </Button>
                  <span className="text-sm text-gray-500">No file chosen</span>
                </div>
              </div>
              <div>
                <Label>Ordered By</Label>
                <Select defaultValue="doctor1">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="doctor1">VISHNUCHAND ZAMPANI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="sm:col-span-2">
                <Label>Reported To</Label>
                <Select defaultValue="doctor1">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="doctor1">VISHNUCHAND ZAMPANI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </fieldset>

          {/* Result Details */}
          <fieldset className="border border-gray-300 rounded-lg p-4 bg-white">
            <legend className="bg-gray-100 text-black px-3 py-1 rounded text-sm font-medium">RESULT</legend>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              <div>
                <Label>Number</Label>
                <Input
                  value={formData.resultNumber}
                  onChange={(e) => handleInputChange("resultNumber", e.target.value)}
                />
              </div>
              <div>
                <Label>Date</Label>
                <Input
                  type="date"
                  value={formData.resultDate}
                  onChange={(e) => handleInputChange("resultDate", e.target.value)}
                />
              </div>
              <div>
                <Label>Lab Code</Label>
                <Input value={formData.labCode} onChange={(e) => handleInputChange("labCode", e.target.value)} />
              </div>
              <div>
                <Label>Lab Dept</Label>
                <Select defaultValue="biochemistry">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="biochemistry">BIOCHEMISTRY</SelectItem>
                    <SelectItem value="hematology">HEMATOLOGY</SelectItem>
                    <SelectItem value="microbiology">MICROBIOLOGY</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Sample Number</Label>
                <Input defaultValue="PHS-LB25-031323" readOnly className="bg-gray-50" />
              </div>
              <div>
                <Label>Sample Date</Label>
                <Input defaultValue="22/09/2025 12:54:09" readOnly className="bg-gray-50" />
              </div>
              <div className="sm:col-span-2">
                <Label>Acceptance Number</Label>
                <Input defaultValue="PHS-SA25-028569" readOnly className="bg-gray-50" />
              </div>
            </div>
          </fieldset>
        </div>

        {/* Test Results Table */}
        <div className="bg-white border border-gray-300 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 text-black">
                <tr>
                  <th className="px-3 py-2 text-left border-r border-blue-500">TEST CODE</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">TEST DESCRIPTION</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">INVESTIGATION CODE</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">INVESTIGATION</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">VALUE</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">UNIT</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">LOWER LIMIT</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">UPPER LIMIT</th>
                  <th className="px-3 py-2 text-left border-r border-blue-500">DEFAULT VALUE</th>
                  <th className="px-3 py-2 text-left">VALUE TYPE</th>
                </tr>
              </thead>
              <tbody>
                {mockTestResults.map((result, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="px-3 py-2 border-r">{result.testCode}</td>
                    <td className="px-3 py-2 border-r">{result.testDescription}</td>
                    <td className="px-3 py-2 border-r">{result.investigationCode}</td>
                    <td className="px-3 py-2 border-r">{result.investigation}</td>
                    <td className="px-3 py-2 border-r">
                      {result.valueType === "FV" && result.investigationCode === "CL025" ? (
                        <Select>
                          <SelectTrigger className="h-8">
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="50ml">50ml</SelectItem>
                            <SelectItem value="100ml">100ml</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          defaultValue={result.value}
                          className="h-8"
                          placeholder={result.valueType === "HD" ? "" : "Enter value"}
                          disabled={result.valueType === "HD"}
                        />
                      )}
                    </td>
                    <td className="px-3 py-2 border-r">{result.unit}</td>
                    <td className="px-3 py-2 border-r">{result.lowerLimit}</td>
                    <td className="px-3 py-2 border-r">{result.upperLimit}</td>
                    <td className="px-3 py-2 border-r">{result.defaultValue}</td>
                    <td className="px-3 py-2">{result.valueType}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Notes Section */}
        <div className="bg-white p-4 border border-gray-300 rounded-lg">
          <Label>Note</Label>
          <Textarea
            className="mt-2"
            rows={4}
            placeholder="Enter notes..."
            value={formData.notes}
            onChange={(e) => handleInputChange("notes", e.target.value)}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 justify-center bg-white p-4 border border-gray-300 rounded-lg">
          <Button>Save</Button>
          <Button variant="outline">Clear</Button>
          <Button variant="outline">print</Button>
          <Button variant="outline">Combaine Print</Button>
          <Button variant="outline">Print With Header</Button>
          <Button variant="outline">Print With Header1</Button>
          <Button variant="secondary" onClick={() => router.back()}>
            Close
          </Button>
        </div>
      </div>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { TestTube, User, Calendar, MapPin, Printer, CheckCircle, Clock, Search, Filter, RefreshCw, Barcode } from 'lucide-react'
import { useToast } from "@/hooks/use-toast"

interface Sample {
  id: number
  orderNo: string
  patientName: string
  patientId: string
  tests: string[]
  sampleType: string
  containerType: string
  priority: string
  status: string
  orderTime: string
  estimatedTAT: string
  collectedBy?: string
  collectionTime?: string
  collectionLocation?: string
  barcode?: string
}

const initialSampleData: Sample[] = [
  {
    id: 1,
    orderNo: "LAB001234",
    patientName: "John Doe",
    patientId: "P001234",
    tests: ["Hemoglobin", "Blood Sugar"],
    sampleType: "Blood",
    containerType: "EDTA, Fluoride",
    priority: "Routine",
    status: "Pending Collection",
    orderTime: "09:30 AM",
    estimatedTAT: "2 hours"
  },
  {
    id: 2,
    orderNo: "LAB001235",
    patientName: "Jane Smith",
    patientId: "P001235",
    tests: ["CBC", "LFT"],
    sampleType: "Blood",
    containerType: "EDTA, Plain",
    priority: "Urgent",
    status: "Pending Collection",
    orderTime: "10:15 AM",
    estimatedTAT: "4 hours"
  },
  {
    id: 3,
    orderNo: "LAB001236",
    patientName: "Mike Johnson",
    patientId: "P001236",
    tests: ["Urine Routine"],
    sampleType: "Urine",
    containerType: "Sterile Container",
    priority: "STAT",
    status: "Collected",
    orderTime: "08:45 AM",
    estimatedTAT: "1 hour",
    collectedBy: "Nurse Priya",
    collectionTime: "11:30 AM",
    collectionLocation: "OPD Collection Room",
    barcode: "BC001236"
  },
  {
    id: 4,
    orderNo: "LAB001237",
    patientName: "Sarah Wilson",
    patientId: "P001237",
    tests: ["Thyroid Profile", "Vitamin D"],
    sampleType: "Blood",
    containerType: "Plain",
    priority: "Routine",
    status: "Pending Collection",
    orderTime: "11:00 AM",
    estimatedTAT: "6 hours"
  }
]

const phlebotomists = [
  { id: 1, name: "Nurse Priya", department: "Lab Collection" },
  { id: 2, name: "Tech Amit", department: "Lab Collection" },
  { id: 3, name: "Nurse Sunita", department: "Lab Collection" },
  { id: 4, name: "Tech Rajesh", department: "Lab Collection" },
]

const collectionLocations = [
  "OPD Collection Room",
  "IPD Ward 1",
  "IPD Ward 2",
  "Emergency Department",
  "ICU",
  "Patient Room - Bedside",
  "Pediatric Ward",
  "Maternity Ward"
]

export default function SampleCollectionConsole() {
  const [sampleData, setSampleData] = useState<Sample[]>(initialSampleData)
  const [selectedSamples, setSelectedSamples] = useState<number[]>([])
  const [isCollectionDialogOpen, setIsCollectionDialogOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [selectedPhlebotomist, setSelectedPhlebotomist] = useState("")
  const [selectedLocation, setSelectedLocation] = useState("")
  const [collectionNotes, setCollectionNotes] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const filteredData = sampleData.filter(sample => {
    const matchesSearch = sample.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.orderNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.patientId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || sample.status === statusFilter
    const matchesPriority = priorityFilter === "all" || sample.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  const handleSampleSelection = (sampleId: number) => {
    if (selectedSamples.includes(sampleId)) {
      setSelectedSamples(selectedSamples.filter(id => id !== sampleId))
    } else {
      setSelectedSamples([...selectedSamples, sampleId])
    }
  }

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const pendingSamples = filteredData.filter(s => s.status === "Pending Collection").map(s => s.id)
      setSelectedSamples(pendingSamples)
    } else {
      setSelectedSamples([])
    }
  }

  const handleBulkCollection = async () => {
    if (!selectedPhlebotomist || !selectedLocation) {
      toast({
        title: "Error",
        description: "Please select phlebotomist and collection location",
        variant: "destructive"
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500))

      const currentTime = new Date().toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
      })

      setSampleData(prev => prev.map(sample => {
        if (selectedSamples.includes(sample.id)) {
          return {
            ...sample,
            status: "Collected",
            collectedBy: phlebotomists.find(p => p.name === selectedPhlebotomist)?.name || selectedPhlebotomist,
            collectionTime: currentTime,
            collectionLocation: selectedLocation,
            barcode: `BC${sample.orderNo.slice(-6)}`
          }
        }
        return sample
      }))

      toast({
        title: "Success",
        description: `${selectedSamples.length} samples marked as collected successfully`,
      })

      setSelectedSamples([])
      setIsCollectionDialogOpen(false)
      setSelectedPhlebotomist("")
      setSelectedLocation("")
      setCollectionNotes("")

    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update sample status. Please try again.",
        variant: "destructive"
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const generateBarcode = (sample: Sample) => {
    const barcode = `BC${sample.orderNo.slice(-6)}`
    
    setSampleData(prev => prev.map(s => 
      s.id === sample.id ? { ...s, barcode } : s
    ))

    toast({
      title: "Barcode Generated",
      description: `Barcode ${barcode} generated for ${sample.patientName}`,
    })
  }

  const handleQuickCollection = async (sample: Sample) => {
    setSelectedSamples([sample.id])
    setIsCollectionDialogOpen(true)
  }

  const handleRefresh = async () => {
    toast({
      title: "Refreshing",
      description: "Updating sample collection queue...",
    })
    
    // Simulate refresh
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    toast({
      title: "Refreshed",
      description: "Sample collection queue updated successfully",
    })
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "STAT": return "destructive"
      case "Urgent": return "secondary"
      default: return "outline"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Collected": return "text-green-600 bg-green-50 border-green-200"
      case "Pending Collection": return "text-orange-600 bg-orange-50 border-orange-200"
      case "In Transit": return "text-blue-600 bg-blue-50 border-blue-200"
      default: return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const stats = {
    pendingCollection: filteredData.filter(s => s.status === "Pending Collection").length,
    collectedToday: filteredData.filter(s => s.status === "Collected").length,
    statPriority: filteredData.filter(s => s.priority === "STAT").length,
    totalSamples: filteredData.length
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sample Collection Console</h1>
          <p className="text-gray-600">Manage sample collection and barcode generation</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button 
            className="bg-red-600 hover:bg-red-700"
            disabled={selectedSamples.length === 0}
            onClick={() => setIsCollectionDialogOpen(true)}
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Mark as Collected ({selectedSamples.length})
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by patient name, order number, or patient ID..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Pending Collection">Pending Collection</SelectItem>
                <SelectItem value="Collected">Collected</SelectItem>
                <SelectItem value="In Transit">In Transit</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="STAT">STAT</SelectItem>
                <SelectItem value="Urgent">Urgent</SelectItem>
                <SelectItem value="Routine">Routine</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Collection Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Collection</p>
                <p className="text-2xl font-bold text-orange-600">{stats.pendingCollection}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Collected Today</p>
                <p className="text-2xl font-bold text-green-600">{stats.collectedToday}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">STAT Priority</p>
                <p className="text-2xl font-bold text-red-600">{stats.statPriority}</p>
              </div>
              <TestTube className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Samples</p>
                <p className="text-2xl font-bold text-blue-600">{stats.totalSamples}</p>
              </div>
              <TestTube className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sample Collection Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <TestTube className="h-5 w-5 mr-2" />
              Sample Collection Queue ({filteredData.length})
            </div>
            <Badge variant="outline">
              {selectedSamples.length} selected
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">
                  <Checkbox
                    checked={selectedSamples.length === filteredData.filter(s => s.status === "Pending Collection").length && filteredData.filter(s => s.status === "Pending Collection").length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                </TableHead>
                <TableHead>Order No.</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Tests</TableHead>
                <TableHead>Sample Type</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Order Time</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.map((sample) => (
                <TableRow key={sample.id} className="hover:bg-gray-50">
                  <TableCell>
                    <Checkbox
                      checked={selectedSamples.includes(sample.id)}
                      onCheckedChange={() => handleSampleSelection(sample.id)}
                      disabled={sample.status !== "Pending Collection"}
                    />
                  </TableCell>
                  <TableCell className="font-medium">{sample.orderNo}</TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{sample.patientName}</p>
                      <p className="text-sm text-gray-500">{sample.patientId}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      {sample.tests.map((test, index) => (
                        <Badge key={index} variant="outline" className="text-xs mr-1">
                          {test}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="text-sm font-medium">{sample.sampleType}</p>
                      <p className="text-xs text-gray-500">{sample.containerType}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={getPriorityColor(sample.priority)}>
                      {sample.priority}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(sample.status)}>
                      {sample.status}
                    </Badge>
                    {sample.collectedBy && (
                      <p className="text-xs text-gray-500 mt-1">
                        By: {sample.collectedBy}
                      </p>
                    )}
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="text-sm">{sample.orderTime}</p>
                      <p className="text-xs text-gray-500">TAT: {sample.estimatedTAT}</p>
                      {sample.collectionTime && (
                        <p className="text-xs text-green-600">
                          Collected: {sample.collectionTime}
                        </p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-1">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => generateBarcode(sample)}
                        disabled={!!sample.barcode}
                      >
                        {sample.barcode ? (
                          <Barcode className="h-3 w-3" />
                        ) : (
                          <Printer className="h-3 w-3" />
                        )}
                      </Button>
                      {sample.status === "Pending Collection" && (
                        <Button 
                          size="sm" 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => handleQuickCollection(sample)}
                        >
                          <CheckCircle className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Collection Dialog */}
      <Dialog open={isCollectionDialogOpen} onOpenChange={setIsCollectionDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Mark Samples as Collected</DialogTitle>
            <DialogDescription>
              Complete the collection details for {selectedSamples.length} sample(s)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Collection Location *</Label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  {collectionLocations.map((location, index) => (
                    <SelectItem key={index} value={location}>
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Phlebotomist *</Label>
              <Select value={selectedPhlebotomist} onValueChange={setSelectedPhlebotomist}>
                <SelectTrigger>
                  <SelectValue placeholder="Select phlebotomist" />
                </SelectTrigger>
                <SelectContent>
                  {phlebotomists.map((person) => (
                    <SelectItem key={person.id} value={person.name}>
                      {person.name} - {person.department}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Collection Notes (Optional)</Label>
              <Input 
                placeholder="Any additional notes..." 
                value={collectionNotes}
                onChange={(e) => setCollectionNotes(e.target.value)}
              />
            </div>
            
            {/* Selected samples preview */}
            <div className="space-y-2">
              <Label>Selected Samples:</Label>
              <div className="max-h-32 overflow-y-auto border rounded p-2">
                {selectedSamples.map(sampleId => {
                  const sample = sampleData.find(s => s.id === sampleId)
                  return sample ? (
                    <div key={sampleId} className="text-sm py-1">
                      {sample.orderNo} - {sample.patientName}
                    </div>
                  ) : null
                })}
              </div>
            </div>
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => {
              setIsCollectionDialogOpen(false)
              setSelectedPhlebotomist("")
              setSelectedLocation("")
              setCollectionNotes("")
            }}>
              Cancel
            </Button>
            <Button 
              className="bg-green-600 hover:bg-green-700" 
              onClick={handleBulkCollection}
              disabled={isSubmitting || !selectedPhlebotomist || !selectedLocation}
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Processing...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Mark as Collected
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

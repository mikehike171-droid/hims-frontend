"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TestTube, Clock, FileCheck, AlertTriangle, TrendingUp, Calendar, Users, Activity, CheckCircle, XCircle, AlertCircle, RefreshCw } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import Link from "next/link"
import PrivateRoute from "@/components/auth/PrivateRoute"

const testVolumeData = [
  { day: 'Mon', tests: 45, completed: 42 },
  { day: 'Tue', tests: 52, completed: 48 },
  { day: 'Wed', tests: 38, completed: 35 },
  { day: 'Thu', tests: 61, completed: 58 },
  { day: 'Fri', tests: 55, completed: 52 },
  { day: 'Sat', tests: 42, completed: 40 },
  { day: 'Sun', tests: 28, completed: 26 },
]

const abnormalityData = [
  { test: 'CBC', normal: 85, abnormal: 15, total: 100 },
  { test: 'LFT', normal: 78, abnormal: 22, total: 100 },
  { test: 'KFT', normal: 92, abnormal: 8, total: 100 },
  { test: 'Lipid', normal: 65, abnormal: 35, total: 100 },
  { test: 'Thyroid', normal: 88, abnormal: 12, total: 100 },
]

const criticalAlerts = [
  { 
    id: 1,
    patient: "John Doe", 
    patientId: "P001234",
    test: "Creatinine", 
    value: "8.5 mg/dL", 
    normalRange: "0.7-1.3 mg/dL",
    time: "10 mins ago", 
    status: "critical",
    orderNo: "LAB001234"
  },
  { 
    id: 2,
    patient: "Jane Smith", 
    patientId: "P001235",
    test: "Hemoglobin", 
    value: "4.2 g/dL", 
    normalRange: "12.0-15.5 g/dL",
    time: "25 mins ago", 
    status: "critical",
    orderNo: "LAB001235"
  },
  { 
    id: 3,
    patient: "Mike Johnson", 
    patientId: "P001236",
    test: "Potassium", 
    value: "6.8 mEq/L", 
    normalRange: "3.5-5.0 mEq/L",
    time: "1 hour ago", 
    status: "urgent",
    orderNo: "LAB001236"
  },
]

const delayedTAT = [
  { 
    id: 1,
    orderNo: "LAB001237", 
    patient: "Sarah Wilson", 
    patientId: "P001237",
    tests: "CBC, LFT", 
    delay: "2 hours", 
    department: "Biochemistry",
    expectedTime: "2:00 PM",
    currentTime: "4:00 PM"
  },
  { 
    id: 2,
    orderNo: "LAB001238", 
    patient: "David Brown", 
    patientId: "P001238",
    tests: "Thyroid Profile", 
    delay: "4 hours", 
    department: "Immunology",
    expectedTime: "1:00 PM",
    currentTime: "5:00 PM"
  },
]

const recentOrders = [
  {
    id: 1,
    orderNo: "LAB001239",
    patient: "Alice Cooper",
    patientId: "P001239",
    tests: 3,
    status: "Processing",
    time: "11:30 AM",
    priority: "Routine"
  },
  {
    id: 2,
    orderNo: "LAB001240",
    patient: "Bob Wilson",
    patientId: "P001240",
    tests: 5,
    status: "Collected",
    time: "11:45 AM",
    priority: "Urgent"
  },
  {
    id: 3,
    orderNo: "LAB001241",
    patient: "Carol Davis",
    patientId: "P001241",
    tests: 2,
    status: "Pending Collection",
    time: "12:00 PM",
    priority: "STAT"
  }
]

export default function LabDashboard() {
  const [activeTab, setActiveTab] = useState("all")
  const [isLoading, setIsLoading] = useState(false)
  const [lastRefresh, setLastRefresh] = useState(new Date())

  const handleRefresh = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    setLastRefresh(new Date())
    setIsLoading(false)
  }

  const handleAlertAction = (alertId: number, action: string) => {
    console.log(`Alert ${alertId}: ${action}`)
    // Here you would typically make an API call to handle the alert
  }

  const stats = [
    {
      title: "Samples Collected Today",
      value: "247",
      change: "+12%",
      icon: TestTube,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      trend: "up"
    },
    {
      title: "Tests Pending Validation",
      value: "23",
      change: "-5%",
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      trend: "down"
    },
    {
      title: "Reports Released",
      value: "189",
      change: "+8%",
      icon: FileCheck,
      color: "text-green-600",
      bgColor: "bg-green-50",
      trend: "up"
    },
    {
      title: "Abnormal Results Today",
      value: "45",
      change: "+3%",
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-50",
      trend: "up"
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Processing": return "bg-blue-100 text-blue-800"
      case "Collected": return "bg-green-100 text-green-800"
      case "Pending Collection": return "bg-orange-100 text-orange-800"
      case "Completed": return "bg-gray-100 text-gray-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "STAT": return "bg-red-100 text-red-800"
      case "Urgent": return "bg-orange-100 text-orange-800"
      case "Routine": return "bg-blue-100 text-blue-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <PrivateRoute modulePath="admin/lab" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Lab Dashboard</h1>
          <p className="text-gray-600">Laboratory Management Overview</p>
          <p className="text-sm text-gray-500">Last updated: {lastRefresh.toLocaleTimeString()}</p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="outline" 
            onClick={handleRefresh}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            {isLoading ? 'Refreshing...' : 'Refresh'}
          </Button>
          <Link href="/lab/orders">
            <Button className="bg-red-600 hover:bg-red-700">
              <TestTube className="h-4 w-4 mr-2" />
              New Lab Order
            </Button>
          </Link>
        </div>
      </div>

      {/* Tab Filters */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="opd">OPD</TabsTrigger>
          <TabsTrigger value="ipd">IPD</TabsTrigger>
          <TabsTrigger value="emergency">Emergency</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <Card key={stat.title} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <p className={`text-sm flex items-center ${
                        stat.trend === 'up' ? "text-green-600" : "text-red-600"
                      }`}>
                        {stat.change} from yesterday
                      </p>
                    </div>
                    <div className={`h-12 w-12 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                      <stat.icon className={`h-6 w-6 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Test Volume Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
                  Test Volume (Last 7 Days)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={testVolumeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Line 
                      type="monotone" 
                      dataKey="tests" 
                      stroke="#dc2626" 
                      strokeWidth={2}
                      name="Total Tests"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="completed" 
                      stroke="#16a34a" 
                      strokeWidth={2}
                      name="Completed"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Abnormality Rate Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2 text-orange-600" />
                  Abnormality Rate by Test Type
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={abnormalityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="test" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="normal" fill="#10b981" name="Normal" />
                    <Bar dataKey="abnormal" fill="#f59e0b" name="Abnormal" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Alerts and Recent Orders */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Critical Value Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-red-600">
                  <div className="flex items-center">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    Critical Value Alerts
                  </div>
                  <Badge variant="destructive">{criticalAlerts.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {criticalAlerts.map((alert) => (
                    <div key={alert.id} className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-full ${
                          alert.status === 'critical' ? 'bg-red-100' : 'bg-orange-100'
                        }`}>
                          {alert.status === 'critical' ? (
                            <XCircle className="h-4 w-4 text-red-600" />
                          ) : (
                            <AlertCircle className="h-4 w-4 text-orange-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{alert.patient}</p>
                          <p className="text-sm text-gray-600">{alert.test}: <span className="font-semibold">{alert.value}</span></p>
                          <p className="text-xs text-gray-500">Normal: {alert.normalRange}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={alert.status === 'critical' ? 'destructive' : 'secondary'}>
                          {alert.status.toUpperCase()}
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">{alert.time}</p>
                        <div className="flex space-x-1 mt-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleAlertAction(alert.id, 'acknowledge')}
                          >
                            Ack
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleAlertAction(alert.id, 'call')}
                          >
                            Call
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Orders */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <FileCheck className="h-5 w-5 mr-2 text-blue-600" />
                    Recent Orders
                  </div>
                  <Link href="/lab/orders">
                    <Button variant="outline" size="sm">View All</Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div>
                        <p className="font-medium text-gray-900">{order.orderNo}</p>
                        <p className="text-sm text-gray-600">{order.patient} ({order.patientId})</p>
                        <p className="text-sm text-gray-500">{order.tests} tests • {order.time}</p>
                      </div>
                      <div className="text-right space-y-2">
                        <Badge className={getStatusColor(order.status)}>
                          {order.status}
                        </Badge>
                        <Badge className={getPriorityColor(order.priority)} variant="outline">
                          {order.priority}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Delayed TAT */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-orange-600">
                <Clock className="h-5 w-5 mr-2" />
                Delayed TAT ({delayedTAT.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {delayedTAT.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{item.orderNo}</p>
                      <p className="text-sm text-gray-600">{item.patient} ({item.patientId})</p>
                      <p className="text-sm text-gray-500">{item.tests}</p>
                      <p className="text-xs text-gray-500">Expected: {item.expectedTime} | Current: {item.currentTime}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                        Delayed by {item.delay}
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">{item.department}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  TestTube,
  Search,
  Save,
  Send,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  Printer,
  Plus,
  Trash2,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface TestResult {
  id: number
  testCode: string
  testName: string
  result: string
  units: string
  referenceRange: string
  status: "Normal" | "Abnormal" | "Critical" | "Pending"
  flags: string[]
  notes: string
}

interface SampleForTesting {
  id: number
  sampleId: string
  orderNo: string
  patientName: string
  patientId: string
  age: number
  gender: string
  doctor: string
  department: string
  collectionDate: string
  receivedDate: string
  priority: string
  status: string
  tests: TestResult[]
  clinicalHistory: string
  currentUser?: string
  entryDate?: string
}

const initialSampleData: SampleForTesting[] = [
  {
    id: 1,
    sampleId: "S001234",
    orderNo: "LAB001234",
    patientName: "John Doe",
    patientId: "P001234",
    age: 45,
    gender: "Male",
    doctor: "Dr. Rajesh Kumar",
    department: "Cardiology",
    collectionDate: "2024-01-08 10:15 AM",
    receivedDate: "2024-01-08 10:45 AM",
    priority: "Routine",
    status: "Processing",
    clinicalHistory: "Chest pain, hypertension",
    tests: [
      {
        id: 1,
        testCode: "HB001",
        testName: "Hemoglobin",
        result: "",
        units: "g/dL",
        referenceRange: "13.5-17.5 (M), 12.0-15.5 (F)",
        status: "Pending",
        flags: [],
        notes: "",
      },
      {
        id: 2,
        testCode: "GLU001",
        testName: "Random Blood Sugar",
        result: "",
        units: "mg/dL",
        referenceRange: "70-140",
        status: "Pending",
        flags: [],
        notes: "",
      },
      {
        id: 3,
        testCode: "CRE001",
        testName: "Serum Creatinine",
        result: "",
        units: "mg/dL",
        referenceRange: "0.7-1.3 (M), 0.6-1.1 (F)",
        status: "Pending",
        flags: [],
        notes: "",
      },
    ],
  },
  {
    id: 2,
    sampleId: "S001235",
    orderNo: "LAB001235",
    patientName: "Jane Smith",
    patientId: "P001235",
    age: 32,
    gender: "Female",
    doctor: "Dr. Priya Sharma",
    department: "Internal Medicine",
    collectionDate: "2024-01-08 11:00 AM",
    receivedDate: "2024-01-08 11:30 AM",
    priority: "Urgent",
    status: "Processing",
    clinicalHistory: "Fatigue, weakness",
    tests: [
      {
        id: 4,
        testCode: "HB001",
        testName: "Hemoglobin",
        result: "8.2",
        units: "g/dL",
        referenceRange: "13.5-17.5 (M), 12.0-15.5 (F)",
        status: "Abnormal",
        flags: ["Low"],
        notes: "Significantly low hemoglobin level",
      },
      {
        id: 5,
        testCode: "CRE001",
        testName: "Serum Creatinine",
        result: "",
        units: "mg/dL",
        referenceRange: "0.7-1.3 (M), 0.6-1.1 (F)",
        status: "Pending",
        flags: [],
        notes: "",
      },
      {
        id: 6,
        testCode: "URI001",
        testName: "Urine Routine",
        result: "",
        units: "-",
        referenceRange: "Normal",
        status: "Pending",
        flags: [],
        notes: "",
      },
    ],
  },
]

export default function ResultEntryWorkflow() {
  const [sampleData, setSampleData] = useState<SampleForTesting[]>(initialSampleData)
  const [selectedSample, setSelectedSample] = useState<SampleForTesting | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [selectedTab, setSelectedTab] = useState("pending")
  const [isValidating, setIsValidating] = useState(false)
  const [editingTestId, setEditingTestId] = useState<number | null>(null)
  const { toast } = useToast()

  const filteredData = sampleData.filter((sample) => {
    const matchesSearch =
      sample.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sample.sampleId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sample.orderNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sample.patientId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || sample.status === statusFilter
    const matchesPriority = priorityFilter === "all" || sample.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  const getTabData = (tab: string) => {
    switch (tab) {
      case "pending":
        return filteredData.filter((s) => s.status === "Processing")
      case "completed":
        return filteredData.filter((s) => s.status === "Completed")
      case "validated":
        return filteredData.filter((s) => s.status === "Validated")
      case "critical":
        return filteredData.filter((s) => s.tests.some((t) => t.status === "Critical"))
      default:
        return filteredData
    }
  }

  const handleResultUpdate = (sampleId: number, testId: number, field: string, value: string) => {
    setSampleData((prev) =>
      prev.map((sample) => {
        if (sample.id === sampleId) {
          const updatedTests = sample.tests.map((test) => {
            if (test.id === testId) {
              const updatedTest = { ...test, [field]: value }

              // Auto-determine status based on result and reference range
              if (field === "result" && value) {
                const numericResult = Number.parseFloat(value)
                const numericValue = !Number.isNaN(numericResult)

                if (numericValue) {
                  // Parse reference range (simplified logic)
                  const ranges = test.referenceRange.match(/(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)/g)
                  if (ranges && ranges.length > 0) {
                    const [min, max] = ranges[0].split("-").map(Number)

                    if (numericResult < min * 0.5 || numericResult > max * 2) {
                      updatedTest.status = "Critical"
                      updatedTest.flags = numericResult < min ? ["Critical Low"] : ["Critical High"]
                    } else if (numericResult < min || numericResult > max) {
                      updatedTest.status = "Abnormal"
                      updatedTest.flags = numericResult < min ? ["Low"] : ["High"]
                    } else {
                      updatedTest.status = "Normal"
                      updatedTest.flags = []
                    }
                  } else {
                    updatedTest.status = "Normal"
                  }
                } else {
                  updatedTest.status = value.toLowerCase().includes("normal") ? "Normal" : "Abnormal"
                }
              }

              return updatedTest
            }
            return test
          })

          return { ...sample, tests: updatedTests }
        }
        return sample
      }),
    )
  }

  const handleSaveResults = async (sample: SampleForTesting) => {
    const pendingTests = sample.tests.filter((test) => test.result === "" || test.status === "Pending")

    if (pendingTests.length > 0) {
      toast({
        title: "Incomplete Results",
        description: `${pendingTests.length} test(s) still pending. Please complete all results.`,
        variant: "destructive",
      })
      return
    }

    setIsValidating(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setSampleData((prev) =>
        prev.map((s) => {
          if (s.id === sample.id) {
            return {
              ...s,
              status: "Completed",
              currentUser: "Lab Technician",
              entryDate: new Date().toLocaleString(),
            }
          }
          return s
        }),
      )

      toast({
        title: "Results Saved",
        description: `Results for ${sample.patientName} saved successfully`,
      })

      setSelectedSample(null)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save results. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsValidating(false)
    }
  }

  const handleValidateResults = async (sample: SampleForTesting) => {
    setIsValidating(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setSampleData((prev) =>
        prev.map((s) => {
          if (s.id === sample.id) {
            return {
              ...s,
              status: "Validated",
              currentUser: "Dr. Pathologist",
              entryDate: new Date().toLocaleString(),
            }
          }
          return s
        }),
      )

      toast({
        title: "Results Validated",
        description: `Results for ${sample.patientName} validated successfully`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to validate results. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsValidating(false)
    }
  }

  const addNewTest = (sampleId: number) => {
    const newTest: TestResult = {
      id: Date.now(),
      testCode: "",
      testName: "",
      result: "",
      units: "",
      referenceRange: "",
      status: "Pending",
      flags: [],
      notes: "",
    }

    setSampleData((prev) =>
      prev.map((sample) => {
        if (sample.id === sampleId) {
          return {
            ...sample,
            tests: [...sample.tests, newTest],
          }
        }
        return sample
      }),
    )
  }

  const removeTest = (sampleId: number, testId: number) => {
    setSampleData((prev) =>
      prev.map((sample) => {
        if (sample.id === sampleId) {
          return {
            ...sample,
            tests: sample.tests.filter((test) => test.id !== testId),
          }
        }
        return sample
      }),
    )
  }

  const getBadgeVariant = (status: string) => {
    switch (status) {
      case "Critical":
        return "destructive"
      case "Abnormal":
        return "secondary"
      case "Normal":
        return "outline"
      case "Pending":
        return "outline"
      default:
        return "secondary"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "STAT":
        return "destructive"
      case "Urgent":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "text-green-600 bg-green-50"
      case "Validated":
        return "text-blue-600 bg-blue-50"
      case "Processing":
        return "text-orange-600 bg-orange-50"
      default:
        return "text-gray-600 bg-gray-50"
    }
  }

  const stats = {
    pending: getTabData("pending").length,
    completed: getTabData("completed").length,
    validated: getTabData("validated").length,
    critical: getTabData("critical").length,
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Lab Result Entry</h1>
          <p className="text-gray-600">Enter and validate laboratory test results</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Printer className="h-4 w-4 mr-2" />
            Print Reports
          </Button>
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by patient name, sample ID, order number..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Processing">Processing</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
                <SelectItem value="Validated">Validated</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="STAT">STAT</SelectItem>
                <SelectItem value="Urgent">Urgent</SelectItem>
                <SelectItem value="Routine">Routine</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedTab("pending")}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Entry</p>
                <p className="text-2xl font-bold text-orange-600">{stats.pending}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedTab("completed")}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedTab("validated")}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Validated</p>
                <p className="text-2xl font-bold text-blue-600">{stats.validated}</p>
              </div>
              <TestTube className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedTab("critical")}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Critical Values</p>
                <p className="text-2xl font-bold text-red-600">{stats.critical}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Result Entry Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="pending">Pending Entry</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="validated">Validated</TabsTrigger>
          <TabsTrigger value="critical">Critical Values</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedTab} className="space-y-4">
          {getTabData(selectedTab).map((sample) => (
            <Card key={sample.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{sample.patientName}</CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>Sample: {sample.sampleId}</span>
                      <span>Order: {sample.orderNo}</span>
                      <span>
                        {sample.age}Y {sample.gender}
                      </span>
                      <span>Dr. {sample.doctor}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={getPriorityColor(sample.priority)}>{sample.priority}</Badge>
                    <Badge className={getStatusColor(sample.status)}>{sample.status}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Sample Details */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Collected:</p>
                      <p className="font-medium">{sample.collectionDate}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Received:</p>
                      <p className="font-medium">{sample.receivedDate}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Department:</p>
                      <p className="font-medium">{sample.department}</p>
                    </div>
                    {sample.currentUser && (
                      <div>
                        <p className="text-gray-600">Processed By:</p>
                        <p className="font-medium">{sample.currentUser}</p>
                      </div>
                    )}
                  </div>

                  {/* Clinical History */}
                  {sample.clinicalHistory && (
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Clinical History:</p>
                      <p className="text-sm bg-gray-50 p-2 rounded">{sample.clinicalHistory}</p>
                    </div>
                  )}

                  {/* Tests Results Entry */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <p className="text-sm font-medium text-gray-700">Test Results ({sample.tests.length}):</p>
                      {sample.status === "Processing" && (
                        <Button size="sm" variant="outline" onClick={() => addNewTest(sample.id)}>
                          <Plus className="h-3 w-3 mr-1" />
                          Add Test
                        </Button>
                      )}
                    </div>

                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Test Name</TableHead>
                            <TableHead>Result</TableHead>
                            <TableHead>Units</TableHead>
                            <TableHead>Reference Range</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Notes</TableHead>
                            {sample.status === "Processing" && <TableHead>Actions</TableHead>}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sample.tests.map((test) => (
                            <TableRow key={test.id}>
                              <TableCell>
                                <div>
                                  {sample.status === "Processing" && editingTestId === test.id ? (
                                    <div className="space-y-2">
                                      <Input
                                        value={test.testName}
                                        onChange={(e) =>
                                          handleResultUpdate(sample.id, test.id, "testName", e.target.value)
                                        }
                                        placeholder="Test name"
                                        className="h-8"
                                      />
                                      <Input
                                        value={test.testCode}
                                        onChange={(e) =>
                                          handleResultUpdate(sample.id, test.id, "testCode", e.target.value)
                                        }
                                        placeholder="Test code"
                                        className="h-8"
                                      />
                                    </div>
                                  ) : (
                                    <div>
                                      <p className="font-medium">{test.testName}</p>
                                      <p className="text-xs text-gray-500">{test.testCode}</p>
                                    </div>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                {sample.status === "Processing" ? (
                                  <Input
                                    value={test.result}
                                    onChange={(e) => handleResultUpdate(sample.id, test.id, "result", e.target.value)}
                                    placeholder="Enter result"
                                    className="h-8 w-24"
                                  />
                                ) : (
                                  <span className="font-medium">{test.result}</span>
                                )}
                              </TableCell>
                              <TableCell>
                                {sample.status === "Processing" ? (
                                  <Input
                                    value={test.units}
                                    onChange={(e) => handleResultUpdate(sample.id, test.id, "units", e.target.value)}
                                    placeholder="Units"
                                    className="h-8 w-16"
                                  />
                                ) : (
                                  test.units
                                )}
                              </TableCell>
                              <TableCell>
                                {sample.status === "Processing" ? (
                                  <Input
                                    value={test.referenceRange}
                                    onChange={(e) =>
                                      handleResultUpdate(sample.id, test.id, "referenceRange", e.target.value)
                                    }
                                    placeholder="Reference range"
                                    className="h-8 w-32"
                                  />
                                ) : (
                                  <span className="text-sm">{test.referenceRange}</span>
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="flex flex-col gap-1">
                                  <Badge variant={getBadgeVariant(test.status)} className="text-xs w-fit">
                                    {test.status}
                                  </Badge>
                                  {test.flags.length > 0 && (
                                    <div className="flex flex-wrap gap-1">
                                      {test.flags.map((flag, idx) => (
                                        <Badge key={idx} variant="destructive" className="text-xs">
                                          {flag}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                {sample.status === "Processing" ? (
                                  <Textarea
                                    value={test.notes}
                                    onChange={(e) => handleResultUpdate(sample.id, test.id, "notes", e.target.value)}
                                    placeholder="Notes..."
                                    className="h-16 w-40 text-xs"
                                  />
                                ) : (
                                  <span className="text-sm">{test.notes}</span>
                                )}
                              </TableCell>
                              {sample.status === "Processing" && (
                                <TableCell>
                                  <div className="flex gap-1">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setEditingTestId(editingTestId === test.id ? null : test.id)}
                                    >
                                      {editingTestId === test.id ? "Done" : "Edit"}
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => removeTest(sample.id, test.id)}
                                      className="text-red-600 hover:text-red-700"
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </TableCell>
                              )}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex justify-end space-x-2 pt-4 border-t">
                    {sample.status === "Processing" && (
                      <Button
                        onClick={() => handleSaveResults(sample)}
                        disabled={isValidating}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {isValidating ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="h-4 w-4 mr-2" />
                            Save Results
                          </>
                        )}
                      </Button>
                    )}

                    {sample.status === "Completed" && (
                      <Button
                        onClick={() => handleValidateResults(sample)}
                        disabled={isValidating}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        {isValidating ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Validating...
                          </>
                        ) : (
                          <>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Validate Results
                          </>
                        )}
                      </Button>
                    )}

                    {sample.status === "Validated" && (
                      <Button variant="outline">
                        <Send className="h-4 w-4 mr-2" />
                        Release Report
                      </Button>
                    )}

                    <Button variant="outline">
                      <Printer className="h-4 w-4 mr-2" />
                      Print
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {getTabData(selectedTab).length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <TestTube className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-500">No samples found for the selected criteria</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

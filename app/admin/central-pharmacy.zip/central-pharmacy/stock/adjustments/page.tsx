"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, Save, AlertTriangle, TrendingUp, TrendingDown, ArrowLeft, Check } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface StockItem {
  id: string
  drugName: string
  genericName: string
  strength: string
  unit: string
  currentStock: number
  adjustedStock: number
  adjustmentQty: number
  adjustmentType: "increase" | "decrease"
  reason: string
  batchNumber: string
  expiryDate: string
  unitCost: number
  totalValue: number
}

export default function StockAdjustments() {
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")

  const [adjustmentData, setAdjustmentData] = useState({
    adjustmentNumber: `ADJ-${Date.now()}`,
    adjustmentDate: new Date().toISOString().split("T")[0],
    adjustedBy: "John Doe",
    approvedBy: "",
    reason: "",
    notes: "",
    status: "draft",
  })

  const [stockItems, setStockItems] = useState<StockItem[]>([
    {
      id: "1",
      drugName: "Paracetamol",
      genericName: "Acetaminophen",
      strength: "500mg",
      unit: "TAB",
      currentStock: 1000,
      adjustedStock: 950,
      adjustmentQty: -50,
      adjustmentType: "decrease",
      reason: "damaged",
      batchNumber: "PCM001",
      expiryDate: "2025-12-31",
      unitCost: 2.5,
      totalValue: -125.0,
    },
    {
      id: "2",
      drugName: "Amoxicillin",
      genericName: "Amoxicillin",
      strength: "250mg",
      unit: "CAP",
      currentStock: 500,
      adjustedStock: 520,
      adjustmentQty: 20,
      adjustmentType: "increase",
      reason: "found_stock",
      batchNumber: "AMX002",
      expiryDate: "2025-06-30",
      unitCost: 5.0,
      totalValue: 100.0,
    },
  ])

  const adjustmentReasons = [
    { value: "damaged", label: "Damaged/Expired" },
    { value: "lost", label: "Lost/Stolen" },
    { value: "found_stock", label: "Found Stock" },
    { value: "system_error", label: "System Error" },
    { value: "physical_count", label: "Physical Count Variance" },
    { value: "return_to_vendor", label: "Return to Vendor" },
    { value: "other", label: "Other" },
  ]

  const updateStockItem = (index: number, field: keyof StockItem, value: any) => {
    const updatedItems = [...stockItems]
    updatedItems[index] = { ...updatedItems[index], [field]: value }

    // Calculate adjustment quantity and type
    if (field === "adjustedStock") {
      const adjustmentQty = value - updatedItems[index].currentStock
      updatedItems[index].adjustmentQty = adjustmentQty
      updatedItems[index].adjustmentType = adjustmentQty >= 0 ? "increase" : "decrease"
      updatedItems[index].totalValue = adjustmentQty * updatedItems[index].unitCost
    }

    setStockItems(updatedItems)
  }

  const addStockItem = () => {
    const newItem: StockItem = {
      id: Date.now().toString(),
      drugName: "",
      genericName: "",
      strength: "",
      unit: "TAB",
      currentStock: 0,
      adjustedStock: 0,
      adjustmentQty: 0,
      adjustmentType: "increase",
      reason: "",
      batchNumber: "",
      expiryDate: "",
      unitCost: 0,
      totalValue: 0,
    }
    setStockItems([...stockItems, newItem])
  }

  const removeStockItem = (index: number) => {
    if (stockItems.length > 1) {
      setStockItems(stockItems.filter((_, i) => i !== index))
    }
  }

  const calculateTotals = () => {
    const totalValue = stockItems.reduce((sum, item) => sum + item.totalValue, 0)
    const increases = stockItems.filter((item) => item.adjustmentType === "increase").length
    const decreases = stockItems.filter((item) => item.adjustmentType === "decrease").length

    return { totalValue, increases, decreases }
  }

  const handleSubmit = async (status: string) => {
    setLoading(true)
    try {
      // Validate required fields
      const hasEmptyItems = stockItems.some((item) => !item.drugName || !item.reason)
      if (hasEmptyItems) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields for stock items",
          variant: "destructive",
        })
        return
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `Stock adjustment ${status === "draft" ? "saved as draft" : "submitted for approval"} successfully`,
      })

      // Navigate back to stock page or adjustments list
      router.push("/central-pharmacy/stock")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save stock adjustment",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredItems = stockItems.filter(
    (item) =>
      item.drugName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.genericName.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const { totalValue, increases, decreases } = calculateTotals()

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/stock/adjustments" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Stock Adjustments</h1>
            <p className="text-gray-600">Adjust inventory levels for discrepancies and corrections</p>
          </div>
        </div>
        <Badge variant="secondary">Draft</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Adjustment Details */}
        <div className="lg:col-span-3 space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Adjustment Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="adjustmentNumber">Adjustment Number</Label>
                  <Input
                    id="adjustmentNumber"
                    value={adjustmentData.adjustmentNumber}
                    disabled
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="adjustmentDate">Adjustment Date</Label>
                  <Input
                    id="adjustmentDate"
                    type="date"
                    value={adjustmentData.adjustmentDate}
                    onChange={(e) => setAdjustmentData({ ...adjustmentData, adjustmentDate: e.target.value })}
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="adjustedBy">Adjusted By</Label>
                  <Input
                    id="adjustedBy"
                    value={adjustmentData.adjustedBy}
                    onChange={(e) => setAdjustmentData({ ...adjustmentData, adjustedBy: e.target.value })}
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="reason">Primary Reason</Label>
                  <Select
                    value={adjustmentData.reason}
                    onValueChange={(value) => setAdjustmentData({ ...adjustmentData, reason: value })}
                  >
                    <SelectTrigger className="border-gray-200">
                      <SelectValue placeholder="Select reason" />
                    </SelectTrigger>
                    <SelectContent>
                      {adjustmentReasons.map((reason) => (
                        <SelectItem key={reason.value} value={reason.value}>
                          {reason.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="approvedBy">Approved By</Label>
                  <Input
                    id="approvedBy"
                    value={adjustmentData.approvedBy}
                    onChange={(e) => setAdjustmentData({ ...adjustmentData, approvedBy: e.target.value })}
                    placeholder="Supervisor name"
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Additional notes about the adjustment"
                  value={adjustmentData.notes}
                  onChange={(e) => setAdjustmentData({ ...adjustmentData, notes: e.target.value })}
                  className="border-gray-200"
                />
              </div>
            </CardContent>
          </Card>

          {/* Stock Items */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Stock Items</CardTitle>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search items..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8 w-64 border-gray-200"
                    />
                  </div>
                  <Button onClick={addStockItem} size="sm" className="bg-red-600 hover:bg-red-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Drug Name</TableHead>
                      <TableHead>Strength</TableHead>
                      <TableHead>Batch</TableHead>
                      <TableHead>Current Stock</TableHead>
                      <TableHead>Adjusted Stock</TableHead>
                      <TableHead>Adjustment</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Value Impact</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredItems.map((item, index) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div>
                            <Input
                              value={item.drugName}
                              onChange={(e) => updateStockItem(index, "drugName", e.target.value)}
                              placeholder="Drug name"
                              className="mb-1 border-gray-200"
                            />
                            <Input
                              value={item.genericName}
                              onChange={(e) => updateStockItem(index, "genericName", e.target.value)}
                              placeholder="Generic name"
                              className="text-xs border-gray-200"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            value={item.strength}
                            onChange={(e) => updateStockItem(index, "strength", e.target.value)}
                            placeholder="Strength"
                            className="w-20 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            value={item.batchNumber}
                            onChange={(e) => updateStockItem(index, "batchNumber", e.target.value)}
                            placeholder="Batch"
                            className="w-24 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={item.currentStock}
                            onChange={(e) =>
                              updateStockItem(index, "currentStock", Number.parseInt(e.target.value) || 0)
                            }
                            className="w-20 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={item.adjustedStock}
                            onChange={(e) =>
                              updateStockItem(index, "adjustedStock", Number.parseInt(e.target.value) || 0)
                            }
                            className="w-20 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            {item.adjustmentType === "increase" ? (
                              <TrendingUp className="h-4 w-4 text-green-600" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-600" />
                            )}
                            <span
                              className={`font-medium ${item.adjustmentType === "increase" ? "text-green-600" : "text-red-600"}`}
                            >
                              {item.adjustmentQty > 0 ? "+" : ""}
                              {item.adjustmentQty}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={item.reason}
                            onValueChange={(value) => updateStockItem(index, "reason", value)}
                          >
                            <SelectTrigger className="w-32 border-gray-200">
                              <SelectValue placeholder="Reason" />
                            </SelectTrigger>
                            <SelectContent>
                              {adjustmentReasons.map((reason) => (
                                <SelectItem key={reason.value} value={reason.value}>
                                  {reason.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <span className={`font-medium ${item.totalValue >= 0 ? "text-green-600" : "text-red-600"}`}>
                            ₹{item.totalValue.toFixed(2)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeStockItem(index)}
                            className="text-red-600 hover:text-red-700"
                            disabled={stockItems.length === 1}
                          >
                            Remove
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary */}
        <div className="space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Adjustment Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Total Items:</span>
                <span>{stockItems.length}</span>
              </div>
              <div className="flex justify-between text-green-600">
                <span>Increases:</span>
                <span>{increases}</span>
              </div>
              <div className="flex justify-between text-red-600">
                <span>Decreases:</span>
                <span>{decreases}</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between font-bold">
                  <span>Value Impact:</span>
                  <span className={totalValue >= 0 ? "text-green-600" : "text-red-600"}>₹{totalValue.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Approval Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                <span className="text-sm">Pending Approval</span>
              </div>
              <p className="text-xs text-gray-600">
                Stock adjustments require supervisor approval before being applied to inventory.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={() => handleSubmit("draft")}
                variant="outline"
                className="w-full border-gray-200"
                disabled={loading}
              >
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Button
                onClick={() => handleSubmit("submitted")}
                className="w-full bg-red-600 hover:bg-red-700"
                disabled={
                  loading || !adjustmentData.reason || stockItems.some((item) => !item.drugName || !item.reason)
                }
              >
                <Check className="h-4 w-4 mr-2" />
                Submit for Approval
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Package, TrendingDown, TrendingUp, Search, Download, Eye, BarChart3, Clock } from "lucide-react"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface StockItem {
  id: string
  itemCode: string
  itemName: string
  category: string
  currentStock: number
  minStock: number
  maxStock: number
  unitPrice: number
  totalValue: number
  expiryDate: string
  batchNumber: string
  supplier: string
  status: "normal" | "low" | "overstock" | "expired" | "near_expiry"
  location: string
}

const mockStockItems: StockItem[] = [
  {
    id: "1",
    itemCode: "MED001",
    itemName: "Paracetamol 500mg",
    category: "Analgesics",
    currentStock: 2500,
    minStock: 500,
    maxStock: 5000,
    unitPrice: 2.5,
    totalValue: 6250,
    expiryDate: "2025-08-15",
    batchNumber: "PCT2024001",
    supplier: "Cipla Pharmaceuticals",
    status: "normal",
    location: "A-01-001",
  },
  {
    id: "2",
    itemCode: "MED002",
    itemName: "Amoxicillin 250mg",
    category: "Antibiotics",
    currentStock: 150,
    minStock: 200,
    maxStock: 1000,
    unitPrice: 8.75,
    totalValue: 1312.5,
    expiryDate: "2024-12-30",
    batchNumber: "AMX2024002",
    supplier: "Sun Pharma Ltd",
    status: "low",
    location: "B-02-015",
  },
  {
    id: "3",
    itemCode: "MED003",
    itemName: "Insulin Injection",
    category: "Antidiabetic",
    currentStock: 45,
    minStock: 25,
    maxStock: 100,
    unitPrice: 285.0,
    totalValue: 12825,
    expiryDate: "2024-03-15",
    batchNumber: "INS2024003",
    supplier: "Novo Nordisk",
    status: "near_expiry",
    location: "C-03-008",
  },
  {
    id: "4",
    itemCode: "MED004",
    itemName: "Aspirin 75mg",
    category: "Cardiovascular",
    currentStock: 8500,
    minStock: 1000,
    maxStock: 3000,
    unitPrice: 1.25,
    totalValue: 10625,
    expiryDate: "2026-01-20",
    batchNumber: "ASP2024004",
    supplier: "Bayer Healthcare",
    status: "overstock",
    location: "A-01-025",
  },
]

export default function StockManagement() {
  const [stockItems, setStockItems] = useState<StockItem[]>(mockStockItems)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [activeTab, setActiveTab] = useState("all")

  const getStatusBadge = (status: string) => {
    const variants = {
      normal: "bg-green-100 text-green-800 border-green-200",
      low: "bg-red-100 text-red-800 border-red-200",
      overstock: "bg-blue-100 text-blue-800 border-blue-200",
      expired: "bg-red-200 text-red-900 border-red-300",
      near_expiry: "bg-yellow-100 text-yellow-800 border-yellow-200",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800 border-gray-200"
  }

  const getStockLevel = (current: number, min: number, max: number) => {
    if (current <= min) return "Low Stock"
    if (current >= max) return "Overstock"
    return "Normal"
  }

  const getStockPercentage = (current: number, min: number, max: number) => {
    return Math.min(100, (current / max) * 100)
  }

  const filteredItems = stockItems.filter((item) => {
    const matchesSearch =
      item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.itemCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.supplier.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || item.category === categoryFilter
    const matchesStatus = statusFilter === "all" || item.status === statusFilter

    if (activeTab === "low") return matchesSearch && matchesCategory && item.status === "low"
    if (activeTab === "expiring")
      return matchesSearch && matchesCategory && (item.status === "expired" || item.status === "near_expiry")
    if (activeTab === "overstock") return matchesSearch && matchesCategory && item.status === "overstock"

    return matchesSearch && matchesCategory && matchesStatus
  })

  const totalItems = stockItems.length
  const lowStockItems = stockItems.filter((item) => item.status === "low").length
  const expiringItems = stockItems.filter((item) => item.status === "expired" || item.status === "near_expiry").length
  const overstockItems = stockItems.filter((item) => item.status === "overstock").length
  const totalStockValue = stockItems.reduce((sum, item) => sum + item.totalValue, 0)

  const categories = [...new Set(stockItems.map((item) => item.category))]

  const isExpiringSoon = (expiryDate: string) => {
    const expiry = new Date(expiryDate)
    const now = new Date()
    const diffTime = expiry.getTime() - now.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays <= 30 && diffDays > 0
  }

  const isExpired = (expiryDate: string) => {
    const expiry = new Date(expiryDate)
    const now = new Date()
    return expiry < now
  }

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/stock" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Stock Management</h1>
          <p className="text-gray-600 mt-1">Monitor inventory levels and stock movements</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="border-gray-200 bg-transparent">
            <Download className="mr-2 h-4 w-4" />
            Export Stock Report
          </Button>
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <Package className="mr-2 h-4 w-4" />
            Stock Adjustment
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Stock Value</CardTitle>
            <BarChart3 className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">₹{(totalStockValue / 100000).toFixed(1)}L</div>
            <p className="text-xs text-gray-500 mt-1">Current inventory value</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Low Stock Items</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{lowStockItems}</div>
            <p className="text-xs text-gray-500 mt-1">Need reordering</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Expiring Soon</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{expiringItems}</div>
            <p className="text-xs text-gray-500 mt-1">Next 30 days</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Overstock Items</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{overstockItems}</div>
            <p className="text-xs text-gray-500 mt-1">Above maximum level</p>
          </CardContent>
        </Card>
      </div>

      {/* Stock Management Tabs */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle className="text-gray-900">Inventory Overview</CardTitle>
          <CardDescription className="text-gray-600">Monitor stock levels and manage inventory</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All Items ({totalItems})</TabsTrigger>
              <TabsTrigger value="low" className="text-red-700">
                Low Stock ({lowStockItems})
              </TabsTrigger>
              <TabsTrigger value="expiring" className="text-orange-700">
                Expiring ({expiringItems})
              </TabsTrigger>
              <TabsTrigger value="overstock" className="text-blue-700">
                Overstock ({overstockItems})
              </TabsTrigger>
            </TabsList>

            <div className="flex gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search items..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 border-gray-200 focus:border-red-500 focus:ring-red-500"
                  />
                </div>
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[200px] border-gray-200">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px] border-gray-200">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="low">Low Stock</SelectItem>
                  <SelectItem value="overstock">Overstock</SelectItem>
                  <SelectItem value="near_expiry">Near Expiry</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <TabsContent value={activeTab} className="space-y-4">
              <div className="rounded-lg border border-gray-200 overflow-hidden">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="font-semibold text-gray-700">Item Code</TableHead>
                      <TableHead className="font-semibold text-gray-700">Item Name</TableHead>
                      <TableHead className="font-semibold text-gray-700">Category</TableHead>
                      <TableHead className="font-semibold text-gray-700">Current Stock</TableHead>
                      <TableHead className="font-semibold text-gray-700">Stock Level</TableHead>
                      <TableHead className="font-semibold text-gray-700">Unit Price</TableHead>
                      <TableHead className="font-semibold text-gray-700">Total Value</TableHead>
                      <TableHead className="font-semibold text-gray-700">Expiry Date</TableHead>
                      <TableHead className="font-semibold text-gray-700">Status</TableHead>
                      <TableHead className="font-semibold text-gray-700">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="font-medium text-gray-900">{item.itemCode}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium text-gray-900">{item.itemName}</div>
                            <div className="text-sm text-gray-500">Batch: {item.batchNumber}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-700">{item.category}</TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="font-medium text-gray-900">{item.currentStock}</div>
                            <Progress
                              value={getStockPercentage(item.currentStock, item.minStock, item.maxStock)}
                              className="w-16 h-2"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div className="text-gray-700">
                              {getStockLevel(item.currentStock, item.minStock, item.maxStock)}
                            </div>
                            <div className="text-xs text-gray-500">
                              Min: {item.minStock} | Max: {item.maxStock}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium text-gray-900">₹{item.unitPrice.toFixed(2)}</TableCell>
                        <TableCell className="font-medium text-gray-900">₹{item.totalValue.toLocaleString()}</TableCell>
                        <TableCell>
                          <div
                            className={`text-sm ${isExpired(item.expiryDate) ? "text-red-600 font-medium" : isExpiringSoon(item.expiryDate) ? "text-orange-600 font-medium" : "text-gray-700"}`}
                          >
                            {new Date(item.expiryDate).toLocaleDateString()}
                            {isExpired(item.expiryDate) && <div className="text-xs">Expired</div>}
                            {isExpiringSoon(item.expiryDate) && !isExpired(item.expiryDate) && (
                              <div className="text-xs">Expires Soon</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getStatusBadge(item.status)} border`}>
                            {item.status === "near_expiry" ? "NEAR EXPIRY" : item.status.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-gray-200 hover:bg-gray-50 bg-transparent"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-gray-200 hover:bg-gray-50 bg-transparent"
                            >
                              <BarChart3 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

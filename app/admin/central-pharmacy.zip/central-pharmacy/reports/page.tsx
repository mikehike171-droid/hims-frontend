"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3, Download, FileText, Calendar, TrendingUp, Clock, Eye } from "lucide-react"
import { DateRangePicker } from "@/components/ui/date-range-picker"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface Report {
  id: string
  name: string
  description: string
  category: string
  lastGenerated: string
  frequency: string
  status: "ready" | "generating" | "scheduled"
}

const availableReports: Report[] = [
  {
    id: "1",
    name: "Daily Stock Movement Report",
    description: "Track all stock movements, receipts, issues, and transfers",
    category: "Inventory",
    lastGenerated: "2024-01-25 09:30 AM",
    frequency: "Daily",
    status: "ready",
  },
  {
    id: "2",
    name: "Purchase Order Analysis",
    description: "Comprehensive analysis of purchase orders, vendors, and costs",
    category: "Procurement",
    lastGenerated: "2024-01-24 08:00 PM",
    frequency: "Weekly",
    status: "ready",
  },
  {
    id: "3",
    name: "Expiry Analysis Report",
    description: "Items nearing expiry, expired items, and wastage analysis",
    category: "Quality Control",
    lastGenerated: "2024-01-25 06:00 AM",
    frequency: "Daily",
    status: "ready",
  },
  {
    id: "4",
    name: "Vendor Performance Report",
    description: "Vendor ratings, delivery times, quality metrics, and costs",
    category: "Vendor Management",
    lastGenerated: "2024-01-20 05:00 PM",
    frequency: "Monthly",
    status: "scheduled",
  },
  {
    id: "5",
    name: "ABC Analysis Report",
    description: "Classification of items based on consumption value and patterns",
    category: "Analytics",
    lastGenerated: "Generating...",
    frequency: "Monthly",
    status: "generating",
  },
  {
    id: "6",
    name: "Cost Center Wise Consumption",
    description: "Department-wise drug consumption and cost analysis",
    category: "Financial",
    lastGenerated: "2024-01-23 11:30 AM",
    frequency: "Weekly",
    status: "ready",
  },
]

const quickStats = {
  totalReports: 24,
  scheduledReports: 8,
  reportsGenerated: 156,
  avgGenerationTime: "2.3 min",
}

const monthlyTrends = [
  { month: "Sep", reports: 45, downloads: 120 },
  { month: "Oct", reports: 52, downloads: 135 },
  { month: "Nov", reports: 48, downloads: 128 },
  { month: "Dec", reports: 56, downloads: 142 },
  { month: "Jan", reports: 38, downloads: 95 },
]

export default function ReportsCenter() {
  const [reports, setReports] = useState<Report[]>(availableReports)
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [activeTab, setActiveTab] = useState("reports")

  const getStatusBadge = (status: string) => {
    const variants = {
      ready: "bg-green-100 text-green-800 border-green-200",
      generating: "bg-blue-100 text-blue-800 border-blue-200",
      scheduled: "bg-yellow-100 text-yellow-800 border-yellow-200",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800 border-gray-200"
  }

  const filteredReports = reports.filter((report) => categoryFilter === "all" || report.category === categoryFilter)

  const categories = [...new Set(reports.map((r) => r.category))]

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/reports" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Reports Center</h1>
          <p className="text-gray-600 mt-1">Generate and manage pharmacy reports and analytics</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="border-gray-200 bg-transparent">
            <Calendar className="mr-2 h-4 w-4" />
            Schedule Report
          </Button>
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <FileText className="mr-2 h-4 w-4" />
            Custom Report
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Available Reports</CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{quickStats.totalReports}</div>
            <p className="text-xs text-gray-500 mt-1">Report templates</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Scheduled Reports</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{quickStats.scheduledReports}</div>
            <p className="text-xs text-gray-500 mt-1">Auto-generated</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Reports Generated</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{quickStats.reportsGenerated}</div>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Avg Generation Time</CardTitle>
            <BarChart3 className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{quickStats.avgGenerationTime}</div>
            <p className="text-xs text-gray-500 mt-1">Processing time</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="reports">Available Reports</TabsTrigger>
          <TabsTrigger value="custom">Custom Reports</TabsTrigger>
          <TabsTrigger value="analytics">Usage Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-gray-900">Report Library</CardTitle>
                  <CardDescription className="text-gray-600">
                    Pre-built reports for common pharmacy operations
                  </CardDescription>
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[200px] border-gray-200">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredReports.map((report) => (
                  <Card key={report.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-base text-gray-900">{report.name}</CardTitle>
                          <CardDescription className="text-sm text-gray-600 mt-1">{report.description}</CardDescription>
                        </div>
                        <Badge className={`${getStatusBadge(report.status)} border text-xs`}>
                          {report.status.toUpperCase()}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Category:</span>
                        <span className="font-medium text-gray-900">{report.category}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Frequency:</span>
                        <span className="font-medium text-gray-900">{report.frequency}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Last Generated:</span>
                        <span className="font-medium text-gray-900">{report.lastGenerated}</span>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <Button
                          size="sm"
                          disabled={report.status === "generating"}
                          className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                        >
                          {report.status === "generating" ? (
                            <>
                              <Clock className="mr-1 h-3 w-3 animate-spin" />
                              Generating...
                            </>
                          ) : (
                            <>
                              <Download className="mr-1 h-3 w-3" />
                              Generate
                            </>
                          )}
                        </Button>
                        <Button variant="outline" size="sm" className="border-gray-200 bg-transparent">
                          <Eye className="h-3 w-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="custom" className="space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle className="text-gray-900">Custom Report Builder</CardTitle>
              <CardDescription className="text-gray-600">
                Create custom reports with specific parameters and filters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Report Type</label>
                    <Select>
                      <SelectTrigger className="border-gray-200">
                        <SelectValue placeholder="Select report type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="inventory">Inventory Report</SelectItem>
                        <SelectItem value="financial">Financial Report</SelectItem>
                        <SelectItem value="vendor">Vendor Report</SelectItem>
                        <SelectItem value="consumption">Consumption Report</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Date Range</label>
                    <DateRangePicker />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Department/Store</label>
                    <Select>
                      <SelectTrigger className="border-gray-200">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        <SelectItem value="central">Central Pharmacy</SelectItem>
                        <SelectItem value="icu">ICU Store</SelectItem>
                        <SelectItem value="emergency">Emergency Store</SelectItem>
                        <SelectItem value="opd">OPD Store</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Output Format</label>
                    <Select>
                      <SelectTrigger className="border-gray-200">
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="excel">Excel</SelectItem>
                        <SelectItem value="csv">CSV</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Schedule</label>
                    <Select>
                      <SelectTrigger className="border-gray-200">
                        <SelectValue placeholder="Report frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="once">Generate Once</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-gray-200">
                <Button className="bg-red-600 hover:bg-red-700 text-white">
                  <Download className="mr-2 h-4 w-4" />
                  Generate Report
                </Button>
                <Button variant="outline" className="border-gray-200 bg-transparent">
                  <Calendar className="mr-2 h-4 w-4" />
                  Save Template
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle className="text-gray-900">Report Usage Analytics</CardTitle>
              <CardDescription className="text-gray-600">Track report generation and download patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-2">
                {monthlyTrends.map((trend, index) => (
                  <div key={index} className="flex flex-col items-center flex-1">
                    <div className="w-full space-y-1 mb-2">
                      <div
                        className="bg-blue-500 rounded-t w-full min-h-[4px] transition-all hover:bg-blue-600"
                        style={{ height: `${(trend.reports / 60) * 100}%` }}
                        title={`Reports: ${trend.reports}`}
                      />
                      <div
                        className="bg-green-500 rounded-t w-full min-h-[4px] transition-all hover:bg-green-600"
                        style={{ height: `${(trend.downloads / 150) * 100}%` }}
                        title={`Downloads: ${trend.downloads}`}
                      />
                    </div>
                    <span className="text-xs text-gray-500">{trend.month}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-center gap-6 mt-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded"></div>
                  <span className="text-gray-600">Reports Generated</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded"></div>
                  <span className="text-gray-600">Downloads</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </PrivateRoute>
  )
}

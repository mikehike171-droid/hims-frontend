"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Plus,
  Search,
  Download,
  Eye,
  Edit,
  RefreshCw,
  Truck,
  CheckCircle,
  Clock,
  XCircle,
  ArrowRight,
  Package,
  MapPin,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface Transfer {
  id: string
  transferNumber: string
  fromStore: string
  toStore: string
  status: "pending" | "approved" | "in_transit" | "received" | "cancelled"
  priority: "low" | "medium" | "high" | "urgent"
  requestDate: string
  approvedDate?: string
  dispatchDate?: string
  receivedDate?: string
  itemCount: number
  totalValue: number
  requestedBy: string
  approvedBy?: string
  reason: string
}

const mockTransfers: Transfer[] = [
  {
    id: "1",
    transferNumber: "TRF-2024-001",
    fromStore: "Central Pharmacy",
    toStore: "ICU Store",
    status: "received",
    priority: "urgent",
    requestDate: "2024-01-20",
    approvedDate: "2024-01-20",
    dispatchDate: "2024-01-21",
    receivedDate: "2024-01-21",
    itemCount: 5,
    totalValue: 85000,
    requestedBy: "Dr. Sharma (ICU)",
    approvedBy: "Mr. Patel",
    reason: "Emergency stock requirement for critical patients",
  },
  {
    id: "2",
    transferNumber: "TRF-2024-002",
    fromStore: "Central Pharmacy",
    toStore: "Emergency Store",
    status: "in_transit",
    priority: "high",
    requestDate: "2024-01-22",
    approvedDate: "2024-01-22",
    dispatchDate: "2024-01-23",
    itemCount: 8,
    totalValue: 42000,
    requestedBy: "Ms. Singh (Emergency)",
    approvedBy: "Mr. Patel",
    reason: "Stock replenishment for emergency medicines",
  },
  {
    id: "3",
    transferNumber: "TRF-2024-003",
    fromStore: "Central Pharmacy",
    toStore: "OPD Store",
    status: "approved",
    priority: "medium",
    requestDate: "2024-01-23",
    approvedDate: "2024-01-24",
    itemCount: 12,
    totalValue: 28000,
    requestedBy: "Dr. Kumar (OPD)",
    approvedBy: "Mr. Patel",
    reason: "Weekly stock replenishment",
  },
  {
    id: "4",
    transferNumber: "TRF-2024-004",
    fromStore: "Central Pharmacy",
    toStore: "Pediatric Store",
    status: "pending",
    priority: "high",
    requestDate: "2024-01-25",
    itemCount: 6,
    totalValue: 15000,
    requestedBy: "Dr. Gupta (Pediatric)",
    reason: "Pediatric specific medicines shortage",
  },
]

export default function TransferManagement() {
  const [transfers, setTransfers] = useState<Transfer[]>(mockTransfers)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [storeFilter, setStoreFilter] = useState<string>("all")
  const [selectedTransfer, setSelectedTransfer] = useState<Transfer | null>(null)
  const { toast } = useToast()

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "received":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "in_transit":
        return <Truck className="h-4 w-4 text-blue-500" />
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "cancelled":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      received: "bg-green-100 text-green-800 border-green-200",
      in_transit: "bg-blue-100 text-blue-800 border-blue-200",
      approved: "bg-purple-100 text-purple-800 border-purple-200",
      pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
      cancelled: "bg-red-100 text-red-800 border-red-200",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800 border-gray-200"
  }

  const getPriorityBadge = (priority: string) => {
    const variants = {
      urgent: "bg-red-100 text-red-800 border-red-200",
      high: "bg-orange-100 text-orange-800 border-orange-200",
      medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
      low: "bg-blue-100 text-blue-800 border-blue-200",
    }
    return variants[priority as keyof typeof variants] || "bg-gray-100 text-gray-800 border-gray-200"
  }

  const filteredTransfers = transfers.filter((transfer) => {
    const matchesSearch =
      transfer.transferNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transfer.toStore.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transfer.requestedBy.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || transfer.status === statusFilter
    const matchesStore = storeFilter === "all" || transfer.toStore === storeFilter
    return matchesSearch && matchesStatus && matchesStore
  })

  const totalTransfers = transfers.length
  const pendingTransfers = transfers.filter((t) => t.status === "pending").length
  const inTransitTransfers = transfers.filter((t) => t.status === "in_transit").length
  const completedTransfers = transfers.filter((t) => t.status === "received").length
  const totalValue = transfers.reduce((sum, t) => sum + t.totalValue, 0)

  const uniqueStores = [...new Set(transfers.map((t) => t.toStore))]

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/transfers" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Inter-Store Transfers</h1>
          <p className="text-gray-600 mt-1">Manage inventory transfers between stores</p>
        </div>
        <Link href="/central-pharmacy/transfers/new">
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <Plus className="mr-2 h-4 w-4" />
            Create Transfer
          </Button>
        </Link>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Transfers</CardTitle>
            <RefreshCw className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{totalTransfers}</div>
            <p className="text-xs text-gray-500 mt-1">All transfers</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending Approval</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingTransfers}</div>
            <p className="text-xs text-gray-500 mt-1">Need approval</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">In Transit</CardTitle>
            <Truck className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{inTransitTransfers}</div>
            <p className="text-xs text-gray-500 mt-1">Being delivered</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Value</CardTitle>
            <Package className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">₹{(totalValue / 100000).toFixed(1)}L</div>
            <p className="text-xs text-gray-500 mt-1">Transfer value</p>
          </CardContent>
        </Card>
      </div>

      {/* Transfer List */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle className="text-gray-900">Transfer Requests</CardTitle>
          <CardDescription className="text-gray-600">Track and manage store-to-store transfers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search transfers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-gray-200 focus:border-red-500 focus:ring-red-500"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px] border-gray-200">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="in_transit">In Transit</SelectItem>
                <SelectItem value="received">Received</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select value={storeFilter} onValueChange={setStoreFilter}>
              <SelectTrigger className="w-[200px] border-gray-200">
                <SelectValue placeholder="Filter by store" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stores</SelectItem>
                {uniqueStores.map((store) => (
                  <SelectItem key={store} value={store}>
                    {store}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" className="border-gray-200 bg-transparent">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>

          <div className="rounded-lg border border-gray-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="font-semibold text-gray-700">Transfer Number</TableHead>
                  <TableHead className="font-semibold text-gray-700">From → To</TableHead>
                  <TableHead className="font-semibold text-gray-700">Status</TableHead>
                  <TableHead className="font-semibold text-gray-700">Priority</TableHead>
                  <TableHead className="font-semibold text-gray-700">Items</TableHead>
                  <TableHead className="font-semibold text-gray-700">Value</TableHead>
                  <TableHead className="font-semibold text-gray-700">Requested By</TableHead>
                  <TableHead className="font-semibold text-gray-700">Request Date</TableHead>
                  <TableHead className="font-semibold text-gray-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransfers.map((transfer) => (
                  <TableRow key={transfer.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium text-gray-900">{transfer.transferNumber}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-gray-700">{transfer.fromStore}</span>
                        <ArrowRight className="h-3 w-3 text-gray-400" />
                        <span className="font-medium text-gray-900">{transfer.toStore}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getStatusBadge(transfer.status)} border`}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(transfer.status)}
                          {transfer.status.replace("_", " ").toUpperCase()}
                        </div>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getPriorityBadge(transfer.priority)} border`}>
                        {transfer.priority.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-700">{transfer.itemCount} items</TableCell>
                    <TableCell className="font-medium text-gray-900">₹{transfer.totalValue.toLocaleString()}</TableCell>
                    <TableCell className="text-gray-700">{transfer.requestedBy}</TableCell>
                    <TableCell className="text-gray-700">
                      {new Date(transfer.requestDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedTransfer(transfer)}
                              className="border-gray-200 hover:bg-gray-50"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl">
                            <DialogHeader>
                              <DialogTitle>Transfer Details - {transfer.transferNumber}</DialogTitle>
                              <DialogDescription>Complete transfer information and timeline</DialogDescription>
                            </DialogHeader>
                            {selectedTransfer && (
                              <div className="space-y-6">
                                <div className="grid grid-cols-2 gap-6">
                                  <div>
                                    <h4 className="font-medium mb-3 flex items-center gap-2">
                                      <MapPin className="h-4 w-4" />
                                      Transfer Information
                                    </h4>
                                    <div className="space-y-2 text-sm">
                                      <p>
                                        <strong>Transfer Number:</strong> {selectedTransfer.transferNumber}
                                      </p>
                                      <p>
                                        <strong>From Store:</strong> {selectedTransfer.fromStore}
                                      </p>
                                      <p>
                                        <strong>To Store:</strong> {selectedTransfer.toStore}
                                      </p>
                                      <p>
                                        <strong>Items Count:</strong> {selectedTransfer.itemCount}
                                      </p>
                                      <p>
                                        <strong>Total Value:</strong> ₹{selectedTransfer.totalValue.toLocaleString()}
                                      </p>
                                      <p>
                                        <strong>Reason:</strong> {selectedTransfer.reason}
                                      </p>
                                    </div>
                                  </div>
                                  <div>
                                    <h4 className="font-medium mb-3 flex items-center gap-2">
                                      <Clock className="h-4 w-4" />
                                      Timeline
                                    </h4>
                                    <div className="space-y-2 text-sm">
                                      <p>
                                        <strong>Requested:</strong>{" "}
                                        {new Date(selectedTransfer.requestDate).toLocaleDateString()}
                                      </p>
                                      <p>
                                        <strong>Requested By:</strong> {selectedTransfer.requestedBy}
                                      </p>
                                      {selectedTransfer.approvedDate && (
                                        <>
                                          <p>
                                            <strong>Approved:</strong>{" "}
                                            {new Date(selectedTransfer.approvedDate).toLocaleDateString()}
                                          </p>
                                          <p>
                                            <strong>Approved By:</strong> {selectedTransfer.approvedBy}
                                          </p>
                                        </>
                                      )}
                                      {selectedTransfer.dispatchDate && (
                                        <p>
                                          <strong>Dispatched:</strong>{" "}
                                          {new Date(selectedTransfer.dispatchDate).toLocaleDateString()}
                                        </p>
                                      )}
                                      {selectedTransfer.receivedDate && (
                                        <p>
                                          <strong>Received:</strong>{" "}
                                          {new Date(selectedTransfer.receivedDate).toLocaleDateString()}
                                        </p>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Link href={`/central-pharmacy/transfers/edit/${transfer.id}`}>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-gray-200 hover:bg-gray-50 bg-transparent"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, ArrowLeft, Save, Send, Trash2, Search } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface TransferItem {
  id: string
  drugName: string
  genericName: string
  strength: string
  unit: string
  requestedQty: number
  availableStock: number
  batchNumber: string
  expiryDate: string
  unitCost: number
  totalValue: number
}

export default function CreateTransfer() {
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")

  const [transferData, setTransferData] = useState({
    transferNumber: `TRF${Date.now()}`,
    transferDate: new Date().toISOString().split("T")[0],
    fromLocation: "",
    toLocation: "",
    requestedBy: "John Doe",
    priority: "normal",
    expectedDate: "",
    purpose: "",
    notes: "",
    status: "draft",
  })

  const [items, setItems] = useState<TransferItem[]>([
    {
      id: "1",
      drugName: "",
      genericName: "",
      strength: "",
      unit: "TAB",
      requestedQty: 0,
      availableStock: 0,
      batchNumber: "",
      expiryDate: "",
      unitCost: 0,
      totalValue: 0,
    },
  ])

  const locations = [
    { id: "1", name: "Central Pharmacy", code: "CP001" },
    { id: "2", name: "Emergency Pharmacy", code: "EP001" },
    { id: "3", name: "ICU Pharmacy", code: "IP001" },
    { id: "4", name: "OPD Pharmacy", code: "OP001" },
    { id: "5", name: "Ward Pharmacy", code: "WP001" },
  ]

  const priorities = [
    { value: "low", label: "Low", color: "bg-gray-100 text-gray-800" },
    { value: "normal", label: "Normal", color: "bg-blue-100 text-blue-800" },
    { value: "high", label: "High", color: "bg-orange-100 text-orange-800" },
    { value: "urgent", label: "Urgent", color: "bg-red-100 text-red-800" },
  ]

  const updateItem = (index: number, field: keyof TransferItem, value: any) => {
    const updatedItems = [...items]
    updatedItems[index] = { ...updatedItems[index], [field]: value }

    // Calculate total value
    if (field === "requestedQty" || field === "unitCost") {
      updatedItems[index].totalValue = updatedItems[index].requestedQty * updatedItems[index].unitCost
    }

    setItems(updatedItems)
  }

  const addItem = () => {
    const newItem: TransferItem = {
      id: Date.now().toString(),
      drugName: "",
      genericName: "",
      strength: "",
      unit: "TAB",
      requestedQty: 0,
      availableStock: 0,
      batchNumber: "",
      expiryDate: "",
      unitCost: 0,
      totalValue: 0,
    }
    setItems([...items, newItem])
  }

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index))
    }
  }

  const calculateTotals = () => {
    const totalItems = items.length
    const totalValue = items.reduce((sum, item) => sum + item.totalValue, 0)
    const totalQty = items.reduce((sum, item) => sum + item.requestedQty, 0)

    return { totalItems, totalValue, totalQty }
  }

  const handleSubmit = async (status: string) => {
    setLoading(true)
    try {
      // Validate required fields
      if (!transferData.fromLocation || !transferData.toLocation) {
        toast({
          title: "Validation Error",
          description: "Please select both from and to locations",
          variant: "destructive",
        })
        return
      }

      if (transferData.fromLocation === transferData.toLocation) {
        toast({
          title: "Validation Error",
          description: "From and To locations cannot be the same",
          variant: "destructive",
        })
        return
      }

      const hasEmptyItems = items.some((item) => !item.drugName || item.requestedQty <= 0)
      if (hasEmptyItems) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields for transfer items",
          variant: "destructive",
        })
        return
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `Transfer request ${status === "draft" ? "saved as draft" : "submitted"} successfully`,
      })

      router.push("/central-pharmacy/transfers")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save transfer request",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredItems = items.filter(
    (item) =>
      item.drugName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.genericName.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const { totalItems, totalValue, totalQty } = calculateTotals()
  const selectedPriority = priorities.find((p) => p.value === transferData.priority)

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/transfers/create" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Create Transfer Request</h1>
            <p className="text-gray-600">Request transfer of inventory between locations</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Badge className={selectedPriority?.color}>{selectedPriority?.label}</Badge>
          <Badge variant="secondary">Draft</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Transfer Details */}
        <div className="lg:col-span-3 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Transfer Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="transferNumber">Transfer Number</Label>
                  <Input id="transferNumber" value={transferData.transferNumber} disabled />
                </div>
                <div>
                  <Label htmlFor="transferDate">Transfer Date</Label>
                  <Input
                    id="transferDate"
                    type="date"
                    value={transferData.transferDate}
                    onChange={(e) => setTransferData({ ...transferData, transferDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="expectedDate">Expected Date</Label>
                  <Input
                    id="expectedDate"
                    type="date"
                    value={transferData.expectedDate}
                    onChange={(e) => setTransferData({ ...transferData, expectedDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="fromLocation">From Location</Label>
                  <Select
                    value={transferData.fromLocation}
                    onValueChange={(value) => setTransferData({ ...transferData, fromLocation: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select source location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.map((location) => (
                        <SelectItem key={location.id} value={location.id}>
                          {location.name} ({location.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="toLocation">To Location</Label>
                  <Select
                    value={transferData.toLocation}
                    onValueChange={(value) => setTransferData({ ...transferData, toLocation: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select destination location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.map((location) => (
                        <SelectItem key={location.id} value={location.id}>
                          {location.name} ({location.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="requestedBy">Requested By</Label>
                  <Input
                    id="requestedBy"
                    value={transferData.requestedBy}
                    onChange={(e) => setTransferData({ ...transferData, requestedBy: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select
                    value={transferData.priority}
                    onValueChange={(value) => setTransferData({ ...transferData, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map((priority) => (
                        <SelectItem key={priority.value} value={priority.value}>
                          {priority.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="purpose">Purpose</Label>
                <Input
                  id="purpose"
                  value={transferData.purpose}
                  onChange={(e) => setTransferData({ ...transferData, purpose: e.target.value })}
                  placeholder="Reason for transfer"
                />
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Additional notes or special instructions"
                  value={transferData.notes}
                  onChange={(e) => setTransferData({ ...transferData, notes: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Items */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Transfer Items</CardTitle>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search items..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8 w-64"
                    />
                  </div>
                  <Button onClick={addItem} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Drug Name</TableHead>
                      <TableHead>Strength</TableHead>
                      <TableHead>Requested Qty</TableHead>
                      <TableHead>Available Stock</TableHead>
                      <TableHead>Batch</TableHead>
                      <TableHead>Unit Cost</TableHead>
                      <TableHead>Total Value</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredItems.map((item, index) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div>
                            <Input
                              value={item.drugName}
                              onChange={(e) => updateItem(index, "drugName", e.target.value)}
                              placeholder="Drug name"
                              className="mb-1"
                            />
                            <Input
                              value={item.genericName}
                              onChange={(e) => updateItem(index, "genericName", e.target.value)}
                              placeholder="Generic name"
                              className="text-xs"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            value={item.strength}
                            onChange={(e) => updateItem(index, "strength", e.target.value)}
                            placeholder="Strength"
                            className="w-20"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={item.requestedQty}
                            onChange={(e) => updateItem(index, "requestedQty", Number.parseInt(e.target.value) || 0)}
                            className="w-20"
                          />
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <span
                              className={`font-medium ${item.availableStock < item.requestedQty ? "text-red-600" : "text-green-600"}`}
                            >
                              {item.availableStock}
                            </span>
                            <div className="text-xs text-gray-500">{item.unit}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            value={item.batchNumber}
                            onChange={(e) => updateItem(index, "batchNumber", e.target.value)}
                            placeholder="Batch"
                            className="w-24"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            step="0.01"
                            value={item.unitCost}
                            onChange={(e) => updateItem(index, "unitCost", Number.parseFloat(e.target.value) || 0)}
                            className="w-20"
                          />
                        </TableCell>
                        <TableCell>
                          <span className="font-medium text-green-600">₹{item.totalValue.toFixed(2)}</span>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(index)}
                            className="text-red-600 hover:text-red-700"
                            disabled={items.length === 1}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Transfer Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Total Items:</span>
                <span>{totalItems}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Quantity:</span>
                <span>{totalQty}</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between font-bold">
                  <span>Total Value:</span>
                  <span className="text-green-600">₹{totalValue.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Transfer Route</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm">
                <div className="font-medium text-gray-700">From:</div>
                <div className="text-blue-600">
                  {transferData.fromLocation
                    ? locations.find((l) => l.id === transferData.fromLocation)?.name
                    : "Select location"}
                </div>
              </div>
              <div className="text-center text-gray-400">↓</div>
              <div className="text-sm">
                <div className="font-medium text-gray-700">To:</div>
                <div className="text-green-600">
                  {transferData.toLocation
                    ? locations.find((l) => l.id === transferData.toLocation)?.name
                    : "Select location"}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button onClick={() => handleSubmit("draft")} variant="outline" className="w-full" disabled={loading}>
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Button
                onClick={() => handleSubmit("submitted")}
                className="w-full"
                disabled={
                  loading ||
                  !transferData.fromLocation ||
                  !transferData.toLocation ||
                  items.some((item) => !item.drugName || item.requestedQty <= 0)
                }
              >
                <Send className="h-4 w-4 mr-2" />
                Submit Request
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, Save, CheckCircle, AlertTriangle } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface GRNItem {
  id: string
  drugName: string
  genericName: string
  strength: string
  unit: string
  orderedQty: number
  receivedQty: number
  unitPrice: number
  batchNumber: string
  expiryDate: string
  mfgDate: string
  manufacturer: string
  totalAmount: number
  discrepancy: boolean
}

export default function CreateGRN() {
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)

  const [grnData, setGrnData] = useState({
    grnNumber: `GRN${Date.now()}`,
    poNumber: "",
    vendorId: "",
    invoiceNumber: "",
    invoiceDate: "",
    receivedDate: new Date().toISOString().split("T")[0],
    receivedBy: "John Doe",
    notes: "",
    status: "pending",
  })

  const [items, setItems] = useState<GRNItem[]>([
    {
      id: "1",
      drugName: "Paracetamol",
      genericName: "Acetaminophen",
      strength: "500mg",
      unit: "TAB",
      orderedQty: 1000,
      receivedQty: 1000,
      unitPrice: 2.5,
      batchNumber: "",
      expiryDate: "",
      mfgDate: "",
      manufacturer: "",
      totalAmount: 2500,
      discrepancy: false,
    },
    {
      id: "2",
      drugName: "Amoxicillin",
      genericName: "Amoxicillin",
      strength: "250mg",
      unit: "CAP",
      orderedQty: 500,
      receivedQty: 480,
      unitPrice: 5.0,
      batchNumber: "",
      expiryDate: "",
      mfgDate: "",
      manufacturer: "",
      totalAmount: 2400,
      discrepancy: true,
    },
  ])

  const purchaseOrders = [
    { id: "PO001", number: "PO001", vendor: "MedSupply Corp", date: "2024-01-15" },
    { id: "PO002", number: "PO002", vendor: "PharmaCare Ltd", date: "2024-01-16" },
  ]

  const vendors = [
    { id: "1", name: "MedSupply Corp", code: "MSC001" },
    { id: "2", name: "PharmaCare Ltd", code: "PCL002" },
  ]

  const updateItem = (index: number, field: keyof GRNItem, value: any) => {
    const updatedItems = [...items]
    updatedItems[index] = { ...updatedItems[index], [field]: value }

    // Calculate discrepancy
    if (field === "receivedQty" || field === "orderedQty") {
      updatedItems[index].discrepancy = updatedItems[index].receivedQty !== updatedItems[index].orderedQty
      updatedItems[index].totalAmount = updatedItems[index].receivedQty * updatedItems[index].unitPrice
    }

    setItems(updatedItems)
  }

  const calculateTotals = () => {
    const totalAmount = items.reduce((sum, item) => sum + item.totalAmount, 0)
    const discrepancies = items.filter((item) => item.discrepancy).length

    return { totalAmount, discrepancies }
  }

  const handleSubmit = async (status: string) => {
    setLoading(true)
    try {
      // Validate required fields
      const hasEmptyBatches = items.some((item) => !item.batchNumber || !item.expiryDate)
      if (hasEmptyBatches && status === "completed") {
        toast({
          title: "Validation Error",
          description: "Please fill in batch numbers and expiry dates for all items",
          variant: "destructive",
        })
        return
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `GRN ${status === "draft" ? "saved as draft" : "completed"} successfully`,
      })

      router.push("/central-pharmacy/grn")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save GRN",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const { totalAmount, discrepancies } = calculateTotals()

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/grn/create" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Create Goods Receipt Note</h1>
            <p className="text-gray-600">Record receipt of goods against purchase order</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {discrepancies > 0 && (
            <Badge variant="destructive">
              <AlertTriangle className="h-3 w-3 mr-1" />
              {discrepancies} Discrepancies
            </Badge>
          )}
          <Badge variant="secondary">Pending</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* GRN Details */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>GRN Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="grnNumber">GRN Number</Label>
                  <Input id="grnNumber" value={grnData.grnNumber} disabled />
                </div>
                <div>
                  <Label htmlFor="poNumber">Purchase Order</Label>
                  <Select
                    value={grnData.poNumber}
                    onValueChange={(value) => setGrnData({ ...grnData, poNumber: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select PO" />
                    </SelectTrigger>
                    <SelectContent>
                      {purchaseOrders.map((po) => (
                        <SelectItem key={po.id} value={po.number}>
                          {po.number} - {po.vendor}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="invoiceNumber">Invoice Number</Label>
                  <Input
                    id="invoiceNumber"
                    value={grnData.invoiceNumber}
                    onChange={(e) => setGrnData({ ...grnData, invoiceNumber: e.target.value })}
                    placeholder="Enter invoice number"
                  />
                </div>
                <div>
                  <Label htmlFor="invoiceDate">Invoice Date</Label>
                  <Input
                    id="invoiceDate"
                    type="date"
                    value={grnData.invoiceDate}
                    onChange={(e) => setGrnData({ ...grnData, invoiceDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="receivedDate">Received Date</Label>
                  <Input
                    id="receivedDate"
                    type="date"
                    value={grnData.receivedDate}
                    onChange={(e) => setGrnData({ ...grnData, receivedDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="receivedBy">Received By</Label>
                  <Input
                    id="receivedBy"
                    value={grnData.receivedBy}
                    onChange={(e) => setGrnData({ ...grnData, receivedBy: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any discrepancies or special notes"
                  value={grnData.notes}
                  onChange={(e) => setGrnData({ ...grnData, notes: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Items */}
          <Card>
            <CardHeader>
              <CardTitle>Items Received</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div
                    key={item.id}
                    className={`border rounded-lg p-4 space-y-4 ${item.discrepancy ? "border-red-200 bg-red-50" : "border-gray-200"}`}
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">
                        {item.drugName} - {item.strength}
                      </h4>
                      {item.discrepancy && (
                        <Badge variant="destructive" size="sm">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          Discrepancy
                        </Badge>
                      )}
                    </div>

                    <div className="grid grid-cols-4 gap-4">
                      <div>
                        <Label>Ordered Qty</Label>
                        <Input value={item.orderedQty} disabled className="bg-gray-50" />
                      </div>
                      <div>
                        <Label>Received Qty</Label>
                        <Input
                          type="number"
                          value={item.receivedQty}
                          onChange={(e) => updateItem(index, "receivedQty", Number.parseInt(e.target.value) || 0)}
                          className={item.discrepancy ? "border-red-300" : ""}
                        />
                      </div>
                      <div>
                        <Label>Unit Price (₹)</Label>
                        <Input value={item.unitPrice} disabled className="bg-gray-50" />
                      </div>
                      <div>
                        <Label>Total Amount</Label>
                        <div className="font-medium text-green-600 py-2">₹{item.totalAmount.toFixed(2)}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Batch Number</Label>
                        <Input
                          value={item.batchNumber}
                          onChange={(e) => updateItem(index, "batchNumber", e.target.value)}
                          placeholder="Enter batch number"
                        />
                      </div>
                      <div>
                        <Label>Manufacturer</Label>
                        <Input
                          value={item.manufacturer}
                          onChange={(e) => updateItem(index, "manufacturer", e.target.value)}
                          placeholder="Enter manufacturer"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Manufacturing Date</Label>
                        <Input
                          type="date"
                          value={item.mfgDate}
                          onChange={(e) => updateItem(index, "mfgDate", e.target.value)}
                        />
                      </div>
                      <div>
                        <Label>Expiry Date</Label>
                        <Input
                          type="date"
                          value={item.expiryDate}
                          onChange={(e) => updateItem(index, "expiryDate", e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Receipt Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Total Items:</span>
                <span>{items.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Amount:</span>
                <span className="font-bold text-green-600">₹{totalAmount.toFixed(2)}</span>
              </div>
              {discrepancies > 0 && (
                <div className="flex justify-between text-red-600">
                  <span>Discrepancies:</span>
                  <span>{discrepancies}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quality Check</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox id="packaging" />
                <Label htmlFor="packaging">Packaging intact</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="expiry" />
                <Label htmlFor="expiry">Expiry dates verified</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="batch" />
                <Label htmlFor="batch">Batch numbers recorded</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="quantity" />
                <Label htmlFor="quantity">Quantities verified</Label>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button onClick={() => handleSubmit("draft")} variant="outline" className="w-full" disabled={loading}>
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Button
                onClick={() => handleSubmit("completed")}
                className="w-full"
                disabled={loading || !grnData.poNumber || !grnData.invoiceNumber}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Complete GRN
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

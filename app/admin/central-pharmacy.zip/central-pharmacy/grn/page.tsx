"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Plus,
  Search,
  Download,
  Eye,
  Edit,
  CheckCircle,
  Clock,
  AlertTriangle,
  Package,
  FileText,
  Building2,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface GRN {
  id: string
  grnNumber: string
  poNumber: string
  vendor: string
  status: "pending" | "partial" | "completed" | "discrepancy"
  receivedDate: string
  totalValue: number
  receivedItems: number
  totalItems: number
  receivedBy: string
  qualityStatus: "pending" | "approved" | "rejected"
  invoiceNumber: string
}

const mockGRNs: GRN[] = [
  {
    id: "1",
    grnNumber: "GRN-2024-001",
    poNumber: "PO-2024-001",
    vendor: "Cipla Pharmaceuticals",
    status: "completed",
    receivedDate: "2024-01-25",
    totalValue: 245000,
    receivedItems: 15,
    totalItems: 15,
    receivedBy: "Mr. Patel",
    qualityStatus: "approved",
    invoiceNumber: "INV-CIPLA-2024-001",
  },
  {
    id: "2",
    grnNumber: "GRN-2024-002",
    poNumber: "PO-2024-003",
    vendor: "Sun Pharma Ltd",
    status: "partial",
    receivedDate: "2024-01-28",
    totalValue: 180000,
    receivedItems: 8,
    totalItems: 12,
    receivedBy: "Ms. Singh",
    qualityStatus: "pending",
    invoiceNumber: "INV-SUN-2024-002",
  },
  {
    id: "3",
    grnNumber: "GRN-2024-003",
    poNumber: "PO-2024-002",
    vendor: "Lupin Limited",
    status: "discrepancy",
    receivedDate: "2024-01-30",
    totalValue: 320000,
    receivedItems: 18,
    totalItems: 20,
    receivedBy: "Dr. Kumar",
    qualityStatus: "rejected",
    invoiceNumber: "INV-LUPIN-2024-003",
  },
]

export default function GRNManagement() {
  const [grns, setGRNs] = useState<GRN[]>(mockGRNs)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [selectedGRN, setSelectedGRN] = useState<GRN | null>(null)
  const { toast } = useToast()

  const getStatusBadge = (status: string) => {
    const variants = {
      completed: "bg-green-100 text-green-800 border-green-200",
      partial: "bg-yellow-100 text-yellow-800 border-yellow-200",
      pending: "bg-blue-100 text-blue-800 border-blue-200",
      discrepancy: "bg-red-100 text-red-800 border-red-200",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800 border-gray-200"
  }

  const getQualityBadge = (status: string) => {
    const variants = {
      approved: "bg-green-100 text-green-800 border-green-200",
      rejected: "bg-red-100 text-red-800 border-red-200",
      pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800 border-gray-200"
  }

  const filteredGRNs = grns.filter((grn) => {
    const matchesSearch =
      grn.grnNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      grn.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      grn.vendor.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || grn.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalGRNs = grns.length
  const pendingGRNs = grns.filter((grn) => grn.status === "pending").length
  const completedGRNs = grns.filter((grn) => grn.status === "completed").length
  const discrepancyGRNs = grns.filter((grn) => grn.status === "discrepancy").length

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/grn" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">GRN Management</h1>
          <p className="text-gray-600 mt-1">Manage goods receipt and inventory updates</p>
        </div>
        <Link href="/central-pharmacy/grn/new">
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <Plus className="mr-2 h-4 w-4" />
            Create GRN
          </Button>
        </Link>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total GRNs</CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{totalGRNs}</div>
            <p className="text-xs text-gray-500 mt-1">All receipts</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingGRNs}</div>
            <p className="text-xs text-gray-500 mt-1">Awaiting receipt</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{completedGRNs}</div>
            <p className="text-xs text-gray-500 mt-1">Fully received</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Discrepancies</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{discrepancyGRNs}</div>
            <p className="text-xs text-gray-500 mt-1">Need attention</p>
          </CardContent>
        </Card>
      </div>

      {/* GRN List */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle className="text-gray-900">Goods Receipt Notes</CardTitle>
          <CardDescription className="text-gray-600">Track and manage inventory receipts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search GRNs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-gray-200 focus:border-red-500 focus:ring-red-500"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px] border-gray-200">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="discrepancy">Discrepancy</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="border-gray-200 bg-transparent">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>

          <div className="rounded-lg border border-gray-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="font-semibold text-gray-700">GRN Number</TableHead>
                  <TableHead className="font-semibold text-gray-700">PO Number</TableHead>
                  <TableHead className="font-semibold text-gray-700">Vendor</TableHead>
                  <TableHead className="font-semibold text-gray-700">Status</TableHead>
                  <TableHead className="font-semibold text-gray-700">Quality Status</TableHead>
                  <TableHead className="font-semibold text-gray-700">Items Received</TableHead>
                  <TableHead className="font-semibold text-gray-700">Total Value</TableHead>
                  <TableHead className="font-semibold text-gray-700">Received Date</TableHead>
                  <TableHead className="font-semibold text-gray-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredGRNs.map((grn) => (
                  <TableRow key={grn.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium text-gray-900">{grn.grnNumber}</TableCell>
                    <TableCell className="font-medium text-blue-600">{grn.poNumber}</TableCell>
                    <TableCell className="text-gray-700">{grn.vendor}</TableCell>
                    <TableCell>
                      <Badge className={`${getStatusBadge(grn.status)} border`}>{grn.status.toUpperCase()}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getQualityBadge(grn.qualityStatus)} border`}>
                        {grn.qualityStatus.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-700">
                      {grn.receivedItems}/{grn.totalItems}
                    </TableCell>
                    <TableCell className="font-medium text-gray-900">₹{grn.totalValue.toLocaleString()}</TableCell>
                    <TableCell className="text-gray-700">{new Date(grn.receivedDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedGRN(grn)}
                              className="border-gray-200 hover:bg-gray-50"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl">
                            <DialogHeader>
                              <DialogTitle>GRN Details - {grn.grnNumber}</DialogTitle>
                              <DialogDescription>Complete goods receipt information</DialogDescription>
                            </DialogHeader>
                            {selectedGRN && (
                              <div className="space-y-6">
                                <div className="grid grid-cols-2 gap-6">
                                  <div>
                                    <h4 className="font-medium mb-3 flex items-center gap-2">
                                      <Building2 className="h-4 w-4" />
                                      Receipt Information
                                    </h4>
                                    <div className="space-y-2 text-sm">
                                      <p>
                                        <strong>GRN Number:</strong> {selectedGRN.grnNumber}
                                      </p>
                                      <p>
                                        <strong>PO Number:</strong> {selectedGRN.poNumber}
                                      </p>
                                      <p>
                                        <strong>Invoice Number:</strong> {selectedGRN.invoiceNumber}
                                      </p>
                                      <p>
                                        <strong>Vendor:</strong> {selectedGRN.vendor}
                                      </p>
                                      <p>
                                        <strong>Total Value:</strong> ₹{selectedGRN.totalValue.toLocaleString()}
                                      </p>
                                    </div>
                                  </div>
                                  <div>
                                    <h4 className="font-medium mb-3 flex items-center gap-2">
                                      <Package className="h-4 w-4" />
                                      Status Information
                                    </h4>
                                    <div className="space-y-2 text-sm">
                                      <p>
                                        <strong>Receipt Status:</strong>{" "}
                                        <Badge className={`${getStatusBadge(selectedGRN.status)} border ml-2`}>
                                          {selectedGRN.status}
                                        </Badge>
                                      </p>
                                      <p>
                                        <strong>Quality Status:</strong>{" "}
                                        <Badge className={`${getQualityBadge(selectedGRN.qualityStatus)} border ml-2`}>
                                          {selectedGRN.qualityStatus}
                                        </Badge>
                                      </p>
                                      <p>
                                        <strong>Items Received:</strong> {selectedGRN.receivedItems}/
                                        {selectedGRN.totalItems}
                                      </p>
                                      <p>
                                        <strong>Received By:</strong> {selectedGRN.receivedBy}
                                      </p>
                                      <p>
                                        <strong>Received Date:</strong>{" "}
                                        {new Date(selectedGRN.receivedDate).toLocaleDateString()}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Link href={`/central-pharmacy/grn/edit/${grn.id}`}>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-gray-200 hover:bg-gray-50 bg-transparent"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

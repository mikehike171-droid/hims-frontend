"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowLeft, Save, CheckCircle, AlertTriangle } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface GRNItem {
  id: string
  drugName: string
  genericName: string
  strength: string
  unit: string
  orderedQty: number
  receivedQty: number
  unitPrice: number
  batchNumber: string
  expiryDate: string
  mfgDate: string
  manufacturer: string
  totalAmount: number
  discrepancy: boolean
}

export default function CreateGRN() {
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)

  const [grnData, setGrnData] = useState({
    grnNumber: `GRN-${Date.now()}`,
    poNumber: "",
    vendorId: "",
    invoiceNumber: "",
    invoiceDate: "",
    receivedDate: new Date().toISOString().split("T")[0],
    receivedBy: "John Doe",
    notes: "",
    status: "pending",
  })

  const [items, setItems] = useState<GRNItem[]>([
    {
      id: "1",
      drugName: "Paracetamol",
      genericName: "Acetaminophen",
      strength: "500mg",
      unit: "TAB",
      orderedQty: 1000,
      receivedQty: 1000,
      unitPrice: 2.5,
      batchNumber: "",
      expiryDate: "",
      mfgDate: "",
      manufacturer: "",
      totalAmount: 2500,
      discrepancy: false,
    },
    {
      id: "2",
      drugName: "Amoxicillin",
      genericName: "Amoxicillin",
      strength: "250mg",
      unit: "CAP",
      orderedQty: 500,
      receivedQty: 480,
      unitPrice: 5.0,
      batchNumber: "",
      expiryDate: "",
      mfgDate: "",
      manufacturer: "",
      totalAmount: 2400,
      discrepancy: true,
    },
  ])

  const [qualityChecks, setQualityChecks] = useState({
    packagingIntact: false,
    expiryVerified: false,
    batchRecorded: false,
    quantityVerified: false,
    temperatureOk: false,
    documentsComplete: false,
  })

  const purchaseOrders = [
    { id: "PO-2024-001", number: "PO-2024-001", vendor: "Cipla Pharmaceuticals", date: "2024-01-15" },
    { id: "PO-2024-002", number: "PO-2024-002", vendor: "Sun Pharma Ltd", date: "2024-01-16" },
    { id: "PO-2024-003", number: "PO-2024-003", vendor: "Lupin Limited", date: "2024-01-20" },
  ]

  const vendors = [
    { id: "1", name: "Cipla Pharmaceuticals", code: "CIPLA001" },
    { id: "2", name: "Sun Pharma Ltd", code: "SUN001" },
    { id: "3", name: "Lupin Limited", code: "LUPIN001" },
  ]

  const updateItem = (index: number, field: keyof GRNItem, value: any) => {
    const updatedItems = [...items]
    updatedItems[index] = { ...updatedItems[index], [field]: value }

    // Calculate discrepancy
    if (field === "receivedQty" || field === "orderedQty") {
      updatedItems[index].discrepancy = updatedItems[index].receivedQty !== updatedItems[index].orderedQty
      updatedItems[index].totalAmount = updatedItems[index].receivedQty * updatedItems[index].unitPrice
    }

    setItems(updatedItems)
  }

  const calculateTotals = () => {
    const totalAmount = items.reduce((sum, item) => sum + item.totalAmount, 0)
    const discrepancies = items.filter((item) => item.discrepancy).length
    const totalItems = items.length

    return { totalAmount, discrepancies, totalItems }
  }

  const handleSubmit = async (status: string) => {
    setLoading(true)
    try {
      // Validate required fields
      if (!grnData.poNumber || !grnData.invoiceNumber) {
        toast({
          title: "Validation Error",
          description: "Please fill in PO Number and Invoice Number",
          variant: "destructive",
        })
        return
      }

      const hasEmptyBatches = items.some((item) => !item.batchNumber || !item.expiryDate)
      if (hasEmptyBatches && status === "completed") {
        toast({
          title: "Validation Error",
          description: "Please fill in batch numbers and expiry dates for all items",
          variant: "destructive",
        })
        return
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `GRN ${status === "draft" ? "saved as draft" : "completed"} successfully`,
      })

      router.push("/central-pharmacy/grn")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save GRN",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const { totalAmount, discrepancies, totalItems } = calculateTotals()

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/grn/new" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Create Goods Receipt Note</h1>
            <p className="text-gray-600">Record receipt of goods against purchase order</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {discrepancies > 0 && (
            <Badge variant="destructive">
              <AlertTriangle className="h-3 w-3 mr-1" />
              {discrepancies} Discrepancies
            </Badge>
          )}
          <Badge variant="secondary">Pending</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* GRN Details */}
        <div className="lg:col-span-3 space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>GRN Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="grnNumber">GRN Number</Label>
                  <Input id="grnNumber" value={grnData.grnNumber} disabled className="bg-gray-50" />
                </div>
                <div>
                  <Label htmlFor="poNumber">Purchase Order *</Label>
                  <Select
                    value={grnData.poNumber}
                    onValueChange={(value) => setGrnData({ ...grnData, poNumber: value })}
                  >
                    <SelectTrigger className="border-gray-200">
                      <SelectValue placeholder="Select PO" />
                    </SelectTrigger>
                    <SelectContent>
                      {purchaseOrders.map((po) => (
                        <SelectItem key={po.id} value={po.number}>
                          {po.number} - {po.vendor}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="invoiceNumber">Invoice Number *</Label>
                  <Input
                    id="invoiceNumber"
                    value={grnData.invoiceNumber}
                    onChange={(e) => setGrnData({ ...grnData, invoiceNumber: e.target.value })}
                    placeholder="Enter invoice number"
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="invoiceDate">Invoice Date</Label>
                  <Input
                    id="invoiceDate"
                    type="date"
                    value={grnData.invoiceDate}
                    onChange={(e) => setGrnData({ ...grnData, invoiceDate: e.target.value })}
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="receivedDate">Received Date</Label>
                  <Input
                    id="receivedDate"
                    type="date"
                    value={grnData.receivedDate}
                    onChange={(e) => setGrnData({ ...grnData, receivedDate: e.target.value })}
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="receivedBy">Received By</Label>
                  <Input
                    id="receivedBy"
                    value={grnData.receivedBy}
                    onChange={(e) => setGrnData({ ...grnData, receivedBy: e.target.value })}
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any discrepancies or special notes"
                  value={grnData.notes}
                  onChange={(e) => setGrnData({ ...grnData, notes: e.target.value })}
                  className="border-gray-200"
                />
              </div>
            </CardContent>
          </Card>

          {/* Items */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Items Received</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Drug Name</TableHead>
                      <TableHead>Ordered</TableHead>
                      <TableHead>Received</TableHead>
                      <TableHead>Batch</TableHead>
                      <TableHead>Expiry</TableHead>
                      <TableHead>Manufacturer</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item, index) => (
                      <TableRow key={item.id} className={item.discrepancy ? "bg-red-50 border-red-200" : ""}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{item.drugName}</div>
                            <div className="text-sm text-gray-500">{item.strength}</div>
                            {item.discrepancy && (
                              <Badge variant="destructive" size="sm" className="mt-1">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Discrepancy
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{item.orderedQty}</div>
                          <div className="text-sm text-gray-500">{item.unit}</div>
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={item.receivedQty}
                            onChange={(e) => updateItem(index, "receivedQty", Number.parseInt(e.target.value) || 0)}
                            className={`w-20 ${item.discrepancy ? "border-red-300" : "border-gray-200"}`}
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            value={item.batchNumber}
                            onChange={(e) => updateItem(index, "batchNumber", e.target.value)}
                            placeholder="Batch"
                            className="w-24 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="date"
                            value={item.expiryDate}
                            onChange={(e) => updateItem(index, "expiryDate", e.target.value)}
                            className="w-32 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            value={item.manufacturer}
                            onChange={(e) => updateItem(index, "manufacturer", e.target.value)}
                            placeholder="Manufacturer"
                            className="w-32 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <div className="font-medium text-green-600">₹{item.totalAmount.toFixed(2)}</div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary */}
        <div className="space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Receipt Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Total Items:</span>
                <span>{totalItems}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Amount:</span>
                <span className="font-bold text-green-600">₹{totalAmount.toFixed(2)}</span>
              </div>
              {discrepancies > 0 && (
                <div className="flex justify-between text-red-600">
                  <span>Discrepancies:</span>
                  <span>{discrepancies}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Quality Check</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="packaging"
                  checked={qualityChecks.packagingIntact}
                  onCheckedChange={(checked) => setQualityChecks({ ...qualityChecks, packagingIntact: !!checked })}
                />
                <Label htmlFor="packaging">Packaging intact</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="expiry"
                  checked={qualityChecks.expiryVerified}
                  onCheckedChange={(checked) => setQualityChecks({ ...qualityChecks, expiryVerified: !!checked })}
                />
                <Label htmlFor="expiry">Expiry dates verified</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="batch"
                  checked={qualityChecks.batchRecorded}
                  onCheckedChange={(checked) => setQualityChecks({ ...qualityChecks, batchRecorded: !!checked })}
                />
                <Label htmlFor="batch">Batch numbers recorded</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="quantity"
                  checked={qualityChecks.quantityVerified}
                  onCheckedChange={(checked) => setQualityChecks({ ...qualityChecks, quantityVerified: !!checked })}
                />
                <Label htmlFor="quantity">Quantities verified</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="temperature"
                  checked={qualityChecks.temperatureOk}
                  onCheckedChange={(checked) => setQualityChecks({ ...qualityChecks, temperatureOk: !!checked })}
                />
                <Label htmlFor="temperature">Temperature maintained</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="documents"
                  checked={qualityChecks.documentsComplete}
                  onCheckedChange={(checked) => setQualityChecks({ ...qualityChecks, documentsComplete: !!checked })}
                />
                <Label htmlFor="documents">Documents complete</Label>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={() => handleSubmit("draft")}
                variant="outline"
                className="w-full border-gray-200"
                disabled={loading}
              >
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Button
                onClick={() => handleSubmit("completed")}
                className="w-full bg-red-600 hover:bg-red-700"
                disabled={loading || !grnData.poNumber || !grnData.invoiceNumber}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Complete GRN
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

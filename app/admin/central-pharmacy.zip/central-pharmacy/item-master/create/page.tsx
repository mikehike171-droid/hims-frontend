"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Save, Check } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import PrivateRoute from "@/components/auth/PrivateRoute"

export default function CreateItem() {
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)

  const [itemData, setItemData] = useState({
    itemCode: `ITM-${Date.now()}`,
    drugName: "",
    genericName: "",
    brandName: "",
    strength: "",
    dosageForm: "",
    unit: "TAB",
    manufacturer: "",
    category: "",
    schedule: "OTC",
    therapeuticClass: "",
    composition: "",
    indication: "",
    contraindication: "",
    sideEffects: "",
    dosage: "",
    storage: "",
    packSize: 1,
    reorderLevel: 0,
    maxLevel: 0,
    unitCost: 0,
    sellingPrice: 0,
    mrp: 0,
    gstRate: 12,
    hsnCode: "",
    barcode: "",
    status: "active",
    isNarcotic: false,
    requiresPrescription: false,
    isRefrigerated: false,
    notes: "",
  })

  const dosageForms = [
    "Tablet",
    "Capsule",
    "Syrup",
    "Injection",
    "Cream",
    "Ointment",
    "Drops",
    "Powder",
    "Suspension",
    "Inhaler",
  ]

  const units = ["TAB", "CAP", "BTL", "AMP", "VIAL", "TUBE", "BOX", "STRIP", "PKT", "GM", "ML", "MG"]

  const categories = [
    "Analgesics",
    "Antibiotics",
    "Antidiabetic",
    "Cardiovascular",
    "Gastrology",
    "Respiratory",
    "Dermatology",
    "Neurology",
    "Oncology",
    "Pediatric",
  ]

  const schedules = [
    { value: "OTC", label: "Over The Counter" },
    { value: "H", label: "Schedule H" },
    { value: "H1", label: "Schedule H1" },
    { value: "X", label: "Schedule X" },
  ]

  const manufacturers = [
    "Cipla Pharmaceuticals",
    "Sun Pharma Ltd",
    "Lupin Limited",
    "Dr. Reddy's Labs",
    "Ranbaxy Laboratories",
    "Cadila Healthcare",
    "Glenmark Pharmaceuticals",
    "Aurobindo Pharma",
  ]

  const handleSubmit = async (status: string) => {
    setLoading(true)
    try {
      // Validate required fields
      if (!itemData.drugName || !itemData.genericName || !itemData.manufacturer) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields",
          variant: "destructive",
        })
        return
      }

      // Validate pricing
      if (itemData.unitCost <= 0 || itemData.sellingPrice <= 0) {
        toast({
          title: "Validation Error",
          description: "Please enter valid pricing information",
          variant: "destructive",
        })
        return
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `Item ${status === "draft" ? "saved as draft" : "created"} successfully`,
      })

      router.push("/central-pharmacy/item-master")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save item",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/item-master/create" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Add New Item</h1>
            <p className="text-gray-600">Create a new pharmaceutical item</p>
          </div>
        </div>
        <Badge variant="secondary">New</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Basic Information */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="itemCode">Item Code</Label>
                  <Input id="itemCode" value={itemData.itemCode} disabled className="bg-gray-50" />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={itemData.status}
                    onValueChange={(value) => setItemData({ ...itemData, status: value })}
                  >
                    <SelectTrigger className="border-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="drugName">Drug Name *</Label>
                  <Input
                    id="drugName"
                    value={itemData.drugName}
                    onChange={(e) => setItemData({ ...itemData, drugName: e.target.value })}
                    placeholder="Enter drug name"
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="genericName">Generic Name *</Label>
                  <Input
                    id="genericName"
                    value={itemData.genericName}
                    onChange={(e) => setItemData({ ...itemData, genericName: e.target.value })}
                    placeholder="Enter generic name"
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="brandName">Brand Name</Label>
                  <Input
                    id="brandName"
                    value={itemData.brandName}
                    onChange={(e) => setItemData({ ...itemData, brandName: e.target.value })}
                    placeholder="Enter brand name"
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="strength">Strength</Label>
                  <Input
                    id="strength"
                    value={itemData.strength}
                    onChange={(e) => setItemData({ ...itemData, strength: e.target.value })}
                    placeholder="e.g., 500mg"
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="dosageForm">Dosage Form</Label>
                  <Select
                    value={itemData.dosageForm}
                    onValueChange={(value) => setItemData({ ...itemData, dosageForm: value })}
                  >
                    <SelectTrigger className="border-gray-200">
                      <SelectValue placeholder="Select form" />
                    </SelectTrigger>
                    <SelectContent>
                      {dosageForms.map((form) => (
                        <SelectItem key={form} value={form}>
                          {form}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="unit">Unit</Label>
                  <Select value={itemData.unit} onValueChange={(value) => setItemData({ ...itemData, unit: value })}>
                    <SelectTrigger className="border-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="packSize">Pack Size</Label>
                  <Input
                    id="packSize"
                    type="number"
                    value={itemData.packSize}
                    onChange={(e) => setItemData({ ...itemData, packSize: Number.parseInt(e.target.value) || 1 })}
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="manufacturer">Manufacturer *</Label>
                  <Select
                    value={itemData.manufacturer}
                    onValueChange={(value) => setItemData({ ...itemData, manufacturer: value })}
                  >
                    <SelectTrigger className="border-gray-200">
                      <SelectValue placeholder="Select manufacturer" />
                    </SelectTrigger>
                    <SelectContent>
                      {manufacturers.map((manufacturer) => (
                        <SelectItem key={manufacturer} value={manufacturer}>
                          {manufacturer}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={itemData.category}
                    onValueChange={(value) => setItemData({ ...itemData, category: value })}
                  >
                    <SelectTrigger className="border-gray-200">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="schedule">Schedule</Label>
                  <Select
                    value={itemData.schedule}
                    onValueChange={(value) => setItemData({ ...itemData, schedule: value })}
                  >
                    <SelectTrigger className="border-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {schedules.map((schedule) => (
                        <SelectItem key={schedule.value} value={schedule.value}>
                          {schedule.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="hsnCode">HSN Code</Label>
                  <Input
                    id="hsnCode"
                    value={itemData.hsnCode}
                    onChange={(e) => setItemData({ ...itemData, hsnCode: e.target.value })}
                    placeholder="Enter HSN code"
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="barcode">Barcode</Label>
                  <Input
                    id="barcode"
                    value={itemData.barcode}
                    onChange={(e) => setItemData({ ...itemData, barcode: e.target.value })}
                    placeholder="Enter barcode"
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="composition">Composition</Label>
                <Textarea
                  id="composition"
                  value={itemData.composition}
                  onChange={(e) => setItemData({ ...itemData, composition: e.target.value })}
                  placeholder="Enter drug composition"
                  className="border-gray-200"
                />
              </div>
            </CardContent>
          </Card>

          {/* Pricing & Stock */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Pricing & Stock Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="unitCost">Unit Cost (₹) *</Label>
                  <Input
                    id="unitCost"
                    type="number"
                    step="0.01"
                    value={itemData.unitCost}
                    onChange={(e) => setItemData({ ...itemData, unitCost: Number.parseFloat(e.target.value) || 0 })}
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="sellingPrice">Selling Price (₹) *</Label>
                  <Input
                    id="sellingPrice"
                    type="number"
                    step="0.01"
                    value={itemData.sellingPrice}
                    onChange={(e) => setItemData({ ...itemData, sellingPrice: Number.parseFloat(e.target.value) || 0 })}
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="mrp">MRP (₹)</Label>
                  <Input
                    id="mrp"
                    type="number"
                    step="0.01"
                    value={itemData.mrp}
                    onChange={(e) => setItemData({ ...itemData, mrp: Number.parseFloat(e.target.value) || 0 })}
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="gstRate">GST Rate (%)</Label>
                  <Input
                    id="gstRate"
                    type="number"
                    value={itemData.gstRate}
                    onChange={(e) => setItemData({ ...itemData, gstRate: Number.parseFloat(e.target.value) || 0 })}
                    className="border-gray-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="reorderLevel">Reorder Level</Label>
                  <Input
                    id="reorderLevel"
                    type="number"
                    value={itemData.reorderLevel}
                    onChange={(e) => setItemData({ ...itemData, reorderLevel: Number.parseInt(e.target.value) || 0 })}
                    className="border-gray-200"
                  />
                </div>
                <div>
                  <Label htmlFor="maxLevel">Maximum Level</Label>
                  <Input
                    id="maxLevel"
                    type="number"
                    value={itemData.maxLevel}
                    onChange={(e) => setItemData({ ...itemData, maxLevel: Number.parseInt(e.target.value) || 0 })}
                    className="border-gray-200"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Clinical Information */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Clinical Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="indication">Indication</Label>
                <Textarea
                  id="indication"
                  value={itemData.indication}
                  onChange={(e) => setItemData({ ...itemData, indication: e.target.value })}
                  placeholder="Enter indications for use"
                  className="border-gray-200"
                />
              </div>

              <div>
                <Label htmlFor="dosage">Dosage</Label>
                <Textarea
                  id="dosage"
                  value={itemData.dosage}
                  onChange={(e) => setItemData({ ...itemData, dosage: e.target.value })}
                  placeholder="Enter dosage instructions"
                  className="border-gray-200"
                />
              </div>

              <div>
                <Label htmlFor="contraindication">Contraindications</Label>
                <Textarea
                  id="contraindication"
                  value={itemData.contraindication}
                  onChange={(e) => setItemData({ ...itemData, contraindication: e.target.value })}
                  placeholder="Enter contraindications"
                  className="border-gray-200"
                />
              </div>

              <div>
                <Label htmlFor="sideEffects">Side Effects</Label>
                <Textarea
                  id="sideEffects"
                  value={itemData.sideEffects}
                  onChange={(e) => setItemData({ ...itemData, sideEffects: e.target.value })}
                  placeholder="Enter side effects"
                  className="border-gray-200"
                />
              </div>

              <div>
                <Label htmlFor="storage">Storage Conditions</Label>
                <Textarea
                  id="storage"
                  value={itemData.storage}
                  onChange={(e) => setItemData({ ...itemData, storage: e.target.value })}
                  placeholder="Enter storage conditions"
                  className="border-gray-200"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Item Properties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isNarcotic"
                  checked={itemData.isNarcotic}
                  onCheckedChange={(checked) => setItemData({ ...itemData, isNarcotic: !!checked })}
                />
                <Label htmlFor="isNarcotic">Narcotic Drug</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="requiresPrescription"
                  checked={itemData.requiresPrescription}
                  onCheckedChange={(checked) => setItemData({ ...itemData, requiresPrescription: !!checked })}
                />
                <Label htmlFor="requiresPrescription">Requires Prescription</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isRefrigerated"
                  checked={itemData.isRefrigerated}
                  onCheckedChange={(checked) => setItemData({ ...itemData, isRefrigerated: !!checked })}
                />
                <Label htmlFor="isRefrigerated">Refrigerated Storage</Label>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Additional Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={itemData.notes}
                onChange={(e) => setItemData({ ...itemData, notes: e.target.value })}
                placeholder="Enter additional notes or comments"
                className="border-gray-200"
              />
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={() => handleSubmit("draft")}
                variant="outline"
                className="w-full border-gray-200"
                disabled={loading}
              >
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Button
                onClick={() => handleSubmit("active")}
                className="w-full bg-red-600 hover:bg-red-700"
                disabled={loading || !itemData.drugName || !itemData.genericName || !itemData.manufacturer}
              >
                <Check className="h-4 w-4 mr-2" />
                Create Item
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

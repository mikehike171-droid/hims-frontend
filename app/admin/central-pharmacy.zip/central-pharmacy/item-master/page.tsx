"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, Edit, Trash2, Package, AlertCircle, CheckCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface DrugItem {
  id: string
  drugName: string
  genericName: string
  brandName: string
  strength: string
  dosageForm: string
  unit: string
  manufacturer: string
  category: string
  schedule: string
  reorderLevel: number
  maxLevel: number
  unitCost: number
  sellingPrice: number
  gstRate: number
  status: "active" | "inactive" | "discontinued"
  createdAt: string
  updatedAt: string
}

export default function ItemMaster() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [filterCategory, setFilterCategory] = useState("")
  const [filterStatus, setFilterStatus] = useState("")

  const [items] = useState<DrugItem[]>([
    {
      id: "1",
      drugName: "Paracetamol",
      genericName: "Acetaminophen",
      brandName: "Crocin",
      strength: "500mg",
      dosageForm: "Tablet",
      unit: "TAB",
      manufacturer: "Cipla Pharmaceuticals",
      category: "Analgesics",
      schedule: "OTC",
      reorderLevel: 500,
      maxLevel: 2000,
      unitCost: 2.5,
      sellingPrice: 3.0,
      gstRate: 12,
      status: "active",
      createdAt: "2024-01-15",
      updatedAt: "2024-01-20",
    },
    {
      id: "2",
      drugName: "Amoxicillin",
      genericName: "Amoxicillin",
      brandName: "Amoxil",
      strength: "250mg",
      dosageForm: "Capsule",
      unit: "CAP",
      manufacturer: "Sun Pharma Ltd",
      category: "Antibiotics",
      schedule: "H",
      reorderLevel: 300,
      maxLevel: 1500,
      unitCost: 5.0,
      sellingPrice: 6.0,
      gstRate: 12,
      status: "active",
      createdAt: "2024-01-10",
      updatedAt: "2024-01-18",
    },
    {
      id: "3",
      drugName: "Omeprazole",
      genericName: "Omeprazole",
      brandName: "Prilosec",
      strength: "20mg",
      dosageForm: "Capsule",
      unit: "CAP",
      manufacturer: "Lupin Limited",
      category: "Gastrology",
      schedule: "H",
      reorderLevel: 200,
      maxLevel: 1000,
      unitCost: 12.0,
      sellingPrice: 15.0,
      gstRate: 12,
      status: "active",
      createdAt: "2024-01-05",
      updatedAt: "2024-01-15",
    },
    {
      id: "4",
      drugName: "Atorvastatin",
      genericName: "Atorvastatin",
      brandName: "Lipitor",
      strength: "10mg",
      dosageForm: "Tablet",
      unit: "TAB",
      manufacturer: "Dr. Reddy's Labs",
      category: "Cardiovascular",
      schedule: "H",
      reorderLevel: 400,
      maxLevel: 2000,
      unitCost: 15.0,
      sellingPrice: 18.0,
      gstRate: 12,
      status: "active",
      createdAt: "2024-01-01",
      updatedAt: "2024-01-12",
    },
    {
      id: "5",
      drugName: "Metformin",
      genericName: "Metformin Hydrochloride",
      brandName: "Glucophage",
      strength: "500mg",
      dosageForm: "Tablet",
      unit: "TAB",
      manufacturer: "Sun Pharma Ltd",
      category: "Antidiabetic",
      schedule: "H",
      reorderLevel: 600,
      maxLevel: 3000,
      unitCost: 3.5,
      sellingPrice: 4.5,
      gstRate: 12,
      status: "active",
      createdAt: "2023-12-20",
      updatedAt: "2024-01-08",
    },
  ])

  const categories = ["All Categories", "Analgesics", "Antibiotics", "Gastrology", "Cardiovascular", "Antidiabetic"]
  const statuses = ["All Status", "active", "inactive", "discontinued"]

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.drugName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.genericName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.brandName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.manufacturer.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = !filterCategory || filterCategory === "All Categories" || item.category === filterCategory
    const matchesStatus = !filterStatus || filterStatus === "All Status" || item.status === filterStatus

    return matchesSearch && matchesCategory && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle className="h-3 w-3 mr-1" />
            Active
          </Badge>
        )
      case "inactive":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            <AlertCircle className="h-3 w-3 mr-1" />
            Inactive
          </Badge>
        )
      case "discontinued":
        return (
          <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200">
            <AlertCircle className="h-3 w-3 mr-1" />
            Discontinued
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/item-master" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Item Master</h1>
          <p className="text-gray-600">Manage all pharmaceutical items and medicines</p>
        </div>
        <Button
          onClick={() => router.push("/central-pharmacy/item-master/create")}
          className="bg-red-600 hover:bg-red-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add New Item
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-6">
            <div className="flex items-center">
              <Package className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Items</p>
                <p className="text-2xl font-bold text-gray-900">{items.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-6">
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Items</p>
                <p className="text-2xl font-bold text-gray-900">
                  {items.filter((item) => item.status === "active").length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-6">
            <div className="flex items-center">
              <AlertCircle className="h-8 w-8 text-yellow-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Categories</p>
                <p className="text-2xl font-bold text-gray-900">{new Set(items.map((item) => item.category)).size}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardContent className="p-6">
            <div className="flex items-center">
              <Package className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Manufacturers</p>
                <p className="text-2xl font-bold text-gray-900">
                  {new Set(items.map((item) => item.manufacturer)).size}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="bg-white shadow-sm border-0">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search items by name, generic name, brand, or manufacturer..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 border-gray-200"
              />
            </div>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-md bg-white"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-md bg-white"
            >
              {statuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Items Table */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle>Items List ({filteredItems.length} items)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Drug Details</TableHead>
                  <TableHead>Strength</TableHead>
                  <TableHead>Manufacturer</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Schedule</TableHead>
                  <TableHead>Stock Levels</TableHead>
                  <TableHead>Pricing</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredItems.map((item) => (
                  <TableRow key={item.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div>
                        <div className="font-medium text-gray-900">{item.drugName}</div>
                        <div className="text-sm text-gray-500">{item.genericName}</div>
                        <div className="text-xs text-blue-600">{item.brandName}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{item.strength}</div>
                        <div className="text-gray-500">{item.dosageForm}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-gray-900">{item.manufacturer}</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {item.category}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={item.schedule === "OTC" ? "secondary" : "default"} className="text-xs">
                        {item.schedule}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>Reorder: {item.reorderLevel}</div>
                        <div className="text-gray-500">Max: {item.maxLevel}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>Cost: ₹{item.unitCost}</div>
                        <div className="text-green-600">MRP: ₹{item.sellingPrice}</div>
                        <div className="text-xs text-gray-500">GST: {item.gstRate}%</div>
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(item.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => router.push(`/central-pharmacy/item-master/edit/${item.id}`)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Package, AlertTriangle, ShoppingCart, Truck, TrendingUp, TrendingDown, Calendar, DollarSign, BarChart3, Brain, ArrowRight, Clock, CheckCircle, XCircle, RefreshCw } from 'lucide-react'
import Link from 'next/link'
import PrivateRoute from '@/components/auth/PrivateRoute'

// Mock data
const dashboardStats = {
  currentStockValue: 2450000,
  expiringIn30Days: 45,
  pendingPOs: 12,
  pendingDispatches: 8,
  totalItems: 1250,
  lowStockItems: 23,
  overstockItems: 15,
  monthlyConsumption: 1850000
}

const consumptionTrend = [
  { date: '2024-01-01', consumption: 58000 },
  { date: '2024-01-02', consumption: 62000 },
  { date: '2024-01-03', consumption: 55000 },
  { date: '2024-01-04', consumption: 68000 },
  { date: '2024-01-05', consumption: 72000 },
  { date: '2024-01-06', consumption: 65000 },
  { date: '2024-01-07', consumption: 59000 },
]

const topDrugs = [
  { name: 'Paracetamol 500mg', usage: 2500, trend: 'up' },
  { name: 'Amoxicillin 250mg', usage: 1800, trend: 'up' },
  { name: 'Metformin 500mg', usage: 1650, trend: 'down' },
  { name: 'Aspirin 75mg', usage: 1420, trend: 'up' },
  { name: 'Omeprazole 20mg', usage: 1350, trend: 'stable' },
  { name: 'Atorvastatin 10mg', usage: 1200, trend: 'up' },
  { name: 'Losartan 50mg', usage: 1150, trend: 'down' },
  { name: 'Amlodipine 5mg', usage: 1080, trend: 'stable' },
  { name: 'Ciprofloxacin 500mg', usage: 950, trend: 'up' },
  { name: 'Diclofenac 50mg', usage: 890, trend: 'down' }
]

const aiAlerts = [
  {
    id: 1,
    type: 'expiry',
    priority: 'high',
    title: 'Near Expiry Alert',
    message: '15 batches of Insulin expiring in next 15 days',
    action: 'Review Batches',
    count: 15
  },
  {
    id: 2,
    type: 'overstock',
    priority: 'medium',
    title: 'Overstock Alert',
    message: 'Paracetamol 500mg has 6 months stock available',
    action: 'Reduce Orders',
    count: 1
  },
  {
    id: 3,
    type: 'understock',
    priority: 'high',
    title: 'Low Stock Alert',
    message: '8 critical drugs below minimum stock level',
    action: 'Create PO',
    count: 8
  },
  {
    id: 4,
    type: 'transfer',
    priority: 'medium',
    title: 'Transfer Suggestion',
    message: 'ICU Store needs Noradrenaline - Available in Central',
    action: 'Create Transfer',
    count: 3
  }
]

const recentActivities = [
  {
    id: 1,
    type: 'po_created',
    message: 'PO-2024-001 created for Cipla Pharmaceuticals',
    user: 'Dr. Sharma',
    time: '2 hours ago',
    status: 'pending'
  },
  {
    id: 2,
    type: 'grn_received',
    message: 'GRN-2024-045 received from Sun Pharma',
    user: 'Mr. Patel',
    time: '4 hours ago',
    status: 'completed'
  },
  {
    id: 3,
    type: 'transfer_dispatched',
    message: 'Transfer to ICU Store dispatched',
    user: 'Ms. Singh',
    time: '6 hours ago',
    status: 'in_transit'
  },
  {
    id: 4,
    type: 'stock_adjusted',
    message: 'Stock adjustment for expired medicines',
    user: 'Dr. Kumar',
    time: '1 day ago',
    status: 'completed'
  }
]

export default function CentralPharmacyDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState('30days')

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'expiry': return <Clock className="h-4 w-4" />
      case 'overstock': return <TrendingUp className="h-4 w-4" />
      case 'understock': return <TrendingDown className="h-4 w-4" />
      case 'transfer': return <RefreshCw className="h-4 w-4" />
      default: return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getAlertColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'po_created': return <ShoppingCart className="h-4 w-4 text-blue-500" />
      case 'grn_received': return <Truck className="h-4 w-4 text-green-500" />
      case 'transfer_dispatched': return <RefreshCw className="h-4 w-4 text-purple-500" />
      case 'stock_adjusted': return <Package className="h-4 w-4 text-orange-500" />
      default: return <Package className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed': return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case 'pending': return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      case 'in_transit': return <Badge className="bg-blue-100 text-blue-800">In Transit</Badge>
      default: return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>
    }
  }

  return (
    <PrivateRoute modulePath="admin/central-pharmacy" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Central Pharmacy Dashboard</h1>
          <p className="text-gray-600 mt-1">Monitor inventory, track orders, and manage stock across all stores</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="border-gray-200">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh Data
          </Button>
          <Link href="/central-pharmacy/purchase-orders/new">
            <Button className="bg-red-600 hover:bg-red-700 text-white">
              <ShoppingCart className="mr-2 h-4 w-4" />
              Create PO
            </Button>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Current Stock Value</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">₹{(dashboardStats.currentStockValue / 100000).toFixed(1)}L</div>
            <p className="text-xs text-gray-500 mt-1">
              <span className="text-green-600">+8.2%</span> from last month
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Expiring in 30 Days</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{dashboardStats.expiringIn30Days}</div>
            <p className="text-xs text-gray-500 mt-1">Items need attention</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">POs Pending Approval</CardTitle>
            <ShoppingCart className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{dashboardStats.pendingPOs}</div>
            <p className="text-xs text-gray-500 mt-1">Awaiting approval</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Store Requests Pending</CardTitle>
            <Truck className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{dashboardStats.pendingDispatches}</div>
            <p className="text-xs text-gray-500 mt-1">Pending dispatch</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Charts Section */}
        <div className="lg:col-span-2 space-y-6">
          {/* Consumption Trend */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle className="text-gray-900">Drug Consumption Trend</CardTitle>
              <CardDescription className="text-gray-600">Daily consumption over the last 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-2">
                {consumptionTrend.map((day, index) => (
                  <div key={index} className="flex flex-col items-center flex-1">
                    <div 
                      className="bg-red-500 rounded-t w-full min-h-[4px] transition-all hover:bg-red-600"
                      style={{ height: `${(day.consumption / 80000) * 100}%` }}
                    />
                    <span className="text-xs text-gray-500 mt-2">
                      {new Date(day.date).getDate()}
                    </span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-sm text-gray-500 mt-4">
                <span>Jan 1</span>
                <span>Jan 7</span>
              </div>
            </CardContent>
          </Card>

          {/* Top Drugs */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle className="text-gray-900">Top 10 Drugs by Usage</CardTitle>
              <CardDescription className="text-gray-600">Most consumed drugs this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topDrugs.map((drug, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium text-gray-500 w-6">#{index + 1}</span>
                      <div>
                        <p className="font-medium text-gray-900">{drug.name}</p>
                        <p className="text-sm text-gray-500">{drug.usage} units</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {drug.trend === 'up' && <TrendingUp className="h-4 w-4 text-green-500" />}
                      {drug.trend === 'down' && <TrendingDown className="h-4 w-4 text-red-500" />}
                      {drug.trend === 'stable' && <div className="h-4 w-4 bg-gray-300 rounded-full" />}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Alerts & Activities */}
        <div className="space-y-6">
          {/* AI Alert Panel */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <Brain className="h-5 w-5 text-purple-600" />
                AI Insights & Alerts
              </CardTitle>
              <CardDescription className="text-gray-600">Smart recommendations and alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {aiAlerts.map((alert) => (
                  <div key={alert.id} className={`p-3 rounded-lg border ${getAlertColor(alert.priority)}`}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-2">
                        {getAlertIcon(alert.type)}
                        <div className="flex-1">
                          <p className="font-medium text-sm">{alert.title}</p>
                          <p className="text-xs mt-1 opacity-90">{alert.message}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {alert.count}
                      </Badge>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="mt-2 h-7 text-xs border-current"
                    >
                      {alert.action}
                      <ArrowRight className="ml-1 h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
              <Link href="/central-pharmacy/ai-insights">
                <Button variant="outline" className="w-full mt-4 border-gray-200">
                  View All Insights
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Recent Activities */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle className="text-gray-900">Recent Activities</CardTitle>
              <CardDescription className="text-gray-600">Latest system activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className="mt-1">
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-xs text-gray-500">by {activity.user} • {activity.time}</p>
                        {getStatusBadge(activity.status)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle className="text-gray-900">Quick Actions</CardTitle>
          <CardDescription className="text-gray-600">Frequently used operations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Link href="/central-pharmacy/purchase-orders/new">
              <Button variant="outline" className="w-full h-20 flex-col gap-2 border-gray-200 hover:bg-gray-50">
                <ShoppingCart className="h-6 w-6 text-blue-600" />
                <span className="text-sm font-medium">Create Purchase Order</span>
              </Button>
            </Link>
            <Link href="/central-pharmacy/grn/new">
              <Button variant="outline" className="w-full h-20 flex-col gap-2 border-gray-200 hover:bg-gray-50">
                <Truck className="h-6 w-6 text-green-600" />
                <span className="text-sm font-medium">Goods Receipt Entry</span>
              </Button>
            </Link>
            <Link href="/central-pharmacy/transfers/new">
              <Button variant="outline" className="w-full h-20 flex-col gap-2 border-gray-200 hover:bg-gray-50">
                <RefreshCw className="h-6 w-6 text-purple-600" />
                <span className="text-sm font-medium">Inter-Store Transfer</span>
              </Button>
            </Link>
            <Link href="/central-pharmacy/stock">
              <Button variant="outline" className="w-full h-20 flex-col gap-2 border-gray-200 hover:bg-gray-50">
                <Package className="h-6 w-6 text-orange-600" />
                <span className="text-sm font-medium">View Stock Ledger</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, ArrowLeft, Save, Send, Trash2, Search, AlertTriangle, TrendingDown } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface POItem {
  id: string
  drugName: string
  genericName: string
  strength: string
  unit: string
  quantity: number
  unitPrice: number
  mrp: number
  scheme: string
  schemeDiscount: number
  totalPrice: number
  taxRate: number
  taxAmount: number
  finalAmount: number
}

interface VendorStock {
  id: string
  drugName: string
  genericName: string
  strength: string
  unit: string
  currentStock: number
  reorderLevel: number
  maxLevel: number
  lastPurchasePrice: number
  mrp: number
  scheme: string
  thresholdPercentage: number
  isLowStock: boolean
  selected: boolean
}

export default function CreatePurchaseOrder() {
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [stockSearchTerm, setStockSearchTerm] = useState("")

  const [poData, setPOData] = useState({
    poNumber: `PO-${Date.now()}`,
    poDate: new Date().toISOString().split("T")[0],
    vendorId: "",
    expectedDelivery: "",
    priority: "normal",
    paymentTerms: "30",
    notes: "",
    status: "draft",
  })

  const [items, setItems] = useState<POItem[]>([])
  const [vendorStocks, setVendorStocks] = useState<VendorStock[]>([])
  const [showVendorStock, setShowVendorStock] = useState(false)

  const vendors = [
    { id: "1", name: "Cipla Pharmaceuticals", code: "CIPLA001" },
    { id: "2", name: "Sun Pharma Ltd", code: "SUN001" },
    { id: "3", name: "Lupin Limited", code: "LUPIN001" },
    { id: "4", name: "Dr. Reddy's Labs", code: "DRL001" },
  ]

  const priorities = [
    { value: "low", label: "Low" },
    { value: "normal", label: "Normal" },
    { value: "high", label: "High" },
    { value: "urgent", label: "Urgent" },
  ]

  const schemeOptions = [
    { value: "none", label: "No Scheme" },
    { value: "BUY_10_GET_1", label: "Buy 10 Get 1 Free" },
    { value: "BUY_5_GET_1", label: "Buy 5 Get 1 Free" },
    { value: "FLAT_5_PERCENT", label: "Flat 5% Discount" },
    { value: "FLAT_10_PERCENT", label: "Flat 10% Discount" },
    { value: "VOLUME_DISCOUNT", label: "Volume Discount" },
    { value: "SEASONAL_OFFER", label: "Seasonal Offer" },
  ]

  // Mock vendor stock data
  const mockVendorStocks: Record<string, VendorStock[]> = {
    "1": [
      {
        id: "1",
        drugName: "Paracetamol",
        genericName: "Acetaminophen",
        strength: "500mg",
        unit: "TAB",
        currentStock: 150,
        reorderLevel: 500,
        maxLevel: 2000,
        lastPurchasePrice: 2.5,
        mrp: 4.0,
        scheme: "BUY_10_GET_1",
        thresholdPercentage: 30,
        isLowStock: true,
        selected: false,
      },
      {
        id: "2",
        drugName: "Amoxicillin",
        genericName: "Amoxicillin",
        strength: "250mg",
        unit: "CAP",
        currentStock: 100,
        reorderLevel: 300,
        maxLevel: 1500,
        lastPurchasePrice: 5.0,
        mrp: 8.5,
        scheme: "FLAT_5_PERCENT",
        thresholdPercentage: 33,
        isLowStock: true,
        selected: false,
      },
      {
        id: "3",
        drugName: "Ciprofloxacin",
        genericName: "Ciprofloxacin",
        strength: "500mg",
        unit: "TAB",
        currentStock: 800,
        reorderLevel: 1000,
        maxLevel: 3000,
        lastPurchasePrice: 8.0,
        mrp: 12.0,
        scheme: "none",
        thresholdPercentage: 80,
        isLowStock: false,
        selected: false,
      },
      {
        id: "4",
        drugName: "Omeprazole",
        genericName: "Omeprazole",
        strength: "20mg",
        unit: "CAP",
        currentStock: 50,
        reorderLevel: 200,
        maxLevel: 1000,
        lastPurchasePrice: 12.0,
        mrp: 18.0,
        scheme: "BUY_5_GET_1",
        thresholdPercentage: 25,
        isLowStock: true,
        selected: false,
      },
    ],
    "2": [
      {
        id: "5",
        drugName: "Atorvastatin",
        genericName: "Atorvastatin",
        strength: "10mg",
        unit: "TAB",
        currentStock: 80,
        reorderLevel: 400,
        maxLevel: 2000,
        lastPurchasePrice: 15.0,
        mrp: 22.0,
        scheme: "FLAT_10_PERCENT",
        thresholdPercentage: 20,
        isLowStock: true,
        selected: false,
      },
      {
        id: "6",
        drugName: "Metformin",
        genericName: "Metformin",
        strength: "500mg",
        unit: "TAB",
        currentStock: 600,
        reorderLevel: 800,
        maxLevel: 3000,
        lastPurchasePrice: 3.5,
        mrp: 6.0,
        scheme: "VOLUME_DISCOUNT",
        thresholdPercentage: 75,
        isLowStock: false,
        selected: false,
      },
    ],
  }

  useEffect(() => {
    if (poData.vendorId) {
      const stocks = mockVendorStocks[poData.vendorId] || []
      setVendorStocks(stocks)
      setShowVendorStock(true)
    } else {
      setVendorStocks([])
      setShowVendorStock(false)
    }
  }, [poData.vendorId])

  const calculateSchemeDiscount = (scheme: string, quantity: number, unitPrice: number) => {
    const totalPrice = quantity * unitPrice

    switch (scheme) {
      case "FLAT_5_PERCENT":
        return totalPrice * 0.05
      case "FLAT_10_PERCENT":
        return totalPrice * 0.1
      case "BUY_10_GET_1":
        return Math.floor(quantity / 10) * unitPrice
      case "BUY_5_GET_1":
        return Math.floor(quantity / 5) * unitPrice
      case "VOLUME_DISCOUNT":
        return quantity > 100 ? totalPrice * 0.08 : quantity > 50 ? totalPrice * 0.05 : 0
      case "SEASONAL_OFFER":
        return totalPrice * 0.07
      case "none":
      default:
        return 0
    }
  }

  const calculateItemTotals = (item: POItem) => {
    const totalPrice = item.quantity * item.unitPrice
    const schemeDiscount = calculateSchemeDiscount(item.scheme, item.quantity, item.unitPrice)
    const priceAfterScheme = totalPrice - schemeDiscount
    const taxAmount = (priceAfterScheme * item.taxRate) / 100
    const finalAmount = priceAfterScheme + taxAmount

    return {
      ...item,
      schemeDiscount,
      totalPrice: priceAfterScheme,
      taxAmount,
      finalAmount,
    }
  }

  const updateItem = (index: number, field: keyof POItem, value: any) => {
    const updatedItems = [...items]
    updatedItems[index] = { ...updatedItems[index], [field]: value }
    updatedItems[index] = calculateItemTotals(updatedItems[index])
    setItems(updatedItems)
  }

  const addItem = () => {
    const newItem: POItem = {
      id: Date.now().toString(),
      drugName: "",
      genericName: "",
      strength: "",
      unit: "TAB",
      quantity: 0,
      unitPrice: 0,
      mrp: 0,
      scheme: "none",
      schemeDiscount: 0,
      totalPrice: 0,
      taxRate: 18,
      taxAmount: 0,
      finalAmount: 0,
    }
    setItems([...items, newItem])
  }

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index))
  }

  const handleStockSelection = (stockIndex: number, checked: boolean) => {
    const updatedStocks = [...vendorStocks]
    updatedStocks[stockIndex].selected = checked
    setVendorStocks(updatedStocks)
  }

  const addSelectedStockItems = () => {
    const selectedStocks = vendorStocks.filter((stock) => stock.selected)
    const newItems: POItem[] = selectedStocks.map((stock) => {
      const suggestedQuantity = Math.max(stock.reorderLevel - stock.currentStock, 0)
      const schemeDiscount = calculateSchemeDiscount(stock.scheme, suggestedQuantity, stock.lastPurchasePrice)
      const totalPrice = suggestedQuantity * stock.lastPurchasePrice - schemeDiscount
      const taxAmount = (totalPrice * 18) / 100
      const finalAmount = totalPrice + taxAmount

      return {
        id: Date.now().toString() + Math.random(),
        drugName: stock.drugName,
        genericName: stock.genericName,
        strength: stock.strength,
        unit: stock.unit,
        quantity: suggestedQuantity,
        unitPrice: stock.lastPurchasePrice,
        mrp: stock.mrp,
        scheme: stock.scheme,
        schemeDiscount,
        totalPrice,
        taxRate: 18,
        taxAmount,
        finalAmount,
      }
    })

    setItems([...items, ...newItems])
    // Reset selections
    const updatedStocks = vendorStocks.map((stock) => ({ ...stock, selected: false }))
    setVendorStocks(updatedStocks)

    toast({
      title: "Items Added",
      description: `${selectedStocks.length} items added to purchase order`,
    })
  }

  const calculateTotals = () => {
    const subtotal = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
    const totalSchemeDiscount = items.reduce((sum, item) => sum + item.schemeDiscount, 0)
    const totalAfterScheme = items.reduce((sum, item) => sum + item.totalPrice, 0)
    const totalTax = items.reduce((sum, item) => sum + item.taxAmount, 0)
    const grandTotal = items.reduce((sum, item) => sum + item.finalAmount, 0)

    return { subtotal, totalSchemeDiscount, totalAfterScheme, totalTax, grandTotal }
  }

  const handleSubmit = async (status: string) => {
    setLoading(true)
    try {
      // Validate required fields
      if (!poData.vendorId) {
        toast({
          title: "Validation Error",
          description: "Please select a vendor",
          variant: "destructive",
        })
        return
      }

      const hasEmptyItems = items.some((item) => !item.drugName || item.quantity <= 0)
      if (hasEmptyItems) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields for PO items",
          variant: "destructive",
        })
        return
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `Purchase Order ${status === "draft" ? "saved as draft" : "submitted"} successfully`,
      })

      router.push("/central-pharmacy/purchase-orders")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save purchase order",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredItems = items.filter(
    (item) =>
      item.drugName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.genericName.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredVendorStocks = vendorStocks.filter(
    (stock) =>
      stock.drugName.toLowerCase().includes(stockSearchTerm.toLowerCase()) ||
      stock.genericName.toLowerCase().includes(stockSearchTerm.toLowerCase()),
  )

  const { subtotal, totalSchemeDiscount, totalAfterScheme, totalTax, grandTotal } = calculateTotals()
  const selectedStockCount = vendorStocks.filter((stock) => stock.selected).length
  const lowStockCount = vendorStocks.filter((stock) => stock.isLowStock).length

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/purchase-orders/new" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Create Purchase Order</h1>
            <p className="text-gray-600">Create a new purchase order for inventory procurement</p>
          </div>
        </div>
        <Badge variant="secondary">Draft</Badge>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* PO Details */}
        <Card className="bg-white shadow-sm border-0">
          <CardHeader>
            <CardTitle>Purchase Order Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="poNumber">PO Number</Label>
                <Input
                  id="poNumber"
                  value={poData.poNumber}
                  onChange={(e) => setPOData({ ...poData, poNumber: e.target.value })}
                  disabled
                  className="bg-gray-50"
                />
              </div>
              <div>
                <Label htmlFor="poDate">PO Date</Label>
                <Input
                  id="poDate"
                  type="date"
                  value={poData.poDate}
                  onChange={(e) => setPOData({ ...poData, poDate: e.target.value })}
                  className="border-gray-200"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="vendor">Vendor *</Label>
                <Select value={poData.vendorId} onValueChange={(value) => setPOData({ ...poData, vendorId: value })}>
                  <SelectTrigger className="border-gray-200">
                    <SelectValue placeholder="Select vendor" />
                  </SelectTrigger>
                  <SelectContent>
                    {vendors.map((vendor) => (
                      <SelectItem key={vendor.id} value={vendor.id}>
                        {vendor.name} ({vendor.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="expectedDelivery">Expected Delivery</Label>
                <Input
                  id="expectedDelivery"
                  type="date"
                  value={poData.expectedDelivery}
                  onChange={(e) => setPOData({ ...poData, expectedDelivery: e.target.value })}
                  className="border-gray-200"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select value={poData.priority} onValueChange={(value) => setPOData({ ...poData, priority: value })}>
                  <SelectTrigger className="border-gray-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {priorities.map((priority) => (
                      <SelectItem key={priority.value} value={priority.value}>
                        {priority.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="paymentTerms">Payment Terms (Days)</Label>
                <Input
                  id="paymentTerms"
                  type="number"
                  value={poData.paymentTerms}
                  onChange={(e) => setPOData({ ...poData, paymentTerms: e.target.value })}
                  className="border-gray-200"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional notes or special instructions"
                value={poData.notes}
                onChange={(e) => setPOData({ ...poData, notes: e.target.value })}
                className="border-gray-200"
              />
            </div>
          </CardContent>
        </Card>

        {/* Vendor Stock Selection */}
        {showVendorStock && (
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Vendor Stock - Quick Selection</CardTitle>
                  <p className="text-sm text-gray-600 mt-1">
                    Select items to add to purchase order. Low stock items are highlighted.
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  {lowStockCount > 0 && (
                    <Badge variant="destructive" className="flex items-center space-x-1">
                      <AlertTriangle className="h-3 w-3" />
                      <span>{lowStockCount} Low Stock</span>
                    </Badge>
                  )}
                  {selectedStockCount > 0 && (
                    <Button onClick={addSelectedStockItems} size="sm" className="bg-green-600 hover:bg-green-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add {selectedStockCount} Selected
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search vendor stock..."
                    value={stockSearchTerm}
                    onChange={(e) => setStockSearchTerm(e.target.value)}
                    className="pl-8 w-64 border-gray-200"
                  />
                </div>
              </div>
              <div className="overflow-x-auto max-h-80">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">Select</TableHead>
                      <TableHead>Drug Name</TableHead>
                      <TableHead>Current Stock</TableHead>
                      <TableHead>Reorder Level</TableHead>
                      <TableHead>Stock %</TableHead>
                      <TableHead>Last Price</TableHead>
                      <TableHead>MRP</TableHead>
                      <TableHead>Scheme</TableHead>
                      <TableHead>Suggested Qty</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredVendorStocks.map((stock, index) => (
                      <TableRow key={stock.id} className={stock.isLowStock ? "bg-red-50 border-red-200" : ""}>
                        <TableCell>
                          <Checkbox
                            checked={stock.selected}
                            onCheckedChange={(checked) => handleStockSelection(index, !!checked)}
                          />
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{stock.drugName}</span>
                              {stock.isLowStock && <TrendingDown className="h-4 w-4 text-red-500" />}
                            </div>
                            <div className="text-xs text-gray-500">
                              {stock.genericName} - {stock.strength}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className={stock.isLowStock ? "text-red-600 font-medium" : ""}>
                            {stock.currentStock} {stock.unit}
                          </span>
                        </TableCell>
                        <TableCell>
                          {stock.reorderLevel} {stock.unit}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  stock.thresholdPercentage <= 30
                                    ? "bg-red-500"
                                    : stock.thresholdPercentage <= 50
                                      ? "bg-yellow-500"
                                      : "bg-green-500"
                                }`}
                                style={{ width: `${Math.min(stock.thresholdPercentage, 100)}%` }}
                              ></div>
                            </div>
                            <span className="text-xs font-medium">{stock.thresholdPercentage.toFixed(0)}%</span>
                          </div>
                        </TableCell>
                        <TableCell>₹{stock.lastPurchasePrice.toFixed(2)}</TableCell>
                        <TableCell>₹{stock.mrp.toFixed(2)}</TableCell>
                        <TableCell>
                          {stock.scheme && stock.scheme !== "none" ? (
                            <Badge variant="secondary" className="text-xs">
                              {schemeOptions.find((s) => s.value === stock.scheme)?.label || stock.scheme}
                            </Badge>
                          ) : (
                            <span className="text-gray-400 text-xs">No Scheme</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <span className="font-medium text-blue-600">
                            {Math.max(stock.reorderLevel - stock.currentStock, 0)} {stock.unit}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Items */}
        <Card className="bg-white shadow-sm border-0">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Purchase Order Items</CardTitle>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search items..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8 w-64 border-gray-200"
                  />
                </div>
                <Button onClick={addItem} size="sm" className="bg-red-600 hover:bg-red-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Drug Name</TableHead>
                    <TableHead>Strength</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Unit Price</TableHead>
                    <TableHead>MRP</TableHead>
                    <TableHead>Scheme</TableHead>
                    <TableHead>Tax %</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-8 text-gray-500">
                        No items added yet. Add items manually or select from vendor stock above.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredItems.map((item, index) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div>
                            <Input
                              value={item.drugName}
                              onChange={(e) => updateItem(index, "drugName", e.target.value)}
                              placeholder="Drug name"
                              className="mb-1 border-gray-200"
                            />
                            <Input
                              value={item.genericName}
                              onChange={(e) => updateItem(index, "genericName", e.target.value)}
                              placeholder="Generic name"
                              className="text-xs border-gray-200"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            value={item.strength}
                            onChange={(e) => updateItem(index, "strength", e.target.value)}
                            placeholder="Strength"
                            className="w-20 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateItem(index, "quantity", Number.parseInt(e.target.value) || 0)}
                            className="w-20 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            step="0.01"
                            value={item.unitPrice}
                            onChange={(e) => updateItem(index, "unitPrice", Number.parseFloat(e.target.value) || 0)}
                            className="w-24 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            step="0.01"
                            value={item.mrp}
                            onChange={(e) => updateItem(index, "mrp", Number.parseFloat(e.target.value) || 0)}
                            placeholder="MRP"
                            className="w-24 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <Select value={item.scheme} onValueChange={(value) => updateItem(index, "scheme", value)}>
                            <SelectTrigger className="w-32 border-gray-200">
                              <SelectValue placeholder="Select scheme" />
                            </SelectTrigger>
                            <SelectContent>
                              {schemeOptions.map((scheme) => (
                                <SelectItem key={scheme.value} value={scheme.value}>
                                  {scheme.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {item.schemeDiscount > 0 && (
                            <div className="text-xs text-green-600 mt-1">
                              Discount: ₹{item.schemeDiscount.toFixed(2)}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={item.taxRate}
                            onChange={(e) => updateItem(index, "taxRate", Number.parseFloat(e.target.value) || 0)}
                            className="w-16 border-gray-200"
                          />
                        </TableCell>
                        <TableCell>
                          <div>
                            <span className="font-medium text-green-600">₹{item.finalAmount.toFixed(2)}</span>
                            {item.schemeDiscount > 0 && (
                              <div className="text-xs text-gray-500">After scheme: ₹{item.totalPrice.toFixed(2)}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              {totalSchemeDiscount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Scheme Discount:</span>
                  <span>-₹{totalSchemeDiscount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>After Scheme:</span>
                <span>₹{totalAfterScheme.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Tax:</span>
                <span>₹{totalTax.toFixed(2)}</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between font-bold text-lg">
                  <span>Grand Total:</span>
                  <span className="text-green-600">₹{grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={() => handleSubmit("draft")}
                variant="outline"
                className="w-full border-gray-200"
                disabled={loading}
              >
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Button
                onClick={() => handleSubmit("submitted")}
                className="w-full bg-red-600 hover:bg-red-700"
                disabled={loading || !poData.vendorId || items.length === 0}
              >
                <Send className="h-4 w-4 mr-2" />
                Submit for Approval
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

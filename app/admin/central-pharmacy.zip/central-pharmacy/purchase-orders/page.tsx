'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Plus, Search, Filter, Download, Eye, Edit, CheckCircle, Clock, XCircle, FileText, ShoppingCart, DollarSign, Calendar, User, Building2, Printer } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Link from 'next/link'
import PrivateRoute from '@/components/auth/PrivateRoute'

interface PurchaseOrder {
  id: string
  poNumber: string
  vendor: string
  vendorCode: string
  status: 'draft' | 'pending_approval' | 'approved' | 'ordered' | 'partially_received' | 'completed' | 'cancelled'
  totalValue: number
  itemCount: number
  createdBy: string
  createdDate: string
  expectedDelivery: string
  approvedBy?: string
  approvedDate?: string
  priority: 'low' | 'medium' | 'high' | 'urgent'
}

const mockPOs: PurchaseOrder[] = [
  {
    id: '1',
    poNumber: 'PO-2024-001',
    vendor: 'Cipla Pharmaceuticals',
    vendorCode: 'CIPLA001',
    status: 'approved',
    totalValue: 245000,
    itemCount: 15,
    createdBy: 'Dr. Sharma',
    createdDate: '2024-01-15',
    expectedDelivery: '2024-01-25',
    approvedBy: 'Mr. Patel',
    approvedDate: '2024-01-16',
    priority: 'high'
  },
  {
    id: '2',
    poNumber: 'PO-2024-002',
    vendor: 'Sun Pharma Ltd',
    vendorCode: 'SUN001',
    status: 'pending_approval',
    totalValue: 180000,
    itemCount: 12,
    createdBy: 'Ms. Singh',
    createdDate: '2024-01-18',
    expectedDelivery: '2024-01-28',
    priority: 'medium'
  },
  {
    id: '3',
    poNumber: 'PO-2024-003',
    vendor: 'Lupin Limited',
    vendorCode: 'LUPIN001',
    status: 'ordered',
    totalValue: 320000,
    itemCount: 20,
    createdBy: 'Dr. Kumar',
    createdDate: '2024-01-20',
    expectedDelivery: '2024-01-30',
    approvedBy: 'Mr. Patel',
    approvedDate: '2024-01-21',
    priority: 'urgent'
  },
  {
    id: '4',
    poNumber: 'PO-2024-004',
    vendor: 'Dr. Reddy\'s Labs',
    vendorCode: 'DRL001',
    status: 'draft',
    totalValue: 95000,
    itemCount: 8,
    createdBy: 'Ms. Gupta',
    createdDate: '2024-01-22',
    expectedDelivery: '2024-02-01',
    priority: 'low'
  }
]

export default function PurchaseOrdersManagement() {
  const [pos, setPOs] = useState<PurchaseOrder[]>(mockPOs)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [vendorFilter, setVendorFilter] = useState<string>('all')
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null)
  const { toast } = useToast()

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'ordered': return <ShoppingCart className="h-4 w-4 text-blue-500" />
      case 'pending_approval': return <Clock className="h-4 w-4 text-yellow-500" />
      case 'draft': return <FileText className="h-4 w-4 text-gray-500" />
      case 'partially_received': return <Clock className="h-4 w-4 text-orange-500" />
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'cancelled': return <XCircle className="h-4 w-4 text-red-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      approved: 'bg-green-100 text-green-800 border-green-200',
      ordered: 'bg-blue-100 text-blue-800 border-blue-200',
      pending_approval: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      draft: 'bg-gray-100 text-gray-800 border-gray-200',
      partially_received: 'bg-orange-100 text-orange-800 border-orange-200',
      completed: 'bg-green-100 text-green-800 border-green-200',
      cancelled: 'bg-red-100 text-red-800 border-red-200'
    }
    return variants[status as keyof typeof variants] || 'bg-gray-100 text-gray-800 border-gray-200'
  }

  const getPriorityBadge = (priority: string) => {
    const variants = {
      urgent: 'bg-red-100 text-red-800 border-red-200',
      high: 'bg-orange-100 text-orange-800 border-orange-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      low: 'bg-blue-100 text-blue-800 border-blue-200'
    }
    return variants[priority as keyof typeof variants] || 'bg-gray-100 text-gray-800 border-gray-200'
  }

  const filteredPOs = pos.filter(po => {
    const matchesSearch = po.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         po.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         po.createdBy.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || po.status === statusFilter
    const matchesVendor = vendorFilter === 'all' || po.vendor === vendorFilter
    return matchesSearch && matchesStatus && matchesVendor
  })

  const totalPOs = pos.length
  const pendingApproval = pos.filter(po => po.status === 'pending_approval').length
  const approved = pos.filter(po => po.status === 'approved').length
  const totalValue = pos.reduce((sum, po) => sum + po.totalValue, 0)

  const uniqueVendors = [...new Set(pos.map(po => po.vendor))]

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/purchase-orders" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Purchase Orders</h1>
          <p className="text-gray-600 mt-1">Manage purchase orders and vendor relationships</p>
        </div>
        <Link href="/central-pharmacy/purchase-orders/new">
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <Plus className="mr-2 h-4 w-4" />
            Create PO
          </Button>
        </Link>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total POs</CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{totalPOs}</div>
            <p className="text-xs text-gray-500 mt-1">All purchase orders</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending Approval</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingApproval}</div>
            <p className="text-xs text-gray-500 mt-1">Need approval</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approved}</div>
            <p className="text-xs text-gray-500 mt-1">Ready to order</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Value</CardTitle>
            <DollarSign className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">₹{(totalValue / 100000).toFixed(1)}L</div>
            <p className="text-xs text-gray-500 mt-1">All POs combined</p>
          </CardContent>
        </Card>
      </div>

      {/* PO List */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle className="text-gray-900">Purchase Orders</CardTitle>
          <CardDescription className="text-gray-600">View and manage all purchase orders</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search POs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-gray-200 focus:border-red-500 focus:ring-red-500"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px] border-gray-200">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="pending_approval">Pending Approval</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="ordered">Ordered</SelectItem>
                <SelectItem value="partially_received">Partially Received</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select value={vendorFilter} onValueChange={setVendorFilter}>
              <SelectTrigger className="w-[200px] border-gray-200">
                <SelectValue placeholder="Filter by vendor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                {uniqueVendors.map(vendor => (
                  <SelectItem key={vendor} value={vendor}>{vendor}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" className="border-gray-200">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>

          <div className="rounded-lg border border-gray-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="font-semibold text-gray-700">PO Number</TableHead>
                  <TableHead className="font-semibold text-gray-700">Vendor</TableHead>
                  <TableHead className="font-semibold text-gray-700">Status</TableHead>
                  <TableHead className="font-semibold text-gray-700">Priority</TableHead>
                  <TableHead className="font-semibold text-gray-700">Total Value</TableHead>
                  <TableHead className="font-semibold text-gray-700">Items</TableHead>
                  <TableHead className="font-semibold text-gray-700">Created By</TableHead>
                  <TableHead className="font-semibold text-gray-700">Expected Delivery</TableHead>
                  <TableHead className="font-semibold text-gray-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPOs.map((po) => (
                  <TableRow key={po.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium text-gray-900">{po.poNumber}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium text-gray-900">{po.vendor}</div>
                        <div className="text-sm text-gray-500">{po.vendorCode}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getStatusBadge(po.status)} border`}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(po.status)}
                          {po.status.replace('_', ' ').toUpperCase()}
                        </div>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getPriorityBadge(po.priority)} border`}>
                        {po.priority.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium text-gray-900">₹{po.totalValue.toLocaleString()}</TableCell>
                    <TableCell className="text-gray-700">{po.itemCount} items</TableCell>
                    <TableCell className="text-gray-700">{po.createdBy}</TableCell>
                    <TableCell className="text-gray-700">{new Date(po.expectedDelivery).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedPO(po)}
                              className="border-gray-200 hover:bg-gray-50"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl">
                            <DialogHeader>
                              <DialogTitle>Purchase Order Details - {po.poNumber}</DialogTitle>
                              <DialogDescription>
                                Complete purchase order information and history
                              </DialogDescription>
                            </DialogHeader>
                            {selectedPO && (
                              <Tabs defaultValue="details" className="w-full">
                                <TabsList>
                                  <TabsTrigger value="details">Details</TabsTrigger>
                                  <TabsTrigger value="items">Items</TabsTrigger>
                                  <TabsTrigger value="history">History</TabsTrigger>
                                </TabsList>
                                <TabsContent value="details" className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <h4 className="font-medium mb-2 flex items-center gap-2">
                                        <Building2 className="h-4 w-4" />
                                        Vendor Information
                                      </h4>
                                      <div className="space-y-2">
                                        <p><strong>Name:</strong> {selectedPO.vendor}</p>
                                        <p><strong>Code:</strong> {selectedPO.vendorCode}</p>
                                        <p><strong>Total Value:</strong> ₹{selectedPO.totalValue.toLocaleString()}</p>
                                        <p><strong>Item Count:</strong> {selectedPO.itemCount}</p>
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-medium mb-2 flex items-center gap-2">
                                        <Calendar className="h-4 w-4" />
                                        Timeline
                                      </h4>
                                      <div className="space-y-2">
                                        <p><strong>Created:</strong> {new Date(selectedPO.createdDate).toLocaleDateString()}</p>
                                        <p><strong>Created By:</strong> {selectedPO.createdBy}</p>
                                        <p><strong>Expected Delivery:</strong> {new Date(selectedPO.expectedDelivery).toLocaleDateString()}</p>
                                        {selectedPO.approvedBy && (
                                          <>
                                            <p><strong>Approved By:</strong> {selectedPO.approvedBy}</p>
                                            <p><strong>Approved Date:</strong> {selectedPO.approvedDate && new Date(selectedPO.approvedDate).toLocaleDateString()}</p>
                                          </>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </TabsContent>
                                <TabsContent value="items">
                                  <div className="text-center py-8">
                                    <ShoppingCart className="mx-auto h-12 w-12 text-gray-400" />
                                    <p className="mt-2 text-gray-500">Item details coming soon</p>
                                  </div>
                                </TabsContent>
                                <TabsContent value="history">
                                  <div className="text-center py-8">
                                    <Clock className="mx-auto h-12 w-12 text-gray-400" />
                                    <p className="mt-2 text-gray-500">Order history coming soon</p>
                                  </div>
                                </TabsContent>
                              </Tabs>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Link href={`/central-pharmacy/purchase-orders/edit/${po.id}`}>
                          <Button variant="outline" size="sm" className="border-gray-200 hover:bg-gray-50">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button variant="outline" size="sm" className="border-gray-200 hover:bg-gray-50">
                          <Printer className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, Save, ArrowLeft, Mail } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface POItem {
  id: string
  drugName: string
  genericName: string
  strength: string
  unit: string
  quantity: number
  unitPrice: number
  totalPrice: number
  taxRate: number
  taxAmount: number
  finalAmount: number
}

export default function CreatePurchaseOrder() {
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [emailBody, setEmailBody] = useState("")

  const [poData, setPOData] = useState({
    vendorId: "",
    poNumber: `PO${Date.now()}`,
    poDate: new Date().toISOString().split("T")[0],
    expectedDelivery: "",
    priority: "normal",
    paymentTerms: "30",
    notes: "",
    status: "draft",
  })

  const [items, setItems] = useState<POItem[]>([
    {
      id: "1",
      drugName: "",
      genericName: "",
      strength: "",
      unit: "TAB",
      quantity: 0,
      unitPrice: 0,
      totalPrice: 0,
      taxRate: 18,
      taxAmount: 0,
      finalAmount: 0,
    },
  ])

  const vendors = [
    { id: "1", name: "MedSupply Corp", code: "MSC001" },
    { id: "2", name: "PharmaCare Ltd", code: "PCL002" },
    { id: "3", name: "HealthFirst Distributors", code: "HFD003" },
  ]

  const calculateItemTotals = (item: POItem) => {
    const totalPrice = item.quantity * item.unitPrice
    const taxAmount = (totalPrice * item.taxRate) / 100
    const finalAmount = totalPrice + taxAmount

    return {
      ...item,
      totalPrice,
      taxAmount,
      finalAmount,
    }
  }

  const updateItem = (index: number, field: keyof POItem, value: any) => {
    const updatedItems = [...items]
    updatedItems[index] = { ...updatedItems[index], [field]: value }
    updatedItems[index] = calculateItemTotals(updatedItems[index])
    setItems(updatedItems)
  }

  const addItem = () => {
    const newItem: POItem = {
      id: Date.now().toString(),
      drugName: "",
      genericName: "",
      strength: "",
      unit: "TAB",
      quantity: 0,
      unitPrice: 0,
      totalPrice: 0,
      taxRate: 18,
      taxAmount: 0,
      finalAmount: 0,
    }
    setItems([...items, newItem])
  }

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index))
    }
  }

  const calculateTotals = () => {
    const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0)
    const totalTax = items.reduce((sum, item) => sum + item.taxAmount, 0)
    const grandTotal = items.reduce((sum, item) => sum + item.finalAmount, 0)

    return { subtotal, totalTax, grandTotal }
  }

  const handleSubmit = async (status: string) => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `Purchase Order ${status === "draft" ? "saved as draft" : "submitted"} successfully`,
      })

      router.push("/central-pharmacy/purchase-orders")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save purchase order",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSendEmail = async () => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: "Email sent to vendor successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send email",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
      setShowPreview(false)
    }
  }

  const { subtotal, totalTax, grandTotal } = calculateTotals()

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/purchase-orders/create" action="view">
      <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Create Purchase Order</h1>
            <p className="text-gray-600">Create a new purchase order for inventory procurement</p>
          </div>
        </div>
        <Badge variant="secondary">Draft</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* PO Details */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Purchase Order Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="poNumber">PO Number</Label>
                  <Input
                    id="poNumber"
                    value={poData.poNumber}
                    onChange={(e) => setPOData({ ...poData, poNumber: e.target.value })}
                    disabled
                  />
                </div>
                <div>
                  <Label htmlFor="poDate">PO Date</Label>
                  <Input
                    id="poDate"
                    type="date"
                    value={poData.poDate}
                    onChange={(e) => setPOData({ ...poData, poDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="vendor">Vendor</Label>
                  <Select value={poData.vendorId} onValueChange={(value) => setPOData({ ...poData, vendorId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select vendor" />
                    </SelectTrigger>
                    <SelectContent>
                      {vendors.map((vendor) => (
                        <SelectItem key={vendor.id} value={vendor.id}>
                          {vendor.name} ({vendor.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="expectedDelivery">Expected Delivery</Label>
                  <Input
                    id="expectedDelivery"
                    type="date"
                    value={poData.expectedDelivery}
                    onChange={(e) => setPOData({ ...poData, expectedDelivery: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={poData.priority} onValueChange={(value) => setPOData({ ...poData, priority: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="paymentTerms">Payment Terms (Days)</Label>
                  <Input
                    id="paymentTerms"
                    type="number"
                    value={poData.paymentTerms}
                    onChange={(e) => setPOData({ ...poData, paymentTerms: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Additional notes or special instructions"
                  value={poData.notes}
                  onChange={(e) => setPOData({ ...poData, notes: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Items */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Items</CardTitle>
                <Button onClick={addItem} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div key={item.id} className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Item {index + 1}</h4>
                      {items.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(index)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Drug Name</Label>
                        <Input
                          value={item.drugName}
                          onChange={(e) => updateItem(index, "drugName", e.target.value)}
                          placeholder="Enter drug name"
                        />
                      </div>
                      <div>
                        <Label>Generic Name</Label>
                        <Input
                          value={item.genericName}
                          onChange={(e) => updateItem(index, "genericName", e.target.value)}
                          placeholder="Enter generic name"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4">
                      <div>
                        <Label>Strength</Label>
                        <Input
                          value={item.strength}
                          onChange={(e) => updateItem(index, "strength", e.target.value)}
                          placeholder="e.g., 500mg"
                        />
                      </div>
                      <div>
                        <Label>Unit</Label>
                        <Select value={item.unit} onValueChange={(value) => updateItem(index, "unit", value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="TAB">Tablet</SelectItem>
                            <SelectItem value="CAP">Capsule</SelectItem>
                            <SelectItem value="SYR">Syrup</SelectItem>
                            <SelectItem value="INJ">Injection</SelectItem>
                            <SelectItem value="BOT">Bottle</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Quantity</Label>
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => updateItem(index, "quantity", Number.parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <div>
                        <Label>Unit Price (₹)</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={item.unitPrice}
                          onChange={(e) => updateItem(index, "unitPrice", Number.parseFloat(e.target.value) || 0)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div>
                        <Label>Total Price</Label>
                        <div className="font-medium">₹{item.totalPrice.toFixed(2)}</div>
                      </div>
                      <div>
                        <Label>Tax Rate (%)</Label>
                        <Input
                          type="number"
                          value={item.taxRate}
                          onChange={(e) => updateItem(index, "taxRate", Number.parseFloat(e.target.value) || 0)}
                        />
                      </div>
                      <div>
                        <Label>Tax Amount</Label>
                        <div className="font-medium">₹{item.taxAmount.toFixed(2)}</div>
                      </div>
                      <div>
                        <Label>Final Amount</Label>
                        <div className="font-medium text-green-600">₹{item.finalAmount.toFixed(2)}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Tax:</span>
                <span>₹{totalTax.toFixed(2)}</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between font-bold text-lg">
                  <span>Grand Total:</span>
                  <span className="text-green-600">₹{grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button onClick={() => handleSubmit("draft")} variant="outline" className="w-full" disabled={loading}>
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    className="w-full"
                    disabled={loading || !poData.vendorId || items.some((item) => !item.drugName)}
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Submit for Approval
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Purchase Order Preview</DialogTitle>
                    <DialogDescription>
                      Review the purchase order and customize the email before sending it to the vendor.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="emailBody">Email Body</Label>
                      <Textarea
                        id="emailBody"
                        placeholder="Customize the email body..."
                        value={emailBody}
                        onChange={(e) => setEmailBody(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setShowPreview(false)}>
                      Cancel
                    </Button>
                    <Button type="button" onClick={handleSendEmail} disabled={loading}>
                      Send Email
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </PrivateRoute>
  )
}

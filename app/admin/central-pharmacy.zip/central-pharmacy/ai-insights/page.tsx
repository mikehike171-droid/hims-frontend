"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain,
  TrendingUp,
  AlertTriangle,
  Clock,
  Package,
  DollarSign,
  RefreshCw,
  ArrowRight,
  Target,
  Zap,
  BarChart3,
} from "lucide-react"
import PrivateRoute from "@/components/auth/PrivateRoute"

interface AIInsight {
  id: string
  type: "demand_forecast" | "expiry_alert" | "cost_optimization" | "stock_optimization" | "vendor_performance"
  priority: "high" | "medium" | "low"
  title: string
  description: string
  impact: string
  confidence: number
  recommendation: string
  potentialSavings?: number
  affectedItems?: number
  timeframe: string
  status: "new" | "acknowledged" | "implemented"
}

export default function AIInsights() {
  const [selectedTab, setSelectedTab] = useState("all")
  const [insights] = useState<AIInsight[]>([
    {
      id: "1",
      type: "demand_forecast",
      priority: "high",
      title: "Increased Demand Predicted for Paracetamol",
      description:
        "AI models predict 40% increase in Paracetamol demand over next 2 weeks based on seasonal patterns and local health trends.",
      impact: "Potential stockout risk",
      confidence: 87,
      recommendation: "Increase order quantity by 35% in next PO",
      potentialSavings: 25000,
      affectedItems: 1,
      timeframe: "Next 2 weeks",
      status: "new",
    },
    {
      id: "2",
      type: "expiry_alert",
      priority: "high",
      title: "Critical Expiry Alert - Insulin Batches",
      description: "15 batches of Insulin (total value ₹2.8L) expiring in next 10 days with low consumption rate.",
      impact: "₹2.8L potential loss",
      confidence: 95,
      recommendation: "Transfer to high-consumption stores or negotiate return with vendor",
      potentialSavings: 280000,
      affectedItems: 15,
      timeframe: "10 days",
      status: "new",
    },
    {
      id: "3",
      type: "cost_optimization",
      priority: "medium",
      title: "Vendor Price Optimization Opportunity",
      description: "Alternative vendor offers 12% lower prices for Antibiotics category with same quality standards.",
      impact: "Cost reduction opportunity",
      confidence: 78,
      recommendation: "Evaluate vendor switch for Antibiotics procurement",
      potentialSavings: 150000,
      affectedItems: 25,
      timeframe: "Next quarter",
      status: "acknowledged",
    },
    {
      id: "4",
      type: "stock_optimization",
      priority: "medium",
      title: "Overstock Alert - Cardiac Medications",
      description:
        "Current stock levels for cardiac medications are 3x higher than optimal based on consumption patterns.",
      impact: "Capital tied up unnecessarily",
      confidence: 82,
      recommendation: "Reduce order quantities by 60% for next 3 months",
      potentialSavings: 180000,
      affectedItems: 8,
      timeframe: "3 months",
      status: "new",
    },
    {
      id: "5",
      type: "vendor_performance",
      priority: "low",
      title: "Vendor Delivery Performance Declining",
      description: "Sun Pharma delivery performance dropped to 72% on-time delivery in last quarter.",
      impact: "Operational efficiency impact",
      confidence: 91,
      recommendation: "Review vendor agreement and consider backup suppliers",
      affectedItems: 1,
      timeframe: "Ongoing",
      status: "implemented",
    },
  ])

  const getInsightIcon = (type: string) => {
    switch (type) {
      case "demand_forecast":
        return <TrendingUp className="h-5 w-5 text-blue-600" />
      case "expiry_alert":
        return <Clock className="h-5 w-5 text-red-600" />
      case "cost_optimization":
        return <DollarSign className="h-5 w-5 text-green-600" />
      case "stock_optimization":
        return <Package className="h-5 w-5 text-orange-600" />
      case "vendor_performance":
        return <BarChart3 className="h-5 w-5 text-purple-600" />
      default:
        return <Brain className="h-5 w-5 text-gray-600" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "acknowledged":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "implemented":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const filteredInsights = selectedTab === "all" ? insights : insights.filter((insight) => insight.type === selectedTab)

  const totalPotentialSavings = insights.reduce((sum, insight) => sum + (insight.potentialSavings || 0), 0)
  const highPriorityCount = insights.filter((insight) => insight.priority === "high").length
  const newInsightsCount = insights.filter((insight) => insight.status === "new").length

  return (
    <PrivateRoute modulePath="admin/central-pharmacy/ai-insights" action="view">
      <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 flex items-center gap-3">
            <Brain className="h-8 w-8 text-purple-600" />
            AI Insights & Recommendations
          </h1>
          <p className="text-gray-600 mt-1">Smart analytics and actionable recommendations for pharmacy operations</p>
        </div>
        <Button className="bg-purple-600 hover:bg-purple-700 text-white">
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh Insights
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Insights</CardTitle>
            <Brain className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{insights.length}</div>
            <p className="text-xs text-gray-500 mt-1">Active recommendations</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">High Priority</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{highPriorityCount}</div>
            <p className="text-xs text-gray-500 mt-1">Require immediate attention</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">New Insights</CardTitle>
            <Zap className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{newInsightsCount}</div>
            <p className="text-xs text-gray-500 mt-1">Unacknowledged</p>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Potential Savings</CardTitle>
            <Target className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">₹{(totalPotentialSavings / 100000).toFixed(1)}L</div>
            <p className="text-xs text-gray-500 mt-1">If all implemented</p>
          </CardContent>
        </Card>
      </div>

      {/* Insights Tabs */}
      <Card className="bg-white shadow-sm border-0">
        <CardHeader>
          <CardTitle className="text-gray-900">AI Recommendations</CardTitle>
          <CardDescription className="text-gray-600">
            Machine learning powered insights to optimize pharmacy operations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="all">All Insights</TabsTrigger>
              <TabsTrigger value="demand_forecast">Demand</TabsTrigger>
              <TabsTrigger value="expiry_alert">Expiry</TabsTrigger>
              <TabsTrigger value="cost_optimization">Cost</TabsTrigger>
              <TabsTrigger value="stock_optimization">Stock</TabsTrigger>
              <TabsTrigger value="vendor_performance">Vendors</TabsTrigger>
            </TabsList>

            <TabsContent value={selectedTab} className="mt-6">
              <div className="space-y-4">
                {filteredInsights.map((insight) => (
                  <Card key={insight.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4 flex-1">
                          <div className="mt-1">{getInsightIcon(insight.type)}</div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-gray-900">{insight.title}</h3>
                              <Badge className={`${getPriorityColor(insight.priority)} border text-xs`}>
                                {insight.priority.toUpperCase()}
                              </Badge>
                              <Badge className={`${getStatusColor(insight.status)} border text-xs`}>
                                {insight.status.replace("_", " ").toUpperCase()}
                              </Badge>
                            </div>

                            <p className="text-gray-600 mb-3">{insight.description}</p>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                              <div>
                                <span className="text-sm font-medium text-gray-500">Impact:</span>
                                <p className="text-sm text-gray-900">{insight.impact}</p>
                              </div>
                              <div>
                                <span className="text-sm font-medium text-gray-500">Timeframe:</span>
                                <p className="text-sm text-gray-900">{insight.timeframe}</p>
                              </div>
                              <div>
                                <span className="text-sm font-medium text-gray-500">Confidence:</span>
                                <div className="flex items-center space-x-2">
                                  <Progress value={insight.confidence} className="flex-1 h-2" />
                                  <span className="text-sm text-gray-900">{insight.confidence}%</span>
                                </div>
                              </div>
                            </div>

                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                              <div className="flex items-start space-x-2">
                                <Brain className="h-4 w-4 text-blue-600 mt-0.5" />
                                <div>
                                  <span className="text-sm font-medium text-blue-900">AI Recommendation:</span>
                                  <p className="text-sm text-blue-800 mt-1">{insight.recommendation}</p>
                                </div>
                              </div>
                            </div>

                            {insight.potentialSavings && (
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-4 text-sm text-gray-600">
                                  {insight.affectedItems && <span>Affects {insight.affectedItems} items</span>}
                                  <span className="font-medium text-green-600">
                                    Potential savings: ₹{insight.potentialSavings.toLocaleString()}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 ml-4">
                          {insight.status === "new" && (
                            <>
                              <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                                Acknowledge
                              </Button>
                              <Button size="sm" variant="outline" className="border-gray-200 bg-transparent">
                                Implement
                                <ArrowRight className="ml-1 h-3 w-3" />
                              </Button>
                            </>
                          )}
                          {insight.status === "acknowledged" && (
                            <Button size="sm" className="bg-green-600 hover:bg-green-700">
                              Implement
                              <ArrowRight className="ml-1 h-3 w-3" />
                            </Button>
                          )}
                          {insight.status === "implemented" && (
                            <Badge className="bg-green-100 text-green-800 border-green-200">✓ Implemented</Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* AI Performance Metrics */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-white shadow-sm border-0">
          <CardHeader>
            <CardTitle className="text-gray-900">AI Model Performance</CardTitle>
            <CardDescription className="text-gray-600">
              Accuracy and reliability metrics for AI predictions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Demand Forecasting</span>
              <div className="flex items-center space-x-2">
                <Progress value={87} className="w-24 h-2" />
                <span className="text-sm text-gray-600">87%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Expiry Prediction</span>
              <div className="flex items-center space-x-2">
                <Progress value={95} className="w-24 h-2" />
                <span className="text-sm text-gray-600">95%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Cost Optimization</span>
              <div className="flex items-center space-x-2">
                <Progress value={78} className="w-24 h-2" />
                <span className="text-sm text-gray-600">78%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Stock Optimization</span>
              <div className="flex items-center space-x-2">
                <Progress value={82} className="w-24 h-2" />
                <span className="text-sm text-gray-600">82%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-0">
          <CardHeader>
            <CardTitle className="text-gray-900">Implementation Impact</CardTitle>
            <CardDescription className="text-gray-600">
              Results from previously implemented AI recommendations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Cost Savings (Last Quarter)</span>
              <span className="text-sm font-bold text-green-600">₹4.2L</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Stockout Reduction</span>
              <span className="text-sm font-bold text-blue-600">65%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Expiry Waste Reduction</span>
              <span className="text-sm font-bold text-purple-600">43%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Inventory Turnover Improvement</span>
              <span className="text-sm font-bold text-orange-600">28%</span>
            </div>
          </CardContent>
        </Card>
      </div>
      </div>
    </PrivateRoute>
  )
}

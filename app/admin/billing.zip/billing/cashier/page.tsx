"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Wallet,
  Search,
  Banknote,
  CreditCard,
  RefreshCcw,
  Clock,
  CheckCircle,
  Printer,
  Download,
  ArrowDown,
  ArrowUp,
  DollarSign,
  Filter,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"

// Mock collections data
const collections = [
  {
    id: "COL2405001",
    billNumber: "OP2405120001",
    patientName: "Rahul Sharma",
    patientId: "P000123",
    amount: 1200,
    paymentMode: "cash",
    collectedBy: "Cashier 1",
    timestamp: "2024-05-12 10:30:45",
    status: "completed",
    shift: "Morning",
  },
  {
    id: "COL2405002",
    billNumber: "OP2405120003",
    patientName: "Mohammad Ali",
    patientId: "P000789",
    amount: 1000,
    paymentMode: "card",
    collectedBy: "Cashier 1",
    timestamp: "2024-05-12 11:15:30",
    status: "completed",
    shift: "Morning",
  },
  {
    id: "COL2405003",
    billNumber: "IP2404002",
    patientName: "Suresh Kumar",
    patientId: "P000567",
    amount: 5000,
    paymentMode: "upi",
    collectedBy: "Cashier 2",
    timestamp: "2024-05-12 13:45:12",
    status: "completed",
    shift: "Afternoon",
  },
  {
    id: "COL2405004",
    billNumber: "OP2405110005",
    patientName: "Deepa Nair",
    patientId: "P000890",
    amount: 1500,
    paymentMode: "cash",
    collectedBy: "Cashier 2",
    timestamp: "2024-05-12 14:30:05",
    status: "completed",
    shift: "Afternoon",
  },
  {
    id: "COL2405005",
    billNumber: "OP2405120006",
    patientName: "Vikram Singh",
    patientId: "P000345",
    amount: 800,
    paymentMode: "card",
    collectedBy: "Cashier 1",
    timestamp: "2024-05-12 15:20:18",
    status: "completed",
    shift: "Afternoon",
  },
]

// Summary data
const cashierSummary = {
  totalCollections: collections.length,
  totalAmount: collections.reduce((sum, col) => sum + col.amount, 0),
  cashAmount: collections.filter((col) => col.paymentMode === "cash").reduce((sum, col) => sum + col.amount, 0),
  cardAmount: collections.filter((col) => col.paymentMode === "card").reduce((sum, col) => sum + col.amount, 0),
  upiAmount: collections.filter((col) => col.paymentMode === "upi").reduce((sum, col) => sum + col.amount, 0),
  morningShift: collections.filter((col) => col.shift === "Morning").reduce((sum, col) => sum + col.amount, 0),
  afternoonShift: collections.filter((col) => col.shift === "Afternoon").reduce((sum, col) => sum + col.amount, 0),
  eveningShift: collections.filter((col) => col.shift === "Evening").reduce((sum, col) => sum + col.amount, 0),
}

// Mock pending bills
const pendingBills = [
  {
    billNumber: "OP2405120002",
    patientName: "Priya Patel",
    patientId: "P000456",
    amount: 1500,
    billDate: "2024-05-12",
    department: "Dermatology",
    billType: "OP",
  },
  {
    billNumber: "OP2405110004",
    patientName: "Anjali Gupta",
    patientId: "P000234",
    amount: 1200,
    billDate: "2024-05-11",
    department: "General Medicine",
    billType: "OP",
  },
  {
    billNumber: "IP2405003",
    patientName: "Rajesh Khanna",
    patientId: "P000678",
    amount: 8500,
    billDate: "2024-05-10",
    department: "Orthopedics",
    billType: "IP",
  },
]

export default function CashierDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [paymentFilter, setPaymentFilter] = useState("all")
  const [shiftFilter, setShiftFilter] = useState("all")

  // Filter collections based on search term and filters
  const filteredCollections = collections.filter((col) => {
    const matchesSearch =
      col.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      col.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      col.billNumber.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesPayment = paymentFilter === "all" || col.paymentMode === paymentFilter
    const matchesShift = shiftFilter === "all" || col.shift === shiftFilter

    return matchesSearch && matchesPayment && matchesShift
  })

  return (
    <PrivateRoute modulePath="admin/billing/cashier" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Cashiering</h1>
            <p className="text-gray-600 mt-1">Manage collections, payments and shift summaries</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button variant="outline">
              <Clock className="h-4 w-4 mr-2" />
              Shift Management
            </Button>
            <Button>
              <Wallet className="h-4 w-4 mr-2" />
              Start Collection
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Collections</CardTitle>
              <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{cashierSummary.totalAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">{cashierSummary.totalCollections} transactions today</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cash Collections</CardTitle>
              <Banknote className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{cashierSummary.cashAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {collections.filter((col) => col.paymentMode === "cash").length} cash transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Card Collections</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{cashierSummary.cardAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {collections.filter((col) => col.paymentMode === "card").length} card transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">UPI Collections</CardTitle>
              <RefreshCcw className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{cashierSummary.upiAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {collections.filter((col) => col.paymentMode === "upi").length} UPI transactions
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Shift Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Morning Shift</CardTitle>
              <ArrowUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{cashierSummary.morningShift.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {collections.filter((col) => col.shift === "Morning").length} transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Afternoon Shift</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{cashierSummary.afternoonShift.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {collections.filter((col) => col.shift === "Afternoon").length} transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Evening Shift</CardTitle>
              <ArrowDown className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{cashierSummary.eveningShift.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {collections.filter((col) => col.shift === "Evening").length} transactions
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Collection Management</CardTitle>
            <CardDescription>Search and filter collection records</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by patient name, ID or bill number..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <DatePickerWithRange className="w-full md:w-auto" />
              <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Payment Mode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Modes</SelectItem>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                </SelectContent>
              </Select>
              <Select value={shiftFilter} onValueChange={setShiftFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Shift" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Shifts</SelectItem>
                  <SelectItem value="Morning">Morning</SelectItem>
                  <SelectItem value="Afternoon">Afternoon</SelectItem>
                  <SelectItem value="Evening">Evening</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs for Collections and Pending Bills */}
        <Tabs defaultValue="collections" className="space-y-4">
          <TabsList>
            <TabsTrigger value="collections">Collections</TabsTrigger>
            <TabsTrigger value="pending">Pending Bills</TabsTrigger>
          </TabsList>

          {/* Collections Tab */}
          <TabsContent value="collections" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Collection Records ({filteredCollections.length})</CardTitle>
                <CardDescription>Track all payment collections</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">Collection ID</th>
                        <th className="text-left p-3">Bill #</th>
                        <th className="text-left p-3">Patient</th>
                        <th className="text-left p-3">Amount</th>
                        <th className="text-left p-3">Payment Mode</th>
                        <th className="text-left p-3">Collected By</th>
                        <th className="text-left p-3">Timestamp</th>
                        <th className="text-left p-3">Shift</th>
                        <th className="text-left p-3">Status</th>
                        <th className="text-left p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredCollections.map((collection) => (
                        <tr key={collection.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{collection.id}</td>
                          <td className="p-3">{collection.billNumber}</td>
                          <td className="p-3">
                            <div>
                              <div className="font-medium">{collection.patientName}</div>
                              <div className="text-sm text-gray-500">{collection.patientId}</div>
                            </div>
                          </td>
                          <td className="p-3 font-semibold">₹{collection.amount.toLocaleString()}</td>
                          <td className="p-3">
                            <Badge
                              variant="outline"
                              className={
                                collection.paymentMode === "cash"
                                  ? "bg-green-50 text-green-700 border-green-200"
                                  : collection.paymentMode === "card"
                                    ? "bg-blue-50 text-blue-700 border-blue-200"
                                    : "bg-purple-50 text-purple-700 border-purple-200"
                              }
                            >
                              {collection.paymentMode === "cash" ? (
                                <Banknote className="h-3 w-3 mr-1" />
                              ) : collection.paymentMode === "card" ? (
                                <CreditCard className="h-3 w-3 mr-1" />
                              ) : (
                                <RefreshCcw className="h-3 w-3 mr-1" />
                              )}
                              {collection.paymentMode.toUpperCase()}
                            </Badge>
                          </td>
                          <td className="p-3">{collection.collectedBy}</td>
                          <td className="p-3">{collection.timestamp}</td>
                          <td className="p-3">{collection.shift}</td>
                          <td className="p-3">
                            <Badge
                              variant={collection.status === "completed" ? "success" : "outline"}
                              className={
                                collection.status === "completed"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : ""
                              }
                            >
                              {collection.status === "completed" ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <Clock className="h-3 w-3 mr-1" />
                              )}
                              {collection.status.charAt(0).toUpperCase() + collection.status.slice(1)}
                            </Badge>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline">
                                <Printer className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pending Bills Tab */}
          <TabsContent value="pending" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Bills ({pendingBills.length})</CardTitle>
                <CardDescription>Bills awaiting payment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">Bill Number</th>
                        <th className="text-left p-3">Patient</th>
                        <th className="text-left p-3">Bill Type</th>
                        <th className="text-left p-3">Department</th>
                        <th className="text-left p-3">Bill Date</th>
                        <th className="text-left p-3">Amount</th>
                        <th className="text-left p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pendingBills.map((bill) => (
                        <tr key={bill.billNumber} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{bill.billNumber}</td>
                          <td className="p-3">
                            <div>
                              <div className="font-medium">{bill.patientName}</div>
                              <div className="text-sm text-gray-500">{bill.patientId}</div>
                            </div>
                          </td>
                          <td className="p-3">
                            <Badge
                              variant="outline"
                              className={
                                bill.billType === "OP"
                                  ? "bg-blue-50 text-blue-700 border-blue-200"
                                  : "bg-purple-50 text-purple-700 border-purple-200"
                              }
                            >
                              {bill.billType}
                            </Badge>
                          </td>
                          <td className="p-3">{bill.department}</td>
                          <td className="p-3">{bill.billDate}</td>
                          <td className="p-3 font-semibold text-red-600">₹{bill.amount.toLocaleString()}</td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline">
                                View
                              </Button>
                              <Button size="sm">Collect</Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import { Shield, Search, Download, Plus, Clock, CheckCircle, XCircle, Filter, BarChart, FileText } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"

// Mock insurance claims data
const claims = [
  {
    id: "CL2405001",
    patientId: "P000123",
    patientName: "Rahul Sharma",
    admissionId: "IP2404001",
    provider: "Star Health Insurance",
    policyNumber: "STAR/2023/123456",
    claimAmount: 65000,
    approvedAmount: 62000,
    submissionDate: "2024-05-01",
    status: "approved",
    paymentStatus: "received",
    paymentDate: "2024-05-15",
  },
  {
    id: "CL2405002",
    patientId: "P000456",
    patientName: "Priya Patel",
    admissionId: "IP2404002",
    provider: "ICICI Lombard",
    policyNumber: "ICICI/2023/789012",
    claimAmount: 45000,
    approvedAmount: 0,
    submissionDate: "2024-05-03",
    status: "submitted",
    paymentStatus: "pending",
    paymentDate: null,
  },
  {
    id: "CL2405003",
    patientId: "P000789",
    patientName: "Mohammad Ali",
    admissionId: "IP2404003",
    provider: "New India Assurance",
    policyNumber: "NIA/2023/345678",
    claimAmount: 35000,
    approvedAmount: 30000,
    submissionDate: "2024-05-05",
    status: "approved",
    paymentStatus: "pending",
    paymentDate: null,
  },
  {
    id: "CL2405004",
    patientId: "P000234",
    patientName: "Anjali Gupta",
    admissionId: "IP2404004",
    provider: "Bajaj Allianz",
    policyNumber: "BA/2023/901234",
    claimAmount: 28000,
    approvedAmount: 25000,
    submissionDate: "2024-05-07",
    status: "approved",
    paymentStatus: "received",
    paymentDate: "2024-05-20",
  },
  {
    id: "CL2404001",
    patientId: "P000567",
    patientName: "Suresh Kumar",
    admissionId: "IP2404005",
    provider: "Star Health Insurance",
    policyNumber: "STAR/2023/567890",
    claimAmount: 52000,
    approvedAmount: 0,
    submissionDate: "2024-04-20",
    status: "rejected",
    paymentStatus: "rejected",
    paymentDate: null,
  },
]

const preAuthorizations = [
  {
    id: "PA2405001",
    patientId: "P000123",
    patientName: "Rahul Sharma",
    admissionId: "IP2405001",
    provider: "Star Health Insurance",
    policyNumber: "STAR/2023/123456",
    requestAmount: 70000,
    approvedAmount: 65000,
    requestDate: "2024-05-01",
    approvalDate: "2024-05-02",
    status: "approved",
    validTill: "2024-06-02",
  },
  {
    id: "PA2405002",
    patientId: "P000456",
    patientName: "Priya Patel",
    admissionId: "IP2405002",
    provider: "ICICI Lombard",
    policyNumber: "ICICI/2023/789012",
    requestAmount: 50000,
    approvedAmount: 0,
    requestDate: "2024-05-03",
    approvalDate: null,
    status: "pending",
    validTill: null,
  },
  {
    id: "PA2405003",
    patientId: "P000789",
    patientName: "Mohammad Ali",
    admissionId: "IP2405003",
    provider: "New India Assurance",
    policyNumber: "NIA/2023/345678",
    requestAmount: 40000,
    approvedAmount: 35000,
    requestDate: "2024-05-05",
    approvalDate: "2024-05-06",
    status: "approved",
    validTill: "2024-06-06",
  },
]

// Summary data
const summaryData = {
  totalClaims: claims.length,
  approvedClaims: claims.filter((claim) => claim.status === "approved").length,
  rejectedClaims: claims.filter((claim) => claim.status === "rejected").length,
  pendingClaims: claims.filter((claim) => claim.status === "submitted").length,
  totalClaimAmount: claims.reduce((sum, claim) => sum + claim.claimAmount, 0),
  approvedClaimAmount: claims.reduce((sum, claim) => sum + claim.approvedAmount, 0),
  receivedPayments: claims.filter((claim) => claim.paymentStatus === "received").length,
  receivedAmount: claims
    .filter((claim) => claim.paymentStatus === "received")
    .reduce((sum, claim) => sum + claim.approvedAmount, 0),
}

export default function InsuranceBilling() {
  const [searchTerm, setSearchTerm] = useState("")
  const [dateRange, setDateRange] = useState({})
  const [statusFilter, setStatusFilter] = useState("all")

  // Filter claims based on search term and status filter
  const filteredClaims = claims.filter((claim) => {
    const matchesSearch =
      claim.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      claim.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      claim.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      claim.provider.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || claim.status === statusFilter

    return matchesSearch && matchesStatus
  })

  // Filter pre-authorizations based on search term
  const filteredPreauths = preAuthorizations.filter((preauth) => {
    const matchesSearch =
      preauth.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      preauth.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      preauth.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      preauth.provider.toLowerCase().includes(searchTerm.toLowerCase())

    return matchesSearch
  })

  return (
    <PrivateRoute modulePath="admin/billing/insurance" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Insurance Billing</h1>
            <p className="text-gray-600 mt-1">Manage insurance claims, pre-authorizations and settlements</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Claim
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Claims</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.totalClaims}</div>
              <div className="flex items-center justify-between text-xs text-muted-foreground mt-2">
                <span>Approved: {summaryData.approvedClaims}</span>
                <span>Pending: {summaryData.pendingClaims}</span>
                <span>Rejected: {summaryData.rejectedClaims}</span>
              </div>
              <Progress value={(summaryData.approvedClaims / summaryData.totalClaims) * 100} className="h-1 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Claim Amount</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{summaryData.totalClaimAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Approved: ₹{summaryData.approvedClaimAmount.toLocaleString()} (
                {Math.round((summaryData.approvedClaimAmount / summaryData.totalClaimAmount) * 100)}%)
              </p>
              <Progress
                value={(summaryData.approvedClaimAmount / summaryData.totalClaimAmount) * 100}
                className="h-1 mt-2"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Received Payments</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.receivedPayments}</div>
              <p className="text-xs text-muted-foreground mt-1">
                ₹{summaryData.receivedAmount.toLocaleString()} received
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pre-Authorizations</CardTitle>
              <BarChart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{preAuthorizations.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {preAuthorizations.filter((p) => p.status === "approved").length} approved,{" "}
                {preAuthorizations.filter((p) => p.status === "pending").length} pending
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Insurance Claims Management</CardTitle>
            <CardDescription>Search and filter insurance claims</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by patient name, ID, claim number or provider..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <DatePickerWithRange className="w-full md:w-auto" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="submitted">Submitted</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs for Claims and Pre-Authorizations */}
        <Tabs defaultValue="claims" className="space-y-4">
          <TabsList>
            <TabsTrigger value="claims">Claims</TabsTrigger>
            <TabsTrigger value="preauths">Pre-Authorizations</TabsTrigger>
          </TabsList>

          {/* Claims Tab */}
          <TabsContent value="claims" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Insurance Claims ({filteredClaims.length})</CardTitle>
                <CardDescription>Track and manage insurance claims</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">Claim #</th>
                        <th className="text-left p-3">Patient</th>
                        <th className="text-left p-3">Insurance</th>
                        <th className="text-left p-3">Claim Amount</th>
                        <th className="text-left p-3">Submission Date</th>
                        <th className="text-left p-3">Status</th>
                        <th className="text-left p-3">Payment</th>
                        <th className="text-left p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredClaims.map((claim) => (
                        <tr key={claim.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{claim.id}</td>
                          <td className="p-3">
                            <div>
                              <div className="font-medium">{claim.patientName}</div>
                              <div className="text-sm text-gray-500">{claim.patientId}</div>
                            </div>
                          </td>
                          <td className="p-3">
                            <div>{claim.provider}</div>
                            <div className="text-sm text-gray-500">{claim.policyNumber}</div>
                          </td>
                          <td className="p-3 font-semibold">
                            <div>₹{claim.claimAmount.toLocaleString()}</div>
                            {claim.approvedAmount > 0 && claim.approvedAmount !== claim.claimAmount && (
                              <div className="text-sm text-gray-600">
                                Approved: ₹{claim.approvedAmount.toLocaleString()}
                              </div>
                            )}
                          </td>
                          <td className="p-3">{claim.submissionDate}</td>
                          <td className="p-3">
                            <Badge
                              variant={
                                claim.status === "approved"
                                  ? "success"
                                  : claim.status === "rejected"
                                    ? "destructive"
                                    : "outline"
                              }
                              className={
                                claim.status === "approved"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : claim.status === "rejected"
                                    ? "bg-red-100 text-red-800 hover:bg-red-100"
                                    : ""
                              }
                            >
                              {claim.status === "approved" ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : claim.status === "rejected" ? (
                                <XCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <Clock className="h-3 w-3 mr-1" />
                              )}
                              {claim.status.charAt(0).toUpperCase() + claim.status.slice(1)}
                            </Badge>
                          </td>
                          <td className="p-3">
                            <Badge
                              variant={
                                claim.paymentStatus === "received"
                                  ? "success"
                                  : claim.paymentStatus === "rejected"
                                    ? "destructive"
                                    : "outline"
                              }
                              className={
                                claim.paymentStatus === "received"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : claim.paymentStatus === "rejected"
                                    ? "bg-red-100 text-red-800 hover:bg-red-100"
                                    : ""
                              }
                            >
                              {claim.paymentStatus === "received" ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : claim.paymentStatus === "rejected" ? (
                                <XCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <Clock className="h-3 w-3 mr-1" />
                              )}
                              {claim.paymentStatus.charAt(0).toUpperCase() + claim.paymentStatus.slice(1)}
                            </Badge>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline">
                                View
                              </Button>
                              <Button size="sm" variant="outline">
                                Track
                              </Button>
                              {claim.paymentStatus === "pending" && claim.status === "approved" && (
                                <Button size="sm">Update</Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pre-Authorizations Tab */}
          <TabsContent value="preauths" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pre-Authorizations ({filteredPreauths.length})</CardTitle>
                <CardDescription>Track insurance pre-authorizations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">Auth #</th>
                        <th className="text-left p-3">Patient</th>
                        <th className="text-left p-3">Insurance</th>
                        <th className="text-left p-3">Requested</th>
                        <th className="text-left p-3">Approved</th>
                        <th className="text-left p-3">Request Date</th>
                        <th className="text-left p-3">Status</th>
                        <th className="text-left p-3">Valid Till</th>
                        <th className="text-left p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredPreauths.map((preauth) => (
                        <tr key={preauth.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{preauth.id}</td>
                          <td className="p-3">
                            <div>
                              <div className="font-medium">{preauth.patientName}</div>
                              <div className="text-sm text-gray-500">{preauth.patientId}</div>
                            </div>
                          </td>
                          <td className="p-3">
                            <div>{preauth.provider}</div>
                            <div className="text-sm text-gray-500">{preauth.policyNumber}</div>
                          </td>
                          <td className="p-3 font-semibold">₹{preauth.requestAmount.toLocaleString()}</td>
                          <td className="p-3">
                            {preauth.approvedAmount > 0 ? `₹${preauth.approvedAmount.toLocaleString()}` : "-"}
                          </td>
                          <td className="p-3">{preauth.requestDate}</td>
                          <td className="p-3">
                            <Badge
                              variant={
                                preauth.status === "approved"
                                  ? "success"
                                  : preauth.status === "rejected"
                                    ? "destructive"
                                    : "outline"
                              }
                              className={
                                preauth.status === "approved"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : preauth.status === "rejected"
                                    ? "bg-red-100 text-red-800 hover:bg-red-100"
                                    : ""
                              }
                            >
                              {preauth.status === "approved" ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : preauth.status === "rejected" ? (
                                <XCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <Clock className="h-3 w-3 mr-1" />
                              )}
                              {preauth.status.charAt(0).toUpperCase() + preauth.status.slice(1)}
                            </Badge>
                          </td>
                          <td className="p-3">{preauth.validTill || "-"}</td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline">
                                View
                              </Button>
                              {preauth.status === "approved" && <Button size="sm">Create Claim</Button>}
                              {preauth.status === "pending" && <Button size="sm">Update</Button>}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PrivateRoute>
  )
}

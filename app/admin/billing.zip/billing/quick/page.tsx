"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Receipt, Search, Plus, Check, X, Printer, CreditCard, User } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function QuickBill() {
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [billItems, setBillItems] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")

  // Mock services data
  const services = [
    { id: 1, code: "CONS001", name: "General Consultation", price: 500, type: "consultation" },
    { id: 2, code: "CONS002", name: "Specialist Consultation", price: 800, type: "consultation" },
    { id: 3, code: "INJ001", name: "IM Injection", price: 100, type: "procedure" },
    { id: 4, code: "INJ002", name: "IV Injection", price: 150, type: "procedure" },
    { id: 5, code: "DRESS001", name: "Small Dressing", price: 200, type: "procedure" },
    { id: 6, code: "DRESS002", name: "Large Dressing", price: 350, type: "procedure" },
    { id: 7, code: "LAB001", name: "Complete Blood Count", price: 300, type: "investigation" },
    { id: 8, code: "LAB002", name: "Blood Sugar", price: 150, type: "investigation" },
    { id: 9, code: "LAB003", name: "Lipid Profile", price: 600, type: "investigation" },
    { id: 10, code: "RAD001", name: "Chest X-Ray", price: 400, type: "investigation" },
  ]

  // Mock patients for quick search
  const patients = [
    { id: "P000123", name: "Rahul Sharma", age: 45, gender: "Male", phone: "9876543210" },
    { id: "P000456", name: "Priya Patel", age: 32, gender: "Female", phone: "9876543211" },
    { id: "P000789", name: "Mohammad Ali", age: 58, gender: "Male", phone: "9876543212" },
  ]

  // Filter services based on search term
  const filteredServices = services.filter(
    (service) =>
      service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.code.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Group services by type
  const consultations = filteredServices.filter((service) => service.type === "consultation")
  const procedures = filteredServices.filter((service) => service.type === "procedure")
  const investigations = filteredServices.filter((service) => service.type === "investigation")

  // Add item to bill
  const addToBill = (service: any) => {
    const existingItem = billItems.find((item) => item.id === service.id)

    if (existingItem) {
      setBillItems(
        billItems.map((item) =>
          item.id === service.id
            ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.price }
            : item,
        ),
      )
    } else {
      setBillItems([...billItems, { ...service, quantity: 1, total: service.price }])
    }
  }

  // Remove item from bill
  const removeFromBill = (id: number) => {
    setBillItems(billItems.filter((item) => item.id !== id))
  }

  // Update item quantity
  const updateQuantity = (id: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromBill(id)
      return
    }

    setBillItems(billItems.map((item) => (item.id === id ? { ...item, quantity, total: quantity * item.price } : item)))
  }

  // Calculate bill totals
  const subtotal = billItems.reduce((sum, item) => sum + item.total, 0)
  const tax = Math.round(subtotal * 0.05) // 5% tax for example
  const total = subtotal + tax

  // Select patient handler
  const selectPatient = (patient: any) => {
    setSelectedPatient(patient)
  }

  return (
    <PrivateRoute modulePath="admin/billing/quick" action="add">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Quick Bill</h1>
            <p className="text-gray-600 mt-1">Generate fast bills for walk-in patients and minor services</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Patient Info */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg">Patient Information</CardTitle>
                <CardDescription>Find or add a patient</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input placeholder="Search patient by name or ID..." className="pl-10" />
                  </div>

                  <div className="max-h-48 overflow-y-auto border rounded-md">
                    {patients.map((patient) => (
                      <div
                        key={patient.id}
                        className={`p-3 border-b cursor-pointer hover:bg-gray-50 ${selectedPatient?.id === patient.id ? "bg-gray-100" : ""}`}
                        onClick={() => selectPatient(patient)}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">{patient.name}</div>
                            <div className="text-sm text-gray-500">
                              {patient.id} • {patient.age} years • {patient.gender}
                            </div>
                          </div>
                          <div>
                            {selectedPatient?.id === patient.id && <Check className="h-5 w-5 text-green-500" />}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button className="w-full bg-transparent" variant="outline">
                    <User className="h-4 w-4 mr-2" />
                    Register New Patient
                  </Button>

                  <div className="border rounded-md p-4 bg-gray-50">
                    <h3 className="font-medium mb-2">Selected Patient</h3>
                    {selectedPatient ? (
                      <div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Name:</span>
                          <span className="font-medium">{selectedPatient.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">ID:</span>
                          <span>{selectedPatient.id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Age/Gender:</span>
                          <span>
                            {selectedPatient.age} / {selectedPatient.gender}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Contact:</span>
                          <span>{selectedPatient.phone}</span>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">No patient selected</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Payment Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="payment-mode">Payment Mode</Label>
                    <RadioGroup defaultValue="cash" className="mt-2 space-y-2">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="cash" id="payment-cash" />
                        <Label htmlFor="payment-cash">Cash</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="card" id="payment-card" />
                        <Label htmlFor="payment-card">Card</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="upi" id="payment-upi" />
                        <Label htmlFor="payment-upi">UPI</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <Label htmlFor="remarks">Remarks</Label>
                    <Input id="remarks" placeholder="Any additional remarks" className="mt-1" />
                  </div>

                  <div className="pt-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="print-receipt" />
                      <Label htmlFor="print-receipt">Print receipt</Label>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button className="w-full" disabled={!selectedPatient || billItems.length === 0}>
                      <CreditCard className="h-4 w-4 mr-2" />
                      Complete Payment
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Middle Column - Services */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Services</CardTitle>
                <CardDescription>Add services to bill</CardDescription>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search services..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Tabs defaultValue="consultations" className="w-full">
                  <TabsList className="w-full grid grid-cols-3">
                    <TabsTrigger value="consultations">Consultations</TabsTrigger>
                    <TabsTrigger value="procedures">Procedures</TabsTrigger>
                    <TabsTrigger value="investigations">Investigations</TabsTrigger>
                  </TabsList>

                  <TabsContent value="consultations">
                    <div className="max-h-[400px] overflow-y-auto">
                      {consultations.length > 0 ? (
                        consultations.map((service) => (
                          <div
                            key={service.id}
                            className="p-3 border-b hover:bg-gray-50 cursor-pointer flex justify-between items-center"
                            onClick={() => addToBill(service)}
                          >
                            <div>
                              <div className="font-medium">{service.name}</div>
                              <div className="text-xs text-gray-500">{service.code}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold">₹{service.price}</div>
                              <Button size="sm" variant="ghost" className="h-6 mt-1">
                                <Plus className="h-3.5 w-3.5 mr-1" />
                                Add
                              </Button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="p-4 text-center text-gray-500">No consultations match your search</div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="procedures">
                    <div className="max-h-[400px] overflow-y-auto">
                      {procedures.length > 0 ? (
                        procedures.map((service) => (
                          <div
                            key={service.id}
                            className="p-3 border-b hover:bg-gray-50 cursor-pointer flex justify-between items-center"
                            onClick={() => addToBill(service)}
                          >
                            <div>
                              <div className="font-medium">{service.name}</div>
                              <div className="text-xs text-gray-500">{service.code}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold">₹{service.price}</div>
                              <Button size="sm" variant="ghost" className="h-6 mt-1">
                                <Plus className="h-3.5 w-3.5 mr-1" />
                                Add
                              </Button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="p-4 text-center text-gray-500">No procedures match your search</div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="investigations">
                    <div className="max-h-[400px] overflow-y-auto">
                      {investigations.length > 0 ? (
                        investigations.map((service) => (
                          <div
                            key={service.id}
                            className="p-3 border-b hover:bg-gray-50 cursor-pointer flex justify-between items-center"
                            onClick={() => addToBill(service)}
                          >
                            <div>
                              <div className="font-medium">{service.name}</div>
                              <div className="text-xs text-gray-500">{service.code}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold">₹{service.price}</div>
                              <Button size="sm" variant="ghost" className="h-6 mt-1">
                                <Plus className="h-3.5 w-3.5 mr-1" />
                                Add
                              </Button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="p-4 text-center text-gray-500">No investigations match your search</div>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Bill */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex justify-between items-center">
                  <span>Bill</span>
                  <Button variant="outline" size="sm">
                    <Receipt className="h-4 w-4 mr-1" />
                    Preview
                  </Button>
                </CardTitle>
                <CardDescription>
                  {billItems.length === 0
                    ? "No items added yet"
                    : `${billItems.length} item${billItems.length !== 1 ? "s" : ""} in bill`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {billItems.length > 0 ? (
                    <div className="border rounded-md overflow-hidden">
                      <table className="min-w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Item</th>
                            <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Qty</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Price</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                            <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {billItems.map((item) => (
                            <tr key={item.id}>
                              <td className="px-4 py-2">
                                <div className="font-medium">{item.name}</div>
                                <div className="text-xs text-gray-500">{item.code}</div>
                              </td>
                              <td className="px-4 py-2">
                                <div className="flex items-center justify-center space-x-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-6 w-6 p-0 bg-transparent"
                                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                  >
                                    -
                                  </Button>
                                  <span>{item.quantity}</span>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-6 w-6 p-0 bg-transparent"
                                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                  >
                                    +
                                  </Button>
                                </div>
                              </td>
                              <td className="px-4 py-2 text-right">₹{item.price}</td>
                              <td className="px-4 py-2 text-right font-medium">₹{item.total}</td>
                              <td className="px-4 py-2 text-center">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-6 w-6 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => removeFromBill(item.id)}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="border rounded-md p-8 text-center text-gray-500">
                      <Receipt className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>Add services from the list to create a bill</p>
                    </div>
                  )}

                  {billItems.length > 0 && (
                    <div>
                      <div className="space-y-1 pt-4">
                        <div className="flex justify-between">
                          <span className="text-sm">Subtotal:</span>
                          <span className="font-medium">₹{subtotal.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Tax (5%):</span>
                          <span>₹{tax.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between border-t pt-2 mt-2">
                          <span className="font-medium">Total:</span>
                          <span className="font-bold text-lg">₹{total.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="mt-6 space-y-2">
                        <Button className="w-full" size="lg" disabled={!selectedPatient}>
                          Generate Bill
                        </Button>
                        <Button className="w-full bg-transparent" variant="outline">
                          <Printer className="h-4 w-4 mr-2" />
                          Print
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PrivateRoute>
  )
}

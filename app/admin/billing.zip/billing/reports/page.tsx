"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  TrendingUp,
  Download,
  Calendar,
  DollarSign,
  FileText,
  Users,
  CreditCard,
  Clock,
  Filter,
  Search,
} from "lucide-react"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"

const reportCategories = [
  {
    id: "revenue",
    name: "Revenue Reports",
    description: "Financial performance and revenue analysis",
    icon: DollarSign,
    reports: [
      { name: "Daily Revenue Report", description: "Daily revenue breakdown by department" },
      { name: "Monthly Revenue Summary", description: "Monthly revenue trends and comparisons" },
      { name: "Department-wise Revenue", description: "Revenue analysis by department" },
      { name: "Payment Mode Analysis", description: "Revenue breakdown by payment methods" },
    ],
  },
  {
    id: "billing",
    name: "Billing Reports",
    description: "Billing transactions and patterns",
    icon: FileText,
    reports: [
      { name: "Bill Summary Report", description: "Summary of all billing transactions" },
      { name: "Outstanding Bills", description: "Pending and overdue bill analysis" },
      { name: "Discount Analysis", description: "Discount usage and impact analysis" },
      { name: "Refund Report", description: "Refund transactions and reasons" },
    ],
  },
  {
    id: "patient",
    name: "Patient Reports",
    description: "Patient billing and payment patterns",
    icon: Users,
    reports: [
      { name: "Patient Billing History", description: "Individual patient billing records" },
      { name: "Insurance Claims Report", description: "Insurance claim status and processing" },
      { name: "Corporate Billing", description: "Corporate client billing summary" },
      { name: "Patient Payment Trends", description: "Patient payment behavior analysis" },
    ],
  },
  {
    id: "collections",
    name: "Collection Reports",
    description: "Payment collections and cash flow",
    icon: CreditCard,
    reports: [
      { name: "Daily Collections", description: "Daily cash and card collections" },
      { name: "Cashier Performance", description: "Individual cashier collection reports" },
      { name: "Collection Trends", description: "Collection patterns and trends" },
      { name: "Outstanding Collections", description: "Pending collection analysis" },
    ],
  },
]

const quickStats = [
  {
    title: "Today's Revenue",
    value: "₹1,25,000",
    change: "+12%",
    trend: "up",
    icon: DollarSign,
  },
  {
    title: "Bills Generated",
    value: "156",
    change: "+8%",
    trend: "up",
    icon: FileText,
  },
  {
    title: "Collections",
    value: "₹98,500",
    change: "+15%",
    trend: "up",
    icon: CreditCard,
  },
  {
    title: "Pending Bills",
    value: "23",
    change: "-5%",
    trend: "down",
    icon: Clock,
  },
]

export default function BillingReportsPage() {
  const [selectedCategory, setSelectedCategory] = useState("revenue")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedDateRange, setSelectedDateRange] = useState<any>(null)

  const handleGenerateReport = (reportName: string) => {
    console.log("Generating report:", reportName)
  }

  const handleExportReport = (reportName: string) => {
    console.log("Exporting report:", reportName)
  }

  const handleScheduleReport = (reportName: string) => {
    console.log("Scheduling report:", reportName)
  }

  return (
    <PrivateRoute modulePath="admin/billing/reports" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Billing Reports</h1>
            <p className="text-gray-600 mt-1">Generate and analyze billing and financial reports</p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <DatePickerWithRange />
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </Button>
            <Button>
              <Download className="h-4 w-4 mr-2" />
              Export All
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {quickStats.map((stat, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    <p
                      className={`text-sm flex items-center mt-1 ${
                        stat.trend === "up" ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {stat.change} from yesterday
                    </p>
                  </div>
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <stat.icon className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            {reportCategories.map((category) => (
              <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
                <category.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{category.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {reportCategories.map((category) => (
            <TabsContent key={category.id} value={category.id} className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <category.icon className="h-5 w-5" />
                        {category.name}
                      </CardTitle>
                      <CardDescription>{category.description}</CardDescription>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search reports..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {category.reports.map((report, index) => (
                      <Card key={index} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="font-semibold text-lg">{report.name}</h4>
                              <p className="text-sm text-gray-600 mt-1">{report.description}</p>
                            </div>
                            <Badge variant="outline">Available</Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button size="sm" onClick={() => handleGenerateReport(report.name)}>
                              <BarChart3 className="h-3 w-3 mr-1" />
                              Generate
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleExportReport(report.name)}>
                              <Download className="h-3 w-3 mr-1" />
                              Export
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleScheduleReport(report.name)}>
                              <Calendar className="h-3 w-3 mr-1" />
                              Schedule
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Sample Chart Placeholder */}
              <Card>
                <CardHeader>
                  <CardTitle>Sample {category.name} Analytics</CardTitle>
                  <CardDescription>Visual representation of {category.name.toLowerCase()}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500 border-2 border-dashed border-gray-200 rounded-lg">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 mx-auto mb-4" />
                      <p>Interactive charts and graphs will be displayed here</p>
                      <p className="text-sm mt-1">Select a report to view detailed analytics</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </PrivateRoute>
  )
}

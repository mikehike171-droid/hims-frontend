"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import {
  Receipt,
  Search,
  Download,
  Plus,
  Calendar,
  Printer,
  Filter,
  ArrowRightLeft,
  CreditCard,
  Users,
  Eye,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"

// Mock outpatient billing data
const billingEntries = [
  {
    id: "OP2405120001",
    patientId: "P000123",
    patientName: "Rahul Sharma",
    consultantName: "Dr. Anil Kumar",
    department: "General Medicine",
    billDate: "2024-05-12",
    billAmount: 1200,
    paidAmount: 1200,
    balanceAmount: 0,
    paymentStatus: "paid",
    billType: "consultation",
  },
  {
    id: "OP2405120002",
    patientId: "P000456",
    patientName: "Priya Patel",
    consultantName: "Dr. Neha Singh",
    department: "Dermatology",
    billDate: "2024-05-12",
    billAmount: 1500,
    paidAmount: 0,
    balanceAmount: 1500,
    paymentStatus: "pending",
    billType: "consultation",
  },
  {
    id: "OP2405120003",
    patientId: "P000789",
    patientName: "Mohammad Ali",
    consultantName: "Dr. Sanjay Desai",
    department: "Orthopedics",
    billDate: "2024-05-12",
    billAmount: 2200,
    paidAmount: 1000,
    balanceAmount: 1200,
    paymentStatus: "partial",
    billType: "procedure",
  },
  {
    id: "OP2405110001",
    patientId: "P000234",
    patientName: "Anjali Gupta",
    consultantName: "Dr. Meera Reddy",
    department: "Gynecology",
    billDate: "2024-05-11",
    billAmount: 1800,
    paidAmount: 1800,
    balanceAmount: 0,
    paymentStatus: "paid",
    billType: "consultation",
  },
  {
    id: "OP2405110002",
    patientId: "P000567",
    patientName: "Suresh Kumar",
    consultantName: "Dr. Vijay Mallya",
    department: "ENT",
    billDate: "2024-05-11",
    billAmount: 950,
    paidAmount: 950,
    balanceAmount: 0,
    paymentStatus: "paid",
    billType: "procedure",
  },
]

// Summary data
const summaryData = {
  totalBills: billingEntries.length,
  paidBills: billingEntries.filter((bill) => bill.paymentStatus === "paid").length,
  pendingBills: billingEntries.filter((bill) => bill.paymentStatus === "pending").length,
  totalAmount: billingEntries.reduce((sum, bill) => sum + bill.billAmount, 0),
  collectedAmount: billingEntries.reduce((sum, bill) => sum + bill.paidAmount, 0),
  pendingAmount: billingEntries.reduce((sum, bill) => sum + bill.balanceAmount, 0),
}

export default function OutpatientBilling() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [dateRange, setDateRange] = useState({})
  const [statusFilter, setStatusFilter] = useState("all")

  // Filter the billing entries based on search term and status filter
  const filteredEntries = billingEntries.filter((entry) => {
    const matchesSearch =
      entry.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.id.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || entry.paymentStatus === statusFilter

    return matchesSearch && matchesStatus
  })

  const handleNewBill = () => {
    router.push("/billing/quick")
  }

  const handleViewSchedule = () => {
    router.push("/queue")
  }

  const handleExport = () => {
    console.log("Exporting outpatient billing data...")
  }

  const handleViewBill = (billId: string) => {
    console.log("Viewing bill:", billId)
  }

  const handlePrintBill = (billId: string) => {
    console.log("Printing bill:", billId)
  }

  const handleCollectPayment = (billId: string) => {
    console.log("Collecting payment for bill:", billId)
  }

  return (
    <PrivateRoute modulePath="admin/billing/outpatient" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Outpatient Billing</h1>
            <p className="text-gray-600 mt-1">Manage outpatient consultations, procedures and investigations</p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <Button variant="outline" onClick={handleViewSchedule}>
              <Calendar className="h-4 w-4 mr-2" />
              View Schedule
            </Button>
            <Button variant="outline" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button onClick={handleNewBill}>
              <Plus className="h-4 w-4 mr-2" />
              New Bill
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Bills</CardTitle>
              <Receipt className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.totalBills}</div>
              <p className="text-xs text-muted-foreground">
                {summaryData.paidBills} paid, {summaryData.pendingBills} pending
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{summaryData.totalAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">From {summaryData.totalBills} bills</p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Collected</CardTitle>
              <ArrowRightLeft className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{summaryData.collectedAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((summaryData.collectedAmount / summaryData.totalAmount) * 100)}% of total
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{summaryData.pendingAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">From {summaryData.pendingBills} pending bills</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Billing Management</CardTitle>
            <CardDescription>Search and filter outpatient bills</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by patient name, ID or bill number..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <DatePickerWithRange className="w-full md:w-auto" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Printer className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Bills Table */}
        <Card>
          <CardHeader>
            <CardTitle>Outpatient Bills ({filteredEntries.length})</CardTitle>
            <CardDescription>Manage all outpatient billing</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 font-medium">Bill #</th>
                    <th className="text-left p-3 font-medium">Patient</th>
                    <th className="text-left p-3 font-medium">Consultant</th>
                    <th className="text-left p-3 font-medium">Department</th>
                    <th className="text-left p-3 font-medium">Bill Date</th>
                    <th className="text-left p-3 font-medium">Amount</th>
                    <th className="text-left p-3 font-medium">Status</th>
                    <th className="text-left p-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEntries.map((bill) => (
                    <tr key={bill.id} className="border-b hover:bg-gray-50 transition-colors">
                      <td className="p-3 font-medium">{bill.id}</td>
                      <td className="p-3">
                        <div>
                          <div className="font-medium">{bill.patientName}</div>
                          <div className="text-sm text-gray-500">{bill.patientId}</div>
                        </div>
                      </td>
                      <td className="p-3">{bill.consultantName}</td>
                      <td className="p-3">{bill.department}</td>
                      <td className="p-3">{bill.billDate}</td>
                      <td className="p-3 font-semibold">
                        <div>₹{bill.billAmount.toLocaleString()}</div>
                        {bill.balanceAmount > 0 && (
                          <div className="text-sm text-red-600">Balance: ₹{bill.balanceAmount.toLocaleString()}</div>
                        )}
                      </td>
                      <td className="p-3">
                        <Badge
                          variant={
                            bill.paymentStatus === "paid"
                              ? "default"
                              : bill.paymentStatus === "pending"
                                ? "destructive"
                                : "secondary"
                          }
                          className={
                            bill.paymentStatus === "paid"
                              ? "bg-green-100 text-green-800 hover:bg-green-100"
                              : bill.paymentStatus === "pending"
                                ? "bg-red-100 text-red-800 hover:bg-red-100"
                                : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                          }
                        >
                          {bill.paymentStatus === "paid"
                            ? "Paid"
                            : bill.paymentStatus === "pending"
                              ? "Pending"
                              : "Partial"}
                        </Badge>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center space-x-2">
                          <Button size="sm" variant="outline" onClick={() => handleViewBill(bill.id)}>
                            <Eye className="h-3 w-3 mr-1" />
                            View
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handlePrintBill(bill.id)}>
                            <Printer className="h-3 w-3 mr-1" />
                            Print
                          </Button>
                          {bill.paymentStatus !== "paid" && (
                            <Button size="sm" onClick={() => handleCollectPayment(bill.id)}>
                              <CreditCard className="h-3 w-3 mr-1" />
                              Collect
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PrivateRoute>
  )
}

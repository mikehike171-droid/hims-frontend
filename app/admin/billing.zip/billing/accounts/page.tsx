"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  PieChart,
  TrendingUp,
  TrendingDown,
  DollarSign,
  CreditCard,
  Wallet,
  FileText,
  Search,
  Download,
  Plus,
  Eye,
  Edit,
} from "lucide-react"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"

const accountSummary = {
  totalRevenue: 3250000,
  totalExpenses: 1850000,
  netProfit: 1400000,
  profitMargin: 43.08,
  accountsReceivable: 450000,
  accountsPayable: 280000,
  cashInHand: 125000,
  bankBalance: 2850000,
}

const recentTransactions = [
  {
    id: 1,
    date: "2024-01-15",
    description: "Patient Payment - OP/2024/001234",
    type: "credit",
    amount: 2500,
    category: "Revenue",
    status: "completed",
  },
  {
    id: 2,
    date: "2024-01-15",
    description: "Medical Equipment Purchase",
    type: "debit",
    amount: 45000,
    category: "Equipment",
    status: "completed",
  },
  {
    id: 3,
    date: "2024-01-15",
    description: "Staff Salary - January",
    type: "debit",
    amount: 125000,
    category: "Payroll",
    status: "pending",
  },
  {
    id: 4,
    date: "2024-01-14",
    description: "Insurance Claim Settlement",
    type: "credit",
    amount: 18000,
    category: "Insurance",
    status: "completed",
  },
]

const accountCategories = [
  {
    name: "Revenue Accounts",
    balance: 3250000,
    change: 12.5,
    trend: "up",
    accounts: [
      { name: "Patient Services Revenue", balance: 2800000, type: "credit" },
      { name: "Insurance Revenue", balance: 350000, type: "credit" },
      { name: "Other Revenue", balance: 100000, type: "credit" },
    ],
  },
  {
    name: "Expense Accounts",
    balance: 1850000,
    change: 8.3,
    trend: "up",
    accounts: [
      { name: "Staff Salaries", balance: 950000, type: "debit" },
      { name: "Medical Supplies", balance: 450000, type: "debit" },
      { name: "Equipment & Maintenance", balance: 280000, type: "debit" },
      { name: "Utilities", balance: 170000, type: "debit" },
    ],
  },
  {
    name: "Asset Accounts",
    balance: 5200000,
    change: 5.2,
    trend: "up",
    accounts: [
      { name: "Cash & Bank", balance: 2975000, type: "debit" },
      { name: "Medical Equipment", balance: 1800000, type: "debit" },
      { name: "Accounts Receivable", balance: 425000, type: "debit" },
    ],
  },
  {
    name: "Liability Accounts",
    balance: 680000,
    change: -3.1,
    trend: "down",
    accounts: [
      { name: "Accounts Payable", balance: 280000, type: "credit" },
      { name: "Accrued Expenses", balance: 150000, type: "credit" },
      { name: "Short-term Loans", balance: 250000, type: "credit" },
    ],
  },
]

export default function AccountsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [selectedDateRange, setSelectedDateRange] = useState<any>(null)

  const handleExport = () => {
    console.log("Exporting accounts data")
  }

  const handleViewTransaction = (id: number) => {
    console.log("Viewing transaction:", id)
  }

  const handleEditTransaction = (id: number) => {
    console.log("Editing transaction:", id)
  }

  return (
    <PrivateRoute modulePath="admin/billing/accounts" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Accounts</h1>
            <p className="text-gray-600 mt-1">Financial accounts and transaction management</p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <DatePickerWithRange />
            <Button variant="outline" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Transaction
            </Button>
          </div>
        </div>

        {/* Account Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-2xl font-bold text-green-600">₹{accountSummary.totalRevenue.toLocaleString()}</p>
                  <p className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +12.5% this month
                  </p>
                </div>
                <div className="p-3 bg-green-100 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Expenses</p>
                  <p className="text-2xl font-bold text-red-600">₹{accountSummary.totalExpenses.toLocaleString()}</p>
                  <p className="text-sm text-red-600 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +8.3% this month
                  </p>
                </div>
                <div className="p-3 bg-red-100 rounded-lg">
                  <TrendingDown className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Net Profit</p>
                  <p className="text-2xl font-bold text-blue-600">₹{accountSummary.netProfit.toLocaleString()}</p>
                  <p className="text-sm text-blue-600 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {accountSummary.profitMargin}% margin
                  </p>
                </div>
                <div className="p-3 bg-blue-100 rounded-lg">
                  <DollarSign className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Cash Balance</p>
                  <p className="text-2xl font-bold text-purple-600">₹{accountSummary.bankBalance.toLocaleString()}</p>
                  <p className="text-sm text-purple-600 flex items-center mt-1">
                    <Wallet className="h-3 w-3 mr-1" />
                    Available funds
                  </p>
                </div>
                <div className="p-3 bg-purple-100 rounded-lg">
                  <Wallet className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Account Balances</CardTitle>
                  <CardDescription>Current balance overview</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-green-100 rounded-lg">
                          <CreditCard className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">Accounts Receivable</p>
                          <p className="text-sm text-gray-600">Outstanding payments</p>
                        </div>
                      </div>
                      <span className="font-semibold text-green-600">
                        ₹{accountSummary.accountsReceivable.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-red-100 rounded-lg">
                          <FileText className="h-4 w-4 text-red-600" />
                        </div>
                        <div>
                          <p className="font-medium">Accounts Payable</p>
                          <p className="text-sm text-gray-600">Outstanding bills</p>
                        </div>
                      </div>
                      <span className="font-semibold text-red-600">
                        ₹{accountSummary.accountsPayable.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <Wallet className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium">Cash in Hand</p>
                          <p className="text-sm text-gray-600">Physical cash</p>
                        </div>
                      </div>
                      <span className="font-semibold text-blue-600">₹{accountSummary.cashInHand.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Financial Overview</CardTitle>
                  <CardDescription>Key financial metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500 border-2 border-dashed border-gray-200 rounded-lg">
                    <div className="text-center">
                      <PieChart className="h-12 w-12 mx-auto mb-4" />
                      <p>Financial charts and graphs will be displayed here</p>
                      <p className="text-sm mt-1">Revenue vs Expenses breakdown</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Recent Transactions</CardTitle>
                    <CardDescription>Latest financial transactions</CardDescription>
                  </div>
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search transactions..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-full sm:w-64"
                      />
                    </div>
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger className="w-full sm:w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="credit">Credit</SelectItem>
                        <SelectItem value="debit">Debit</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="w-full sm:w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3 font-medium">Date</th>
                        <th className="text-left p-3 font-medium">Description</th>
                        <th className="text-left p-3 font-medium">Category</th>
                        <th className="text-left p-3 font-medium">Type</th>
                        <th className="text-left p-3 font-medium">Amount</th>
                        <th className="text-left p-3 font-medium">Status</th>
                        <th className="text-left p-3 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentTransactions.map((transaction) => (
                        <tr key={transaction.id} className="border-b hover:bg-gray-50 transition-colors">
                          <td className="p-3">{transaction.date}</td>
                          <td className="p-3 font-medium">{transaction.description}</td>
                          <td className="p-3">{transaction.category}</td>
                          <td className="p-3">
                            <Badge
                              variant={transaction.type === "credit" ? "default" : "secondary"}
                              className={
                                transaction.type === "credit"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : "bg-red-100 text-red-800 hover:bg-red-100"
                              }
                            >
                              {transaction.type === "credit" ? "Credit" : "Debit"}
                            </Badge>
                          </td>
                          <td className="p-3 font-semibold">
                            <span className={transaction.type === "credit" ? "text-green-600" : "text-red-600"}>
                              {transaction.type === "credit" ? "+" : "-"}₹{transaction.amount.toLocaleString()}
                            </span>
                          </td>
                          <td className="p-3">
                            <Badge
                              variant={transaction.status === "completed" ? "default" : "secondary"}
                              className={
                                transaction.status === "completed"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                              }
                            >
                              {transaction.status}
                            </Badge>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline" onClick={() => handleViewTransaction(transaction.id)}>
                                <Eye className="h-3 w-3" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleEditTransaction(transaction.id)}>
                                <Edit className="h-3 w-3" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="categories" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {accountCategories.map((category, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{category.name}</CardTitle>
                      <Badge variant="outline" className={category.trend === "up" ? "text-green-600" : "text-red-600"}>
                        {category.trend === "up" ? "+" : ""}
                        {category.change}%
                      </Badge>
                    </div>
                    <CardDescription>Total Balance: ₹{category.balance.toLocaleString()}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {category.accounts.map((account, accountIndex) => (
                        <div key={accountIndex} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                          <span className="text-sm font-medium">{account.name}</span>
                          <span className="text-sm font-semibold">₹{account.balance.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue vs Expenses</CardTitle>
                  <CardDescription>Monthly comparison</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500 border-2 border-dashed border-gray-200 rounded-lg">
                    <div className="text-center">
                      <TrendingUp className="h-12 w-12 mx-auto mb-4" />
                      <p>Revenue vs Expenses chart will be displayed here</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Cash Flow Analysis</CardTitle>
                  <CardDescription>Monthly cash flow trends</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500 border-2 border-dashed border-gray-200 rounded-lg">
                    <div className="text-center">
                      <PieChart className="h-12 w-12 mx-auto mb-4" />
                      <p>Cash flow analytics will be displayed here</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PrivateRoute>
  )
}

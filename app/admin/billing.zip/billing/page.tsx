"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Receipt,
  FileText,
  Calculator,
  Shield,
  Wallet,
  TrendingUp,
  DollarSign,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  BarChart3,
  PieChart,
  Search,
  Download,
  Plus,
  Eye,
  Edit,
  CreditCard,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import Link from "next/link"
import { useRouter } from "next/navigation"

// Mock data for demonstration
const dashboardStats = {
  todayRevenue: 125000,
  monthlyRevenue: 3250000,
  pendingBills: 45,
  overduePayments: 12,
  cashCollections: 85000,
  cardCollections: 40000,
  insuranceClaims: 25,
  averageBillValue: 2800,
}

const recentBills = [
  {
    id: 1,
    billNumber: "OP/2024/001234",
    patientName: "Rajesh Kumar",
    patientId: "P001234",
    amount: 2500,
    status: "paid",
    paymentMode: "card",
    billDate: "2024-01-15",
    department: "Cardiology",
  },
  {
    id: 2,
    billNumber: "IP/2024/000567",
    patientName: "Priya Sharma",
    patientId: "P005678",
    amount: 15000,
    status: "pending",
    paymentMode: "insurance",
    billDate: "2024-01-15",
    department: "Surgery",
  },
  {
    id: 3,
    billNumber: "OP/2024/001235",
    patientName: "Amit Singh",
    patientId: "P009876",
    amount: 800,
    status: "partial",
    paymentMode: "cash",
    billDate: "2024-01-15",
    department: "General Medicine",
  },
]

const pendingApprovals = [
  {
    id: 1,
    type: "discount",
    amount: 500,
    reason: "Senior Citizen Discount",
    requestedBy: "Dr. Sharma",
    patientName: "Ram Prasad",
    billNumber: "OP/2024/001236",
  },
  {
    id: 2,
    type: "refund",
    amount: 1200,
    reason: "Cancelled Procedure",
    requestedBy: "Nurse Priya",
    patientName: "Sunita Devi",
    billNumber: "IP/2024/000568",
  },
]

export default function BillingDashboard() {
  const router = useRouter()
  const [selectedDateRange, setSelectedDateRange] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")

  const handleQuickBill = () => {
    router.push("/billing/quick")
  }

  const handleExport = () => {
    // Export functionality
    console.log("Exporting data...")
  }

  const handleViewBill = (billId: number) => {
    console.log("Viewing bill:", billId)
  }

  const handleEditBill = (billId: number) => {
    console.log("Editing bill:", billId)
  }

  const handleApproval = (approvalId: number, action: "approve" | "reject") => {
    console.log(`${action} approval:`, approvalId)
  }

  return (
    <PrivateRoute modulePath="admin/billing" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Billing & Accounts</h1>
            <p className="text-gray-600 mt-1">Comprehensive billing and financial management</p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <DatePickerWithRange />
            <Button variant="outline" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button onClick={handleQuickBill}>
              <Plus className="h-4 w-4 mr-2" />
              Quick Bill
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{dashboardStats.todayRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                +12% from yesterday
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{dashboardStats.monthlyRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                +8% from last month
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Bills</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{dashboardStats.pendingBills}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <AlertTriangle className="h-3 w-3 mr-1 text-orange-500" />
                {dashboardStats.overduePayments} overdue
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Bill Value</CardTitle>
              <Calculator className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{dashboardStats.averageBillValue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                +5% from last week
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Link href="/billing/outpatient">
            <Card className="hover:shadow-md transition-all cursor-pointer hover:scale-105">
              <CardContent className="flex items-center p-6">
                <div className="p-3 bg-blue-100 rounded-lg mr-4">
                  <Receipt className="h-8 w-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">OP Billing</h3>
                  <p className="text-sm text-gray-600">Outpatient billing</p>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/billing/inpatient">
            <Card className="hover:shadow-md transition-all cursor-pointer hover:scale-105">
              <CardContent className="flex items-center p-6">
                <div className="p-3 bg-green-100 rounded-lg mr-4">
                  <FileText className="h-8 w-8 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">IP Billing</h3>
                  <p className="text-sm text-gray-600">Inpatient billing</p>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/billing/insurance">
            <Card className="hover:shadow-md transition-all cursor-pointer hover:scale-105">
              <CardContent className="flex items-center p-6">
                <div className="p-3 bg-purple-100 rounded-lg mr-4">
                  <Shield className="h-8 w-8 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Insurance</h3>
                  <p className="text-sm text-gray-600">Claims & TPA</p>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/billing/cashier">
            <Card className="hover:shadow-md transition-all cursor-pointer hover:scale-105">
              <CardContent className="flex items-center p-6">
                <div className="p-3 bg-orange-100 rounded-lg mr-4">
                  <Wallet className="h-8 w-8 text-orange-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Cashiering</h3>
                  <p className="text-sm text-gray-600">Collections & shifts</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        <Tabs defaultValue="recent-bills" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="recent-bills">Recent Bills</TabsTrigger>
            <TabsTrigger value="pending-approvals">Pending Approvals</TabsTrigger>
            <TabsTrigger value="collections">Collections</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="recent-bills" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Recent Bills</CardTitle>
                    <CardDescription>Latest billing transactions</CardDescription>
                  </div>
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search bills..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-full sm:w-64"
                      />
                    </div>
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="w-full sm:w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="partial">Partial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3 font-medium">Bill Number</th>
                        <th className="text-left p-3 font-medium">Patient</th>
                        <th className="text-left p-3 font-medium">Department</th>
                        <th className="text-left p-3 font-medium">Amount</th>
                        <th className="text-left p-3 font-medium">Status</th>
                        <th className="text-left p-3 font-medium">Payment Mode</th>
                        <th className="text-left p-3 font-medium">Date</th>
                        <th className="text-left p-3 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentBills.map((bill) => (
                        <tr key={bill.id} className="border-b hover:bg-gray-50 transition-colors">
                          <td className="p-3 font-medium">{bill.billNumber}</td>
                          <td className="p-3">
                            <div>
                              <div className="font-medium">{bill.patientName}</div>
                              <div className="text-sm text-gray-500">{bill.patientId}</div>
                            </div>
                          </td>
                          <td className="p-3">{bill.department}</td>
                          <td className="p-3 font-semibold">₹{bill.amount.toLocaleString()}</td>
                          <td className="p-3">
                            <Badge
                              variant={
                                bill.status === "paid"
                                  ? "default"
                                  : bill.status === "pending"
                                    ? "destructive"
                                    : "secondary"
                              }
                              className={
                                bill.status === "paid"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : bill.status === "pending"
                                    ? "bg-red-100 text-red-800 hover:bg-red-100"
                                    : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                              }
                            >
                              {bill.status === "paid" && <CheckCircle className="h-3 w-3 mr-1" />}
                              {bill.status === "pending" && <Clock className="h-3 w-3 mr-1" />}
                              {bill.status === "partial" && <AlertTriangle className="h-3 w-3 mr-1" />}
                              {bill.status.charAt(0).toUpperCase() + bill.status.slice(1)}
                            </Badge>
                          </td>
                          <td className="p-3 capitalize">{bill.paymentMode}</td>
                          <td className="p-3">{bill.billDate}</td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline" onClick={() => handleViewBill(bill.id)}>
                                <Eye className="h-3 w-3" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleEditBill(bill.id)}>
                                <Edit className="h-3 w-3" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pending-approvals" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Approvals</CardTitle>
                <CardDescription>Items requiring approval</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingApprovals.map((approval) => (
                    <div
                      key={approval.id}
                      className="flex flex-col lg:flex-row lg:items-center justify-between p-4 border rounded-lg gap-4"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <AlertTriangle className="h-6 w-6 text-yellow-600" />
                        </div>
                        <div>
                          <h4 className="font-semibold capitalize">{approval.type} Request</h4>
                          <p className="text-sm text-gray-600">
                            {approval.patientName} - {approval.billNumber}
                          </p>
                          <p className="text-sm text-gray-500">
                            Requested by: {approval.requestedBy} | Amount: ₹{approval.amount}
                          </p>
                          <p className="text-sm text-gray-500">Reason: {approval.reason}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button size="sm" variant="outline" onClick={() => handleApproval(approval.id, "reject")}>
                          <XCircle className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                        <Button size="sm" onClick={() => handleApproval(approval.id, "approve")}>
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="collections" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Wallet className="h-5 w-5 mr-2 text-green-600" />
                    Cash Collections
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    ₹{dashboardStats.cashCollections.toLocaleString()}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Today's cash collection</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <CreditCard className="h-5 w-5 mr-2 text-blue-600" />
                    Card Collections
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">
                    ₹{dashboardStats.cardCollections.toLocaleString()}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Today's card collection</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Shield className="h-5 w-5 mr-2 text-purple-600" />
                    Insurance Claims
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">{dashboardStats.insuranceClaims}</div>
                  <p className="text-sm text-gray-600 mt-1">Pending claims</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex flex-col items-center justify-center text-gray-500">
                    <BarChart3 className="h-16 w-16 mb-4" />
                    <p>Revenue analytics chart will be displayed here</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Payment Mode Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex flex-col items-center justify-center text-gray-500">
                    <PieChart className="h-16 w-16 mb-4" />
                    <p>Payment mode distribution chart will be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PrivateRoute>
  )
}

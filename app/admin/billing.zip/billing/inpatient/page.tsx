"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import {
  Search,
  Download,
  Plus,
  Calendar,
  Printer,
  Filter,
  ArrowRightLeft,
  CreditCard,
  BarChart,
  Bed,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock inpatient billing data
const admittedPatients = [
  {
    id: "IP2405001",
    patientId: "P000123",
    patientName: "Rahul Sharma",
    admissionDate: "2024-05-01",
    room: "301A",
    roomType: "Single Room",
    consultant: "Dr. Anil Kumar",
    department: "General Medicine",
    insuranceProvider: null,
    currentBill: 24500,
    advancePaid: 10000,
    runningBalance: 14500,
    status: "active",
  },
  {
    id: "IP2405002",
    patientId: "P000456",
    patientName: "Priya Patel",
    admissionDate: "2024-05-03",
    room: "402B",
    roomType: "Deluxe Room",
    consultant: "Dr. Suresh Mehta",
    department: "Cardiology",
    insuranceProvider: "Star Health",
    currentBill: 45000,
    advancePaid: 15000,
    runningBalance: 30000,
    status: "active",
  },
  {
    id: "IP2405003",
    patientId: "P000789",
    patientName: "Mohammad Ali",
    admissionDate: "2024-05-05",
    room: "203C",
    roomType: "Twin Sharing",
    consultant: "Dr. Sanjay Desai",
    department: "Orthopedics",
    insuranceProvider: null,
    currentBill: 18500,
    advancePaid: 5000,
    runningBalance: 13500,
    status: "active",
  },
]

const dischargedPatients = [
  {
    id: "IP2404001",
    patientId: "P000234",
    patientName: "Anjali Gupta",
    admissionDate: "2024-04-25",
    dischargeDate: "2024-05-02",
    room: "305A",
    roomType: "Single Room",
    consultant: "Dr. Meera Reddy",
    department: "Gynecology",
    insuranceProvider: "ICICI Lombard",
    finalBill: 38500,
    paidAmount: 38500,
    balance: 0,
    paymentStatus: "paid",
  },
  {
    id: "IP2404002",
    patientId: "P000567",
    patientName: "Suresh Kumar",
    admissionDate: "2024-04-27",
    dischargeDate: "2024-05-04",
    room: "204C",
    roomType: "Twin Sharing",
    consultant: "Dr. Vijay Mallya",
    department: "ENT",
    insuranceProvider: null,
    finalBill: 22500,
    paidAmount: 20000,
    balance: 2500,
    paymentStatus: "partial",
  },
]

// Summary data
const summaryData = {
  totalAdmitted: admittedPatients.length,
  totalCurrentBill: admittedPatients.reduce((sum, patient) => sum + patient.currentBill, 0),
  totalAdvance: admittedPatients.reduce((sum, patient) => sum + patient.advancePaid, 0),
  totalRunningBalance: admittedPatients.reduce((sum, patient) => sum + patient.runningBalance, 0),
  dischargedCount: dischargedPatients.length,
  totalDischargedBill: dischargedPatients.reduce((sum, patient) => sum + patient.finalBill, 0),
  pendingDischargeBalance: dischargedPatients.reduce((sum, patient) => sum + patient.balance, 0),
}

export default function InpatientBilling() {
  const [searchTerm, setSearchTerm] = useState("")
  const [dateRange, setDateRange] = useState({})
  const [insuranceFilter, setInsuranceFilter] = useState("all")

  // Filter admitted patients based on search term and insurance filter
  const filteredAdmitted = admittedPatients.filter((patient) => {
    const matchesSearch =
      patient.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.id.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesInsurance =
      insuranceFilter === "all" ||
      (insuranceFilter === "insured" && patient.insuranceProvider) ||
      (insuranceFilter === "non-insured" && !patient.insuranceProvider)

    return matchesSearch && matchesInsurance
  })

  // Filter discharged patients based on search term and insurance filter
  const filteredDischarged = dischargedPatients.filter((patient) => {
    const matchesSearch =
      patient.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.id.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesInsurance =
      insuranceFilter === "all" ||
      (insuranceFilter === "insured" && patient.insuranceProvider) ||
      (insuranceFilter === "non-insured" && !patient.insuranceProvider)

    return matchesSearch && matchesInsurance
  })

  return (
    <PrivateRoute modulePath="admin/billing/inpatient" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Inpatient Billing</h1>
            <p className="text-gray-600 mt-1">Manage admitted patients, interim and final bills</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              View All
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Interim Bill
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Admitted Patients</CardTitle>
              <Bed className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.totalAdmitted}</div>
              <p className="text-xs text-muted-foreground">Active inpatients</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Current Bill Value</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{summaryData.totalCurrentBill.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Running total of all patients</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Advance Collected</CardTitle>
              <ArrowRightLeft className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{summaryData.totalAdvance.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((summaryData.totalAdvance / summaryData.totalCurrentBill) * 100)}% of current bill
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Running Balance</CardTitle>
              <BarChart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{summaryData.totalRunningBalance.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Current unpaid balance</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Inpatient Billing Management</CardTitle>
            <CardDescription>Search and filter inpatient bills</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by patient name, ID or bill number..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <DatePickerWithRange className="w-full md:w-auto" />
              <Select value={insuranceFilter} onValueChange={setInsuranceFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Insurance Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Patients</SelectItem>
                  <SelectItem value="insured">Insured</SelectItem>
                  <SelectItem value="non-insured">Non-Insured</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Printer className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs for Admitted and Discharged Patients */}
        <Tabs defaultValue="admitted" className="space-y-4">
          <TabsList>
            <TabsTrigger value="admitted">Admitted Patients</TabsTrigger>
            <TabsTrigger value="discharged">Discharged Patients</TabsTrigger>
          </TabsList>

          {/* Admitted Patients Tab */}
          <TabsContent value="admitted" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Current Inpatients ({filteredAdmitted.length})</CardTitle>
                <CardDescription>Manage billing for admitted patients</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">IP #</th>
                        <th className="text-left p-3">Patient</th>
                        <th className="text-left p-3">Room</th>
                        <th className="text-left p-3">Admission Date</th>
                        <th className="text-left p-3">Consultant</th>
                        <th className="text-left p-3">Current Bill</th>
                        <th className="text-left p-3">Advance</th>
                        <th className="text-left p-3">Balance</th>
                        <th className="text-left p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredAdmitted.map((patient) => (
                        <tr key={patient.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{patient.id}</td>
                          <td className="p-3">
                            <div>
                              <div className="font-medium">{patient.patientName}</div>
                              <div className="text-sm text-gray-500">{patient.patientId}</div>
                              {patient.insuranceProvider && (
                                <Badge variant="outline" className="mt-1">
                                  {patient.insuranceProvider}
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="p-3">
                            <div>{patient.room}</div>
                            <div className="text-sm text-gray-500">{patient.roomType}</div>
                          </td>
                          <td className="p-3">{patient.admissionDate}</td>
                          <td className="p-3">
                            <div>{patient.consultant}</div>
                            <div className="text-sm text-gray-500">{patient.department}</div>
                          </td>
                          <td className="p-3 font-semibold">₹{patient.currentBill.toLocaleString()}</td>
                          <td className="p-3">₹{patient.advancePaid.toLocaleString()}</td>
                          <td className="p-3 font-medium text-red-600">₹{patient.runningBalance.toLocaleString()}</td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline">
                                View
                              </Button>
                              <Button size="sm">Generate Bill</Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Discharged Patients Tab */}
          <TabsContent value="discharged" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recently Discharged ({filteredDischarged.length})</CardTitle>
                <CardDescription>Final bills and payment status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">IP #</th>
                        <th className="text-left p-3">Patient</th>
                        <th className="text-left p-3">Admission</th>
                        <th className="text-left p-3">Discharge</th>
                        <th className="text-left p-3">Room</th>
                        <th className="text-left p-3">Final Bill</th>
                        <th className="text-left p-3">Status</th>
                        <th className="text-left p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredDischarged.map((patient) => (
                        <tr key={patient.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{patient.id}</td>
                          <td className="p-3">
                            <div>
                              <div className="font-medium">{patient.patientName}</div>
                              <div className="text-sm text-gray-500">{patient.patientId}</div>
                              {patient.insuranceProvider && (
                                <Badge variant="outline" className="mt-1">
                                  {patient.insuranceProvider}
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="p-3">{patient.admissionDate}</td>
                          <td className="p-3">{patient.dischargeDate}</td>
                          <td className="p-3">
                            <div>{patient.room}</div>
                            <div className="text-sm text-gray-500">{patient.roomType}</div>
                          </td>
                          <td className="p-3 font-semibold">
                            <div>₹{patient.finalBill.toLocaleString()}</div>
                            {patient.balance > 0 && (
                              <div className="text-sm text-red-600">Balance: ₹{patient.balance.toLocaleString()}</div>
                            )}
                          </td>
                          <td className="p-3">
                            <Badge
                              variant={patient.paymentStatus === "paid" ? "success" : "warning"}
                              className={
                                patient.paymentStatus === "paid"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                              }
                            >
                              {patient.paymentStatus === "paid" ? "Paid" : "Partial"}
                            </Badge>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="outline">
                                View
                              </Button>
                              <Button size="sm" variant="outline">
                                Print
                              </Button>
                              {patient.balance > 0 && <Button size="sm">Collect</Button>}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PrivateRoute>
  )
}

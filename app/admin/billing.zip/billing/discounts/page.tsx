"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { TrendingDown, Plus, Search, Edit, Trash2, Copy, Download, Upload, MoreHorizontal, Percent } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const discountRules = [
  {
    id: 1,
    name: "Senior Citizen Discount",
    description: "Discount for patients above 60 years",
    type: "percentage",
    value: 10,
    minAmount: 1000,
    maxDiscount: 500,
    applicableOn: "all",
    status: "active",
    validFrom: "2024-01-01",
    validTo: "2024-12-31",
    usageCount: 245,
    createdBy: "Admin",
  },
  {
    id: 2,
    name: "Emergency Discount",
    description: "Special discount for emergency cases",
    type: "fixed",
    value: 200,
    minAmount: 500,
    maxDiscount: 200,
    applicableOn: "emergency",
    status: "active",
    validFrom: "2024-01-01",
    validTo: "2024-12-31",
    usageCount: 89,
    createdBy: "Dr. Sharma",
  },
  {
    id: 3,
    name: "Staff Discount",
    description: "Discount for hospital staff and family",
    type: "percentage",
    value: 25,
    minAmount: 0,
    maxDiscount: 2000,
    applicableOn: "all",
    status: "active",
    validFrom: "2024-01-01",
    validTo: "2024-12-31",
    usageCount: 156,
    createdBy: "HR Manager",
  },
]

export default function DiscountRulesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterType, setFilterType] = useState("all")
  const [selectedRule, setSelectedRule] = useState<any>(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  const handleCreateRule = () => {
    setIsCreateDialogOpen(true)
  }

  const handleEditRule = (rule: any) => {
    setSelectedRule(rule)
    setIsEditDialogOpen(true)
  }

  const handleDeleteRule = (id: number) => {
    console.log("Deleting discount rule:", id)
  }

  const handleDuplicateRule = (id: number) => {
    console.log("Duplicating discount rule:", id)
  }

  const handleExport = () => {
    console.log("Exporting discount rules")
  }

  const handleImport = () => {
    console.log("Importing discount rules")
  }

  return (
    <PrivateRoute modulePath="admin/billing/discounts" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Discount Rules</h1>
            <p className="text-gray-600 mt-1">Manage discount policies and rules</p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <Button variant="outline" onClick={handleImport}>
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
            <Button variant="outline" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button onClick={handleCreateRule}>
              <Plus className="h-4 w-4 mr-2" />
              Create Rule
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search discount rules..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full lg:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full lg:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="percentage">Percentage</SelectItem>
                  <SelectItem value="fixed">Fixed Amount</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Discount Rules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {discountRules.map((rule) => (
            <Card key={rule.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{rule.name}</CardTitle>
                    <CardDescription className="mt-1">{rule.description}</CardDescription>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEditRule(rule)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDuplicateRule(rule.id)}>
                        <Copy className="h-4 w-4 mr-2" />
                        Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDeleteRule(rule.id)} className="text-red-600">
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Type</span>
                    <Badge variant="outline" className="capitalize">
                      {rule.type === "percentage" ? (
                        <>
                          <Percent className="h-3 w-3 mr-1" />
                          Percentage
                        </>
                      ) : (
                        <>
                          <TrendingDown className="h-3 w-3 mr-1" />
                          Fixed
                        </>
                      )}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Value</span>
                    <span className="font-semibold">
                      {rule.type === "percentage" ? `${rule.value}%` : `₹${rule.value}`}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Min Amount</span>
                    <span className="text-sm">₹{rule.minAmount}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Max Discount</span>
                    <span className="text-sm">₹{rule.maxDiscount}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Applicable On</span>
                    <Badge variant="secondary" className="capitalize">
                      {rule.applicableOn}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Usage Count</span>
                    <span className="text-sm font-medium">{rule.usageCount}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Status</span>
                    <Badge variant={rule.status === "active" ? "default" : "secondary"}>{rule.status}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Valid Period</span>
                    <span className="text-xs">
                      {rule.validFrom} to {rule.validTo}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Create Discount Rule Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Create New Discount Rule</DialogTitle>
              <DialogDescription>Create a new discount rule for billing.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Rule Name</Label>
                <Input id="name" placeholder="Enter rule name" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" placeholder="Enter rule description" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="type">Discount Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Percentage</SelectItem>
                      <SelectItem value="fixed">Fixed Amount</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="value">Discount Value</Label>
                  <Input id="value" type="number" placeholder="Enter value" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="min-amount">Minimum Amount</Label>
                  <Input id="min-amount" type="number" placeholder="0" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="max-discount">Maximum Discount</Label>
                  <Input id="max-discount" type="number" placeholder="0" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="applicable-on">Applicable On</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select applicability" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Services</SelectItem>
                    <SelectItem value="consultation">Consultation Only</SelectItem>
                    <SelectItem value="laboratory">Laboratory Only</SelectItem>
                    <SelectItem value="emergency">Emergency Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="valid-from">Valid From</Label>
                  <Input id="valid-from" type="date" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="valid-to">Valid To</Label>
                  <Input id="valid-to" type="date" />
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="active" />
                <Label htmlFor="active">Active</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsCreateDialogOpen(false)}>Create Rule</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Discount Rule Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Edit Discount Rule</DialogTitle>
              <DialogDescription>Update the discount rule details.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name">Rule Name</Label>
                <Input id="edit-name" defaultValue={selectedRule?.name} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-description">Description</Label>
                <Textarea id="edit-description" defaultValue={selectedRule?.description} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-type">Discount Type</Label>
                  <Select defaultValue={selectedRule?.type}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Percentage</SelectItem>
                      <SelectItem value="fixed">Fixed Amount</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-value">Discount Value</Label>
                  <Input id="edit-value" type="number" defaultValue={selectedRule?.value} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-min-amount">Minimum Amount</Label>
                  <Input id="edit-min-amount" type="number" defaultValue={selectedRule?.minAmount} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-max-discount">Maximum Discount</Label>
                  <Input id="edit-max-discount" type="number" defaultValue={selectedRule?.maxDiscount} />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-applicable-on">Applicable On</Label>
                <Select defaultValue={selectedRule?.applicableOn}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Services</SelectItem>
                    <SelectItem value="consultation">Consultation Only</SelectItem>
                    <SelectItem value="laboratory">Laboratory Only</SelectItem>
                    <SelectItem value="emergency">Emergency Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-valid-from">Valid From</Label>
                  <Input id="edit-valid-from" type="date" defaultValue={selectedRule?.validFrom} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-valid-to">Valid To</Label>
                  <Input id="edit-valid-to" type="date" defaultValue={selectedRule?.validTo} />
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="edit-active" defaultChecked={selectedRule?.status === "active"} />
                <Label htmlFor="edit-active">Active</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsEditDialogOpen(false)}>Update Rule</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </PrivateRoute>
  )
}

"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings, CreditCard, FileText, Bell, Shield, Printer, Save, RefreshCw } from "lucide-react"

export default function BillingSettingsPage() {
  const [settings, setSettings] = useState({
    // General Settings
    hospitalName: "Pranam Hospital",
    hospitalAddress: "123 Medical Street, Healthcare City",
    taxNumber: "GST123456789",
    currency: "INR",

    // Billing Settings
    billPrefix: "BILL",
    billNumberFormat: "YYYY/MM/NNNN",
    autoGenerateBill: true,
    requireApprovalForDiscount: true,
    maxDiscountPercent: 25,

    // Payment Settings
    acceptCash: true,
    acceptCard: true,
    acceptUPI: true,
    acceptCheque: true,

    // Notification Settings
    emailNotifications: true,
    smsNotifications: false,
    billDueReminders: true,
    paymentConfirmations: true,

    // Print Settings
    printBillAfterGeneration: true,
    printReceiptAfterPayment: true,
    printerName: "Default Printer",

    // Tax Settings
    enableGST: true,
    gstRate: 18,
    enableCess: false,
    cessRate: 0,
  })

  const handleSave = () => {
    console.log("Saving settings:", settings)
  }

  const handleReset = () => {
    console.log("Resetting settings to default")
  }

  const updateSetting = (key: string, value: any) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <PrivateRoute modulePath="admin/billing/settings" action="edit">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Billing Settings</h1>
            <p className="text-gray-600 mt-1">Configure billing system preferences and options</p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <Button variant="outline" onClick={handleReset}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset to Default
            </Button>
            <Button onClick={handleSave}>
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </Button>
          </div>
        </div>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="payment">Payment</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="printing">Printing</TabsTrigger>
            <TabsTrigger value="tax">Tax</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  General Settings
                </CardTitle>
                <CardDescription>Basic hospital and system information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="hospital-name">Hospital Name</Label>
                    <Input
                      id="hospital-name"
                      value={settings.hospitalName}
                      onChange={(e) => updateSetting("hospitalName", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tax-number">Tax Number (GST)</Label>
                    <Input
                      id="tax-number"
                      value={settings.taxNumber}
                      onChange={(e) => updateSetting("taxNumber", e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hospital-address">Hospital Address</Label>
                  <Textarea
                    id="hospital-address"
                    value={settings.hospitalAddress}
                    onChange={(e) => updateSetting("hospitalAddress", e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select value={settings.currency} onValueChange={(value) => updateSetting("currency", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="INR">Indian Rupee (₹)</SelectItem>
                      <SelectItem value="USD">US Dollar ($)</SelectItem>
                      <SelectItem value="EUR">Euro (€)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Billing Configuration
                </CardTitle>
                <CardDescription>Configure billing number formats and rules</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bill-prefix">Bill Number Prefix</Label>
                    <Input
                      id="bill-prefix"
                      value={settings.billPrefix}
                      onChange={(e) => updateSetting("billPrefix", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bill-format">Bill Number Format</Label>
                    <Input
                      id="bill-format"
                      value={settings.billNumberFormat}
                      onChange={(e) => updateSetting("billNumberFormat", e.target.value)}
                      placeholder="YYYY/MM/NNNN"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max-discount">Maximum Discount Percentage</Label>
                  <Input
                    id="max-discount"
                    type="number"
                    value={settings.maxDiscountPercent}
                    onChange={(e) => updateSetting("maxDiscountPercent", Number.parseInt(e.target.value))}
                    min="0"
                    max="100"
                  />
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Auto Generate Bill</Label>
                      <p className="text-sm text-gray-600">Automatically generate bill after service completion</p>
                    </div>
                    <Switch
                      checked={settings.autoGenerateBill}
                      onCheckedChange={(checked) => updateSetting("autoGenerateBill", checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Require Approval for Discount</Label>
                      <p className="text-sm text-gray-600">Require manager approval for discounts</p>
                    </div>
                    <Switch
                      checked={settings.requireApprovalForDiscount}
                      onCheckedChange={(checked) => updateSetting("requireApprovalForDiscount", checked)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Methods
                </CardTitle>
                <CardDescription>Configure accepted payment methods</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Accept Cash Payments</Label>
                        <p className="text-sm text-gray-600">Allow cash payments</p>
                      </div>
                      <Switch
                        checked={settings.acceptCash}
                        onCheckedChange={(checked) => updateSetting("acceptCash", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Accept Card Payments</Label>
                        <p className="text-sm text-gray-600">Allow credit/debit card payments</p>
                      </div>
                      <Switch
                        checked={settings.acceptCard}
                        onCheckedChange={(checked) => updateSetting("acceptCard", checked)}
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Accept UPI Payments</Label>
                        <p className="text-sm text-gray-600">Allow UPI/digital payments</p>
                      </div>
                      <Switch
                        checked={settings.acceptUPI}
                        onCheckedChange={(checked) => updateSetting("acceptUPI", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Accept Cheque Payments</Label>
                        <p className="text-sm text-gray-600">Allow cheque payments</p>
                      </div>
                      <Switch
                        checked={settings.acceptCheque}
                        onCheckedChange={(checked) => updateSetting("acceptCheque", checked)}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Notification Settings
                </CardTitle>
                <CardDescription>Configure notification preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Email Notifications</Label>
                        <p className="text-sm text-gray-600">Send notifications via email</p>
                      </div>
                      <Switch
                        checked={settings.emailNotifications}
                        onCheckedChange={(checked) => updateSetting("emailNotifications", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>SMS Notifications</Label>
                        <p className="text-sm text-gray-600">Send notifications via SMS</p>
                      </div>
                      <Switch
                        checked={settings.smsNotifications}
                        onCheckedChange={(checked) => updateSetting("smsNotifications", checked)}
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Bill Due Reminders</Label>
                        <p className="text-sm text-gray-600">Send reminders for due bills</p>
                      </div>
                      <Switch
                        checked={settings.billDueReminders}
                        onCheckedChange={(checked) => updateSetting("billDueReminders", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Payment Confirmations</Label>
                        <p className="text-sm text-gray-600">Send payment confirmation messages</p>
                      </div>
                      <Switch
                        checked={settings.paymentConfirmations}
                        onCheckedChange={(checked) => updateSetting("paymentConfirmations", checked)}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="printing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Printer className="h-5 w-5" />
                  Printing Settings
                </CardTitle>
                <CardDescription>Configure printing preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="printer-name">Default Printer</Label>
                  <Select value={settings.printerName} onValueChange={(value) => updateSetting("printerName", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Default Printer">Default Printer</SelectItem>
                      <SelectItem value="HP LaserJet">HP LaserJet</SelectItem>
                      <SelectItem value="Canon Printer">Canon Printer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Print Bill After Generation</Label>
                      <p className="text-sm text-gray-600">Automatically print bills when generated</p>
                    </div>
                    <Switch
                      checked={settings.printBillAfterGeneration}
                      onCheckedChange={(checked) => updateSetting("printBillAfterGeneration", checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Print Receipt After Payment</Label>
                      <p className="text-sm text-gray-600">Automatically print receipts after payment</p>
                    </div>
                    <Switch
                      checked={settings.printReceiptAfterPayment}
                      onCheckedChange={(checked) => updateSetting("printReceiptAfterPayment", checked)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tax" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Tax Configuration
                </CardTitle>
                <CardDescription>Configure tax rates and settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Enable GST</Label>
                      <p className="text-sm text-gray-600">Apply GST to bills</p>
                    </div>
                    <Switch
                      checked={settings.enableGST}
                      onCheckedChange={(checked) => updateSetting("enableGST", checked)}
                    />
                  </div>
                  {settings.enableGST && (
                    <div className="space-y-2">
                      <Label htmlFor="gst-rate">GST Rate (%)</Label>
                      <Input
                        id="gst-rate"
                        type="number"
                        value={settings.gstRate}
                        onChange={(e) => updateSetting("gstRate", Number.parseFloat(e.target.value))}
                        min="0"
                        max="100"
                        step="0.1"
                      />
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Enable Cess</Label>
                      <p className="text-sm text-gray-600">Apply additional cess</p>
                    </div>
                    <Switch
                      checked={settings.enableCess}
                      onCheckedChange={(checked) => updateSetting("enableCess", checked)}
                    />
                  </div>
                  {settings.enableCess && (
                    <div className="space-y-2">
                      <Label htmlFor="cess-rate">Cess Rate (%)</Label>
                      <Input
                        id="cess-rate"
                        type="number"
                        value={settings.cessRate}
                        onChange={(e) => updateSetting("cessRate", Number.parseFloat(e.target.value))}
                        min="0"
                        max="100"
                        step="0.1"
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PrivateRoute>
  )
}

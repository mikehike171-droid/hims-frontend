"use client"

import { useState } from "react"
import PrivateRoute from "@/components/auth/PrivateRoute"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Search, Edit, Trash2, Eye, Download, Upload, FileText, Tag, Building, Activity } from "lucide-react"
import { Switch } from "@/components/ui/switch"

// Mock data for services
const mockServices = [
  {
    id: 1,
    serviceCode: "CONS001",
    serviceName: "General Consultation",
    department: "General Medicine",
    category: "consultation",
    baseRate: 500,
    doctorShare: 60,
    taxSlab: "GST 0%",
    unit: "each",
    isActive: true,
    hsnSacCode: "998314",
  },
  {
    id: 2,
    serviceCode: "CONS002",
    serviceName: "Specialist Consultation",
    department: "Cardiology",
    category: "consultation",
    baseRate: 800,
    doctorShare: 65,
    taxSlab: "GST 0%",
    unit: "each",
    isActive: true,
    hsnSacCode: "998314",
  },
  {
    id: 3,
    serviceCode: "LAB001",
    serviceName: "Complete Blood Count",
    department: "Laboratory",
    category: "investigation",
    baseRate: 300,
    doctorShare: 0,
    taxSlab: "GST 5%",
    unit: "each",
    isActive: true,
    hsnSacCode: "998211",
  },
  {
    id: 4,
    serviceCode: "RAD001",
    serviceName: "Chest X-Ray",
    department: "Radiology",
    category: "investigation",
    baseRate: 400,
    doctorShare: 0,
    taxSlab: "GST 5%",
    unit: "each",
    isActive: true,
    hsnSacCode: "998211",
  },
  {
    id: 5,
    serviceCode: "PROC001",
    serviceName: "Minor Surgery",
    department: "Surgery",
    category: "procedure",
    baseRate: 5000,
    doctorShare: 40,
    taxSlab: "GST 12%",
    unit: "each",
    isActive: true,
    hsnSacCode: "998314",
  },
]

const departments = [
  "General Medicine",
  "Cardiology",
  "Surgery",
  "Laboratory",
  "Radiology",
  "Orthopedics",
  "Pediatrics",
  "Gynecology",
]

const categories = ["consultation", "procedure", "investigation", "pharmacy", "room", "consumables", "equipment"]

const taxSlabs = ["GST 0%", "GST 5%", "GST 12%", "GST 18%", "GST 28%"]

const units = ["each", "hour", "day", "ml", "mg", "gm", "kg", "liter"]

export default function ServiceMaster() {
  const [services, setServices] = useState(mockServices)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterCategory, setFilterCategory] = useState("all")
  const [filterDepartment, setFilterDepartment] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingService, setEditingService] = useState<any>(null)
  const [newService, setNewService] = useState({
    serviceCode: "",
    serviceName: "",
    department: "",
    category: "",
    subCategory: "",
    description: "",
    baseRate: "",
    doctorShare: "",
    taxSlab: "",
    unit: "each",
    hsnSacCode: "",
    isPackageInclusion: false,
    isActive: true,
  })

  const filteredServices = services.filter((service) => {
    const matchesSearch =
      service.serviceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.serviceCode.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = filterCategory === "all" || service.category === filterCategory
    const matchesDepartment = filterDepartment === "all" || service.department === filterDepartment

    return matchesSearch && matchesCategory && matchesDepartment
  })

  const handleAddService = () => {
    const service = {
      id: services.length + 1,
      ...newService,
      baseRate: Number.parseFloat(newService.baseRate) || 0,
      doctorShare: Number.parseFloat(newService.doctorShare) || 0,
    }
    setServices([...services, service])
    setNewService({
      serviceCode: "",
      serviceName: "",
      department: "",
      category: "",
      subCategory: "",
      description: "",
      baseRate: "",
      doctorShare: "",
      taxSlab: "",
      unit: "each",
      hsnSacCode: "",
      isPackageInclusion: false,
      isActive: true,
    })
    setIsAddDialogOpen(false)
  }

  const handleEditService = (service: any) => {
    setEditingService(service)
    setNewService({
      serviceCode: service.serviceCode,
      serviceName: service.serviceName,
      department: service.department,
      category: service.category,
      subCategory: service.subCategory || "",
      description: service.description || "",
      baseRate: service.baseRate.toString(),
      doctorShare: service.doctorShare.toString(),
      taxSlab: service.taxSlab,
      unit: service.unit,
      hsnSacCode: service.hsnSacCode,
      isPackageInclusion: service.isPackageInclusion || false,
      isActive: service.isActive,
    })
    setIsAddDialogOpen(true)
  }

  const handleUpdateService = () => {
    if (editingService) {
      const updatedServices = services.map((service) =>
        service.id === editingService.id
          ? {
              ...service,
              ...newService,
              baseRate: Number.parseFloat(newService.baseRate) || 0,
              doctorShare: Number.parseFloat(newService.doctorShare) || 0,
            }
          : service,
      )
      setServices(updatedServices)
      setEditingService(null)
      setNewService({
        serviceCode: "",
        serviceName: "",
        department: "",
        category: "",
        subCategory: "",
        description: "",
        baseRate: "",
        doctorShare: "",
        taxSlab: "",
        unit: "each",
        hsnSacCode: "",
        isPackageInclusion: false,
        isActive: true,
      })
      setIsAddDialogOpen(false)
    }
  }

  const handleDeleteService = (id: number) => {
    setServices(services.filter((service) => service.id !== id))
  }

  const toggleServiceStatus = (id: number) => {
    setServices(services.map((service) => (service.id === id ? { ...service, isActive: !service.isActive } : service)))
  }

  return (
    <PrivateRoute modulePath="admin/billing/services" action="view">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Service Master</h1>
            <p className="text-gray-600 mt-1">Manage hospital services, pricing, and configurations</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Service
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingService ? "Edit Service" : "Add New Service"}</DialogTitle>
                  <DialogDescription>
                    {editingService ? "Update service details" : "Create a new service in the system"}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="serviceCode">Service Code *</Label>
                    <Input
                      id="serviceCode"
                      value={newService.serviceCode}
                      onChange={(e) => setNewService({ ...newService, serviceCode: e.target.value })}
                      placeholder="e.g., CONS001"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="serviceName">Service Name *</Label>
                    <Input
                      id="serviceName"
                      value={newService.serviceName}
                      onChange={(e) => setNewService({ ...newService, serviceName: e.target.value })}
                      placeholder="e.g., General Consultation"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">Department *</Label>
                    <Select
                      value={newService.department}
                      onValueChange={(value) => setNewService({ ...newService, department: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept} value={dept}>
                            {dept}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select
                      value={newService.category}
                      onValueChange={(value) => setNewService({ ...newService, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subCategory">Sub Category</Label>
                    <Input
                      id="subCategory"
                      value={newService.subCategory}
                      onChange={(e) => setNewService({ ...newService, subCategory: e.target.value })}
                      placeholder="e.g., Cardiology Consultation"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="baseRate">Base Rate (₹) *</Label>
                    <Input
                      id="baseRate"
                      type="number"
                      value={newService.baseRate}
                      onChange={(e) => setNewService({ ...newService, baseRate: e.target.value })}
                      placeholder="0.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="doctorShare">Doctor Share (%)</Label>
                    <Input
                      id="doctorShare"
                      type="number"
                      value={newService.doctorShare}
                      onChange={(e) => setNewService({ ...newService, doctorShare: e.target.value })}
                      placeholder="0.00"
                      max="100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="taxSlab">Tax Slab</Label>
                    <Select
                      value={newService.taxSlab}
                      onValueChange={(value) => setNewService({ ...newService, taxSlab: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select tax slab" />
                      </SelectTrigger>
                      <SelectContent>
                        {taxSlabs.map((slab) => (
                          <SelectItem key={slab} value={slab}>
                            {slab}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Unit</Label>
                    <Select
                      value={newService.unit}
                      onValueChange={(value) => setNewService({ ...newService, unit: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {units.map((unit) => (
                          <SelectItem key={unit} value={unit}>
                            {unit}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hsnSacCode">HSN/SAC Code</Label>
                    <Input
                      id="hsnSacCode"
                      value={newService.hsnSacCode}
                      onChange={(e) => setNewService({ ...newService, hsnSacCode: e.target.value })}
                      placeholder="e.g., 998314"
                    />
                  </div>
                  <div className="col-span-2 space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newService.description}
                      onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                      placeholder="Service description..."
                      rows={3}
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="isPackageInclusion"
                      checked={newService.isPackageInclusion}
                      onCheckedChange={(checked) => setNewService({ ...newService, isPackageInclusion: checked })}
                    />
                    <Label htmlFor="isPackageInclusion">Package Inclusion</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="isActive"
                      checked={newService.isActive}
                      onCheckedChange={(checked) => setNewService({ ...newService, isActive: checked })}
                    />
                    <Label htmlFor="isActive">Active</Label>
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsAddDialogOpen(false)
                      setEditingService(null)
                      setNewService({
                        serviceCode: "",
                        serviceName: "",
                        department: "",
                        category: "",
                        subCategory: "",
                        description: "",
                        baseRate: "",
                        doctorShare: "",
                        taxSlab: "",
                        unit: "each",
                        hsnSacCode: "",
                        isPackageInclusion: false,
                        isActive: true,
                      })
                    }}
                  >
                    Cancel
                  </Button>
                  <Button onClick={editingService ? handleUpdateService : handleAddService}>
                    {editingService ? "Update Service" : "Add Service"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Services</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{services.length}</div>
              <p className="text-xs text-muted-foreground">{services.filter((s) => s.isActive).length} active</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Consultations</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{services.filter((s) => s.category === "consultation").length}</div>
              <p className="text-xs text-muted-foreground">Consultation services</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Procedures</CardTitle>
              <Tag className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{services.filter((s) => s.category === "procedure").length}</div>
              <p className="text-xs text-muted-foreground">Procedure services</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Investigations</CardTitle>
              <Building className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{services.filter((s) => s.category === "investigation").length}</div>
              <p className="text-xs text-muted-foreground">Investigation services</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Service Management</CardTitle>
            <CardDescription>Search and filter services</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search services..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Services Table */}
        <Card>
          <CardHeader>
            <CardTitle>Services ({filteredServices.length})</CardTitle>
            <CardDescription>Manage your service catalog</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3">Service Code</th>
                    <th className="text-left p-3">Service Name</th>
                    <th className="text-left p-3">Department</th>
                    <th className="text-left p-3">Category</th>
                    <th className="text-left p-3">Base Rate</th>
                    <th className="text-left p-3">Doctor Share</th>
                    <th className="text-left p-3">Tax Slab</th>
                    <th className="text-left p-3">Status</th>
                    <th className="text-left p-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredServices.map((service) => (
                    <tr key={service.id} className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">{service.serviceCode}</td>
                      <td className="p-3">
                        <div>
                          <div className="font-medium">{service.serviceName}</div>
                          <div className="text-sm text-gray-500">HSN: {service.hsnSacCode}</div>
                        </div>
                      </td>
                      <td className="p-3">{service.department}</td>
                      <td className="p-3">
                        <Badge variant="outline">
                          {service.category.charAt(0).toUpperCase() + service.category.slice(1)}
                        </Badge>
                      </td>
                      <td className="p-3 font-semibold">₹{service.baseRate.toLocaleString()}</td>
                      <td className="p-3">{service.doctorShare}%</td>
                      <td className="p-3">{service.taxSlab}</td>
                      <td className="p-3">
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={service.isActive}
                            onCheckedChange={() => toggleServiceStatus(service.id)}
                            size="sm"
                          />
                          <Badge variant={service.isActive ? "default" : "secondary"}>
                            {service.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center space-x-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleEditService(service)}>
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleDeleteService(service.id)}>
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PrivateRoute>
  )
}
